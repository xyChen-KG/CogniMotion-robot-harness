"""Generate an operator-owned eight-task registry, never launch a model or simulation."""
import argparse
import hashlib
import json
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project-root', type=Path, required=True)
    p.add_argument('--libero-root', type=Path, required=True)
    p.add_argument('--sim-python', type=Path, required=True)
    p.add_argument('--intern-socket', type=Path)
    p.add_argument('--intern-manifest', type=Path)
    p.add_argument('--atomic-port', type=int, default=18321)
    p.add_argument('--render-gpu', type=int, default=0)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    if bool(a.intern_socket) != bool(a.intern_manifest):
        p.error('Supply both InternW0 socket and prompt manifest, or neither')
    if not 1 <= a.atomic_port <= 65535 or a.render_gpu < 0:
        p.error('Invalid port or render GPU')
    root, libero = a.project_root.resolve(), a.libero_root.resolve()
    harness = root / 'harnesses/starHarness_Libero'
    core = list(harness.glob('*.py'))
    rows = []
    for family in ('same', 'mixed', 'same_perturb', 'mixed_perturb'):
        for length in ('five_stage', 'eight_stage'):
            task = root / 'benchmarks/custom_long' / family / length
            table = json.loads((task / 'stage_table.json').read_text())
            spec = json.loads((task / 'task.json').read_text())
            files = core + [task / n for n in ('task.py', 'task.json', 'task.bddl', 'stage_table.json')]
            files.append(task / spec['initial_state'])
            policies = {'atomic': {'atomic_port': a.atomic_port, 'atomic_replan_steps': 10}}
            if a.intern_manifest:
                manifest = a.intern_manifest.resolve()
                prompt = json.loads(manifest.read_text())
                entries = {e['instruction']: e for e in prompt['prompts']}
                for stage in table['stages']:
                    if stage['instruction'] not in entries:
                        p.error('Missing exact InternW0 instruction encoding')
                    context = Path(entries[stage['instruction']]['context_file'])
                    if digest(context) != entries[stage['instruction']]['sha256']:
                        p.error('InternW0 context hash differs')
                    files.append(context)
                files.append(manifest)
                policies['internw0'] = {'intern_socket': str(a.intern_socket.resolve()),
                                       'prompt_manifest': str(manifest)}
            rows.append({'id': family + '_' + length, 'title': family + '/' + length,
                'python': str(a.sim_python.resolve()), 'entrypoint': str(task / 'task.py'),
                'task_table': str(task / 'stage_table.json'), 'cwd': str(task),
                'env': {'PYTHONPATH': str(root / 'harnesses') + ':' + str(libero / 'repo'),
                    'LIBERO_CONFIG_PATH': str(libero / 'configs/standard'),
                    'MUJOCO_GL': 'egl', 'PYOPENGL_PLATFORM': 'egl',
                    'PYTHONDONTWRITEBYTECODE': '1', 'TOKENIZERS_PARALLELISM': 'false',
                    'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1',
                    'ROBOT_PREVIEW_FPS': '8'},
                'allowed_seeds': [table['task']['seed']], 'policies': policies,
                'sha256': {str(f): digest(f) for f in set(files)},
                'render_gpu': a.render_gpu, 'settling_steps': 10})
    a.output.parent.mkdir(parents=True, exist_ok=True)
    with a.output.open('x') as f:
        json.dump({'version': 1, 'tasks': rows}, f, indent=2, ensure_ascii=False)
        f.write('\n')
    print(json.dumps({'tasks': len(rows), 'simulation_started': False, 'models_loaded': False}))


if __name__ == '__main__':
    main()
