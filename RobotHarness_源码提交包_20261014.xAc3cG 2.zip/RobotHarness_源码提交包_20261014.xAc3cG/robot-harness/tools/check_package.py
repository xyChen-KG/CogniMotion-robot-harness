"""Offline submission audit. Never import model/simulator packages."""
import ast
import hashlib
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / 'MANIFEST.json').read_text())
bad = []
for row in manifest['files']:
    p = root / row['path']
    if not p.is_file() or p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest() != row['sha256']:
        bad.append(row['path'] + ': hash')
        continue
    if p.suffix == '.npy':
        if not p.read_bytes().startswith(b'\x93NUMPY'):
            bad.append(row['path'] + ': invalid numpy header')
        continue
    text = p.read_text(encoding='utf-8')
    private_markers = r'/Users/[A-Za-z0-9._-]+/|/data[01]/|\b' + 'lamda' + '5090' + r'\b|\bGPU-[a-fA-F0-9]{8}-'
    if re.search(private_markers, text):
        bad.append(row['path'] + ': private deployment marker')
    if re.search(r'\b(?:sk-[A-Za-z0-9_-]{20,}|hf_[A-Za-z0-9]{24,}|gh[pousr]_[A-Za-z0-9]{30,}|AKIA[A-Z0-9]{16})\b', text):
        bad.append(row['path'] + ': credential-like literal')
    if '-----BEGIN ' in text and re.search(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----', text):
        bad.append(row['path'] + ': private key')
    if p.suffix == '.py':
        try:
            ast.parse(text, filename=row['path'])
        except SyntaxError:
            bad.append(row['path'] + ': syntax')
    if p.suffix == '.json':
        try:
            json.loads(text)
        except ValueError:
            bad.append(row['path'] + ': JSON')
print(json.dumps({'passed': not bad, 'checked_files': len(manifest['files']), 'issues': bad,
                  'models_loaded': False, 'simulation_started': False}, ensure_ascii=False))
raise SystemExit(bool(bad))
