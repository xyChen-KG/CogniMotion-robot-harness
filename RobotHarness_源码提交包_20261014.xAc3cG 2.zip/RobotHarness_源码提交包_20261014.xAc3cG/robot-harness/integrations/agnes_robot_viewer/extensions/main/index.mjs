import { createReader, createSceneController } from './backend.mjs';
import {registerPlanning} from './planning.mjs';

export function createRuntime(readerFactory=createReader,controllerFactory=createSceneController) {return {
  inject:['extension'],
  apply(ctx) {
    const read = readerFactory();
    const control = controllerFactory();
    registerPlanning(ctx.extension(),read);
    const run = {type: 'string', pattern: '^run_[a-f0-9]{32}$'};
    ctx.services.register({
      name: 'robot.tasks', kind: 'query', timeoutMs: 30000, maxResultBytes: 524288,
      inputSchema: {type: 'object', properties: {}, additionalProperties: false},
      outputSchema: {type: 'object', additionalProperties: true},
      handler(input, context) { return read('tasks', input, context?.signal); }
    });
    ctx.services.register({
      name: 'robot.observation', kind: 'query', timeoutMs: 30000, maxResultBytes: 1048576,
      inputSchema: {type: 'object', properties: {run_id: {anyOf: [run, {type: 'null'}]}}, additionalProperties: false},
      outputSchema: {type: 'object', additionalProperties: true},
      handler(input, context) { return read('observation', input, context?.signal); }
    });
    ctx.services.register({
      name: 'robot.replay.chunk', kind: 'query', timeoutMs: 30000, maxResultBytes: 1048576,
      inputSchema: {type: 'object', properties: {run_id: run, offset: {type: 'integer', minimum: 0, maximum: 67108864}}, required: ['run_id', 'offset'], additionalProperties: false},
      outputSchema: {type: 'object', additionalProperties: true},
      handler(input, context) { return read('replay_chunk', input, context?.signal); }
    });
    const id = {type:'string',pattern:'^[A-Za-z0-9_-]{1,128}$'};
    ctx.services.register({
      name:'robot.scene',kind:'query',timeoutMs:30000,maxResultBytes:1048576,
      inputSchema:{type:'object',properties:{},additionalProperties:false},
      outputSchema:{type:'object',additionalProperties:true},
      handler(input,context){return read('scene',input,context?.signal);}
    });
    ctx.services.register({
      name:'robot.scene.open',kind:'effect',timeoutMs:30000,maxResultBytes:524288,
      inputSchema:{type:'object',properties:{task_id:{type:'string',pattern:'^[A-Za-z0-9._-]{1,128}$'},
        policy:{type:'string',enum:['atomic','internw0']},seed:{type:'integer',minimum:0,maximum:2147483647},request_id:id},
        required:['task_id','policy','seed','request_id'],additionalProperties:false},
      outputSchema:{type:'object',additionalProperties:true},
      handler(input,context){return control('open',input,context);}
    });
    ctx.services.register({
      name:'robot.scene.command',kind:'effect',timeoutMs:30000,maxResultBytes:524288,
      inputSchema:{type:'object',properties:{scene_id:{type:'string',pattern:'^scene_[a-f0-9]{32}$'},
        operation:{type:'string',enum:['execute','execute_plan','stop','reset','close']},revision:{type:'integer',minimum:1},
        plan:{type:'object',properties:{planning_request_id:{type:'string',pattern:'^plan_[a-f0-9]{32}$'},
          goal:{type:'string',minLength:1,maxLength:2000},scene_step:{type:'integer',minimum:0},
          stage_ids:{type:'array',items:{type:'integer',minimum:1,maximum:32},minItems:1,maxItems:32,uniqueItems:true}},
          required:['planning_request_id','goal','scene_step','stage_ids'],additionalProperties:false},
        stage_id:{type:'integer',minimum:1,maximum:32},request_id:id},
        required:['scene_id','operation','revision','request_id'],additionalProperties:false},
      outputSchema:{type:'object',additionalProperties:true},
      handler(input,context){return control('command',input,context);}
    });
    ctx.services.register({
      name:'robot.scene.replay.chunk',kind:'query',timeoutMs:30000,maxResultBytes:1048576,
      inputSchema:{type:'object',properties:{scene_id:{type:'string',pattern:'^scene_[a-f0-9]{32}$'},
        command_id:{type:'string',pattern:'^cmd_[a-f0-9]{32}$'},offset:{type:'integer',minimum:0,maximum:67108864}},
        required:['scene_id','command_id','offset'],additionalProperties:false},
      outputSchema:{type:'object',additionalProperties:true},
      handler(input,context){return read('scene_replay_chunk',input,context?.signal);}
    });
  }
};}
export const runtime=createRuntime();
