import {createElement as h,useEffect,useRef,useState} from 'react';
import {planningPrompt,planReceipt,executablePlan,PLAN} from './plan-state.mjs';
import {readSessionProjection,sessionIsBusy} from './session-projection.mjs';

export function PlanPanel({ctx,sessionId,scene,task,blocked,onExecute}) {
  const [goal,setGoal]=useState(''),[intent,setIntent]=useState(null),[proposal,setProposal]=useState(null);
  const [error,setError]=useState(''),[sending,setSending]=useState(false),[modelBusy,setModelBusy]=useState(false);
  const [includeImage,setIncludeImage]=useState(false);
  const [queued,setQueued]=useState(null),[finishedWithoutPlan,setFinishedWithoutPlan]=useState(false);
  const timeline=useRef(null),currentIntent=useRef(null),lock=useRef(false),epoch=useRef(0);
  const key='rh-scene-plan:'+sessionId;
  useEffect(()=>{
    const generation=++epoch.current;let live=true;
    setGoal('');setProposal(null);setError('');setSending(false);setIncludeImage(false);lock.current=false;
    let saved=null;try{saved=JSON.parse(localStorage.getItem(key));}catch{}
    if(!PLAN.test(saved?.planning_request_id || '') || saved.session_id!==sessionId)saved=null;
    currentIntent.current=saved;setIntent(saved);if(saved){setGoal(saved.goal);setIncludeImage(saved.include_image===true);}
    async function refresh(){
      try{const response=await readSessionProjection(ctx);
        if(!live || generation!==epoch.current || response.status!=='available')return;
        timeline.current=response.value;setModelBusy(sessionIsBusy(response.value));
        const plan=planReceipt(response.value,currentIntent.current);setProposal(plan);
        const id=currentIntent.current?.planning_request_id;
        setQueued(id?(response.value.pendingInputs || []).find(p=>p.preview?.includes(id)) || null:null);
        setFinishedWithoutPlan(!!id && !plan && !sessionIsBusy(response.value) &&
          (response.value.nodes || []).some(n=>n.kind==='assistant' && !n.streaming && n.seq>currentIntent.current.before_seq));
      }catch{if(live)setError('会话规划回执暂不可读取；不会自动重发。');}
    }
    const off=ctx.session.projection.subscribe(refresh);void refresh();
    return()=>{live=false;epoch.current++;off();};
  },[ctx,sessionId]);
  async function generate(){
    if(lock.current || sending || modelBusy || intent || blocked)return;
    const handle=ctx.session.handle;
    if(handle?.id!==sessionId){setError('当前会话绑定不可用，请刷新或重新选择 Agnes 会话。');return;}
    if(!goal.trim() || goal.length>2000)return;
    lock.current=true;setSending(true);setError('');const generation=epoch.current;
    const value={session_id:sessionId,planning_request_id:'plan_'+crypto.randomUUID().replaceAll('-',''),
      goal:goal.trim(),include_image:includeImage,scene_id:scene.scene_id,revision:scene.revision,scene_step:scene.steps,before_seq:timeline.current?.upto || 0};
    try{
      // Cache identity BEFORE the official SDK request; never resend on reload/disconnect.
      localStorage.setItem(key,JSON.stringify(value));currentIntent.current=value;setIntent(value);setProposal(null);
      await handle.followUp(planningPrompt(value),{commandId:value.planning_request_id});
    }catch{if(generation===epoch.current)setError('规划提交未确认。请查看 Agnes 对话，勿连续重发；机器人未因规划而执行。');}
    finally{if(generation===epoch.current){lock.current=false;setSending(false);}}
  }
  const ready=executablePlan(proposal,scene,task);
  const execution=(scene?.commands || []).find(c=>c.planning_request_id===proposal?.planning_request_id && !!proposal);
  const supported=scene?.plan_protocol===1;
  return h('section',{className:'rh-plan-panel','aria-label':'大模型阶段规划'},
    h('h4',null,'大模型阶段规划'),
    h('p',{className:'rh-note'},'使用当前 Agnes 会话的模型。先生成并查看计划，再确认执行；VLA 自动按阶段推进。'),
    !supported && scene?.status==='idle' && h('p',{className:'rh-error'},'此场景在功能更新前打开，请先关闭并重新打开场景。'),
    h('label',null,'长时程指令',h('textarea',{'aria-label':'长时程指令',rows:4,maxLength:2000,value:goal,
      placeholder:'例如：把奶酪放到黑碗上，把酒瓶放到柜子上，然后打开中间抽屉。',
      disabled:sending||!!intent,onChange:e=>setGoal(e.target.value)})),
    h('label',null,h('input',{type:'checkbox',checked:includeImage,disabled:sending||!!intent,
      onChange:e=>setIncludeImage(e.target.checked)}),'发送当前场景图片（需支持图片的模型）'),
    h('p',{className:'rh-note'},'默认只根据登记技能表分解指令，不进行视觉判断，也不会另调用一个视觉大模型。'),
    h('button',{type:'button',disabled:blocked||!supported||scene?.status!=='idle'||!goal.trim()||sending||modelBusy||!!intent,
      onClick:generate},sending?'正在提交规划…':'生成阶段计划'),
    error && h('p',{role:'status',className:'rh-error'},error),
    intent && !proposal && h('p',{role:'status',className:finishedWithoutPlan?'rh-error':'rh-note'},
      finishedWithoutPlan?'本轮已结束但没有有效阶段表，请查看聊天原因；机器人未因规划执行。':
      queued?'规划消息已在会话队列中，尚未开始；不会重新提交。':'等待真实规划工具回执；不会自动重试。'),
    queued && h('button',{type:'button',disabled:modelBusy||sending||blocked||typeof ctx.session.handle?.sendNow!=='function',
      onClick:async()=>{if(lock.current)return;lock.current=true;setSending(true);
        try{await ctx.session.handle.sendNow(queued.itemId,{commandId:'resume_'+intent.planning_request_id});}
        catch{setError('继续队列的结果未确认；请核对原请求，不要重发。');}
        finally{lock.current=false;setSending(false);}
      }},'继续已排队规划（不重复提交）'),
    intent && h('small',null,'规划请求：',intent.planning_request_id),
    proposal?.conflict && h('p',{className:'rh-error'},'同一请求返回了不同计划，禁止执行；请重新规划。'),
    proposal && !proposal.conflict && h('div',null,
      h('p',null,'计划目标：',proposal.goal),
      h('ol',null,...proposal.stage_ids.map((id,index)=>{
        const stage=task?.stages?.find(s=>s.id===id);
        return h('li',{key:id},`${index+1}. ${stage?.instruction || '登记技能不可用'}`,
          h('small',null,`技能 ${id} · VLA 上限 ${stage?.max_steps ?? '—'} 步 · 沿用原阶段后复位`),
          stage?.checker && h('details',null,h('summary',null,'检查条件（原登记判据）'),h('pre',null,JSON.stringify(stage.checker,null,2))));
      })),
      h('p',{className:'rh-note'},`共享剩余预算 ${scene?.remaining_steps ?? '—'} 步；不会因多阶段增加预算。阶段完成和完整场景原生成功分开记录。`),
      execution ? h('p',{role:'status',className:'rh-note'},
        `本计划已执行：完成 ${execution.completed_source_stage_ids?.length ?? 0} / ${proposal.stage_ids.length} 阶段；`+
        `计划流程 ${execution.workflow_success===true?'成功':execution.workflow_success===false?'未成功':'未知'}；`+
        `完整场景原生结果 ${execution.native_success===true?'成功':execution.native_success===false?'未成功':'未知'}。不会重复执行。`) :
        !ready && h('p',{className:scene?.status==='executing'?'rh-note':'rh-error'},
          scene?.status==='executing'?'机器人正在执行，暂不能再次提交计划。':'场景已变化或目录不可用，此计划当前不能执行。'),
      h('button',{type:'button',disabled:blocked||!ready||modelBusy||sending,onClick:()=>onExecute({planning_request_id:proposal.planning_request_id,
        goal:proposal.goal,scene_step:proposal.scene_step,stage_ids:proposal.stage_ids})},'确认并执行阶段计划')),
    intent && h('button',{type:'button',disabled:sending||modelBusy||blocked||!!queued,onClick:()=>{
      localStorage.removeItem(key);currentIntent.current=null;setIntent(null);setProposal(null);setError('');
    }},'清除规划草稿（不停止机器人）'));
}
