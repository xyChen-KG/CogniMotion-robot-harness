export function displayMode(snapshot) {
  if (snapshot?.connection !== 'connected' || snapshot?.runner_available !== true) return '连接异常 · 保留画面非实时';
  if (snapshot?.mode === 'archive') return '历史画面 · 非实时';
  if (snapshot?.status?.active === false && snapshot.available) return '最终画面';
  if (snapshot?.status?.ownership_uncertain || snapshot?.status?.status === 'interrupted') return '状态待核实 · 非实时保证';
  return snapshot?.available ? '实时画面' : '等待画面';
}

// Schedule from request start, not request end: transport latency is part of the
// 125 ms preview period. Requests remain serial, with no backlog or model calls.
export function previewDelay(snapshot, hidden, elapsed = 0) {
  const interval = hidden ? 1500 : snapshot?.status?.active === false ? 1000 :
    snapshot?.connection === 'connected' && snapshot?.runner_available === true ? 125 : 500;
  return Math.max(0, interval - Math.max(0, elapsed));
}

// Read only Host session UI tool results, never user text or the newest global run.
export function sessionRobotRun(timeline) {
  let linked = null;
  for (const node of timeline?.nodes || []) {
    if (node.kind !== 'tool' || !['robot_start_run', 'robot_get_run'].includes(node.name)) continue;
    if (node.status === 'planned' || node.status === 'running') {
      if (node.name === 'robot_start_run') linked = {run_id: null, state: 'waiting'};
      continue;
    }
    let value;
    try { value = JSON.parse(node.resultPreview || ''); } catch { continue; }
    if ([200, 202].includes(value.http_status) && /^run_[a-f0-9]{32}$/.test(value.response?.run_id || ''))
      linked = {run_id: value.response.run_id, state: 'linked'};
    else if (node.name === 'robot_start_run') linked = {run_id: null, state: 'unconfirmed_or_refused'};
  }
  return linked;
}

export function exactObservation(snapshot, requested) {
  if (requested && (snapshot?.selected_run_id !== requested ||
      (snapshot?.status && snapshot.status.run_id !== requested)))
    return {...snapshot, selected_run_id: requested, status: null, details: null, frame: null, available: false,
      mode: 'waiting', selection_pending: true};
  return snapshot;
}

export function decodeChunk(value, runId, offset, total) {
  if (!value || value.run_id !== runId || value.offset !== offset || value.mime !== 'video/mp4' ||
      !Number.isSafeInteger(value.total_bytes) || value.total_bytes <= 0 || value.total_bytes > 67108864 ||
      (total != null && total !== value.total_bytes) || typeof value.data_base64 !== 'string' || value.data_base64.length > 262144)
    throw new Error('录像数据不一致');
  const bytes = Uint8Array.from(atob(value.data_base64), c => c.charCodeAt(0));
  const next = offset + bytes.length;
  if (!bytes.length || next > value.total_bytes || value.next_offset !== next || value.eof !== (next === value.total_bytes))
    throw new Error('录像分块无进展');
  return bytes;
}
