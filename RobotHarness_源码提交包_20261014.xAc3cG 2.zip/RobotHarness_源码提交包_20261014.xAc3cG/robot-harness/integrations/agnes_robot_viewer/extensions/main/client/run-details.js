import {createElement as h} from 'react';

const yes = value => value === true ? '是' : value === false ? '否' : '未知';
const result = value => value === true ? '成功' : value === false ? '未成功' : '未知';
const PHASE = {ended:'已结束',vla:'VLA阶段／等待推理',reset:'复位工具',motion_tool:'运动工具',between_stages:'阶段衔接',unknown:'未知'};
const STATUS = {finished:'已结束',running:'执行中',starting:'初始化',stopped:'已停止',failed:'执行错误',start_failed:'启动失败',interrupted:'待核实'};
const EVENTS = {stage_start:'阶段开始',state_update:'阶段更新',vla_paused_for_tools:'VLA暂停，进入工具',
  final_stage_native_complete:'末阶段由原生成功完成',post_tool_failed:'阶段后工具未达标',
  stage_start_captured:'记录阶段起点',tool_start:'工具开始',tool_end:'工具结束',
  collision_replan:'碰撞后路径重规划',tracking_replan:'跟踪偏差后重规划',stage_state_change:'阶段条件变化'};
const REASONS = {final_stage_native_success:'最终原生任务成功',all_stages_complete:'全部阶段完成',
  stage_step_budget_exhausted:'阶段动作预算耗尽',total_step_budget_exhausted:'总控制步预算耗尽',
  wall_clock_budget_exhausted:'时间预算耗尽',environment_terminated:'环境终止',
  interface_or_runtime_error:'接口或运行错误',signal:'收到停止信号',finished:'执行结束',unrecognized_reason:'未识别原因（原文已隐藏）'};
const timestamp = value => typeof value === 'number' && Number.isFinite(value) && value > 0 ? new Date(value*1000).toLocaleString() : '未知时间';

export function stageLabel(stage, currentId, active, uncertain=false) {
  if (stage.achieved_once === true) return '历史已完成';
  if (uncertain) return '状态待核实';
  if (active && stage.id === currentId) return '执行中';
  if (active === false && stage.id === currentId && stage.achieved_once === false) return '本阶段未完成';
  return stage.achieved_once === false ? '待执行／未达标' : '记录未知';
}

export function RunHistory({runs=[],runId,onSelect,linkedRun}) {
  return h('details',{className:'rh-run-history'},h('summary',null,'运行记录 · 最近20个'),
    h('p',{className:'rh-note'},'查看历史不会获得停止权限，也不会重跑任务。'),
    h('ul',null,...runs.map(row=>h('li',{key:row.run_id},
      h('button',{type:'button','aria-pressed':row.run_id===runId,onClick:()=>onSelect(row.run_id)},
        `${row.request?.task_id || '未知任务'} · ${row.request?.policy || '未知VLA'} · seed ${row.request?.seed ?? '未知'}`),
      h('small',null,`${timestamp(row.created_at)} · ${STATUS[row.status] || '未知'} · ${row.run_id===linkedRun?'本会话回合':'只读查看'}`),
      h('code',null,row.run_id)))));
}

export function RunDetails({snapshot,runId}) {
  const details=runId && snapshot?.details?.run_id===runId?snapshot.details:null;
  const status=snapshot?.status || {};
  const stale=snapshot?.connection!=='connected'||snapshot?.runner_available!==true;
  const stages=Array.isArray(details?.stages)?details.stages:[];
  const entries=Array.isArray(details?.log_summary?.entries)?details.log_summary.entries:[];
  const termination=details?.termination_reason;
  return h('div',{className:'rh-run-details'},
    h('details',{open:true},h('summary',null,'阶段详情与结果'),
      h('p',{className:'rh-note'},`查看回合：${runId || '未选择'} · ${stale?'连接异常，保留记录非实时':status.active===false?'历史／最终记录':'当前回合记录'}`),
      h('p',null,`执行模式（最新记录）：${stale?'未知（断线）':PHASE[details?.execution_phase] || '未知'} · 记录步号 ${details?.snapshot_step ?? '—'}`),
      h('p',{className:'rh-note'},'“曾完成”是历史里程碑；条件可以再次变成否。阶段条件可能含松爪等流程要求，不等于最终原生任务结果。'),
      !details?.details_available && h('p',{className:'rh-error'},'没有可核对的阶段表／记录；不根据录像或当前任务配置猜测。'),
      h('ol',{className:'rh-stage-details'},...stages.map(stage=>h('li',{key:stage.id},
        h('strong',null,`阶段 ${stage.id} · ${stageLabel(stage,details.current_stage,status.active,stale || status.ownership_uncertain || status.status==='interrupted')}`),
        h('p',null,stage.instruction || '原始指令缺失'),
        h('p',null,`曾完成：${yes(stage.achieved_once)} · 条件${status.active===false?'最终记录':'本次记录'}：${yes(stage.current_satisfied)}`),
        h('small',null,`首次完成步 ${stage.first_achieved_step ?? '—'} · 检查步 ${stage.last_checked_step ?? '—'} · VLA ${stage.vla_steps ?? '—'} / 工具 ${stage.tool_steps ?? '—'}`),
        Array.isArray(stage.checks)&&stage.checks.length>0&&h('p',{className:'rh-note'},'阶段检查：'+stage.checks.map(c=>`${c.predicate}=${yes(c.satisfied)}`).join(' · '))))),
      h('div',{className:'rh-results'},h('span',null,'最终 native_success：'+result(details?.native_success)),
        h('span',null,'最终 workflow_success：'+result(details?.workflow_success))),
      !details?.final_result_available&&h('p',{className:'rh-note'},'最终结果尚不可用；过程状态不填作最终成功。'),
      h('p',null,'终止原因：'+(termination?REASONS[termination] || (termination.startsWith('post_tool_')?'阶段后工具：'+termination.slice(10):'未知'):'尚未记录')),
      details?.error_recorded&&h('p',{className:'rh-error'},'已记录执行诊断；此处不公开原始异常或路径。'),
      details?.post_tool_failures?.length>0&&h('p',{className:'rh-note'},'复位／工具未达标记录：'+details.post_tool_failures.map(f=>`阶段${f.stage_id ?? '?'} ${f.status}，继续=${yes(f.continued)}`).join('；'))),
    h('details',null,h('summary',null,'脱敏事件摘要'),
      h('p',{className:'rh-note'},'仅固定结构化事件，每个来源最多读取64KiB，最多显示80项；不开放原始日志、文件路径、命令或凭据。'),
      details?.log_summary?.truncated&&h('p',{className:'rh-note'},'摘要已截断，只显示最近事件。'),
      !entries.length&&h('p',null,'暂无可展示的结构化事件；不是完整原始日志。'),
      h('ol',{className:'rh-event-list'},...entries.map((entry,index)=>h('li',{key:index},
        `步 ${entry.step ?? '—'} · 阶段 ${entry.stage_id ?? '—'} · ${EVENTS[entry.event] || '事件'}`+
        (entry.tool?` · ${entry.tool}`:'')+(entry.status?` · ${entry.status}`:'')+
        (entry.achieved_once!=null?` · 曾完成=${yes(entry.achieved_once)}，条件=${yes(entry.current_satisfied)}`:''))))));
}
