import {createElement as h, useEffect, useRef, useState} from 'react';
import {BUDGET_LABELS, catalogModel, legalSelection} from './catalog.js';
import {LABELS} from './operations.mjs';

const policyName = {atomic: 'AtomicVLA', internw0: 'InternW0-Δ'};

export function TaskConfig({ctx, sessionId, operations}) {
  const [catalog, setCatalog] = useState(null), [selection, setSelection] = useState({});
  const [loading, setLoading] = useState(false), [error, setError] = useState('');
  const epoch = useRef(0), busy = useRef(false), mounted = useRef(true);
  async function refresh() {
    if (!sessionId || busy.current) return;
    busy.current = true; setLoading(true); setError('');
    const current = epoch.current;
    try {
      const value = catalogModel(await ctx.agnes.services.call('robot.tasks', {}));
      if (!mounted.current || current !== epoch.current) return;
      setCatalog(value); setSelection(old => legalSelection(value.tasks, old));
      if (!value.connected) setError('登记接口连接不可用；执行开关未知。');
    } catch {
      if (mounted.current && current === epoch.current) {
        setCatalog(old => old ? {...old, connected: false, runs_enabled: null} : null);
        setError('任务目录读取失败；保留的配置仅为上次显示，不代表当前登记。');
      }
    } finally {
      if (current === epoch.current) {busy.current = false; if (mounted.current) setLoading(false);}
    }
  }
  useEffect(() => {
    mounted.current = true; epoch.current++; busy.current = false;
    setCatalog(null); setSelection({}); setError(''); setLoading(false);
    void refresh();
    return () => {mounted.current = false; epoch.current++;};
  }, [ctx, sessionId]);
  const tasks = catalog?.tasks || [], chosen = legalSelection(tasks, selection);
  const task = tasks.find(t => t.task_id === chosen.task_id);
  const disabled = loading || !catalog?.connected || !task || operations?.sending;
  const runDisabled=disabled||!task?.configuration_available||catalog?.runs_enabled!==true||operations?.startBlocked;
  const stopDisabled=!operations?.stopAllowed||operations?.sending;
  const choose = update => setSelection(legalSelection(tasks, {...chosen, ...update}));
  const flag = catalog?.runs_enabled === true ? '已开启' : catalog?.runs_enabled === false ? '已关闭' : '未知';
  return h('details', {className: 'rh-task-config', open: true},
    h('summary', null, '任务配置与操作'),
    h('div', {className: 'rh-config-status', role: 'status'},
      h('span', null, `登记接口：${loading ? '读取中' : catalog?.connected ? '已连接' : '未连接'}`),
      h('span', null, `执行开关：${flag}`)),
    h('p', {className: 'rh-note'}, '阶段表与预算只读。运行/停止提交到当前Agnes会话，仍需原有工具审批；按钮不是启动成功证明。'),
    h('label', null, '任务', h('select', {disabled, value: chosen.task_id, 'aria-label': '机器人任务',
      onChange: e => choose({task_id: e.target.value})},
      !tasks.length && h('option', {value: ''}, sessionId ? '等待真实登记任务' : '请先选择Agnes会话'),
      ...tasks.map(t => h('option', {key: t.task_id, value: t.task_id}, t.title)))),
    h('div', {className: 'rh-config-choices'},
      h('label', null, 'VLA', h('select', {disabled, value: chosen.policy, 'aria-label': '机器人VLA',
        onChange: e => choose({policy: e.target.value})},
        ...(task?.policies || []).map(p => h('option', {key: p, value: p}, `${policyName[p] || p} · ${p}`)))),
      h('label', null, 'seed', h('select', {disabled, value: chosen.seed ?? '', 'aria-label': '机器人seed',
        onChange: e => choose({seed: Number(e.target.value)})},
        ...(task?.allowed_seeds || []).map(s => h('option', {key: s, value: s}, String(s)))))),
    h('button', {type: 'button', disabled: loading || !sessionId, onClick: refresh}, loading ? '正在读取任务…' : '刷新任务'),
    operations && h('div',{className:'rh-operation-buttons'},
      h('button',{type:'button',disabled:runDisabled,onClick:()=>operations.submit('start',chosen)},'请求运行'),
      h('button',{type:'button',disabled:operations.sending||!sessionId,onClick:()=>operations.submit('status',{})},'查询状态'),
      h('button',{type:'button',disabled:stopDisabled,onClick:()=>operations.submit('stop',{run_id:operations.state.run_id})},'请求停止')),
    operations && h('p',{role:'status',className:'rh-note'},`请求状态：${LABELS[operations.state.state] || '待核实'} · 本会话run_id：${operations.state.run_id || '未确认'}`),
    operations?.message && h('p',{role:'alert',className:'rh-error'},operations.message),
    error && h('p', {className: 'rh-error', role: 'alert'}, error),
    task && h('p', {className: 'rh-note'}, `task_id：${task.task_id} · 选定组合：${chosen.policy} / seed ${chosen.seed}`),
    task && !task.configuration_available && h('p', {className: 'rh-error'}, '登记的阶段表缺失、变化或超出展示限制；不展示猜测配置。'),
    task?.configuration_available && h('div', null,
      !catalog.connected && h('p', {className: 'rh-error'}, '以下为上次读取的配置，当前未连接；请选择刷新后再核对。'),
      h('h3', null, '人工阶段表'),
      h('ol', {className: 'rh-config-stages'}, ...task.stages.map(s => h('li', {key: s.id},
        h('span', null, s.instruction), h('small', null, `阶段 ${s.id} · VLA上限 ${s.max_steps} 控制步`)))),
      h('h3', null, '登记预算（不可编辑）'),
      h('dl', {className: 'rh-config-budget'}, ...Object.entries(BUDGET_LABELS).flatMap(([key, label]) =>
        [h('dt', {key: key + '-label'}, label), h('dd', {key: key + '-value'}, String(task.budget[key]))])),
      h('p', {className: 'rh-note'}, `完成模式：${task.completion_mode ?? '未知'} · stable_steps：${task.stable_steps ?? '未知'}`)));
}
