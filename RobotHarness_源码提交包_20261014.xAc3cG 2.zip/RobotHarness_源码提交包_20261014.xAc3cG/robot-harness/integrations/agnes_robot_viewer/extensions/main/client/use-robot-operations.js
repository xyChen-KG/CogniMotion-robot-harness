import {useEffect,useRef,useState} from 'react';
import {SessionOperations,timelineState,BUSY} from './operations.mjs';
import {readSessionProjection} from './session-projection.mjs';

export function useRobotOperations(ctx,sessionId) {
  const [state,setState]=useState({state:'idle',run_id:null,owned:false});
  const [message,setMessage]=useState(''),[sending,setSending]=useState(false);
  const generation=useRef(0),model=useRef(null),timeline=useRef(null),sendLock=useRef(false);
  useEffect(()=>{
    let live=true;generation.current++;sendLock.current=false;
    setState({state:'idle',run_id:null,owned:false});setSending(false);setMessage('');timeline.current=null;
    try {model.current=sessionId?new SessionOperations(sessionId,localStorage):null;}
    catch {model.current=null;setMessage('无法保存提交身份，已禁止运行请求。');}
    async function update(){
      try{
        const value=await readSessionProjection(ctx);
        if(live&&value.status==='available'){
          timeline.current=value.value;
          // Cached intent never proves ownership. Only Host tool receipts do.
          const next=model.current?model.current.reconcile(value.value):timelineState(value.value);
          setState(next);
        }
      }catch{if(live)setMessage('会话回执暂不可核对；不会自动重发运行。');}
    }
    const off=ctx.session.projection.subscribe(update);void update();
    return()=>{live=false;generation.current++;off();model.current=null;};
  },[ctx,sessionId]);
  async function submit(op,args){
    if(sendLock.current||!model.current) return;
    if(op==='start' && (['starting','running','mismatch'].includes(state.state)||BUSY.has(state.state))){
      setMessage('本会话回合或请求尚未结束，请先查询状态。');return;
    }
    if(op==='stop'&&(!state.owned||state.run_id!==args.run_id)){
      setMessage('不能停止非本会话拥有的回合。');return;
    }
    const epoch=generation.current;sendLock.current=true;setSending(true);setMessage('');
    try {
      const pending=model.current.submit(op,args,ctx.session.handle,timeline.current);
      if(op!=='status')setState(old=>({...old,state:op==='stop'?'stopping':'startup_unconfirmed',
        ...(op==='start'?{run_id:null,owned:false}:{})}));
      await pending;
      const projection=await readSessionProjection(ctx);
      if(epoch===generation.current && projection.status==='available') {
        timeline.current=projection.value;setState(model.current.reconcile(projection.value));
      }
    }catch(error){if(epoch===generation.current)setMessage(error instanceof Error?error.message:'提交未确认');}
    finally{if(epoch===generation.current){sendLock.current=false;setSending(false);}}
  }
  function observe(value) {
    if (!state.owned || value?.run_id!==state.run_id) return;
    if(value.ownership_uncertain===true || value.status==='interrupted') {
      if(state.state!=='unknown')setState(old=>({...old,state:'unknown'}));return;
    }
    const phase={starting:'starting',running:'running',finished:'finished',stopped:'stopped',stopping:'stopping',failed:'failed',start_failed:'failed'}[value.status];
    if (phase && phase!==state.state) {
      setState(old=>({...old,state:phase}));
      const intent=model.current?.intent;
      if(intent) {try{model.current.save({...intent,state:phase});}catch{setMessage('状态缓存写入失败；查询回执后再操作。');}}
    }
  }
  return {state,message,sending,submit,observe,
    startBlocked:sending||BUSY.has(state.state)||state.state==='mismatch'||['starting','running'].includes(state.state),
    stopAllowed:state.owned&&!!state.run_id&&!['finished','stopped','failed','mismatch','unknown','stopping'].includes(state.state)};
}
