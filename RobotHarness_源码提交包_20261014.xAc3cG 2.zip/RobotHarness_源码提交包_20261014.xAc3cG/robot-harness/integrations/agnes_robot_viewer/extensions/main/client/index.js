import { createElement as h, useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { decodeChunk, displayMode, exactObservation, previewDelay } from './state.js';
import { TaskConfig } from './task-config.js';
import { useRobotOperations } from './use-robot-operations.js';
import { RunDetails, RunHistory } from './run-details.js';
import { ScenePanel } from './scene-panel.js';


const labels = {running:'执行中', starting:'初始化', finished:'已结束', stopped:'已停止', stopping:'正在停止', failed:'执行错误', start_failed:'启动失败', interrupted:'需检查'};
const result = value => value === true ? '成功' : value === false ? '未成功' : '未知';

export function Cameras({frame, runId}) {
  const main = useRef(null), wrist = useRef(null);
  const paintedRun = useRef(null);
  useEffect(() => {
    const nodes = [main.current, wrist.current];
    if (paintedRun.current !== runId) {
      for (const node of nodes) node?.getContext('2d').clearRect(0,0,node.width,node.height);
      paintedRun.current = runId;
    }
    if (!frame?.image_base64) return;
    let live = true; let url;
    try {
      if (!['image/jpeg','image/png'].includes(frame.image_mime) || frame.image_base64.length > 600000) throw new Error('Invalid frame');
      const bytes = Uint8Array.from(atob(frame.image_base64), c => c.charCodeAt(0));
      url = URL.createObjectURL(new Blob([bytes], {type:frame.image_mime}));
      const image = new Image();
      image.onload = () => {
        if (!live || image.width > 2048 || image.height > 2048) return;
        nodes.forEach((node,index) => {if (!node) return;node.width=image.width/2;node.height=image.height;
          node.getContext('2d').drawImage(image,index*node.width,0,node.width,node.height,0,0,node.width,node.height);});
      };
      image.src = url;
    } catch { /* Missing/corrupt frames never trigger any robot operation. */ }
    return () => {live=false;if(url)URL.revokeObjectURL(url);};
  }, [runId, frame?.frame_id, frame?.image_base64]);
  return h('div',{className:'rh-cameras'},
    h('figure',null,h('figcaption',null,'主视角 · agentview'),h('canvas',{ref:main,width:256,height:256,'aria-label':'机器人主视角'})),
    h('figure',null,h('figcaption',null,'腕部视角 · wrist'),h('canvas',{ref:wrist,width:256,height:256,'aria-label':'机器人腕部视角'})));
}

function Panel({ctx}) {
  const sessionId = useSyncExternalStore(ctx.session.subscribe, ctx.session.getSnapshot);
  const [snapshot,setSnapshot] = useState(null), [selected,setSelected] = useState(null);
  const operations=useRobotOperations(ctx,sessionId);
  const sessionLink=operations.state.state==='idle'?null:operations.state;
  const linkedRun = operations.state.run_id || null;
  const requestedRun = selected || linkedRun;
  useEffect(()=>{setSelected(null);},[sessionId]);
  const [error,setError] = useState(''), [refresh,setRefresh] = useState(0);
  const [replay,setReplay] = useState(null), [loading,setLoading] = useState(false), [percent,setPercent] = useState(0);
  const [replayRunId,setReplayRunId] = useState(null);
  const [replayError,setReplayError] = useState('');
  const generation = useRef(0), videoUrl = useRef(null);
  useEffect(() => {
    let live=true,timer;setSnapshot(null);setError('');
    async function poll() {
      if (!live) return;
      if (!sessionId) {setError('请先在 Agnes 选择一个会话');return;}
      const started=performance.now();let value;
      try {
        value=await ctx.agnes.services.call('robot.observation',{run_id:requestedRun});
        if (!live) return;
        // A shared read-only observer may briefly display another client's run.
        // Never render it as this session's selected robot.
        setSnapshot(sessionLink && !requestedRun ? {...value, selected_run_id:null, status:null, frame:null,
          available:false, mode:'waiting'} : exactObservation(value, requestedRun));setError('');
        if(value.selected_run_id===linkedRun) operations.observe(value.status);
      } catch {if(live)setError('观看通道暂不可用，正在重连；机器人执行不受影响');}
      if(live)timer=setTimeout(poll,previewDelay(value,document.hidden,performance.now()-started));
    }
    void poll();return()=>{live=false;clearTimeout(timer);};
  },[ctx,sessionId,requestedRun,sessionLink?.state,refresh]);
  const runId = snapshot?.selected_run_id;
  useEffect(() => {
    generation.current++;setLoading(false);setReplay(null);setReplayRunId(null);setPercent(0);setReplayError('');
    if(videoUrl.current){URL.revokeObjectURL(videoUrl.current);videoUrl.current=null;}
    return()=>{generation.current++;if(videoUrl.current){URL.revokeObjectURL(videoUrl.current);videoUrl.current=null;}};
  },[runId,sessionId]);
  async function loadReplay() {
    if(loading || !runId)return;
    const current=generation.current;setLoading(true);setPercent(0);setReplayError('');
    try {
      let offset=0,total;const parts=[];
      do {
        const value=await ctx.agnes.services.call('robot.replay.chunk',{run_id:runId,offset});
        if(current!==generation.current)return;
        const bytes=decodeChunk(value,runId,offset,total);total=value.total_bytes;parts.push(bytes);offset=value.next_offset;
        setPercent(Math.round(offset/total*100));
      } while(offset<total);
      const url=URL.createObjectURL(new Blob(parts,{type:'video/mp4'}));
      if(videoUrl.current)URL.revokeObjectURL(videoUrl.current);videoUrl.current=url;setReplay(url);setReplayRunId(runId);setError('');
    } catch (error) {if(current===generation.current)setReplayError('录像暂不可用：'+(error instanceof Error ? error.message : '未知错误')+'；不会重新运行任务');}
    finally {if(current===generation.current)setLoading(false);}
  }
  const status=snapshot?.status || {},frame=snapshot?.frame;
  const connected=snapshot?.connection==='connected' && snapshot?.runner_available;
  return h('section',{className:'rh-robot-panel','aria-label':'机器人实时画面'},
    h('header',null,h('div',null,h('small',null,'ROBOT HARNESS · 只读'),h('h2',null,'机器人实时画面')),h('span',{className:connected?'rh-badge':'rh-badge rh-warn'},connected?'已连接':'连接中')),
    h('p',{className:'rh-note'},'状态与观看只读；运行/停止通过当前会话及工具审批。'),
    h(ScenePanel,{ctx,sessionId,Cameras}),
    h(TaskConfig,{ctx,sessionId,operations}),
    sessionLink && h('p',{className:'rh-note'},linkedRun ? `本会话回合：${linkedRun}` : '本会话启动请求等待确认；不会自动重跑。'),
    selected && linkedRun && selected !== linkedRun && h('button',{type:'button',onClick:()=>setSelected(null)},'跟随本会话回合'),
    h('label',null,'观看回合',h('select',{'aria-label':'选择机器人回合',value:requestedRun || runId || '',onChange:e=>setSelected(e.target.value || null)},
      ...(requestedRun && !(snapshot?.runs || []).some(row=>row.run_id===requestedRun) ? [h('option',{key:requestedRun,value:requestedRun},'等待回合 · '+requestedRun.slice(-8))] : []),
      ...(snapshot?.runs || []).map(row=>h('option',{key:row.run_id,value:row.run_id},`${row.request?.task_id || '任务'} · ${row.request?.policy || ''} · ${row.run_id.slice(-8)}`)))),
    h(RunHistory,{runs:snapshot?.runs || [],runId,linkedRun,onSelect:setSelected}),
    h('button',{type:'button',className:'rh-refresh',onClick:()=>setRefresh(n=>n+1)},'刷新观看'),
    error && h('p',{role:'status',className:'rh-error'},error),
    h('div',{className:'rh-metrics'},h('div',null,h('small',null,'执行阶段'),h('strong',null,`${status.current_stage ?? '—'} / ${status.stage_count ?? '—'}`)),
      h('div',null,h('small',null,'真实控制步'),h('strong',null,status.steps ?? '—'))),
    h('p',null,`${labels[status.status] || '等待状态'} · VLA ${status.vla_steps ?? '—'} / 工具 ${status.tool_steps ?? '—'}`),
    h('div',{className:'rh-mode'},h('span',null,displayMode(snapshot)),h('span',null,status.active===false?'回合已结束':`帧龄 ${snapshot?.frame_age_seconds == null ? '—' : snapshot.frame_age_seconds.toFixed(1)+' s'}`)),
    h(Cameras,{frame,runId}),
    snapshot?.selection_pending && h('p',{role:'status',className:'rh-error'},'等待所选回合画面，不显示其他回合替代。'),
    h('p',{className:'rh-note'},`画面步数 ${frame?.step ?? '—'} · 画面阶段 ${frame?.stage_id ?? '—'} · ${frame?.source === 'tool' ? '复位/运动工具' : frame?.source === 'vla' ? 'VLA 动作' : '相机画面'}`),
    !snapshot?.available && h('p',{className:'rh-error'},'尚无有效画面；正在等待服务器图片。'),
    status.active && snapshot?.frame_age_seconds>2 && h('p',{className:'rh-error'},'画面暂未更新，可能正在推理或路径搜索。'),
    h('p',null,'已完成阶段：'+(status.completed_stage_ids?.join(' → ') || '—')),
    h('div',{className:'rh-results'},h('span',null,'原生结果：'+result(status.native_success)),h('span',null,'流程结果：'+result(status.workflow_success))),
    h(RunDetails,{snapshot,runId}),
    h('button',{type:'button',disabled:loading || !(status.active===false && status.video_size_bytes>0),onClick:loadReplay},loading?`加载录像 ${percent}%`:'在此回放完整录像'),
    replayError && h('p',{role:'status',className:'rh-error'},replayError),
    h('p',{className:'rh-note'},'先加载完整录像，随后可回放或下载；切换回合会清除旧录像链接。'),
    replay && runId && replayRunId===runId && h('a',{className:'rh-video-download',href:replay,download:`robot_${runId.slice(-8)}.mp4`},'下载完整录像（MP4）'),
    replay && replayRunId===runId && h('video',{controls:true,src:replay,preload:'metadata','aria-label':'机器人完整录像'}),
    h('footer',null,runId || '等待回合',' · 关闭页面不会停止机器人'));
}

export function apply(ctx) {
  ctx.commands.registerEffect({id:'robot.scene.open',title:'打开机器人场景（不运行 VLA）',service:'robot.scene.open'});
  ctx.commands.registerEffect({id:'robot.scene.command',title:'执行所选机器人场景操作',service:'robot.scene.command'});
  let visible=true;
  const listeners=new Set();
  const register=()=>ctx.slots.register({name:'rightbar',id:'robot-harness-live-viewer',priority:-10},()=>h(Panel,{ctx}));
  let remove=register();
  function toggle() {
    visible=!visible;
    if(visible)remove=register();else remove();
    for(const listener of listeners)listener();
  }
  function Toggle() {
    const opened=useSyncExternalStore(listener=>{listeners.add(listener);return()=>listeners.delete(listener);},()=>visible);
    return h('button',{type:'button','aria-pressed':opened,onClick:toggle},opened?'收起机器人画面':'展开机器人画面');
  }
  ctx.slots.register({name:'conversation.session.header.actions',id:'robot-harness-viewer-toggle',priority:10},Toggle);
  ctx.effect(()=>()=>{remove();listeners.clear();});
}
