// Reuse the SAME authenticated SDK handle. Never replay an unbounded long-session ledger.
export async function readSessionProjection(ctx) {
  const handle=ctx.session.handle;
  if(typeof handle?.projectUIOpening==='function') {
    const opening=await handle.projectUIOpening({surface:'web',maxNodes:128,maxBytes:262144});
    return {status:'available',value:opening.timeline};
  }
  return ctx.session.projection.read(); // Compatibility/test hosts lacking the public windowed SDK.
}
export function sessionIsBusy(timeline) {
  const phase=timeline?.opState?.phase ?? timeline?.opState?.data?.phase;
  return !!phase && phase!=='idle';
}
