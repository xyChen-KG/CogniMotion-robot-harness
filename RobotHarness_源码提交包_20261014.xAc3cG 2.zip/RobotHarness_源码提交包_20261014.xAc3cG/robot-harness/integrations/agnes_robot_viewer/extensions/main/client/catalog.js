// Public display contract. Unknown/missing fields are not guessed or replaced.
const ID = /^[A-Za-z0-9._-]{1,128}$/;
export const BUDGET_LABELS = {
  max_steps: '总控制步上限（含工具）',
  check_interval_steps: '状态检查间隔（步）',
  max_state_requests: '状态请求上限',
  max_policy_queries: 'VLA请求上限',
  max_wall_seconds: '墙钟时间上限（秒）',
};

export function catalogModel(value) {
  if (!value || !Array.isArray(value.tasks) || value.tasks.length > 64) throw new Error('目录格式无效');
  const seen = new Set();
  const tasks = value.tasks.map(row => {
    if (!row || !ID.test(row.task_id || '') || seen.has(row.task_id) || !Array.isArray(row.policies) ||
        !row.policies.length || row.policies.some(p => !['atomic', 'internw0'].includes(p)) ||
        !Array.isArray(row.allowed_seeds) || !row.allowed_seeds.length || row.allowed_seeds.length > 256 ||
        row.allowed_seeds.some(s => !Number.isSafeInteger(s) || s < 0 || s > 2147483647)) throw new Error('登记选项无效');
    seen.add(row.task_id);
    let valid = row.configuration_available === true;
    const stageIds = new Set();
    valid &&= Array.isArray(row.stages) && row.stages.length > 0 && row.stages.length <= 32 &&
      row.stages.every(s => {
        if (!s || !Number.isSafeInteger(s.id) || s.id < 1 || stageIds.has(s.id) ||
            typeof s.instruction !== 'string' || !s.instruction.trim() || s.instruction.length > 2048 ||
            !Number.isSafeInteger(s.max_steps) || s.max_steps < 1) return false;
        stageIds.add(s.id); return true;
      }) &&
      row.budget && Object.keys(BUDGET_LABELS).every(k => Number.isSafeInteger(row.budget[k]) && row.budget[k] > 0);
    return {task_id: row.task_id, title: typeof row.title === 'string' ? row.title.slice(0, 200) : row.task_id,
      policies: [...new Set(row.policies)], allowed_seeds: [...new Set(row.allowed_seeds)],
      configuration_available: !!valid, stages: valid ? row.stages.map(s => ({id: s.id, instruction: s.instruction, max_steps: s.max_steps})) : null,
      budget: valid ? Object.fromEntries(Object.keys(BUDGET_LABELS).map(k => [k, row.budget[k]])) : null,
      completion_mode: typeof row.completion_mode === 'string' ? row.completion_mode : null,
      stable_steps: Number.isSafeInteger(row.stable_steps) ? row.stable_steps : null};
  });
  const connected = value.connection === 'connected' && value.runner_available === true;
  return {tasks, connected, runs_enabled: connected && typeof value.runs_enabled === 'boolean' ? value.runs_enabled : null};
}

export function legalSelection(tasks, selected = {}) {
  const task = tasks.find(t => t.task_id === selected.task_id) || tasks[0];
  if (!task) return {task_id: '', policy: '', seed: null};
  return {task_id: task.task_id,
    policy: task.policies.includes(selected.policy) ? selected.policy : task.policies[0],
    seed: task.allowed_seeds.includes(selected.seed) ? selected.seed : task.allowed_seeds[0]};
}
