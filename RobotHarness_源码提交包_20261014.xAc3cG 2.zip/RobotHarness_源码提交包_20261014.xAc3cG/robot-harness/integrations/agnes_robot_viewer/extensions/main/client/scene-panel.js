import {createElement as h, useEffect, useRef, useState} from 'react';
import {decodeChunk} from './state.js';
import {PlanPanel} from './plan-panel.js';

const labels={opening:'打开中',idle:'等待指令 · 场景保持不变',executing:'执行操作中',resetting:'重置场景中',
  exhausted:'控制预算用完 · 请重置或关闭',closed:'已关闭',failed:'场景错误',interrupted:'进程需要检查'};
const success=value=>value===true?'完成':value===false?'未完成':'未知';

export function ScenePanel({ctx,sessionId,Cameras}) {
  const [catalog,setCatalog]=useState(null),[snapshot,setSnapshot]=useState(null);
  const [taskId,setTaskId]=useState('same_five_stage'),[policy,setPolicy]=useState('internw0');
  const [seed,setSeed]=useState(47),[stageId,setStageId]=useState(1);
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const [target,setTarget]=useState(null),[pending,setPending]=useState(null);
  const [retryIntent,setRetryIntent]=useState(null);
  const [catalogError,setCatalogError]=useState(''),[catalogBusy,setCatalogBusy]=useState(false);
  const actionLock=useRef(false),epoch=useRef(0);
  const [replay,setReplay]=useState(null),[loadingVideo,setLoadingVideo]=useState(false);
  const videoUrl=useRef(null),videoGeneration=useRef(0);
  async function refreshCatalog(){
    if(!sessionId)return;
    const generation=epoch.current;setCatalogBusy(true);setCatalogError('');
    try{
      const value=await ctx.agnes.services.call('robot.tasks',{});
      if(generation!==epoch.current)return;
      if(value.runner_available!==true || !Array.isArray(value.tasks))throw new Error('Catalog unavailable');
      setCatalog(value);if(!value.tasks.some(t=>t.task_id===taskId))setTaskId(value.tasks[0]?.task_id || '');
    }catch{if(generation===epoch.current){setCatalog(null);setCatalogError('场景目录不可用；点击刷新场景目录，不会启动任务。');}}
    finally{if(generation===epoch.current)setCatalogBusy(false);}
  }
  useEffect(()=>{videoGeneration.current++;setReplay(null);setLoadingVideo(false);
    if(videoUrl.current){URL.revokeObjectURL(videoUrl.current);videoUrl.current=null;}
    return()=>{videoGeneration.current++;if(videoUrl.current)URL.revokeObjectURL(videoUrl.current);};
  },[snapshot?.scene_id,snapshot?.status?.revision,sessionId]);
  useEffect(()=>{
    const generation=++epoch.current;let live=true,timer;
    setSnapshot(null);setTarget(null);setPending(null);setError('');setNotice('');
    try{setRetryIntent(JSON.parse(sessionStorage.getItem('rh-scene-intent:'+sessionId) || 'null'));}catch{setRetryIntent(null);}
    if(!sessionId)return;
    void refreshCatalog();
    async function poll(){
      const start=performance.now();let value;
      try {value=await ctx.agnes.services.call('robot.scene',{});
        if(!live || generation!==epoch.current)return;
        setSnapshot(value);
        setPending(current=>{
          if(!current)return null;
          const state=value.status;
          if(state?.commands?.some(c=>c.command_id===current) || state?.current_command_id===current ||
            state?.status==='closed' || state?.status==='failed') return null;
          return current;
        });
      }catch{if(live)setError('场景观看暂不可用；不会自动启动或重跑。');}
      if(live)timer=setTimeout(poll,Math.max(20,(document.hidden?1500:value?.status?.status==='executing'?125:500)-(performance.now()-start)));
    }
    void poll();return()=>{live=false;clearTimeout(timer);};
  },[ctx,sessionId]);
  const selected=(catalog?.tasks || []).find(t=>t.task_id===taskId);
  useEffect(()=>{if(selected){if(!selected.policies.includes(policy))setPolicy(selected.policies[0]);
    if(!selected.allowed_seeds.includes(seed))setSeed(selected.allowed_seeds[0]);}},[selected,policy,seed]);
  const scene=snapshot?.status;
  const exact=!target || snapshot?.scene_id===target;
  const shown=exact?scene:null, frame=exact?snapshot?.frame:null;
  const currentTask=(catalog?.tasks || []).find(t=>t.task_id===shown?.request?.task_id);
  const stages=currentTask?.stages || [];
  const connected=snapshot?.connection==='connected' && snapshot?.runner_available && sessionId;
  const active=scene?.active===true;
  const idle=shown?.active && ['idle','exhausted'].includes(shown.status) && !shown.ownership_uncertain;
  async function effect(operation, retry=false, plan=null){
    if(retryIntent && !retry)return;
    if(actionLock.current)return;actionLock.current=true;setBusy(true);setError('');setNotice('');
    const generation=epoch.current;
    const args=retry?retryIntent.args:operation==='open'?{task_id:taskId,policy,seed,request_id:crypto.randomUUID()}:
      {scene_id:shown.scene_id,operation,revision:shown.revision,request_id:crypto.randomUUID(),
       ...(operation==='execute'?{stage_id:stageId}:{}),...(operation==='execute_plan'?{plan}:{})};
    const intent={operation,args};setRetryIntent(intent);
    try{sessionStorage.setItem('rh-scene-intent:'+sessionId,JSON.stringify(intent));}catch{/* Server idempotency remains authoritative. */}
    try{
      // Public effect command triggers Agnes permission dialog + durable journal.
      // Execution is separate from planning; no model request or query-based mutation.
      const reply=await ctx.commands.execute(operation==='open'?'robot.scene.open':'robot.scene.command',args);
      if(generation!==epoch.current)return;
      if(reply.http_status<200 || reply.http_status>=300){
        if(reply.http_status<500){setRetryIntent(null);try{sessionStorage.removeItem('rh-scene-intent:'+sessionId);}catch{}}
        throw new Error(reply.response?.error || '场景操作未接受');
      }
      setRetryIntent(null);try{sessionStorage.removeItem('rh-scene-intent:'+sessionId);}catch{}
      const value=reply.response;
      if(operation==='open')setTarget(value.scene_id);
      else if(value.command_id && operation!=='stop')setPending(value.command_id);
      setNotice(operation==='open'?'打开请求已接受：只加载仿真，不执行 VLA。':
        operation==='stop'?'停止请求已接受；会丢弃未执行动作，场景保留。':'操作已接受；请查看实际状态和结果。');
    }catch(reason){if(generation===epoch.current){
      // Host denied before dispatch: no remote effect exists to recover.
      if(/^client command is not authorized:/.test(reason?.message || '')){
        setRetryIntent(null);try{sessionStorage.removeItem('rh-scene-intent:'+sessionId);}catch{}
        setNotice('已取消授权，未提交场景操作。');
      }else setError(reason?.message || '请求结果未知；请刷新状态，不要连续重发。');
    }}
    finally{actionLock.current=false;if(generation===epoch.current)setBusy(false);}
  }
  async function loadVideo(command,requestedSceneId=shown?.scene_id){
    if(loadingVideo || !requestedSceneId)return;
    const generation=videoGeneration.current;setLoadingVideo(true);setError('');
    const sceneId=requestedSceneId,commandId=command.command_id;
    try{
      let offset=0,total;const parts=[];
      do{
        const value=await ctx.agnes.services.call('robot.scene.replay.chunk',{scene_id:sceneId,command_id:commandId,offset});
        if(generation!==videoGeneration.current)return;
        if(value.scene_id!==sceneId || value.command_id!==commandId)throw new Error('录像身份不匹配');
        const bytes=decodeChunk({...value,run_id:commandId},commandId,offset,total);
        total=value.total_bytes;offset=value.next_offset;parts.push(bytes);
      }while(offset<total);
      if(videoUrl.current)URL.revokeObjectURL(videoUrl.current);
      videoUrl.current=URL.createObjectURL(new Blob(parts,{type:'video/mp4'}));
      setReplay({url:videoUrl.current,commandId});
    }catch(reason){if(generation===videoGeneration.current)setError('操作录像暂不可用；不会重跑操作。');}
    finally{if(generation===videoGeneration.current)setLoadingVideo(false);}
  }
  return h('section',{className:'rh-scene-panel','aria-label':'交互场景'},
    h('h3',null,'交互场景'),
    h('p',{className:'rh-note'},'先打开场景，再连续执行操作。物体位置保留；按钮直接控制，不调用大模型。'),
    h('button',{type:'button',disabled:catalogBusy || !sessionId,onClick:refreshCatalog},catalogBusy?'刷新中…':'刷新场景目录'),
    catalogError && h('p',{role:'status',className:'rh-error'},catalogError),
    h('label',null,'场景',h('select',{'aria-label':'选择交互场景',value:taskId,disabled:busy || active,onChange:e=>setTaskId(e.target.value)},
      ...(catalog?.tasks || []).map(t=>h('option',{key:t.task_id,value:t.task_id},t.title)))),
    h('div',{className:'rh-config-choices'},h('label',null,'VLA',h('select',{'aria-label':'场景执行模型',value:policy,disabled:busy || active,onChange:e=>setPolicy(e.target.value)},
      ...(selected?.policies || []).map(p=>h('option',{key:p,value:p},p)))),
      h('label',null,'种子',h('select',{'aria-label':'场景种子',value:seed,disabled:busy || active,onChange:e=>setSeed(Number(e.target.value))},
        ...(selected?.allowed_seeds || []).map(s=>h('option',{key:s,value:s},s))))),
    h('button',{type:'button',disabled:!connected || catalog?.runs_enabled!==true || !selected?.configuration_available || active || busy || !!retryIntent,
      onClick:()=>effect('open')},busy?'提交中…':'打开场景'),
    notice && h('p',{role:'status',className:'rh-note'},notice),
    error && h('p',{role:'status',className:'rh-error'},error),
    retryIntent && !busy && h('div',null,h('p',{className:'rh-note'},'有未确认请求：保留原编号，不会自动重发。'),
      h('button',{type:'button',disabled:!connected,onClick:()=>effect(retryIntent.operation,true)},'重试同一请求（保留编号）')),
    target && !exact && h('p',{className:'rh-note'},'等待所选场景初始化，不显示其他场景的画面。'),
    shown && h('div',null,
      h('p',null,`${labels[shown.status] || shown.status} · 第 ${shown.revision ?? '—'} 版`),
      h(Cameras,{frame,runId:shown.scene_id+':'+shown.revision}),
      h('p',{className:'rh-note'},`场景控制步 ${shown.steps ?? 0} · 剩余 ${shown.remaining_steps ?? '—'} · VLA ${shown.vla_steps ?? 0} / 工具 ${shown.tool_steps ?? 0}`),
      snapshot?.connection!=='connected' && h('p',{className:'rh-error'},'连接异常：保留画面非实时，操作暂不可用。'),
      shown.status==='executing' && h('p',{className:'rh-note'},`正在执行 ${shown.current_stage_id ?? '—'}. ${stages.find(s=>s.id===shown.current_stage_id)?.instruction || ''}；推理/路径搜索期间画面可能暂缓更新。`),
      shown.plan_stage_count>1 && h('p',null,`自动阶段进度 ${shown.plan_stage_index ?? '—'} / ${shown.plan_stage_count}`),
      h(PlanPanel,{ctx,sessionId,scene:shown,task:currentTask,blocked:!connected||busy||!!retryIntent||!!pending||!idle,
        onExecute:plan=>effect('execute_plan',false,plan)}),
      h('label',null,'下一项操作',h('select',{'aria-label':'选择场景操作',value:stageId,disabled:busy || !idle || pending,onChange:e=>setStageId(Number(e.target.value))},
        ...stages.map(s=>h('option',{key:s.id,value:s.id},`${s.id}. ${s.instruction}`)))),
      h('p',{className:'rh-note'},stages.find(s=>s.id===stageId)?.instruction || ''),
      h('div',{className:'rh-scene-actions'},
        h('button',{type:'button',disabled:!connected || !idle || shown.status==='exhausted' || busy || retryIntent || pending || !stages.some(s=>s.id===stageId),onClick:()=>effect('execute')},'执行选中操作'),
        h('button',{type:'button',disabled:!connected || shown.status!=='executing' || busy || retryIntent,onClick:()=>effect('stop')},'停止当前操作'),
        h('button',{type:'button',disabled:!connected || !idle || busy || retryIntent || pending,onClick:()=>effect('reset')},'重置整个场景'),
        h('button',{type:'button',disabled:!connected || !idle || busy || retryIntent || pending,onClick:()=>effect('close')},'关闭场景')),
      shown.error && h('p',{className:'rh-error'},shown.error),
      h('p',{className:'rh-note'},'选中操作沿用原阶段指令、判据和阶段后复位。重置整个场景会恢复初始物体布局；关闭不卸载常驻模型。空闲 30 分钟自动关闭仿真。'),
      h('details',null,h('summary',null,'本场景操作记录'),
        h('ol',null,...(shown.commands || []).map(c=>h('li',{key:c.command_id},
          c.instruction || c.status,' · 子目标：',success(c.stage_completed),
          ' · 完整场景原生结果：',success(c.native_success),' · ',c.steps ?? 0,' 步',
          c.termination_reason && h('small',null,c.termination_reason),
          c.source_stage_ids?.length>1 && h('small',null,`已达成技能：${c.completed_source_stage_ids?.join(', ') || '无'} / 计划 ${c.source_stage_ids.join(', ')}`),
          c.video_size_bytes>0 && h('button',{type:'button',disabled:loadingVideo,onClick:()=>loadVideo(c)},'回放操作录像'))))),
      replay && h('div',null,h('video',{controls:true,src:replay.url,'aria-label':'场景操作录像'}),
        h('a',{href:replay.url,download:`scene_${replay.commandId.slice(-8)}.mp4`},'下载操作录像')),
      h('footer',null,shown.scene_id,' · 页面关闭不会立即关闭场景')),
    h('details',null,h('summary',null,'历史场景操作录像'),
      h('ol',null,...(snapshot?.scenes || []).flatMap(row=>(row.commands || []).filter(c=>c.video_size_bytes>0).map(c=>
        h('li',{key:c.command_id},c.instruction,' · 子目标：',success(c.stage_completed),' · ',row.scene_id.slice(-8),
          h('button',{type:'button',disabled:loadingVideo,onClick:()=>loadVideo(c,row.scene_id)},'回放这项操作')))))));
}
