// Session-bound UI intentions. Browser cache is display/deduplication, NEVER authority.
export const RUN = /^run_[a-f0-9]{32}$/;
const SUBMIT = /^ui_[a-f0-9]{32}$/;
export const BUSY = new Set(['submitted', 'awaiting_approval', 'startup_unconfirmed', 'stopping', 'unknown']);
export const LABELS = {idle:'未提交', submitted:'启动待确认', awaiting_approval:'待审批',
  rejected:'审批拒绝', startup_unconfirmed:'启动待确认', starting:'初始化', running:'执行中',
  finished:'已结束', stopped:'已停止', stopping:'请求停止待确认', failed:'执行错误', unknown:'进程状态待核实', mismatch:'参数不一致 · 待核实'};
const parse = text => {try {return JSON.parse(text);} catch {return null;}};
const argsEqual = (a, b) => a && b && ['task_id','policy','seed'].every(k=>a[k]===b[k]);

export function commandText(op, args, id) {
  if (!SUBMIT.test(id)) throw new Error('Invalid UI command identity');
  const params = op === 'start' ? {...args, submission_id:id} : op === 'stop' ? {run_id:args.run_id} : {};
  const tool = {start:'robot_start_run', status:'robot_get_run', stop:'robot_stop_run'}[op];
  if (!tool) throw new Error('Unsupported operation');
  return `机器人控制台请求 ${id}。请只调用 ${tool}，参数严格为 ${JSON.stringify(params)}。` +
    (op === 'status' ? '只读核对本会话最近未确认或拥有的回合，不启动新任务。' :
    '只提交一次，保留正常Host审批。审批中请核对实际任务、策略、seed或run_id；拒绝后不要再申请。') +
    '只有真实工具回执才代表提交结果；不要用口头回复表示已运行。若连接中断，先查询原请求，不生成新启动身份。';
}

export function timelineState(timeline, intent = null) {
  const nodes = timeline?.nodes || [];
  const tools = nodes.filter(n=>n.kind==='tool' && ['robot_start_run','robot_get_run','robot_stop_run'].includes(n.name));
  let state = intent?.state || 'idle', run_id = null, owned = false, receipt = null;
  let relevant = false, mismatch=false;
  if(intent && intent.op!=='start') {
    for(const node of tools) {
      if(node.name!=='robot_start_run' || node.seq>(intent.before_seq||0))continue;
      const prior=parse(node.resultPreview);
      if([200,202].includes(prior?.http_status) && RUN.test(prior.response?.run_id||'') && prior.response.owned_by_session===true) {
        run_id=prior.response.run_id;owned=true;receipt=prior.response;
      }
    }
  }
  for (const node of tools) {
    const args = parse(node.argsPreview);
    if (intent && node.seq <= (intent.before_seq || 0) && args?.submission_id !== intent.command_id) continue;
    if (intent?.op === 'start' && (BUSY.has(intent.state) || intent.state==='mismatch') && node.name === 'robot_start_run' &&
        (!argsEqual(args, intent.args) || args?.submission_id !== intent.command_id)) {
      state='mismatch'; mismatch=true; relevant=true; continue;
    }
    if(intent?.op==='stop' && node.name==='robot_stop_run' && args?.run_id!==intent.args.run_id) {
      state='mismatch';mismatch=true;continue;
    }
    if (node.name==='robot_start_run' || node.name==='robot_stop_run') {
      relevant=true;
      if(node.name==='robot_start_run' && ['awaiting_approval','planned','running','failed','cancelled'].includes(node.status)) {
        run_id=null;owned=false;receipt=null; // Never display an older receipt for a new pending start.
      }
      if (node.status==='awaiting_approval') {state='awaiting_approval';continue;}
      if (node.status==='planned' || node.status==='running') {state=node.name==='robot_stop_run'?'stopping':'startup_unconfirmed';continue;}
      if (node.status==='failed' || node.status==='cancelled') {
        // A denied/cancelled native approval has no runner receipt.
        const nextTool=tools.find(n=>n.seq>node.seq)?.seq || Infinity;
        const nearby=nodes.filter(n=>n.kind==='approval' && n.seq>node.seq && n.seq<nextTool);
        const denied=nearby.some(n=>n.decision && !String(n.decision.verdict).startsWith('allowed'));
        if (denied) {state='rejected';continue;}
      }
    }
    const value = parse(node.resultPreview);
    if (!value || typeof value !== 'object') continue;
    relevant=true;
    const response=value.response || {};
    if ([200,202].includes(value.http_status) && RUN.test(response.run_id || '')) {
      receipt=response;run_id=response.run_id;owned=response.owned_by_session===true;
      state=response.ownership_uncertain===true || response.status==='interrupted' ? 'unknown' :
        response.status==='stopping'?'stopping':response.status==='stopped'?'stopped':
        ['finished','failed','start_failed'].includes(response.status) ? response.status==='finished'?'finished':'failed':
        response.status==='running'?'running':'starting';
    } else if (value.http_status>=400 && !response.outcome_unknown) {
      state='failed';
    } else if (response.status==='no_session_run') {
      state='idle';run_id=null;owned=false;
    } else if (response.status==='startup_unconfirmed' || value.error) {
      state='startup_unconfirmed';run_id=null;owned=false;
    }
  }
  if (intent?.op==='start' && !relevant && timeline?.opState?.data?.phase==='idle') state='startup_unconfirmed';
  return mismatch ? {state:'mismatch',run_id:null,owned:false,receipt:null} : {state,run_id,owned,receipt};
}

export class SessionOperations {
  constructor(sessionId, storage, onChange = ()=>{}) {
    this.sessionId=sessionId;this.storage=storage;this.onChange=onChange;this.key='robot-harness/intent/'+sessionId;
    this.intent=parse(storage.getItem(this.key));this.busy=false;this.queryId=null;
    if (this.intent && (!SUBMIT.test(this.intent.command_id || '') || this.intent.session_id!==sessionId)) this.intent=null;
  }
  save(value) {this.storage.setItem(this.key,JSON.stringify(value));this.intent=value;this.onChange(value);}
  async submit(op, args, session, timeline) {
    if (!session || session.id!==this.sessionId || typeof session.followUp!=='function') throw new Error('当前宿主会话不可用');
    const persisted=parse(this.storage.getItem(this.key));
    if(persisted?.session_id===this.sessionId && SUBMIT.test(persisted.command_id || '')) this.intent=persisted;
    if (this.busy || (op==='start' && this.intent && (BUSY.has(this.intent.state)||['starting','running','mismatch'].includes(this.intent.state)))) throw new Error('请求尚未确认；先查询原请求');
    const id='ui_'+crypto.randomUUID().replaceAll('-','');
    const state=op==='start'?'submitted':op==='stop'?'stopping':'startup_unconfirmed';
    const intent=op==='status' && this.intent ? this.intent :
      {session_id:this.sessionId,command_id:id,op,args:{...args},before_seq:timeline?.upto || 0,state};
    // Persistence before supported SDK submission; storage failure prevents sending.
    if(op==='status') this.queryId=id;
    this.save(intent);this.busy=true;
    try {await session.followUp(commandText(op,args,id),{commandId:id});}
    catch {if(op!=='status')this.save({...intent,state:op==='stop'?'stopping':'startup_unconfirmed'});throw new Error('会话提交结果未确认；请查询状态，不要重复运行');}
    finally {this.busy=false;}
    return intent;
  }
  reconcile(timeline) {
    const status=timelineState(timeline,this.intent);
    if (this.intent && status.state!==this.intent.state) this.save({...this.intent,state:status.state});
    return status;
  }
}
