import { constants, closeSync, fstatSync, openSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { isAbsolute, join } from 'node:path';

const RUN = /^run_[a-f0-9]{32}$/;
const configurationPath = join(homedir(), '.config/robot-harness/agnes-viewer.json');

function privateFile(path, maxBytes) {
  const fd = openSync(path, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
  try {
    const stat = fstatSync(fd);
    if (!stat.isFile() || stat.uid !== process.getuid() || (stat.mode & 0o077) !== 0 || stat.size > maxBytes)
      throw new Error('Private integration configuration is unavailable');
    return readFileSync(fd, 'utf8');
  } finally { closeSync(fd); }
}

export function validateInput(op, input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Invalid observer request');
  const allowed = op === 'tasks' || op === 'scene' ? [] : op === 'observation' ? ['run_id'] : op === 'replay_chunk' ? ['run_id', 'offset'] : op==='scene_replay_chunk'?['scene_id','command_id','offset']:null;
  if (!allowed || Object.keys(input).some(k => !allowed.includes(k))) throw new Error('Read-only observer request required');
  if (input.run_id != null && (typeof input.run_id !== 'string' || !RUN.test(input.run_id))) throw new Error('Invalid run identifier');
  if (op === 'replay_chunk' && (!RUN.test(input.run_id || '') || !Number.isSafeInteger(input.offset) || input.offset < 0 || input.offset > 64 * 1024 * 1024))
    throw new Error('Invalid recording offset');
  if(op==='scene_replay_chunk' && (!/^scene_[a-f0-9]{32}$/.test(input.scene_id || '') || !/^cmd_[a-f0-9]{32}$/.test(input.command_id || '') ||
    !Number.isSafeInteger(input.offset) || input.offset<0 || input.offset>64*1024*1024))throw new Error('Invalid scene recording');
  return {op, ...input};
}

export function createReader({configPath = configurationPath, fetcher = fetch} = {}) {
  const request = createLocalRequest({configPath, fetcher});
  return async function read(op, input, signal) {
    const payload = validateInput(op, input);
    return request('/internal/read', payload, signal);
  };
}

export function validateSceneInput(op, input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Invalid scene input');
  const fields = op === 'open' ? ['task_id','policy','seed','request_id'] :
    op === 'command' ? ['scene_id','operation','revision','request_id','stage_id','plan'] : null;
  if (!fields || Object.keys(input).some(k=>!fields.includes(k)) ||
      typeof input.request_id !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(input.request_id)) throw new Error('Invalid scene request identity');
  if(op==='open') {
    if(typeof input.task_id!=='string' || !/^[A-Za-z0-9._-]{1,128}$/.test(input.task_id) ||
      !['atomic','internw0'].includes(input.policy) || !Number.isSafeInteger(input.seed) || input.seed<0) throw new Error('Invalid scene selection');
  } else if(!/^scene_[a-f0-9]{32}$/.test(input.scene_id || '') || !Number.isSafeInteger(input.revision) || input.revision<1 ||
    !['execute','execute_plan','stop','reset','close'].includes(input.operation) ||
    ((input.operation==='execute') !== ('stage_id' in input)) ||
    ((input.operation==='execute_plan') !== ('plan' in input)) ||
    ('stage_id' in input && (!Number.isSafeInteger(input.stage_id) || input.stage_id<1 || input.stage_id>32))) throw new Error('Invalid scene operation');
  if(input.plan) {
    if(Object.keys(input.plan).some(k=>!['planning_request_id','goal','stage_ids','scene_step'].includes(k)))throw new Error('Invalid plan field');
    validatePlanInput({...input.plan,scene_id:input.scene_id,revision:input.revision});
  }
  return {...input};
}

export function validatePlanInput(input) {
  const fields=['planning_request_id','scene_id','revision','scene_step','goal','stage_ids'];
  if(!input || typeof input!=='object' || Array.isArray(input) || Object.keys(input).some(k=>!fields.includes(k)) ||
    fields.some(k=>!(k in input)) || !/^plan_[a-f0-9]{32}$/.test(input.planning_request_id || '') ||
    !/^scene_[a-f0-9]{32}$/.test(input.scene_id || '') || !Number.isSafeInteger(input.revision) || input.revision<1 ||
    !Number.isSafeInteger(input.scene_step) || input.scene_step<0 || typeof input.goal!=='string' ||
    input.goal.trim().length<1 || input.goal.length>2000 || !Array.isArray(input.stage_ids) ||
    input.stage_ids.length<1 || input.stage_ids.length>32 || new Set(input.stage_ids).size!==input.stage_ids.length ||
    input.stage_ids.some(i=>!Number.isSafeInteger(i)||i<1||i>32)) throw new Error('Invalid bounded scene plan');
  return {...input,stage_ids:[...input.stage_ids]};
}

export function createSceneController(options = {}) {
  const request = createLocalRequest(options);
  return (op, input, context) => {
    const checked = validateSceneInput(op, input);
    if (!context?.actor?.id || typeof context.actor.id !== 'string') throw new Error('Authorized scene principal required');
    // Host-supplied actor, not a browser-supplied owner or user text.
    checked.owner = createHash('sha256').update('agnes-scene-principal:' + context.actor.id).digest('hex');
    return request('/internal/scene-effect', {op, input:checked}, context.signal);
  };
}

function createLocalRequest({configPath = configurationPath, fetcher = fetch} = {}) {
  return async (path, payload, signal) => {
    try {
      const config = JSON.parse(privateFile(configPath, 4096));
      if (Object.keys(config).some(k => !['port', 'privateDirectory'].includes(k)) ||
          !Number.isInteger(config.port) || config.port < 1024 || config.port > 65535 ||
          typeof config.privateDirectory !== 'string' || !isAbsolute(config.privateDirectory)) throw new Error('Invalid local configuration');
      const state = JSON.parse(privateFile(join(config.privateDirectory, 'server_state.json'), 4096));
      if (state.port !== config.port || typeof state.instance_id !== 'string') throw new Error('Invalid local instance');
      const origin = 'http://127.0.0.1:' + config.port;
      const deadline = AbortSignal.any([...(signal ? [signal] : []), AbortSignal.timeout(25_000)]);
      const health = await fetcher(origin + '/health', {signal: deadline, redirect: 'error'});
      if (!health.ok || (await health.json()).instance_id !== state.instance_id) throw new Error('Wrong local service');
      const token = privateFile(join(config.privateDirectory, 'admin.token'), 128).trim();
      if (!/^[A-Za-z0-9_-]{43}$/.test(token)) throw new Error('Invalid local credential');
      const response = await fetcher(origin + path, {method: 'POST', redirect: 'error', signal: deadline,
        headers: {'Content-Type': 'application/json', Authorization: 'Bearer ' + token}, body: JSON.stringify(payload)});
      const reader = response.body.getReader(); let length = 0; const chunks = [];
      try {
        while (true) {
          const {done, value} = await reader.read(); if (done) break;
          length += value.byteLength; if (length > 950_000) throw new Error('Observer response exceeds limit');
          chunks.push(value);
        }
      } finally { await reader.cancel().catch(() => {}); }
      if (!response.ok) throw new Error('Observer unavailable');
      return JSON.parse(Buffer.concat(chunks).toString('utf8'));
    } catch {
      // Never propagate request headers, credentials, private paths or raw fetch errors.
      throw new Error(path === '/internal/read' ? '机器人观看服务暂不可用；不会启动、停止或重跑机器人。' :
        '场景操作的结果暂未确认；请刷新状态，不要重复提交新请求。');
    }
  };
}
