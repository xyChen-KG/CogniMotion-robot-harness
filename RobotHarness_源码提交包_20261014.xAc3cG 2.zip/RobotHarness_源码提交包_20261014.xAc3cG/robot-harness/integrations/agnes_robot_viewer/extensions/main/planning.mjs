import {validatePlanInput} from './backend.mjs';

const K=Symbol.for('TypeBox.Kind');
const str=options=>({[K]:'String',type:'string',...options});
const int=options=>({[K]:'Integer',type:'integer',...options});
const object=properties=>({[K]:'Object',type:'object',properties,required:Object.keys(properties),additionalProperties:false});
const scene=str({pattern:'^scene_[a-f0-9]{32}$'});
const readMeta={isReadOnly:true,isDestructive:false,isConcurrencySafe:true,isOpenWorld:false,
  replay:'safe',costHint:{wallMs:25000},deferLoading:false,requiresApproval:'never'};

// Planning is read-only. Only an explicit journaled browser effect can move the robot.
export function registerPlanning(api, read) {
  async function context(sceneId, signal) {
    const [snapshot,catalog]=await Promise.all([read('scene',{},signal),read('tasks',{},signal)]);
    const state=snapshot.status;
    if(snapshot.connection!=='connected' || !snapshot.runner_available || snapshot.scene_id!==sceneId ||
      !state?.active || state.status!=='idle' || state.ownership_uncertain || state.plan_protocol!==1)
      throw new Error('Select an idle planning-enabled scene; close and reopen older scenes first.');
    const task=catalog.tasks?.find(t=>t.task_id===state.request.task_id);
    if(!catalog.runner_available || !task?.configuration_available || !Array.isArray(task.stages))
      throw new Error('Registered skill catalog unavailable.');
    return {snapshot,state,task};
  }
  const define=(name,description,parameters,execute)=>api.registerTool({name,description,parameters,meta:readMeta,
    async execute(input,ctx) {
      try {return await execute(input,ctx);}
      catch(error) {const structured={error:'planning_refused',message:error.message};
        return {content:[{type:'text',text:JSON.stringify(structured)}],structured,isError:true};}
    }});
  define('robot_scene_plan_context',
    'Read the currently open idle LIBERO scene and exact registered VLA skills, checks and shared budgets. '+
    'Use this before decomposing a long user goal. No motion or model loading. Historical completions are not live physical proof.',
    {[K]:'Object',type:'object',properties:{scene_id:scene,include_image:{[K]:'Boolean',type:'boolean'}},required:['scene_id'],additionalProperties:false},
    async(input,ctx)=>{
      if(!input || Object.keys(input).some(k=>!['scene_id','include_image'].includes(k)) ||
        !/^scene_[a-f0-9]{32}$/.test(input.scene_id || '') ||
        ('include_image' in input && typeof input.include_image!=='boolean'))throw new Error('Invalid scene selection.');
      const {snapshot,state,task}=await context(input.scene_id,ctx?.signal);
      const structured={scene_id:state.scene_id,revision:state.revision,scene_step:state.steps,
        task_id:task.task_id,policy:state.request.policy,seed:state.request.seed,
        skills:task.stages,budget:task.budget,remaining_steps:state.remaining_steps,
        native_success:state.native_success,
        recent_operations:(state.commands || []).slice(-4).map(c=>({stage_ids:c.source_stage_ids || [c.stage_id],
          achieved_once:c.stage_completed,native_success:c.native_success})),
        rules:'Choose only registered stage IDs, each at most once. Preserve exact instructions/checkers/reset tools. '+
          'Respect object source-location dependencies and user ordering. Decline unsupported goals; do not call robot_start_run. '+
          'Use robot_scene_plan to return a proposed plan, then wait for the human Execute plan button. No automatic recovery/replanning. '+
          'Subset milestones and full-scene final native_success are different outcomes. Historical successes may no longer hold.'};
      const images=[];
      const frame=snapshot.frame;
      structured.image_status='not_requested';
      if(input.include_image===true) {
        if(!frame?.image_base64 || frame.image_base64.length>750000 ||
          !['image/jpeg','image/png'].includes(frame.image_mime) || !ctx?.artifacts?.put)
          throw new Error('Current image or Host artifact storage unavailable; no image was inspected.');
        // ToolResult accepts Host artifact references, NOT provider {data,mimeType} blocks.
        const bytes=Buffer.from(frame.image_base64,'base64');
        const ref=await ctx.artifacts.put(bytes,{mime:frame.image_mime,name:'robot-scene-current'});
        structured.image_status='host_artifact';
        structured.image_step=frame.scene_step;
        images.push({type:'image',ref,mime:frame.image_mime});
      }
      const content=[{type:'text',text:JSON.stringify(structured)},...images];
      return {structured,content};
    });
  define('robot_scene_plan',
    'Return a structurally validated proposed stage table for a long goal in the OPEN scene. '+
    'Read robot_scene_plan_context first. Supply exact scene revision/step, original user goal and planning_request_id. '+
    'stage_ids is the ordered list of registered skill IDs. Cannot invent instructions, objects, checks or budgets. '+
    'This does NOT execute anything or prove the plan semantically fulfils the goal; human review/execution remains separate.',
    object({planning_request_id:str({pattern:'^plan_[a-f0-9]{32}$'}),scene_id:scene,revision:int({minimum:1}),
      scene_step:int({minimum:0}),goal:str({minLength:1,maxLength:2000}),
      stage_ids:{[K]:'Array',type:'array',items:int({minimum:1,maximum:32}),minItems:1,maxItems:32,uniqueItems:true}}),
    async(input,ctx)=>{
      const checked=validatePlanInput(input),{state,task}=await context(checked.scene_id,ctx?.signal);
      if(state.revision!==checked.revision || state.steps!==checked.scene_step)
        throw new Error('Scene changed during planning; no plan accepted.');
      if(checked.stage_ids.some(i=>!task.stages.some(s=>s.id===i)))throw new Error('Skill is not registered in this scene.');
      const structured={kind:'robot_scene_plan/v1',status:'validated',...checked,task_id:task.task_id,
        policy:state.request.policy,seed:state.request.seed};
      return {structured,content:[{type:'text',text:JSON.stringify(structured)}]};
    });
}
