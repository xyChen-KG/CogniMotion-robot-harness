import test from 'node:test';
import assert from 'node:assert/strict';
import {registerPlanning} from '../extensions/main/planning.mjs';
import {validateSceneInput} from '../extensions/main/backend.mjs';
import {planReceipt,executablePlan,planningPrompt} from '../extensions/main/client/plan-state.mjs';
import {readSessionProjection,sessionIsBusy} from '../extensions/main/client/session-projection.mjs';
const scene_id='scene_'+'a'.repeat(32),planning_request_id='plan_'+'b'.repeat(32);
const scene={scene_id,active:true,status:'idle',revision:2,steps:10,plan_protocol:1,
 request:{task_id:'same',policy:'internw0',seed:47}};
const task={task_id:'same',configuration_available:true,stages:[{id:1,instruction:'Put cheese in bowl.',max_steps:400},
 {id:2,instruction:'Put wine on cabinet.',max_steps:400}]};
const input={scene_id,planning_request_id,revision:2,scene_step:10,goal:'Put cheese in bowl then wine on cabinet.',stage_ids:[1,2]};
const intent={...input,before_seq:4};
const fixture=(frame)=>{const tools=new Map(),ops=[];
 registerPlanning({registerTool:t=>tools.set(t.name,t)},async(op)=>{ops.push(op);
 return op==='scene'?{connection:'connected',runner_available:true,scene_id,status:scene,frame}:
 {runner_available:true,tasks:[task]};});return {tools,ops};};

test('model proposes exact catalog IDs using read-only tools, never executes or loads a model',async()=>{
 const {tools,ops}=fixture();
 const context=await tools.get('robot_scene_plan_context').execute({scene_id},{});
 assert.equal(context.structured.skills[1].instruction,task.stages[1].instruction);
 const result=await tools.get('robot_scene_plan').execute(input,{});
 assert.equal(result.structured.status,'validated');assert.deepEqual(result.structured.stage_ids,[1,2]);
 assert.ok(ops.every(o=>['scene','tasks'].includes(o)));
 const command={scene_id,operation:'execute_plan',revision:2,request_id:'one',
 plan:{planning_request_id,goal:input.goal,stage_ids:[1,2],scene_step:10}};
 assert.deepEqual(validateSceneInput('command',command),command);
 assert.throws(()=>validateSceneInput('command',{...command,plan:{...command.plan,instruction:'invented'}}));
});

test('scene images use Host artifact ToolResult references, not provider base64 blocks',async()=>{
 const bytes=Buffer.from('synthetic'),frame={image_mime:'image/jpeg',image_base64:bytes.toString('base64'),scene_step:10};
 const {tools}=fixture(frame),tool=tools.get('robot_scene_plan_context');
 const text=await tool.execute({scene_id},{});assert.equal(text.content.length,1);
 const ref={sha256:'c'.repeat(64),size:bytes.length,mime:'image/jpeg'};
 const result=await tool.execute({scene_id,include_image:true},{artifacts:{put:async(data,meta)=>{
   assert.deepEqual(data,bytes);assert.equal(meta.mime,'image/jpeg');return ref;
 }}});
 assert.deepEqual(result.content[1],{type:'image',ref,mime:'image/jpeg'});
 assert.equal(result.structured.image_status,'host_artifact');
 assert.equal('data' in result.content[1],false);
 assert.equal((await tool.execute({scene_id,include_image:true},{})).isError,true);
});

test('unknown/duplicate skills, invented checks, changed scene and superseded protocol fail closed',async()=>{
 const {tools}=fixture(),tool=tools.get('robot_scene_plan');
 for(const change of [{stage_ids:[3]},{stage_ids:[1,1]},{scene_step:9},{revision:1},{checker:'fake'},{stage_ids:[]}])
  assert.equal((await tool.execute({...input,...change},{})).isError,true);
 const original=scene.plan_protocol;scene.plan_protocol=null;
 assert.equal((await tool.execute(input,{})).isError,true);scene.plan_protocol=original;
});

test('oral/model text or cached IDs are not receipts; exact request and scene bind execution',async()=>{
 const {tools}=fixture();const receipt=(await tools.get('robot_scene_plan').execute(input,{})).structured;
 const node={kind:'tool',name:'robot_scene_plan',status:'completed',seq:5,resultPreview:JSON.stringify(receipt)};
 assert.equal(planReceipt({nodes:[{...node,kind:'assistant'}]},intent),null);
 assert.equal(planReceipt({nodes:[{...node,seq:4}]},intent),null);
 assert.equal(planReceipt({nodes:[{...node,resultPreview:JSON.stringify({...receipt,goal:'other'})}]},intent),null);
 const plan=planReceipt({nodes:[node]},intent);assert.equal(executablePlan(plan,scene,task),true);
 assert.equal(executablePlan(plan,{...scene,steps:11},task),false);
 assert.equal(executablePlan(plan,{...scene,revision:3},task),false);
 assert.equal(executablePlan(plan,{...scene,commands:[{planning_request_id:plan.planning_request_id}]},task),false);
 const conflicting={...node,seq:6,resultPreview:JSON.stringify({...receipt,stage_ids:[2,1]})};
 assert.equal(planReceipt({nodes:[node,conflicting]},intent).conflict,true);
 assert.match(planningPrompt(intent),/PLANNING ONLY/);assert.match(planningPrompt(intent),/Do not start runs/);
});

test('long sessions use bounded public SDK projections and direct opState phases',async()=>{
 let calls=[];
 const timeline={opState:{phase:'running'},nodes:[]};
 const ctx={session:{handle:{projectUIOpening:async options=>{calls.push(options);return {timeline};}},
  projection:{read:()=>assert.fail('Must not clone an entire long session')}}};
 assert.equal((await readSessionProjection(ctx)).value,timeline);
 assert.deepEqual(calls,[{surface:'web',maxNodes:128,maxBytes:262144}]);
 assert.equal(sessionIsBusy(timeline),true);assert.equal(sessionIsBusy({opState:null}),false);
 assert.equal(sessionIsBusy({opState:{data:{phase:'idle'}}}),false);
});
