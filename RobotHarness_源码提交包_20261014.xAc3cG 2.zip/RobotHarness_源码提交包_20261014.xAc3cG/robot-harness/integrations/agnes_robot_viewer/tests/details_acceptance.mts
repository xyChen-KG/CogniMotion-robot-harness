// Render real read-only components against synthetic evidence; no model, SSH or GPU.
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const repo='/opt/agnes-harness';
const require=createRequire(repo+'/packages/web-client/package.json');
const React=require('react'),{renderToStaticMarkup}=require('react-dom/server');
const {build}=createRequire(repo+'/packages/cli/package.json')('esbuild');
const output=await build({stdin:{contents:'export * from "'+process.cwd()+'/integrations/agnes_robot_viewer/extensions/main/client/run-details.js";',resolveDir:process.cwd(),loader:'js'},
  bundle:true,write:false,format:'esm',platform:'node',plugins:[{name:'shared-react',setup(b){b.onResolve({filter:/^react$/},()=>({path:pathToFileURL(require.resolve('react')).href,external:true}));}}]});
const {RunDetails,RunHistory,stageLabel}=await import('data:text/javascript;base64,'+Buffer.from(output.outputFiles[0].text).toString('base64'));
const run='run_'+'a'.repeat(32),other='run_'+'b'.repeat(32);
const initial=renderToStaticMarkup(React.createElement(RunDetails,{snapshot:null,runId:undefined}));
assert.ok(initial.includes('最终 native_success：未知'));
assert.ok(initial.includes('未选择'));
const stage={id:1,instruction:'Turn on the stove.',achieved_once:true,current_satisfied:false,checks:[{predicate:'released',satisfied:false}]};
const snapshot={connection:'connected',runner_available:true,status:{active:false},details:{run_id:run,details_available:true,
  stages:[stage],native_success:true,workflow_success:true,final_result_available:true,termination_reason:'final_stage_native_success',
  log_summary:{entries:[{event:'tool_end',step:9,stage_id:1,tool:'reset_to_stage_start',status:'reached'}],truncated:true}}};
const html=renderToStaticMarkup(React.createElement(RunDetails,{snapshot,runId:run}));
for(const text of ['历史已完成','条件最终记录：否','最终 native_success：成功','最终 workflow_success：成功','最终原生任务成功','摘要已截断'])assert.ok(html.includes(text),text);
const wrong=renderToStaticMarkup(React.createElement(RunDetails,{snapshot,runId:other}));assert.ok(!wrong.includes('Turn on the stove.'));
assert.ok(wrong.includes('最终 native_success：未知'));
const stale=renderToStaticMarkup(React.createElement(RunDetails,{snapshot:{...snapshot,connection:'reconnecting'},runId:run}));
assert.ok(stale.includes('未知（断线）'));assert.ok(stale.includes('保留记录非实时'));
assert.equal(stageLabel({id:2,achieved_once:false},2,false),'本阶段未完成');
assert.equal(stageLabel({id:2,achieved_once:false},2,true,true),'状态待核实');
const history=renderToStaticMarkup(React.createElement(RunHistory,{runs:[{run_id:run,request:{task_id:'five',policy:'atomic',seed:47},status:'finished'}],runId:run,onSelect:()=>{}}));
assert.ok(history.includes('查看历史不会获得停止权限'));assert.ok(!history.includes('请求停止'));
console.log(JSON.stringify({stage_history_vs_current:true,native_independent:true,wrong_run_hidden:true,stale_unknown:true,history_readonly:true,model_calls:0,gpu_runs:0}));
