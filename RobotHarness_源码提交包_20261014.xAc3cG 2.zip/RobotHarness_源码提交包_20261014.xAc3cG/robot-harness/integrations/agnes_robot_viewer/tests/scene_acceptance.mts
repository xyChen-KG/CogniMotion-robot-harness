// Real mounted scene panel; fake Host effect boundary. No SSH/model/GPU.
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const repo='/opt/agnes-harness';
const require=createRequire(repo+'/packages/web-client/package.json');
const rootRequire=createRequire(repo+'/package.json');
const {Window}=rootRequire('happy-dom'),win=new Window();
for(const k of ['window','document','HTMLElement','Event','MouseEvent'])globalThis[k]=k==='window'?win:win[k];
const React=require('react'),{createRoot}=require('react-dom/client'),{flushSync}=require('react-dom');
const {build}=createRequire(repo+'/packages/cli/package.json')('esbuild');
const code=await build({stdin:{contents:'export {ScenePanel} from "'+process.cwd()+'/integrations/agnes_robot_viewer/extensions/main/client/scene-panel.js";',resolveDir:process.cwd(),loader:'js'},
 bundle:true,write:false,format:'esm',platform:'node',plugins:[{name:'shared-react',setup(b){b.onResolve({filter:/^react$/},()=>({path:pathToFileURL(require.resolve('react')).href,external:true}));}}]});
const {ScenePanel}=await import('data:text/javascript;base64,'+Buffer.from(code.outputFiles[0].text).toString('base64'));
const id='scene_'+'a'.repeat(32),command='cmd_'+'b'.repeat(32);
const task={task_id:'same_five_stage',title:'same/five_stage',policies:['internw0'],allowed_seeds:[47],configuration_available:true,
 stages:[{id:1,instruction:'Put the cheese in the bowl.'},{id:2,instruction:'Put the wine on the cabinet.'}]};
let scene=null,calls=[],release;
const ctx={session:{projection:{subscribe:()=>()=>{},read:async()=>({status:'available',value:{nodes:[],upto:0}})}},agnes:{services:{call:async(name)=>name==='robot.tasks'?{tasks:[task],runs_enabled:true,runner_available:true}:
 {connection:'connected',runner_available:true,scene_id:scene?.scene_id,status:scene,scenes:scene?[scene]:[]}}},
 commands:{execute:async(name,input)=>{calls.push({name,input});
 if(name==='robot.scene.open'){scene={scene_id:id,revision:1,request:{task_id:task.task_id,policy:'internw0',seed:47},active:true,status:'idle',commands:[],steps:0};
   return{http_status:202,response:{scene_id:id}};}
 return await new Promise(resolve=>{release=()=>{scene={...scene,status:'executing',current_command_id:command};resolve({http_status:202,response:{scene_id:id,command_id:command}});};});}}};
const container=document.createElement('div');document.body.append(container);const root=createRoot(container);
const button=text=>[...container.querySelectorAll('button')].find(b=>b.textContent===text);
const settle=ms=>new Promise(r=>setTimeout(r,ms));
try{
 flushSync(()=>root.render(React.createElement(ScenePanel,{ctx,sessionId:'s1',Cameras:()=>React.createElement('div',null,'cameras')})));
 await settle(40);assert.equal(calls.length,0);assert.equal(button('打开场景').disabled,false);
 flushSync(()=>button('打开场景').click());await settle(600);
 assert.equal(calls.length,1);assert.equal(calls[0].name,'robot.scene.open');assert.equal(calls[0].input.policy,'internw0');
 assert.ok(container.textContent.includes('等待指令'));assert.equal(button('打开场景').disabled,true);
 const select=container.querySelector('[aria-label="选择场景操作"]');select.value='2';
 flushSync(()=>select.dispatchEvent(new Event('change',{bubbles:true})));
 flushSync(()=>{button('执行选中操作').click();button('执行选中操作').click();});await settle(30);
 assert.equal(calls.length,2);assert.equal(calls[1].input.stage_id,2);assert.equal(calls[1].input.scene_id,id);
 release();await settle(650);assert.equal(button('重置整个场景').disabled,true);assert.equal(button('停止当前操作').disabled,false);
 assert.equal(calls.filter(c=>c.name==='model'||c.name==='followUp').length,0);
 console.log(JSON.stringify({scene_panel:true,open_without_motion:true,exact_scene_id:true,explicit_effects:true,double_click_single_command:true,busy_reset_blocked:true,model_calls:0}));
}finally{root.unmount();win.happyDOM.abort();}
