// Mounted React component + fake Host SDK. No live model/SSH/robot.
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const repo='/opt/agnes-harness';
const require=createRequire(repo+'/packages/web-client/package.json');
const rootRequire=createRequire(repo+'/package.json');
const {Window}=rootRequire('happy-dom');const win=new Window();
for(const k of ['window','document','HTMLElement','HTMLSelectElement','Event','MouseEvent','localStorage'])globalThis[k]=k==='window'?win:win[k];
const React=require('react'),{createRoot}=require('react-dom/client'),{flushSync}=require('react-dom');
// Resolve component's React to the one shared platform instance, not a copied React.
const {build}=createRequire(repo+'/packages/cli/package.json')('esbuild');
const code=await build({stdin:{contents:'export {TaskConfig} from "'+process.cwd()+'/integrations/agnes_robot_viewer/extensions/main/client/task-config.js";export {Cameras} from "'+process.cwd()+'/integrations/agnes_robot_viewer/extensions/main/client/index.js";',resolveDir:process.cwd(),loader:'js'},
  bundle:true,write:false,format:'esm',platform:'node',plugins:[{name:'shared-react',setup(b){b.onResolve({filter:/^react$/},()=>({path:pathToFileURL(require.resolve('react')).href,external:true}));}}]});
const {TaskConfig,Cameras}=await import('data:text/javascript;base64,'+Buffer.from(code.outputFiles[0].text).toString('base64'));
const budget={max_steps:3500,check_interval_steps:10,max_state_requests:300,max_policy_queries:250,max_wall_seconds:1200};
const task=(id,policies,seeds)=>({task_id:id,title:id,policies,allowed_seeds:seeds,configuration_available:true,
  stages:[{id:1,instruction:'Put the bowl on the plate.',max_steps:400}],budget});
let calls=0,submitted=[];
const ctx={agnes:{services:{call:async(name,input)=>{calls++;assert.equal(name,'robot.tasks');assert.deepEqual(input,{});
  return {connection:'connected',runner_available:true,runs_enabled:true,tasks:[task('one',['atomic','internw0'],[47]),task('two',['internw0'],[48])]};}}}};
const operations={state:{state:'idle',run_id:null},sending:false,startBlocked:false,stopAllowed:false,
  submit:(op,args)=>submitted.push({op,args})};
const container=document.createElement('div');document.body.append(container);const root=createRoot(container);
const cameraContainer=document.createElement('div');document.body.append(cameraContainer);const cameraRoot=createRoot(cameraContainer);
async function settle(){await new Promise(r=>setTimeout(r,30));}
try{
 flushSync(()=>root.render(React.createElement(TaskConfig,{ctx,sessionId:'s1',operations})));await settle();
 const select=label=>container.querySelector('select[aria-label="'+label+'"]');
 assert.equal(select('机器人任务').options.length,2);assert.equal(select('机器人VLA').options.length,2);
 assert.ok(container.textContent.includes('3500'));assert.ok(container.textContent.includes('Put the bowl'));
 select('机器人任务').value='two';flushSync(()=>select('机器人任务').dispatchEvent(new Event('change',{bubbles:true})));await settle();
 assert.equal(select('机器人VLA').value,'internw0');assert.equal(select('机器人seed').value,'48');
 const button=text=>[...container.querySelectorAll('button')].find(b=>b.textContent===text);
 flushSync(()=>button('请求运行').click());assert.deepEqual(submitted[0],{op:'start',args:{task_id:'two',policy:'internw0',seed:48}});
 assert.equal(button('请求停止').disabled,true);
 const before=calls;flushSync(()=>button('刷新任务').click());await settle();assert.equal(calls,before+1);
 // Viewing a historical run cannot enable a stop: only explicit owner state does.
 assert.equal(button('请求停止').disabled,true);
 flushSync(()=>root.render(React.createElement(TaskConfig,{ctx,sessionId:'s1',operations:{...operations,sending:true,startBlocked:true}})));
 assert.equal(button('请求运行').disabled,true);
 // Decode asynchronously without blanking same-run pixels; late images cannot cross runs.
 const originalImage=globalThis.Image,originalContext=win.HTMLCanvasElement.prototype.getContext;
 const images=[],events=[];
 globalThis.Image=class {width=512;height=256;onload=null;set src(value){images.push(this);}};
 win.HTMLCanvasElement.prototype.getContext=function(){return {clearRect:()=>events.push('clear'),drawImage:image=>events.push(image)}};
 try {
  const frame=id=>({frame_id:id,image_mime:'image/jpeg',image_base64:'eA=='});
  const render=(runId,id)=>flushSync(()=>cameraRoot.render(React.createElement(Cameras,{runId,frame:frame(id)})));
  render('A',1);await settle();const clears=events.filter(e=>e==='clear').length;
  images[0].onload();assert.equal(events.filter(e=>e!== 'clear').length,2);
  render('A',2);await settle();assert.equal(events.filter(e=>e==='clear').length,clears);
  assert.equal(events.filter(e=>e!== 'clear').length,2);images[1].onload();
  render('A',3);await settle();render('A',4);await settle();const before=events.length;
  images[2].onload();assert.equal(events.length,before);images[3].onload();
  render('B',5);await settle();assert.equal(events.filter(e=>e==='clear').length,clears+2);
  const afterSwitch=events.length;images[3].onload();assert.equal(events.length,afterSwitch);
  images[4].onload();assert.equal(events.length,afterSwitch+2);
 } finally {globalThis.Image=originalImage;win.HTMLCanvasElement.prototype.getContext=originalContext;}
 console.log(JSON.stringify({mounted_component:true,legal_choices:true,read_only_budget:true,button_sdk_intent:true,foreign_stop_disabled:true,no_decode_blank:true,late_images_cancelled:true,run_switch_clears_old_frame:true,model_calls:0,gpu_runs:0}));
}finally{cameraRoot.unmount();root.unmount();win.happyDOM.abort();}
