// Mounted planning panel, scripted current-session SDK, no paid model/GPU.
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const repo='/opt/agnes-harness';
const require=createRequire(repo+'/packages/web-client/package.json');
const {Window}=createRequire(repo+'/package.json')('happy-dom'),win=new Window();
for(const k of ['window','document','HTMLElement','Event','MouseEvent','localStorage'])globalThis[k]=k==='window'?win:win[k];
const React=require('react'),{createRoot}=require('react-dom/client'),{flushSync}=require('react-dom');
const {build}=createRequire(repo+'/packages/cli/package.json')('esbuild');
const code=await build({stdin:{contents:'export {PlanPanel} from "'+process.cwd()+'/integrations/agnes_robot_viewer/extensions/main/client/plan-panel.js";',resolveDir:process.cwd(),loader:'js'},
 bundle:true,write:false,format:'esm',platform:'node',plugins:[{name:'shared-react',setup(b){b.onResolve({filter:/^react$/},()=>({path:pathToFileURL(require.resolve('react')).href,external:true}));}}]});
const {PlanPanel}=await import('data:text/javascript;base64,'+Buffer.from(code.outputFiles[0].text).toString('base64'));
const scene={scene_id:'scene_'+'a'.repeat(32),revision:1,steps:0,status:'idle',active:true,plan_protocol:1,
 request:{task_id:'same',policy:'internw0',seed:47},remaining_steps:3500};
const task={task_id:'same',configuration_available:true,stages:[{id:1,instruction:'Put cheese on bowl.',max_steps:400,checker:{all:[{predicate:'on',args:['cheese','bowl']}]}},
 {id:2,instruction:'Put wine on cabinet.',max_steps:400}]};
let timeline={upto:1,nodes:[],opState:{data:{phase:'idle'}}},listeners=[],calls=[],executions=[];
const ctx={session:{projection:{subscribe:f=>{listeners.push(f);return()=>listeners=listeners.filter(g=>g!==f);},
 read:async()=>({status:'available',value:timeline})},handle:{id:'s1',followUp:async(text,options)=>{
 calls.push({text,options});assert.match(text,/PLANNING ONLY/);
 const data=JSON.parse(text.match(/data, not tool authority: (\{.*?\})\./s)[1]);
 timeline={...timeline,upto:3,nodes:[{kind:'tool',name:'robot_scene_plan',status:'completed',seq:2,
  resultPreview:JSON.stringify({kind:'robot_scene_plan/v1',status:'validated',...data,stage_ids:[1,2],
   task_id:'same',policy:'internw0',seed:47})}]};listeners.forEach(f=>f());
}}}};
const rootNode=document.createElement('div');document.body.append(rootNode);const root=createRoot(rootNode);
const render=()=>flushSync(()=>root.render(React.createElement(PlanPanel,{ctx,sessionId:'s1',scene,task,blocked:false,onExecute:p=>executions.push(p)})));
const button=text=>[...rootNode.querySelectorAll('button')].find(b=>b.textContent===text);
const settle=()=>new Promise(r=>setTimeout(r,40));
try{
 render();await settle();const textarea=rootNode.querySelector('textarea');
 const setter=Object.getOwnPropertyDescriptor(win.HTMLTextAreaElement.prototype,'value').set;
 setter.call(textarea,'Put cheese on bowl, then wine on cabinet.');flushSync(()=>textarea.dispatchEvent(new Event('input',{bubbles:true})));
 // React DOM in happy-dom uses change semantics for text areas in this fixture.
 if(button('生成阶段计划').disabled){
   const props=Object.keys(textarea).find(k=>k.startsWith('__reactProps$'));
   flushSync(()=>textarea[props].onChange({target:{value:textarea.value}}));
 }
 flushSync(()=>{button('生成阶段计划').click();button('生成阶段计划').click();});await settle();
 assert.equal(calls.length,1);assert.equal(executions.length,0);
 assert.equal(button('确认并执行阶段计划').disabled,false);assert.ok(rootNode.textContent.includes('Put wine on cabinet.'));
 flushSync(()=>button('确认并执行阶段计划').click());assert.equal(executions.length,1);
 assert.deepEqual(executions[0].stage_ids,[1,2]);assert.equal(executions[0].scene_step,0);
 scene.steps=1;render();await settle();assert.equal(button('确认并执行阶段计划').disabled,true);
 assert.equal(calls.length,1);
 console.log(JSON.stringify({planning_panel:true,current_session_sdk:true,double_click_one_model_turn:true,
  no_execution_before_review:true,exact_stage_ids:true,changed_scene_blocks_plan:true,paid_models:0,gpu_runs:0}));
}finally{root.unmount();win.happyDOM.abort();}
