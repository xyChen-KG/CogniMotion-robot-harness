import test from 'node:test';
import assert from 'node:assert/strict';
import {SessionOperations,commandText,timelineState} from '../extensions/main/client/operations.mjs';
const RUN='run_'+'a'.repeat(32),ID='ui_'+'b'.repeat(32);
const args={task_id:'task',policy:'internw0',seed:47};
const storage=()=>{const map=new Map();return {getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,v)};};
const node=(args,value,state='completed')=>({kind:'tool',name:'robot_start_run',seq:12,status:state,
  argsPreview:JSON.stringify(args),resultPreview:JSON.stringify(value)});

test('double-click dispatches only one durable SDK followUp, no direct API/tool invocation',async()=>{
  const save=storage();const ops=new SessionOperations('s1',save);let calls=[];let finish;
  const handle={id:'s1',followUp:async(text,options)=>{calls.push({text,options});await new Promise(r=>finish=r);}};
  const first=ops.submit('start',args,handle,{upto:10});
  await assert.rejects(ops.submit('start',args,handle,{upto:10}),/尚未确认/);
  assert.equal(calls.length,1);assert.match(calls[0].text,/robot_start_run/);
  const persisted=JSON.parse(save.getItem('robot-harness/intent/s1'));
  assert.equal(calls[0].options.commandId,persisted.command_id);
  assert.ok(calls[0].text.includes(persisted.command_id));finish();await first;
});

test('reload and lost acknowledgement never automatically resubmit start; query preserves original identity',async()=>{
  const save=storage();const ops=new SessionOperations('s1',save);let sends=[];
  const handle={id:'s1',followUp:async(text,o)=>{sends.push(o.commandId);throw Error('disconnect');}};
  await assert.rejects(ops.submit('start',args,handle,{upto:10}));
  const original=ops.intent.command_id;
  const reload=new SessionOperations('s1',save);
  await assert.rejects(reload.submit('start',args,handle,{upto:10}));
  await assert.rejects(reload.submit('status',{},handle,{upto:10}));
  assert.equal(reload.intent.command_id,original);assert.equal(sends.length,2);
});

test('only real successful receipt binds ID; oral assistant text, mismatched args and pending calls cannot',()=>{
  const intent={op:'start',command_id:ID,args,before_seq:10,state:'submitted'};
  assert.equal(timelineState({nodes:[{kind:'assistant',content:'started '+RUN}]},intent).run_id,null);
  const p={...args,submission_id:ID};
  assert.equal(timelineState({nodes:[node(p,null,'awaiting_approval')]},intent).state,'awaiting_approval');
  const receipt={http_status:202,response:{run_id:RUN,status:'starting',owned_by_session:true}};
  assert.equal(timelineState({nodes:[node({...p,seed:48},receipt)]},intent).state,'mismatch');
  const matched=timelineState({nodes:[node(p,receipt)]},intent);
  assert.equal(matched.run_id,RUN);assert.equal(matched.owned,true);
});

test('approval rejection blocks binding and unknown response does not fall back to old run',()=>{
  const intent={op:'start',command_id:ID,args,before_seq:10,state:'submitted'};
  const p={...args,submission_id:ID};
  const reject=timelineState({nodes:[node(p,null,'failed'),{kind:'approval',seq:13,decision:{verdict:'rejected'}}]},intent);
  assert.equal(reject.state,'rejected');assert.equal(reject.run_id,null);
  const unknown=timelineState({nodes:[node(p,{error:'robot_control_unconfirmed'})]},intent);
  assert.equal(unknown.state,'startup_unconfirmed');assert.equal(unknown.owned,false);
});

test('a newer pending chat/UI startup cannot reuse an older successful run receipt',()=>{
  const receipt={http_status:202,response:{run_id:RUN,status:'starting',owned_by_session:true}};
  const previous=node(args,receipt);previous.seq=1;
  const pending=node({...args,submission_id:ID},null,'awaiting_approval');pending.seq=20;
  const state=timelineState({nodes:[previous,pending]});
  assert.equal(state.state,'awaiting_approval');assert.equal(state.run_id,null);assert.equal(state.owned,false);
});

test('multiple panel instances share durable pending intent and cannot submit a second start',async()=>{
  const save=storage();let count=0;
  const a=new SessionOperations('s1',save),b=new SessionOperations('s1',save);
  const handle={id:'s1',followUp:async()=>count++};
  await a.submit('start',args,handle,{upto:0});
  await assert.rejects(b.submit('start',args,handle,{upto:0}));assert.equal(count,1);
});

test('session handle must match and caches do not grant ownership',async()=>{
  const save=storage();save.setItem('robot-harness/intent/s1',JSON.stringify({session_id:'s1',command_id:ID,
    op:'start',args,state:'running',run_id:RUN,owned:true}));
  const ops=new SessionOperations('s1',save);
  assert.equal(ops.reconcile({nodes:[]}).owned,false);
  await assert.rejects(ops.submit('status',{}, {id:'s2',followUp:()=>assert.fail()},{}),/宿主会话/);
  assert.match(commandText('stop',{run_id:RUN},ID),/robot_stop_run/);
});
