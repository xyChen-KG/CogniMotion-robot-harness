// Actual Agnes SDK/Core/Host + scripted model, isolated home, no paid calls/GPU.
import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
const here=fileURLToPath(new URL('..',import.meta.url)),repo='/opt/agnes-harness';
const {createRuntime}=await import(pathToFileURL(join(here,'extensions/main/index.mjs')).href);
const {planReceipt}=await import(pathToFileURL(join(here,'extensions/main/client/plan-state.mjs')).href);
const {createTestHost}=await import(pathToFileURL(repo+'/packages/host/testkit/index.ts').href);
const {createLocalEndpoint}=await import(pathToFileURL(repo+'/packages/daemon/src/local/index.ts').href);
const {testWorkspaceCatalog}=await import(pathToFileURL(repo+'/packages/daemon/test/host.ts').href);
const {createClient,memoryJournal}=await import(pathToFileURL(repo+'/packages/sdk/src/index.node.ts').href);
const {hashDirectory}=await import(pathToFileURL(repo+'/packages/package-manager/src/index.ts').href);
const {buildRuntimeTarget,createPluginRow}=await import(pathToFileURL(repo+'/packages/plugin-runtime/src/host/index.ts').href);
const root=mkdtempSync(join(tmpdir(),'robot-planning-host-')),old=process.env.HOME;process.env.HOME=root;
const manifest=JSON.parse(readFileSync(join(here,'package.json'),'utf8')),digest='sha256-'+'9'.repeat(64);
const source={snapshot:{snapshotId:digest,profile:'local-dev',packageId:manifest.name,version:manifest.version,integrity:digest,
 treeIntegrity:hashDirectory(here,{exclude:[]}),capabilityHash:'fixture',directory:here,contributions:[]},generation:1,trusted:true};
const row=createPluginRow({id:manifest.agnes.plugins[0].id,plugin:`${manifest.name}@${digest}/runtime`,snapshotDigest:digest,
 exportName:'runtime',entryRevision:digest,extrasRevision:'none',mountRevision:'host-ordinary-row:v1',inject:['extension']});
const target=rows=>buildRuntimeTarget({rows,resources:{mcp:[],skills:{}},resourceRevision:'0'.repeat(64),compositeRevision:'0'.repeat(64)});
const scene_id='scene_'+'a'.repeat(32),input={scene_id,revision:1,scene_step:0,goal:'Put cheese on bowl and wine on cabinet.',
 planning_request_id:'plan_'+'b'.repeat(32),stage_ids:[1,2]};
const scene={scene_id,active:true,status:'idle',plan_protocol:1,revision:1,steps:0,request:{task_id:'same',policy:'internw0',seed:47}};
const ops=[],read=async op=>{ops.push(op);return op==='scene'?{scene_id,status:scene,connection:'connected',runner_available:true}:
 {runner_available:true,tasks:[{task_id:'same',configuration_available:true,stages:[{id:1,instruction:'Put cheese on bowl.'},{id:2,instruction:'Put wine on cabinet.'}]}]};};
const call=(name,args)=>[{type:'toolcall_end',via:'native',call:{toolUseId:'',name,args,ordinal:0}},{type:'done',reason:'toolUse'}];
const {host}=await createTestHost({dataDir:join(root,'host'),disableSessionTitle:true,runtimePluginCatalogue:[source],
 script:[call('robot_scene_plan_context',{scene_id}),call('robot_scene_plan',input),[{type:'text_delta',delta:'Plan ready; await confirmation.'}]],
 extensionLoader:{import:async file=>file.endsWith('/index.mjs')?{runtime:createRuntime(()=>read,()=>()=>assert.fail('Planning must not execute'))}:import(pathToFileURL(file).href)}});
let client;
try{
 await host.applyRuntimeTarget(target([row]));
 const workspaces=await testWorkspaceCatalog(join(root,'host'));
 client=createClient({transport:{kind:'inproc',endpoint:createLocalEndpoint(host,{workspaces,pollMs:5})},journal:memoryJournal()});
 const sdk=await client.session.new({cwd:join(root,'host')}),session=host.kernel.get(sdk.id);
 await sdk.followUp('Decompose the goal using robot_scene_plan_context and robot_scene_plan. Do not execute.',{commandId:input.planning_request_id});
 const deadline=Date.now()+8000;
 while(Date.now()<deadline){if((await session.scan({type:'turn/end',toSeq:session.lastSeq})).length)break;await new Promise(r=>setTimeout(r,20));}
 const timeline=await session.projectUI(),receipt=planReceipt(timeline,{...input,before_seq:0});
 assert.ok(receipt,JSON.stringify(timeline.nodes.filter(n=>n.kind==='tool')));assert.deepEqual(receipt.stage_ids,[1,2]);
 assert.ok(ops.every(op=>['tasks','scene'].includes(op)));
 const saved=host.kernel.tools.resolve('robot_scene_plan');await host.applyRuntimeTarget(target([]));
 await assert.rejects(saved.execute(input,{session:{key:sdk.id,toolUseId:'old',depth:0},signal:new AbortController().signal}));
 await session.close();console.log(JSON.stringify({formal_host:true,sdk_followup:true,scripted_model_tools:true,
  projected_plan_receipt:true,unload_revokes_old_handle:true,paid_models:0,gpu_runs:0}));
}finally{if(client)await client.close();await host.close();process.env.HOME=old;rmSync(root,{recursive:true,force:true});}
