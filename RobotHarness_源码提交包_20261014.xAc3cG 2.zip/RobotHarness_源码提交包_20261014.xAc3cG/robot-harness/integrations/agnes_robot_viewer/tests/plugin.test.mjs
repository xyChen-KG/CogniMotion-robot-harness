import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync, rmSync, chmodSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createReader, validateInput, validateSceneInput, createSceneController } from '../extensions/main/backend.mjs';
import { runtime } from '../extensions/main/index.mjs';
import { decodeChunk, displayMode, sessionRobotRun, exactObservation, previewDelay } from '../extensions/main/client/state.js';
import { catalogModel, legalSelection } from '../extensions/main/client/catalog.js';
const run='run_'+'a'.repeat(32);

test('active preview cadence includes request time; history/background/error polls stay bounded',()=>{
  const live={connection:'connected',runner_available:true,status:{active:true}};
  assert.equal(previewDelay(live,false,0),125);
  assert.equal(previewDelay(live,false,45),80);
  assert.equal(previewDelay(live,false,200),0);
  assert.equal(previewDelay({...live,status:{active:false}},false,0),1000);
  assert.equal(previewDelay(live,true,0),1500);
  assert.equal(previewDelay(null,false,0),500);
});

test('read queries and explicit journaled effects have separate capabilities',()=>{
  const services=[],tools=[];
  runtime.apply({services:{register:value=>services.push(value)},extension:()=>({registerTool:t=>tools.push(t)})});
  assert.deepEqual(tools.map(t=>t.name),['robot_scene_plan_context','robot_scene_plan']);
  assert.ok(tools.every(t=>t.meta.isReadOnly && t.meta.requiresApproval==='never'));
  assert.deepEqual(services.map(s=>s.name),['robot.tasks','robot.observation','robot.replay.chunk','robot.scene','robot.scene.open','robot.scene.command','robot.scene.replay.chunk']);
  for(const service of services){assert.equal(service.kind,service.name.endsWith('.open')||service.name.endsWith('.command')?'effect':'query');assert.ok(service.maxResultBytes<=1048576);assert.equal(service.inputSchema.additionalProperties,false);}
});

test('scene controls reject paths, arbitrary skills, budgets and spoofed owners',()=>{
  const input={task_id:'same_five_stage',policy:'internw0',seed:47,request_id:'stable-request'};
  assert.deepEqual(validateSceneInput('open',input),input);
  for(const change of [{owner:'forged'},{path:'/etc'},{budget:9999},{instruction:'free text'}, {seed:true}])
    assert.throws(()=>validateSceneInput('open',{...input,...change}));
  const command={scene_id:'scene_'+'a'.repeat(32),operation:'execute',revision:1,request_id:'one',stage_id:1};
  assert.deepEqual(validateSceneInput('command',command),command);
  for(const change of [{operation:'shell'},{scene_id:'../../bad'},{revision:0},{stage_id:33},{owner:'fake'}])
    assert.throws(()=>validateSceneInput('command',{...command,...change}));
  assert.throws(()=>validateSceneInput('command',{...command,operation:'close'}));
  assert.throws(()=>createSceneController()('open',input,{}));
});

test('requests cannot specify arbitrary paths, commands or budgets',()=>{
  assert.deepEqual(validateInput('tasks',{}),{op:'tasks'});
  for (const input of [{run_id:run},{path:'/private'},{url:'http://evil'},{command:'start'},[]])
    assert.throws(()=>validateInput('tasks',input));
  assert.deepEqual(validateInput('observation',{run_id:run}),{op:'observation',run_id:run});
  for(const input of [{run_id:'../../bad'},{url:'http://evil'},{command:'stop'},{budget:10000},null])
    assert.throws(()=>validateInput('observation',input));
  for(const offset of [-1,NaN,1.5,67108865])assert.throws(()=>validateInput('replay_chunk',{run_id:run,offset}));
  assert.throws(()=>validateInput('start',{}));
});

const task = (task_id='five', policies=['atomic','internw0'], allowed_seeds=[47]) => ({
  task_id, title:task_id, policies, allowed_seeds, configuration_available:true,
  stages:[{id:1,instruction:'Put the bowl on the plate.',max_steps:400}],
  budget:{max_steps:3500,check_interval_steps:10,max_state_requests:300,max_policy_queries:250,max_wall_seconds:1200},
  completion_mode:'stable_conditions',stable_steps:1,
});
const envelope = tasks => ({connection:'connected',runner_available:true,runs_enabled:false,tasks});

test('catalog reflects only registered combinations and read-only public config',()=>{
  const model=catalogModel(envelope([task(),task('eight',['internw0'],[48])]));
  assert.equal(model.connected,true); assert.equal(model.runs_enabled,false);
  assert.deepEqual(legalSelection(model.tasks,{task_id:'five',policy:'internw0',seed:47}),
    {task_id:'five',policy:'internw0',seed:47});
  assert.deepEqual(legalSelection(model.tasks,{task_id:'eight',policy:'atomic',seed:47}),
    {task_id:'eight',policy:'internw0',seed:48});
  assert.deepEqual(legalSelection([],{}),{task_id:'',policy:'',seed:null});
  assert.deepEqual(legalSelection(model.tasks,{task_id:'missing',seed:999}).seed,47);
  assert.equal(model.tasks[0].stages[0].max_steps,400);
  assert.equal(model.tasks[0].budget.max_steps,3500);
});

test('missing, changed or invalid stage tables are not guessed',()=>{
  for(const change of [{configuration_available:false},{stages:null},{stages:[null]},
    {stages:[{id:1,instruction:'',max_steps:400}]},
    {stages:[{id:1,instruction:'x',max_steps:400},{id:1,instruction:'y',max_steps:400}]},
    {budget:{max_steps:999}}]) {
    const item=catalogModel(envelope([{...task(),...change}])).tasks[0];
    assert.equal(item.configuration_available,false); assert.equal(item.stages,null); assert.equal(item.budget,null);
  }
  for(const tasks of [[task(),task()], [{...task(),allowed_seeds:[]}],
    [{...task(),policies:['unknown']}], [{...task(),allowed_seeds:[47.5]}]])
    assert.throws(()=>catalogModel(envelope(tasks)));
});

test('execution switch is unknown on disconnection, never inferred from old state',()=>{
  assert.equal(catalogModel({...envelope([task()]),connection:'unavailable',runs_enabled:true}).runs_enabled,null);
  assert.equal(catalogModel({...envelope([task()]),runs_enabled:'false'}).runs_enabled,null);
  assert.equal(catalogModel({...envelope([task()]),runner_available:false}).connected,false);
});

test('private backend credential stays local, and wrong service never receives it',async()=>{
  const dir=mkdtempSync(join(tmpdir(),'agnes_robot_viewer_'));chmodSync(dir,0o700);
  const secret='s'.repeat(43),config=join(dir,'config.json');
  writeFileSync(config,JSON.stringify({port:18432,privateDirectory:dir}),{mode:0o600});
  writeFileSync(join(dir,'server_state.json'),JSON.stringify({port:18432,instance_id:'expected'}),{mode:0o600});
  writeFileSync(join(dir,'admin.token'),secret,{mode:0o600});
  try{
    const calls=[];
    const read=createReader({configPath:config,fetcher:async(url,options)=>{
      calls.push({url,options});
      if(url.endsWith('/health'))return Response.json({instance_id:'expected'});
      assert.equal(options.headers.Authorization,'Bearer '+secret);
      assert.equal(options.redirect,'error');
      return Response.json({mode:'final',status:{native_success:true}});
    }});
    const result=await read('observation',{run_id:run});
    assert.equal(result.status.native_success,true);assert.ok(!JSON.stringify(result).includes(secret));
    assert.equal(calls.length,2);assert.equal(calls[0].options.headers,undefined);
    let requests=0;
    const wrong=createReader({configPath:config,fetcher:async()=>{requests++;return Response.json({instance_id:'wrong'});}});
    await assert.rejects(wrong('observation',{}),error=>!error.message.includes(secret));
    assert.equal(requests,1);
    chmodSync(join(dir,'admin.token'),0o644);
    await assert.rejects(read('observation',{}));
  }finally{rmSync(dir,{recursive:true});}
});

test('video chunks enforce identity, monotonic offsets, total cap and eof',()=>{
  const packet={run_id:run,offset:0,next_offset:3,total_bytes:3,eof:true,mime:'video/mp4',data_base64:btoa('abc')};
  assert.deepEqual([...decodeChunk(packet,run,0)], [97,98,99]);
  for(const change of [{offset:1},{run_id:'other'},{next_offset:0},{total_bytes:67108865},{eof:false},{mime:'text/html'},{data_base64:''}])
    assert.throws(()=>decodeChunk({...packet,...change},run,0));
});

test('historical, final and live are never conflated',()=>{
  assert.equal(displayMode({mode:'archive',available:true,connection:'connected',runner_available:true}),'历史画面 · 非实时');
  assert.equal(displayMode({mode:'final',available:true,status:{active:false},connection:'connected',runner_available:true}),'最终画面');
  assert.equal(displayMode({mode:'archive',available:true,connection:'reconnecting'}),'连接异常 · 保留画面非实时');
  assert.equal(displayMode({mode:'live',connection:'connected',runner_available:true,available:true,status:{active:true}}),'实时画面');
  assert.equal(displayMode(null),'连接异常 · 保留画面非实时');
  assert.equal(displayMode({mode:'live',connection:'reconnecting',available:true}),'连接异常 · 保留画面非实时');
});

test('follow Host session tool receipts, never latest global run or user text',()=>{
  assert.equal(sessionRobotRun({nodes:[{kind:'user',content:run}]}),null);
  assert.deepEqual(sessionRobotRun({nodes:[{kind:'tool',name:'robot_start_run',status:'completed',resultPreview:JSON.stringify({http_status:202,response:{run_id:run}})}]}),{run_id:run,state:'linked'});
  assert.deepEqual(sessionRobotRun({nodes:[{kind:'tool',name:'robot_start_run',status:'planned'}]}),{run_id:null,state:'waiting'});
  const wrong=exactObservation({selected_run_id:'run_'+'b'.repeat(32),status:{run_id:'run_'+'b'.repeat(32)},frame:{image_base64:'old'},available:true},run);
  assert.equal(wrong.selected_run_id,run);assert.equal(wrong.frame,null);assert.equal(wrong.status,null);
  const same={selected_run_id:run,status:{run_id:run},available:true};
  assert.equal(exactObservation(same,run),same);
});
