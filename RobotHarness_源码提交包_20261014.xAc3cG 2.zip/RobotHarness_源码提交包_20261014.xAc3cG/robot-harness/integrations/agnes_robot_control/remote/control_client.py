"""Fixed SSH JSON control entry. Reuses client.request; never emits the API token."""
from __future__ import annotations
import fcntl
import hashlib
import http.client
import json
import os
from pathlib import Path
import re
import sqlite3
import sys

HERE = Path(__file__).resolve().parent
NAME = re.compile(r'[A-Za-z0-9._-]{1,128}\Z')
RUN = re.compile(r'run_[a-f0-9]{32}\Z')
OPS = {'tasks', 'start', 'status', 'result', 'stop', 'resolve'}


def validate(value):
    if not isinstance(value, dict) or set(value) != {'op', 'owner', 'call_id', 'args'}:
        raise ValueError('Invalid control envelope')
    if value['op'] not in OPS or not isinstance(value['owner'], dict):
        raise ValueError('Invalid operation')
    if set(value['owner']) != {'installation', 'session'} or any(
        not isinstance(v, str) or not NAME.fullmatch(v) for v in value['owner'].values()):
        raise ValueError('Invalid Host identity')
    if not isinstance(value['call_id'], str) or not NAME.fullmatch(value['call_id']):
        raise ValueError('Invalid call identity')
    args = value['args']
    expected = {'task_id', 'policy', 'seed', 'request_id'} if value['op'] == 'start' else {'request_id'} if value['op'] == 'resolve' else {'run_id'} if value['op'] in {'status', 'result', 'stop'} else set()
    if not isinstance(args, dict) or set(args) != expected:
        raise ValueError('Invalid arguments')
    if value['op'] == 'start':
        if any(not isinstance(args[k], str) or not NAME.fullmatch(args[k]) for k in ('task_id', 'request_id')) or args['policy'] not in ('atomic', 'internw0') or type(args['seed']) is not int or args['seed'] < 0:
            raise ValueError('Invalid start')
    elif value['op'] == 'resolve':
        if not isinstance(args['request_id'], str) or not NAME.fullmatch(args['request_id']):
            raise ValueError('Invalid request_id')
    elif expected and (not isinstance(args['run_id'], str) or not RUN.fullmatch(args['run_id'])):
        raise ValueError('Invalid run')
    return value


def owner_key(value):
    return hashlib.sha256(json.dumps([os.getuid(), value['installation'], value['session']], separators=(',', ':')).encode()).hexdigest()


def safe_diagnostic(value):
    if value is None:
        return None
    if not isinstance(value, str):
        return 'runner_reported_error'
    # Diagnostics may originate in executor exceptions, not just this adapter.
    # Do not expose recognizable credentials embedded in headers, URLs or text.
    value = re.sub(r'(?i)\bbearer\s+[^\s,;]+', 'Bearer [REDACTED]', value)
    value = re.sub(r'''(?i)(\b(?:api[_ -]?key|token|password|secret)\b["']?\s*[:=]\s*)(?:"[^"]*"|'[^']*'|[^\s,;&]+)''',
                   r'\1[REDACTED]', value)
    value = re.sub(r'(?i)(https?://)[^\s/@]+(?::[^\s/@]*)?@', r'\1[REDACTED]@', value)
    value = re.sub(r'\bsk-[A-Za-z0-9_-]+', '[REDACTED]', value)
    return ''.join(c if c >= ' ' else ' ' for c in value)[:512]


def summary(body):
    if not isinstance(body, dict):
        raise ValueError('Invalid runner response')
    keys = ('run_id', 'status', 'active', 'ownership_uncertain', 'outcome_unknown', 'request', 'current_stage', 'stage_count',
            'vla_steps', 'tool_steps', 'steps', 'elapsed_seconds', 'native_success', 'workflow_success',
            'completed_stage_ids', 'stage_states', 'stop_requested', 'completed', 'result_available', 'idempotent')
    result = {k: body[k] for k in keys if k in body}
    if 'error' in body:
        result['error'] = safe_diagnostic(body['error'])
    if type(body.get('exit_code')) is int:
        result['exit_code'] = body['exit_code']
    if 'summary' in body:
        raw = body['summary']
        result['summary'] = None if raw is None else {k: raw.get(k) for k in (
            'status', 'success', 'task_success', 'workflow_success', 'native_success', 'native_success_ever',
            'all_stages_completed', 'completed_stage_ids', 'stage_states', 'post_tools_success',
            'termination_reason', 'steps', 'vla_steps', 'tool_steps', 'elapsed_seconds')}
        if result['summary'] is not None:
            result['summary']['termination_reason'] = safe_diagnostic(raw.get('termination_reason'))
    if 'artifacts' in body:
        result['artifacts'] = [{'path': a['path'], 'size_bytes': a['size_bytes']} for a in body['artifacts']
            if isinstance(a, dict) and isinstance(a.get('path'), str) and '..' not in a['path'].split('/')
            and not a['path'].startswith('/') and type(a.get('size_bytes')) is int][:200]
    return result


def serve(packet, api, db):
    owner = owner_key(packet['owner'])
    op, args = packet['op'], packet['args']
    db.execute('CREATE TABLE IF NOT EXISTS claims(request_id TEXT PRIMARY KEY, owner TEXT NOT NULL, params TEXT NOT NULL, run_id TEXT)')
    db.commit()
    if op == 'tasks':
        code, body = api('GET', '/tasks')
        return {'http_status': code, 'response': body if code == 200 else {'error': 'runner_query_refused'}}
    if op == 'resolve':
        row = db.execute('SELECT owner,params,run_id FROM claims WHERE request_id=?', (args['request_id'],)).fetchone()
        if not row or row[0] != owner:
            return {'http_status': 200, 'response': {'run_id': None, 'status': 'startup_unconfirmed'}}
        if row[2]:
            code, body = api('GET', '/runs/' + row[2])
            return {'http_status': code, 'response': summary(body) if code == 200 else {'error': 'owned_run_cannot_be_confirmed'}}
        code, body = api('GET', '/runs')
        expected = dict(json.loads(row[1]), request_id=args['request_id'])
        matched = [r for r in body.get('runs', []) if r.get('request') == expected] if code == 200 else []
        if len(matched) == 1 and RUN.fullmatch(matched[0].get('run_id', '')):
            db.execute('UPDATE claims SET run_id=? WHERE request_id=?', (matched[0]['run_id'], args['request_id']))
            db.commit()
            return {'http_status': 200, 'response': summary(matched[0])}
        return {'http_status': 200, 'response': {'run_id': None, 'status': 'startup_unconfirmed'}}
    if op == 'start':
        params = json.dumps({k: args[k] for k in ('task_id', 'policy', 'seed')}, sort_keys=True)
        row = db.execute('SELECT owner,params,run_id FROM claims WHERE request_id=?', (args['request_id'],)).fetchone()
        if row and (row[0] != owner or row[1] != params):
            return {'http_status': 409, 'response': {'error': 'request_identity_conflict'}}
        if row and row[2]:
            code, body = api('GET', '/runs/' + row[2])
            if code == 200 and body.get('request') == args:
                return {'http_status': 200, 'response': {'run_id': row[2], 'status': body.get('status'), 'idempotent': True}}
            return {'http_status': 409, 'response': {'error': 'owned_run_cannot_be_confirmed', 'outcome_unknown': True}}
        if row:
            code, listing = api('GET', '/runs')
            matched = [r for r in listing.get('runs', []) if r.get('request') == args] if code == 200 else []
            if len(matched) == 1 and RUN.fullmatch(matched[0].get('run_id', '')):
                run_id = matched[0]['run_id']
                db.execute('UPDATE claims SET run_id=? WHERE request_id=?', (run_id, args['request_id']))
                db.commit()
                return {'http_status': 200, 'response': {'run_id': run_id, 'status': matched[0].get('status'), 'idempotent': True}}
        code, listing = api('GET', '/tasks')
        task = next((t for t in listing.get('tasks', []) if t.get('task_id') == args['task_id']), None) if code == 200 else None
        if not task or args['policy'] not in task.get('policies', []) or args['seed'] not in task.get('allowed_seeds', []):
            return {'http_status': 503 if row else 400, 'response': {'error': 'not_in_actual_allowlist', 'outcome_unknown': bool(row)}}
        if listing.get('runs_enabled') is not True:
            return {'http_status': 503 if row else 403, 'response': {'error': 'startup_unconfirmed' if row else 'runs_disabled', 'outcome_unknown': bool(row)}}
        db.execute('INSERT OR IGNORE INTO claims VALUES(?,?,?,NULL)', (args['request_id'], owner, params))
        db.commit()  # Durable intent before original API effect, even if SSH response is lost.
        code, body = api('POST', '/runs', args)
        if code in (200, 202) and RUN.fullmatch(body.get('run_id', '')):
            db.execute('UPDATE claims SET run_id=? WHERE request_id=?', (body['run_id'], args['request_id']))
            db.commit()
        return {'http_status': code, 'response': summary(body) if code in (200, 202) else {'error': 'runner_start_refused'}}
    run_id = args['run_id']
    code, body = api('GET', '/runs/' + run_id)
    if code != 200:
        return {'http_status': code, 'response': {'error': 'runner_query_refused'}}
    if op == 'status':
        return {'http_status': code, 'response': summary(body)}
    if op == 'result':
        code, body = api('GET', '/runs/' + run_id + '/result')
        return {'http_status': code, 'response': summary(body) if code in (200, 202) else {'error': 'runner_result_refused'}}
    row = db.execute('SELECT owner,params,request_id FROM claims WHERE run_id=?', (run_id,)).fetchone()
    expected = None if row is None else dict(json.loads(row[1]), request_id=row[2])
    if row is None or row[0] != owner or body.get('request') != expected:
        return {'http_status': 403, 'response': {'error': 'run_not_owned_by_this_session'}}
    if body.get('ownership_uncertain') is True or body.get('process_state') == 'unknown':
        return {'http_status': 409, 'response': {'error': 'process_ownership_unknown'}}
    code, body = api('POST', '/runs/' + run_id + '/stop', {})
    return {'http_status': code, 'response': summary(body) if code in (200, 202) else {'error': 'runner_stop_refused'}}


def main():
    try:
        raw = sys.stdin.buffer.read(8193)
        if len(raw) > 8192:
            raise ValueError('Oversized request')
        packet = validate(json.loads(raw))
        sys.path.insert(0, str(HERE))
        from client import request
        private = HERE / 'private'
        info = private.stat()
        if private.is_symlink() or info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise ValueError('Private state unavailable')
        lock_path = private / 'agnes_control.lock'
        fd = os.open(lock_path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'w') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            path = private / 'agnes_control.sqlite'
            if path.is_symlink():
                raise ValueError('Invalid ownership state')
            old_umask = os.umask(0o077)
            try:
                db = sqlite3.connect(path, timeout=2)
            finally:
                os.umask(old_umask)
            try:
                value = serve(packet, lambda method, route, payload=None: request(18431, private / 'api.token', method, route, payload), db)
            finally:
                db.close()
        print(json.dumps(value, ensure_ascii=False, allow_nan=False))
    except Exception:
        print(json.dumps({'http_status': 503, 'response': {'error': 'control_connection_unconfirmed'}}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
