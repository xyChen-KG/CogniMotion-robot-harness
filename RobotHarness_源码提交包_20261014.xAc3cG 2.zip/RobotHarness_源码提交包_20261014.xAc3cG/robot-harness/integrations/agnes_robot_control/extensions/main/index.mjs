import { createControl } from './backend.mjs';

const Kind = Symbol.for('TypeBox.Kind');
const string = (options = {}) => ({[Kind]: 'String', type: 'string', ...options});
const object = (properties, required = Object.keys(properties)) => ({[Kind]: 'Object', type: 'object', properties, required, additionalProperties: false});
const run = string({pattern: '^run_[a-f0-9]{32}$'});
const readMeta = {isReadOnly: true, isDestructive: false, isConcurrencySafe: true, isOpenWorld: false,
  replay: 'safe', costHint: undefined, deferLoading: false, requiresApproval: 'never'};
const effectMeta = {isReadOnly: false, isDestructive: false, isConcurrencySafe: false, isOpenWorld: false,
  replay: 'never', costHint: {wallMs: 25000}, deferLoading: false, requiresApproval: 'always'};

// Agnes sends content to the model; structured is retained for inspection only.
// Keep the run receipt first and omit bulky per-stage traces, not success facts.
export function modelVisibleResult(envelope) {
  const body = envelope.response || {};
  const response = Object.fromEntries(
    ['run_id', 'status', 'active', 'owned_by_session', 'ownership_uncertain', 'outcome_unknown', 'native_success', 'workflow_success',
     'current_stage', 'stage_count', 'steps', 'vla_steps', 'tool_steps', 'elapsed_seconds', 'completed_stage_ids',
     'completed', 'result_available', 'stop_requested', 'idempotent', 'state', 'error', 'exit_code', 'tasks', 'runs_enabled']
      .filter(k => k in body).map(k => [k, body[k]]));
  if ('summary' in body) response.summary = body.summary == null ? null : Object.fromEntries(
    ['status', 'success', 'task_success', 'workflow_success', 'native_success', 'native_success_ever',
     'all_stages_completed', 'completed_stage_ids', 'post_tools_success', 'termination_reason',
     'steps', 'vla_steps', 'tool_steps', 'elapsed_seconds']
      .filter(k => k in body.summary).map(k => [k, body.summary[k]]));
  if (Array.isArray(body.artifacts)) {
    const videos = body.artifacts.filter(a => a && typeof a.path === 'string' && a.path.length <= 512 &&
      !a.path.startsWith('/') && !a.path.includes('\\') && !a.path.split('/').includes('..') &&
      a.path.endsWith('.mp4') && Number.isSafeInteger(a.size_bytes) && a.size_bytes >= 0);
    response.recordings = videos.slice(0, 8).map(({path, size_bytes}) => ({path, size_bytes}));
    if (videos.length > 8) response.recordings_truncated = true;
  }
  return {http_status: envelope.http_status, response};
}

export function createRuntime(factory=createControl) { return {
  inject: ['extension'],
  apply(ctx) {
    const api = ctx.extension();
    const control = factory({rowSignal: api.ctx.signal});
    const disposers = [];
    let closed = false;
    const definitions = [
      ['robot_list_tasks', 'tasks', object({}), 'List the actual registered robot tasks, policies and allowed seeds. Does not enable execution or load models.', readMeta],
      ['robot_start_run', 'start', object({task_id: string({pattern: '^[A-Za-z0-9._-]{1,128}$'}),
        policy: string({enum: ['atomic', 'internw0']}), seed: {[Kind]: 'Integer', type: 'integer', minimum: 0, maximum: 2147483647},
        submission_id:string({pattern:'^ui_[a-f0-9]{32}$'})},['task_id','policy','seed']),
        'Start ONE allowlisted physical robot simulation run asynchronously. Requires user approval and server runs_enabled=true. Uses fixed registered budget, no retries with new IDs. No arbitrary paths or commands. If the UI supplies submission_id, copy it exactly; it is an idempotency key, never authority. Returns run_id immediately; run end is not task success.', effectMeta],
      ['robot_get_run', 'status', object({run_id: run}, []), 'Read a run status. Omit run_id to query/reconcile this session\'s last owned or unconfirmed start; never restarts a task.', readMeta],
      ['robot_get_result', 'result', object({run_id: run}, []), 'Read original result and recording metadata. Keeps native_success, workflow_success and historical stages distinct. No task is started.', readMeta],
      ['robot_stop_run', 'stop', object({run_id: run}), 'Request graceful stop of the explicit run owned by THIS main Agnes session. Requires approval. Original runner validates process ownership; never unloads models or stops another session.', {...effectMeta, isDestructive: true}],
    ];
    for (const [name, op, parameters, description, meta] of definitions) {
      disposers.push(api.registerTool({name, description, parameters, meta,
        async execute(input, tctx) {
          if (closed) throw new Error('Robot control plugin disabled');
          try {
            const structured = await control.execute(op, input, tctx);
            return {content: [{type: 'text', text: JSON.stringify(modelVisibleResult(structured))}], structured,
              isError: structured.http_status >= 400};
          } catch (error) {
            const message = error instanceof Error && /^(Cannot stop|Robot control plugin|Robot connection|Robot response|An unresolved|Another control|Trusted main-session|Invalid task|Invalid run|Only registered|Explicit run|Host confinement)/.test(error.message)
              ? error.message : '控制连接或私有关联暂不可核实；未自动重跑，请查询本会话状态。';
            const structured = {error: 'robot_control_unconfirmed', message};
            return {content: [{type: 'text', text: JSON.stringify(structured)}], structured, isError: true};
          }
        }}));
    }
    ctx.effect(() => () => {closed = true; control.close(); for (const dispose of disposers) dispose();});
  }
}; }
export const runtime=createRuntime();
