import { CONFIG, configuration, StateStore, RUN, NAME } from './state.mjs';
import { spawn } from 'node:child_process';

// Fixed audited entry, no model-controlled URL/path/command/environment.
export const SSH_ARGV = Object.freeze(['ssh', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=12',
  '-o', 'ClearAllForwardings=yes', '-o', 'ServerAliveInterval=5', '-o', 'ServerAliveCountMax=2',
  'robot-gpu', '/opt/libero/runtime/bin/python -B /opt/robot-harness/services/robot_runner/agnes_control_client.py']);

export function validate(op, input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Object arguments required');
  const expected = op === 'start' ? ['task_id', 'policy', 'seed', 'submission_id'] : op === 'tasks' ? [] : ['run_id'];
  if (Object.keys(input).some(k => !expected.includes(k))) throw new Error('Only registered structured arguments are accepted');
  if (op === 'start') {
    if (!NAME.test(input.task_id || '') || !['atomic', 'internw0'].includes(input.policy) ||
        !Number.isSafeInteger(input.seed) || input.seed < 0 || input.seed > 2147483647) throw new Error('Invalid task, policy or seed');
    if (input.submission_id !== undefined && (typeof input.submission_id !== 'string' || !/^ui_[a-f0-9]{32}$/.test(input.submission_id)))
      throw new Error('Invalid task submission identity');
    return {task_id: input.task_id, policy: input.policy, seed: input.seed,
      ...(input.submission_id ? {submission_id:input.submission_id} : {})};
  }
  if (input.run_id != null && !RUN.test(input.run_id)) throw new Error('Invalid run_id');
  if (op === 'stop' && !RUN.test(input.run_id || '')) throw new Error('Explicit run_id is required to stop');
  return input.run_id ? {run_id: input.run_id} : {};
}

function trustedIdentity(ctx) {
  if (!ctx?.session || typeof ctx.session.key !== 'string' || !ctx.session.key || ctx.session.key.length>512 || /[\u0000-\u001f\u007f]/.test(ctx.session.key) ||
      typeof ctx.session.toolUseId !== 'string' || !ctx.session.toolUseId || ctx.session.depth !== 0)
    throw new Error('Trusted main-session tool identity required; child sessions cannot control robotics');
  // Tool IDs may contain provider punctuation; convert to a fixed deterministic digest.
  return {session: ctx.session.key, call: ctx.session.toolUseId};
}

export function createControl({configPath = CONFIG, store: suppliedStore, transport: suppliedTransport,
                                rowSignal, spawner = spawn} = {}) {
  let store;
  const controller = new AbortController();
  const active = new Set();
  function alive(signal) {
    if (controller.signal.aborted || rowSignal?.aborted || signal?.aborted) throw new Error('Robot control plugin is disabled or invocation ended');
  }
  async function remote(packet, ctx) {
    alive(ctx.signal);
    if (suppliedTransport) return suppliedTransport(packet, ctx);
    if (typeof ctx.sandbox?.confine !== 'function') throw new Error('Host confinement port unavailable');
    // Host-approved invocation argv is the only spawn opening. Node is used
    // after confinement so plugin unload can close its own SSH immediately.
    const argv = await ctx.sandbox.confine([...SSH_ARGV]);
    alive(ctx.signal);
    const result = await new Promise((resolve, reject) => {
      const env = Object.fromEntries(['HOME', 'PATH', 'USER', 'LANG', 'SSH_AUTH_SOCK'].filter(k => process.env[k]).map(k => [k, process.env[k]]));
      const child = spawner(argv[0], argv.slice(1), {stdio: ['pipe', 'pipe', 'ignore'], cwd: ctx.cwd, env});
      let output = '', oversized = false, ended = false;
      const stop = () => {if (!ended) child.kill('SIGTERM');};
      const timer = setTimeout(stop, 25000);
      const force = setTimeout(() => {if (!ended) child.kill('SIGKILL');}, 28000);
      ctx.signal.addEventListener('abort', stop, {once: true});
      child.stdout.on('data', data => {output += data.toString('utf8'); if (output.length > 262144) {oversized = true; stop();}});
      child.on('error', () => {clearTimeout(timer); clearTimeout(force); ctx.signal.removeEventListener('abort', stop); reject(new Error('SSH connection could not be established'));});
      child.on('close', code => {ended = true; clearTimeout(timer); clearTimeout(force); ctx.signal.removeEventListener('abort', stop);
        resolve({code, stdout: output, truncated: oversized, timedOut: code === null});});
      child.stdin.on('error', () => {});
      child.stdin.end(JSON.stringify(packet));
    });
    alive(ctx.signal);
    if (result.truncated || result.timedOut || result.code !== 0 || result.stdout.length > 262144)
      throw new Error('Robot connection interrupted; startup identity retained, no new run was submitted');
    let value;
    try { value = JSON.parse(result.stdout); } catch { throw new Error('Robot response unconfirmed; do not start a replacement run'); }
    if (!Number.isInteger(value.http_status) || !value.response || typeof value.response !== 'object') throw new Error('Robot response unconfirmed');
    return value;
  }
  async function execute(op, input, ctx) {
    alive(ctx.signal);
    const args = validate(op, input);
    const id = trustedIdentity(ctx);
    store ||= suppliedStore || new StateStore(configuration(configPath));
    const call = await import('node:crypto').then(m => m.createHash('sha256').update(id.call).digest('hex'));
    const remoteSession=NAME.test(id.session)?id.session:'session_'+await import('node:crypto').then(m=>m.createHash('sha256').update(id.session).digest('hex'));
    const packet = (operation, params) => ({op: operation, owner: {installation: store.config.installationId, session: remoteSession}, call_id: call, args: params});
    if (op === 'tasks') return remote(packet('tasks', {}), ctx);
    if (op === 'start') return store.transaction(async () => {
      alive(ctx.signal);
      const params = {task_id:args.task_id,policy:args.policy,seed:args.seed};
      // UI submission identity is an idempotency key only, NOT session authority.
      const row = store.claim(id.session, args.submission_id || call, params);
      if (row.state === 'owned') return {http_status: 200, response: {run_id: row.run_id, idempotent: true, state: 'previously_submitted',owned_by_session:true}};
      const response = await remote(packet('start', {...params, request_id: row.request_id}), ctx);
      alive(ctx.signal);
      store.settle(id.session, row.request_id, response);
      return {...response,response:{...response.response,owned_by_session:store.owns(id.session,response.response?.run_id)}, request_id: row.request_id};
    });
    let runId = args.run_id;
    if (!runId) {
      const state = store.read(id.session);
      // An older receipt is not evidence about a newer, unconfirmed startup.
      // Only an explicit run_id may bypass reconciliation of that startup.
      const pending = state.calls.findLast(r => r.state === 'unconfirmed');
      if (pending) {
        const recovered = await remote(packet('resolve', {request_id: pending.request_id}), ctx);
        if (![200, 202].includes(recovered.http_status) || !RUN.test(recovered.response?.run_id || '')) return recovered;
        alive(ctx.signal);
        store.settle(id.session, pending.request_id, recovered);
        runId = recovered.response.run_id;
      } else runId = state.selected_run_id;
      if (!runId) return {http_status: 200, response: {run_id: null, status: 'no_session_run'}};
    }
    alive(ctx.signal);
    if (op === 'stop' && !store.owns(id.session, runId)) throw new Error('Cannot stop a run not started by this Agnes session');
    const response=await remote(packet(op, {run_id: runId}), ctx);
    return {...response,response:{...response.response,owned_by_session:store.owns(id.session,runId)}};
  }
  return {
    async execute(op, input, ctx) {
      alive(ctx.signal);
      const local = new AbortController(); active.add(local);
      const signal = AbortSignal.any([controller.signal, local.signal, ...(rowSignal ? [rowSignal] : []), ctx.signal]);
      try { return await execute(op, input, {...ctx, signal}); }
      finally { active.delete(local); }
    },
    close() { controller.abort(); for (const ac of active) ac.abort(); active.clear(); }
  };
}
