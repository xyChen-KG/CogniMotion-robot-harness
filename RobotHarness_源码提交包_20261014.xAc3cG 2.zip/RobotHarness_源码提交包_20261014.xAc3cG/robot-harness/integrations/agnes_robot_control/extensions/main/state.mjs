// Adapter-owned private persistence, not user task filesystem or runner state.
import { constants, closeSync, fstatSync, openSync, readFileSync, writeFileSync, fsyncSync,
         renameSync, mkdirSync, rmdirSync, lstatSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { join, isAbsolute } from 'node:path';

export const CONFIG = join(homedir(), '.config/robot-harness/agnes-control.json');
export const digest = value => createHash('sha256').update(value).digest('hex');
export const RUN = /^run_[a-f0-9]{32}$/;
export const NAME = /^[A-Za-z0-9._-]{1,128}$/;

export function privateRead(path, limit = 262144) {
  const fd = openSync(path, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
  try {
    const stat = fstatSync(fd);
    if (!stat.isFile() || stat.uid !== process.getuid() || stat.mode & 0o077 || stat.size > limit)
      throw new Error('Private adapter state unavailable');
    return JSON.parse(readFileSync(fd, 'utf8'));
  } finally { closeSync(fd); }
}

export function configuration(path = CONFIG) {
  const value = privateRead(path, 4096);
  const keys = ['installationId', 'stateDirectory'];
  if (Object.keys(value).some(k => !keys.includes(k)) ||
      !NAME.test(value.installationId || '') || !isAbsolute(value.stateDirectory || ''))
    throw new Error('Invalid operator configuration');
  const stat = lstatSync(value.stateDirectory);
  if (!stat.isDirectory() || stat.isSymbolicLink() || stat.uid !== process.getuid() || stat.mode & 0o077)
    throw new Error('Private adapter directory required');
  return value;
}

function save(path, value) {
  const tmp = path + '.' + process.pid + '.tmp';
  const fd = openSync(tmp, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600);
  try { writeFileSync(fd, JSON.stringify(value)); fsyncSync(fd); } finally { closeSync(fd); }
  renameSync(tmp, path);
  const parent = openSync(path.slice(0, path.lastIndexOf('/')), constants.O_RDONLY);
  try { fsyncSync(parent); } finally { closeSync(parent); }
}

export class StateStore {
  constructor(config) { this.config = config; this.tail = Promise.resolve(); }
  async transaction(fn) {
    const prior = this.tail;
    let release;
    this.tail = new Promise(r => { release = r; });
    await prior;
    const lock = join(this.config.stateDirectory, 'control-operation.lock');
    let claimed = false;
    try {
      mkdirSync(lock, {mode: 0o700}); claimed = true;
      return await fn();
    } catch (error) {
      if (error.code === 'EEXIST') throw new Error('Another control operation or unresolved owner holds the adapter lock; no task submitted');
      throw error;
    } finally { if (claimed) rmdirSync(lock); release(); }
  }
  path(session) { return join(this.config.stateDirectory, 'session_' + digest(session) + '.json'); }
  read(session) {
    try { return privateRead(this.path(session)); }
    catch (error) { if (error.code === 'ENOENT') return {session, calls: [], selected_run_id: null}; throw error; }
  }
  write(session, value) { save(this.path(session), value); }
  claim(session, callId, args) {
    const state = this.read(session);
    let row = state.calls.find(r => r.call_id === callId || r.call_ids?.includes(callId));
    if (!row) row = state.calls.find(r => r.state === 'unconfirmed');
    if (row) {
      if (JSON.stringify(row.args) !== JSON.stringify(args)) throw new Error('An unresolved startup exists; query it before a different task');
      if (!(row.call_ids || []).includes(callId)) {
        row.call_ids = [...(row.call_ids || [row.call_id]), callId];
        this.write(session, state);
      }
      return row;
    }
    const requestId = 'agnes_' + digest(JSON.stringify([this.config.installationId, session, callId]));
    row = {call_id: callId, call_ids: [callId], request_id: requestId, args, state: 'unconfirmed', run_id: null, created_at: Date.now()};
    state.calls.push(row);
    this.write(session, state); // Durable before SSH; errors must prevent the effect.
    return row;
  }
  settle(session, requestId, envelope) {
    const state = this.read(session);
    const row = state.calls.find(r => r.request_id === requestId);
    if (!row) throw new Error('Missing persistent intent');
    if ([200, 202].includes(envelope.http_status) && RUN.test(envelope.response?.run_id || '')) {
      row.run_id = envelope.response.run_id; row.state = 'owned';
      state.selected_run_id = row.run_id;
    } else if ([400, 403, 409, 422].includes(envelope.http_status) && envelope.response?.outcome_unknown !== true) {
      row.state = 'refused';
    }
    row.last_http_status = envelope.http_status;
    this.write(session, state);
    return row;
  }
  owns(session, runId) { return this.read(session).calls.some(r => r.state === 'owned' && r.run_id === runId); }
}
