# Agnes Robot Control 0.1.2

独立控制工具插件。不会修改 VLA、阶段、复位、预算、成功标准或只读 SSH 观看桥。

## 工具与授权

- `robot_list_tasks {}`：真实登记任务、策略、种子和执行开关。
- `robot_start_run {task_id, policy, seed}`：需要 Agnes 正常审批；从原 API 异步返回 run_id。模型不提供request_id、路径、URL、命令或预算。前端已有固定submission_id时须原样携带，它只作幂等键，不授予权限。
- `robot_get_run {run_id?}`：省略 ID 时查询本会话回合，或只读核对尚未确认的启动。
- `robot_get_result {run_id?}`：结果语义原样保留，尚未完成明确返回。
- `robot_stop_run {run_id}`：需要审批；本会话拥有且远端确认归属才经原 API 请求停止。不能停其他会话或常驻模型。

启动/停止声明 `isReadOnly:false`、`requiresApproval:always`、`replay:never`。查询为只读。SDK/Host 撤销租约与插件 disposer 均拒绝旧工具句柄。停用仅取消适配器连接，不停止机器人。

## 固定链路

工具 → 调用时 Host `ctx.sandbox.confine` → 仅启动经限制后的固定 SSH argv → 固定 SSH alias `robot-gpu` → 固定服务器 `agnes_control_client.py` → 已有 `client.request` → runner HTTP API。

JSON 走 stdin，不拼接模型参数到命令。远端 token 仅由既有 client 在服务器私有文件读取；不复制到 Mac、包、网页、提示词或日志。不修改只读 `remote_preview_bridge.py`。

远端适配器代码在 `remote/control_client.py`，部署为 runner 目录中的 `agnes_control_client.py`。服务器 `private/agnes_control.sqlite` 保存 Unix用户、安装身份、会话、request_id、参数、run_id归属。每个调用使用私有锁序列化，不删除锁文件，不排队重跑。未知进程状态由原服务保守拒绝。

## 持久幂等

主会话身份取自 Host `session.key`，调用身份取自 `toolUseId`。先持久化意图，随后发送相同 request_id。响应丢失后新工具调用先复用尚未确认意图；不同参数会被拒绝。`robot_get_run {}` 用 GET 查询核对，绝不触发启动。

0.1.2增加UI submission_id确定性绑定；同一UI意图的多个model toolUseId归于同一个request_id。宿主会话ID可带冒号，固定SSH协议用确定性摘要编码，仍取自可信ToolContext，不从模型参数读取。真实成功/查询回执增加owned_by_session供面板展示，停止仍受本地记录与远端服务双重检查。

0.1.1 修复：默认查询先核对最近未确认启动，即使会话已有旧回合。无法确认时明确返回 `startup_unconfirmed`，不回退展示旧回合；显式指定历史 `run_id` 仍只查询指定回合。查询不会发 POST 或生成新启动标识。

结果工具将独立原生/流程结果、阶段完成历史、终止原因和 MP4 相对位置写入模型可见的 `content`，而非仅存 `structured`。保留 `null`/缺失的未知语义，不从 `native_success_ever` 推断最终成功。每次摘要最多列出 8 个录像、每个相对路径最多 512 字符；超出明确标注，完整阶段记录和产物仍保存在 `structured`。远端错误和终止原因经凭据模式脱敏并限制为 512 字符，保留退出码。

本机私有配置：`~/.config/robot-harness/agnes-control.json`，0600：

```json
{"installationId":"操作员生成的固定UUID","stateDirectory":"本机私有状态目录绝对路径"}
```

状态目录0700，写原子替换并fsync。安装身份不是API token，不充当独立认证；实际访问受本机用户、SSH认证、Agnes工具审批与服务token保护。同一Unix用户/root不属于防恶意隔离边界。

进程意外崩溃遗留本机操作锁时保守拒绝；不自动删除锁或恢复动作。查询仍可核对已提交意图。正常收尾撤销自己的锁。

## 面板联动

配套 viewer 0.1.3仍只注册原有两条query。它读取当前Agnes会话的Host工具结果投影，精确关联run_id；没有启动回执不猜最新任务。可手动观看其他历史回合，也可重新“跟随本会话回合”。错误回合/共享观察器切换期间等待，不拿另一回合画面替代。

`native_success`、`workflow_success`和历史阶段分别显示。断线/unknown不等于任务失败；旧图不称实时。关闭页面/会话、收起面板都不调用stop。

## 测试

```sh
/usr/local/bin/node --test tests/*.test.mjs
PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest discover -s tests -p 'test_*.py' -v
```

均为模拟：不接GPU、不发付费请求。另有 `tests/host_acceptance.mts`，使用真正 Agnes Host/Core 与脚本模型验证注册、会话上下文、审批拒绝、撤销旧句柄；`--read-only-live`让任务列表和已有验收回合结果查询走真实SSH，并断言后续模型请求确实包含成功判定、阶段历史和录像位置。只读验收依赖保留的已结束回合，不启动任务。需从 Agnes 源码目录使用 Node24 `--import tsx` 运行。真实联网查询与真实GPU验收分别报告。

0.1.0 历史验收：控制Node测试10项、远端适配器模拟6项、观看插件6项通过；Agnes定向62项通过，正式Host验收通过。runner原41项、viewer原8项回归通过。0.1.1 新增了旧回合存在/不存在、核对成功/未知的四种子用例及模型可见结果回归；不把测试通过等同真实GPU任务完成。

## 正常部署

本包为标准 `agnes.plugins` row，`inject:extension`。使用 Settings → Plugins 的 inspect/install/trust/enable流程；viewer更新也走update，不编辑安装快照。不自行提高profile能力、不关闭审批。

远端运行开关若关闭，工具返回 `runs_disabled`；这不是模型失败，插件不会开启它。部署与加载插件不构成新实验预算。

## 0.1.0 部署历史（2026-10-13）

- 标准SDK完成 control 0.1.0的 inspect/install/trust/enable，actual=running；live-viewer 0.1.3正常update/activation，actual=running。
- 控制插件停用显示not-running，重新启用恢复running。原runner服务和常驻模型没有停止。
- 真正Host脚本模型调用robot_list_tasks通过；远端runs_enabled=false、无活动回合。部署没有开启执行开关。
- 已有回合 `run_a76106ba1cfb4a5b8afba6a052a62af6` 的最终图与MP4分块读取通过，不是新任务成功证明。
- Computer Use权限不足，本次没有新版面板屏幕验收或自然语言真实模型选工具验收。用户刷新Agnes后可使用；真实GPU验收须另授权。
- 排查时曾有一次CLI把package status误作对话触发模型回复，计费未知；已停止该路径，正式部署使用SDK，没有再发模型请求。

## 使用示例

- “列出机器人实际可运行的任务和允许种子，不启动任务。”
- “查询本会话机器人任务进度。”
- 获得实验授权后：“用internw0运行same_perturb_five_stage，seed47；先请求我的审批。”
- “停止本会话启动的run_…；请求审批，不停止模型。”
- “显示这次结果，并在右侧面板回放已有录像。”

限制：仅主会话可控制；单任务由原runner保护；无暂停/恢复、无自动启用/重试新ID；SSH不稳定时结果可能待核对。只读resolve查最近20条列表，久远未确认请求需要操作员核查，不重跑。模型自然语言选工具尚需实际会话验证；模拟成功不冒充真实任务成功。
