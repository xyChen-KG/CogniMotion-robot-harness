// Actual Agnes Host/Core + this plugin, isolated HOME and scripted model only.
import assert from 'node:assert/strict';
import {mkdtempSync, mkdirSync, writeFileSync, readFileSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';

const repo='/opt/agnes-harness';
const directory=join(repo,'extensions/robot-control');
const scratch=mkdtempSync(join(tmpdir(),'robot-host-acceptance-'));
const oldHome=process.env.HOME;
const liveRead = process.argv.includes('--read-only-live');
const liveConfig = liveRead ? readFileSync(join(oldHome || '', '.config/robot-harness/agnes-control.json'),'utf8') : null;
process.env.HOME=scratch;
mkdirSync(join(scratch,'.config/robot-harness'),{recursive:true,mode:0o700});
const state=join(scratch,'control-state');mkdirSync(state,{mode:0o700});
writeFileSync(join(scratch,'.config/robot-harness/agnes-control.json'),JSON.stringify({installationId:liveConfig ? JSON.parse(liveConfig).installationId : 'isolated-host-test',stateDirectory:state}),{mode:0o600});

const {createTestHost}=await import(pathToFileURL(join(repo,'packages/host/testkit/index.ts')).href);
const {hashDirectory}=await import(pathToFileURL(join(repo,'packages/package-manager/src/index.ts')).href);
const {buildRuntimeTarget,createPluginRow}=await import(pathToFileURL(join(repo,'packages/plugin-runtime/src/host/index.ts')).href);
const {checkToolDef}=await import(pathToFileURL(join(repo,'packages/extension-api/src/index.ts')).href);
const manifest=JSON.parse(readFileSync(join(directory,'package.json'),'utf8'));
const declared=manifest.agnes.plugins[0];
const snapshotId='sha256-'+'9'.repeat(64);
const source={snapshot:{snapshotId,profile:'local-dev',packageId:manifest.name,version:manifest.version,
  integrity:snapshotId,treeIntegrity:hashDirectory(directory,{exclude:[]}),capabilityHash:'fixture',directory,contributions:[]},generation:1,trusted:true};
const row=createPluginRow({id:declared.id,plugin:`@robot-harness/control@${snapshotId}/runtime`,snapshotDigest:snapshotId,
  exportName:'runtime',entryRevision:snapshotId,extrasRevision:'none',mountRevision:'host-ordinary-row:v1',inject:['extension'],runtime:'in-process'});
const target=(rows)=>buildRuntimeTarget({rows,resources:{mcp:[],skills:{}},resourceRevision:'0'.repeat(64),compositeRevision:'0'.repeat(64)});
const call=(name,args)=>[{type:'toolcall_end',via:'native',call:{toolUseId:'',name,args,ordinal:0}},{type:'done',reason:'toolUse'}];
let approvals=0;
let modelResultVerified=false;
const readScript=liveRead ? [call('robot_list_tasks',{}),
  call('robot_get_result',{run_id:'run_a76106ba1cfb4a5b8afba6a052a62af6'}), req => {
    const text=req.messages.filter(m=>m.role==='tool_result' || m.role==='tool')
      .flatMap(m=>m.content).filter(b=>b.type==='text' || b.type==='tool_result').map(b=>b.text).join('\n');
    assert.ok(text.includes('"native_success":true'));
    assert.ok(text.includes('"workflow_success":true'));
    assert.ok(text.includes('"completed_stage_ids"'));
    assert.ok(text.includes('"recordings":['));
    assert.ok(text.includes('episode/episode.mp4'));
    modelResultVerified=true;
    return [{type:'text_delta',delta:'Read-only result verified'}];
  }] : [call('robot_get_run',{}),[{type:'text_delta',delta:'done'}]];
const {host}=await createTestHost({dataDir:join(scratch,'host'),disableSessionTitle:true,
  script:[...readScript,
          call('robot_start_run',{task_id:'same_perturb_five_stage',policy:'internw0',seed:47}),[{type:'text_delta',delta:'denied'}]],
  approval:async()=>{approvals++;return {passed:false,tier:0,reasons:['Simulated explicit denial']};},
  runtimePluginCatalogue:[source],extensionLoader:{import:async file=>import(pathToFileURL(file).href)}});
try{
  await host.applyRuntimeTarget(target([row]));
  const tools=host.kernel.tools.list().filter(t=>t.name.startsWith('robot_'));
  assert.equal(tools.length,5);
  for(const tool of tools)assert.equal(checkToolDef(tool,{prefix:''}).ok,true);
  const session=await host.createSession({cwd:join(scratch,'host'),key:'robot-host-test'});
  await session.enqueue('next-turn',{actor:session.d.actor,content:[{type:'text',text:'Query own robot state'}]});
  await session.run({until:'turn-end',signal:new AbortController().signal});
  const results=await session.scan({type:'tool/result',toSeq:session.lastSeq});
  assert.match(JSON.stringify(results),liveRead ? /same_perturb_five_stage/ : /no_session_run/);
  if (liveRead) assert.match(JSON.stringify(results),/runs_enabled.*false/);
  if (liveRead) assert.equal(modelResultVerified,true);
  const saved=host.kernel.tools.resolve('robot_get_run');
  await session.enqueue('next-turn',{actor:session.d.actor,content:[{type:'text',text:'Denied test start, no robot'}]});
  await session.run({until:'turn-end',signal:new AbortController().signal});
  assert.ok(approvals>=1);
  assert.equal(readFileSync(join(scratch,'.config/robot-harness/agnes-control.json'),'utf8').includes('api.token'),false);
  await host.applyRuntimeTarget(target([]));
  assert.equal(host.kernel.tools.list().filter(t=>t.name.startsWith('robot_')).length,0);
  await assert.rejects(saved.execute({}, {session:{key:'robot-host-test',toolUseId:'old',depth:0},signal:new AbortController().signal}),/closed|expired|disabled|unavailable/i);
  await session.close();
  console.log(JSON.stringify({actual_host_tools:tools.map(t=>t.name),read_context_verified:true,approval_denial_verified:true,
    old_handles_revoked:true,read_only_live:liveRead,model_result_verified:modelResultVerified,model:'scripted-only',gpu_runs:0}));
}finally{await host.close();process.env.HOME=oldHome;rmSync(scratch,{recursive:true,force:true});}
