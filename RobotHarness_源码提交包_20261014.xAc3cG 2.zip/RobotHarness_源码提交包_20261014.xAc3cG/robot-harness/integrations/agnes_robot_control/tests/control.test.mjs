import test from 'node:test';
import {EventEmitter} from 'node:events';
import {PassThrough, Writable} from 'node:stream';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createControl, SSH_ARGV, validate } from '../extensions/main/backend.mjs';
import { StateStore } from '../extensions/main/state.mjs';
import * as plugin from '../extensions/main/index.mjs';
const { runtime } = plugin;

const run = 'run_' + 'a'.repeat(32);
const args = {task_id: 'same_perturb_five_stage', policy: 'internw0', seed: 47};
const context = (session = 'session-a', call = 'call1') => ({session: {key: session, toolUseId: call, depth: 0}, signal: new AbortController().signal});
function fixture(transport) {
  const dir = mkdtempSync(join(tmpdir(), 'agnes_control_'));
  const store = new StateStore({installationId: 'test-installation', stateDirectory: dir});
  return {dir, store, control: createControl({store, transport}), close() {this.control.close(); rmSync(dir, {recursive: true});}};
}

test('start persists identity before effect, responds immediately with exact run, replay is same', async () => {
  let f, starts = 0;
  f = fixture(async packet => {
    starts++;
    assert.equal(f.store.read('session-a').calls[0].request_id, packet.args.request_id);
    return {http_status: 202, response: {run_id: run, status: 'starting'}};
  });
  try {
    const result = await f.control.execute('start', args, context());
    assert.equal(result.response.run_id, run);
    assert.equal(f.store.read('session-a').selected_run_id, run);
    assert.equal((await f.control.execute('start', args, context())).response.run_id, run);
    assert.equal(starts, 1);
  } finally { f.close(); }
});

test('lost response + restart + changed tool id preserves same request id, not model memory', async () => {
  let seen;
  const f = fixture(async packet => {seen = packet.args.request_id; throw new Error('lost response');});
  try {
    await assert.rejects(f.control.execute('start', args, context()));
    f.control.close();
    const recovered = createControl({store: new StateStore(f.store.config), transport: async p => {
      assert.equal(p.args.request_id, seen);
      return {http_status: 200, response: {run_id: run, idempotent: true}};
    }});
    assert.equal((await recovered.execute('start', args, context('session-a', 'retry-new-call'))).response.run_id, run);
    recovered.close();
  } finally {f.close();}
});

test('read prioritizes unconfirmed startup, never falls back to an older run or POSTs', async t => {
  for (const previous of [false, true]) for (const recovered of [false, true]) {
    await t.test(`older run=${previous}, recovery=${recovered}`, async () => {
      const newer = 'run_' + 'b'.repeat(32);
      let first = true, resolveCalls = 0, startCalls = 0;
      const f = fixture(async p => {
        if (p.op === 'start') {
          startCalls++;
          if (previous && first) { first = false; return {http_status: 202, response: {run_id: run}}; }
          throw new Error('disconnect after newer run submitted');
        }
        if (p.op === 'resolve') {
          resolveCalls++;
          return {http_status: 200, response: recovered ? {run_id: newer, status: 'running'} :
            {run_id: null, status: 'startup_unconfirmed'}};
        }
        assert.ok(['status', 'result'].includes(p.op));
        return {http_status: 200, response: {run_id: p.args.run_id, status: 'finished'}};
      });
      try {
        if (previous) await f.control.execute('start', args, context('session-a', 'older-start'));
        await assert.rejects(f.control.execute('start', args, context('session-a', 'newer-start')));
        if (previous) {
          assert.equal((await f.control.execute('status', {run_id: run}, context())).response.run_id, run);
          assert.equal(resolveCalls, 0); // Explicit historical queries remain explicit.
        }
        for (const op of ['status', 'result']) {
          const reply = await f.control.execute(op, {}, context());
          assert.equal(reply.response.run_id, recovered ? newer : null);
          if (!recovered) assert.equal(reply.response.status, 'startup_unconfirmed');
        }
        assert.equal(f.store.read('session-a').selected_run_id, recovered ? newer : previous ? run : null);
        assert.ok(resolveCalls > 0);
        assert.equal(startCalls, previous ? 2 : 1);
      } finally {f.close();}
    });
  }
});

test('model-visible results retain native outcomes, history, diagnostics and recording metadata', () => {
  assert.equal(typeof plugin.modelVisibleResult, 'function');
  for (const outcome of [true, false, null]) {
    const summary = {native_success: outcome, workflow_success: false, native_success_ever: true,
      completed_stage_ids: [1, 2], termination_reason: 'stage_failed', steps: 512};
    const envelope = {http_status: 200, response: {run_id: run, status: 'finished', completed: true,
      result_available: true, summary, error: 'motion stopped', exit_code: 1,
      artifacts: [{path: 'episode/episode.mp4', size_bytes: 1234}, {path: '../private.mp4', size_bytes: 1}],
      stage_states: [{huge: 'x'.repeat(20000)}]}};
    const text = JSON.stringify(plugin.modelVisibleResult(envelope));
    const visible = JSON.parse(text).response;
    assert.equal(visible.run_id, run);
    assert.equal(visible.completed, true);
    assert.equal(visible.result_available, true);
    assert.equal(visible.summary.native_success, outcome);
    assert.equal(visible.summary.workflow_success, false);
    assert.deepEqual(visible.summary.completed_stage_ids, [1, 2]);
    assert.equal(visible.summary.termination_reason, 'stage_failed');
    assert.equal(visible.error, 'motion stopped');
    assert.equal(visible.exit_code, 1);
    assert.deepEqual(visible.recordings, [{path: 'episode/episode.mp4', size_bytes: 1234}]);
    assert.ok(text.length < 4096); // Run receipt remains parseable by the session panel.
  }
  const absent = plugin.modelVisibleResult({http_status: 202, response: {run_id: run, completed: false, summary: null}});
  assert.equal(absent.response.summary, null);
  assert.equal(absent.response.completed, false);
  const tasks = [{task_id: 'task', policies: ['internw0'], allowed_seeds: [47]}];
  assert.deepEqual(plugin.modelVisibleResult({http_status: 200, response: {tasks, runs_enabled: false}}).response.tasks, tasks);
});

test('UI submission identity dedupes model duplicate calls across tool IDs and survives reload',async()=>{
  let starts=0;
  const f=fixture(async()=>{starts++;return {http_status:202,response:{run_id:run,status:'starting'}};});
  try{
    const withId={...args,submission_id:'ui_'+'c'.repeat(32)};
    const first=await f.control.execute('start',withId,context('session-a','model-call-1'));
    const second=await f.control.execute('start',withId,context('session-a','model-call-2'));
    assert.equal(first.response.owned_by_session,true);assert.equal(second.response.run_id,run);assert.equal(starts,1);
    assert.throws(()=>validate('start',{...args,submission_id:'anything'}));
  }finally{f.close();}
});

test('same call cannot change parameters, foreign sessions cannot stop', async () => {
  const f = fixture(async () => ({http_status: 202, response: {run_id: run}}));
  try {
    await f.control.execute('start', args, context());
    await assert.rejects(f.control.execute('start', {...args, seed: 48}, context()));
    await assert.rejects(f.control.execute('stop', {run_id: run}, context('other-session')));
  } finally {f.close();}
});

test('concurrent starts are serialized and original server remains single-slot authority', async () => {
  let started = false;
  const f = fixture(async () => {
    if (started) return {http_status: 409, response: {error: 'busy'}};
    started = true; return {http_status: 202, response: {run_id: run}};
  });
  try {
    const values = await Promise.all(['s1', 's2'].map(s => f.control.execute('start', args, context(s))));
    assert.deepEqual(values.map(v => v.http_status), [202, 409]);
  } finally {f.close();}
});

test('disabled and unknown runner outcomes remain explicit, unknown not turned into success', async () => {
  const f = fixture(async p => p.op === 'start' ? {http_status: 403, response: {error: 'runs_disabled'}} :
    {http_status: 200, response: {run_id: run, active: true, status: 'interrupted', ownership_uncertain: true}});
  try {
    const response = await f.control.execute('start', args, context());
    assert.equal(response.http_status, 403);
    assert.equal(f.store.read('session-a').selected_run_id, null);
    const status = await f.control.execute('status', {run_id: run}, context());
    assert.equal(status.response.ownership_uncertain, true);
    assert.equal(status.response.native_success, undefined);
  } finally {f.close();}
});

test('strict input and Host main-session identity, no client shell/path/url/budget', async () => {
  for (const bad of [{...args, command: 'id'}, {...args, request_id: 'model-id'}, {...args, seed: true}, {...args, task_id: 'a;id'}])
    assert.throws(() => validate('start', bad));
  assert.throws(() => validate('tasks', {url: 'http://evil'}));
  const f = fixture(async () => assert.fail('must not dispatch'));
  try {
    await assert.rejects(f.control.execute('start', args, {...context(), session: {...context().session, depth: 1}}));
  } finally {f.close();}
});

test('SSH command is constant, JSON input travels on stdin and credentials never supplied', async () => {
  const f = fixture();
  const control = createControl({store: f.store, spawner: (command, argv, options) => {
    assert.deepEqual([command,...argv],[...SSH_ARGV]);
    assert.equal(options.env.API_TOKEN,undefined);
    const child = new EventEmitter();child.stdout=new PassThrough();child.kill=()=>{};
    let body='';child.stdin=new Writable({write(chunk,encoding,done){body+=chunk;done();},final(done){
      assert.equal(JSON.parse(body).op,'tasks');done();
      queueMicrotask(()=>{child.stdout.write(JSON.stringify({http_status:200,response:{tasks:[]}}));child.emit('close',0);});
    }});return child;
  }});
  try {
    const ctx = {...context(),sandbox:{confine:async argv=>{assert.deepEqual(argv,[...SSH_ARGV]);return argv;}}};
    assert.equal((await control.execute('tasks', {}, ctx)).http_status, 200);
  } finally {control.close(); f.close();}
});

test('plugin declares effects and lifecycle rejects retained old tools', async () => {
  const definitions = [], effects = [];
  const ac = new AbortController();
  runtime.apply({extension: () => ({ctx: {signal: ac.signal}, registerTool: d => {definitions.push(d); return () => {};}}), effect: f => effects.push(f())});
  assert.equal(definitions.length, 5);
  for (const d of definitions) {
    if (['robot_start_run', 'robot_stop_run'].includes(d.name)) {
      assert.equal(d.meta.isReadOnly, false); assert.equal(d.meta.requiresApproval, 'always'); assert.equal(d.meta.replay, 'never');
    } else assert.equal(d.meta.isReadOnly, true);
  }
  effects.forEach(f => f());
  await assert.rejects(definitions[0].execute({}, context()), /disabled/);
});

test('stale adapter lock fails closed; no deletion or process signalling', async () => {
  const f = fixture(async () => assert.fail('no effect'));
  try {
    mkdirSync(join(f.dir, 'control-operation.lock'));
    await assert.rejects(f.control.execute('start', args, context()), /lock/);
  } finally {f.close();}
});
