// Formal Host tools + scripted provider + real runner HTTP/fake child. No GPU/API model.
import assert from 'node:assert/strict';
import {mkdtempSync, mkdirSync,writeFileSync,rmSync,readFileSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
const here=fileURLToPath(new URL('..',import.meta.url));
const repo='/opt/agnes-harness';
const pkg=join(here,'extensions/main/index.mjs');
const {createRuntime}=await import(pathToFileURL(pkg).href);
const {createControl}=await import(pathToFileURL(join(here,'extensions/main/backend.mjs')).href);
const {SessionOperations,timelineState}=await import(pathToFileURL(join(here,'../agnes_robot_viewer/extensions/main/client/operations.mjs')).href);
const {createTestHost}=await import(pathToFileURL(repo+'/packages/host/testkit/index.ts').href);
const {createLocalEndpoint}=await import(pathToFileURL(repo+'/packages/daemon/src/local/index.ts').href);
const {testWorkspaceCatalog}=await import(pathToFileURL(repo+'/packages/daemon/test/host.ts').href);
const {createClient,memoryJournal}=await import(pathToFileURL(repo+'/packages/sdk/src/index.node.ts').href);
const {hashDirectory}=await import(pathToFileURL(repo+'/packages/package-manager/src/index.ts').href);
const {buildRuntimeTarget,createPluginRow}=await import(pathToFileURL(repo+'/packages/plugin-runtime/src/host/index.ts').href);
const root=mkdtempSync(join(tmpdir(),'robot-ui-host-'));
const old=process.env.HOME;process.env.HOME=root;
const state=join(root,'state');mkdirSync(state,{mode:0o700});mkdirSync(join(root,'.config/robot-harness'),{recursive:true,mode:0o700});
writeFileSync(join(root,'.config/robot-harness/agnes-control.json'),JSON.stringify({installationId:'test-install',stateDirectory:state}),{mode:0o600});
const child=spawn('python3',['-B',join(here,'tests/fake_runner_fixture.py')],{stdio:['pipe','pipe','pipe'],env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'}});
let stderr='';child.stderr.on('data',d=>stderr+=d);
const lines=createInterface({input:child.stdout});const queue=[];let ready;
const readiness=new Promise(r=>ready=r);
lines.on('line',line=>{const value=JSON.parse(line);if(value.ready)ready();else queue.shift()?.(value);});
await Promise.race([readiness,new Promise((_,reject)=>setTimeout(()=>reject(Error(stderr||'Fixture readiness failed')),8000).unref())]);
const packets=[];
const transport=(packet)=>new Promise(resolve=>{packets.push(packet);queue.push(resolve);child.stdin.write(JSON.stringify(packet)+'\n');});
const manifest=JSON.parse(readFileSync(join(here,'package.json'),'utf8'));
const snapshotId='sha256-'+'8'.repeat(64);
const source={snapshot:{snapshotId,profile:'local-dev',packageId:manifest.name,version:manifest.version,integrity:snapshotId,
 treeIntegrity:hashDirectory(here,{exclude:[]}),capabilityHash:'fixture',directory:here,contributions:[]},generation:1,trusted:true};
const row=createPluginRow({id:manifest.agnes.plugins[0].id,plugin:`${manifest.name}@${snapshotId}/runtime`,snapshotDigest:snapshotId,
 exportName:'runtime',entryRevision:snapshotId,extrasRevision:'none',mountRevision:'host-ordinary-row:v1',inject:['extension']});
const target=rows=>buildRuntimeTarget({rows,resources:{mcp:[],skills:{}},resourceRevision:'0'.repeat(64),compositeRevision:'0'.repeat(64)});
const call=(name,args)=>[{type:'toolcall_end',via:'native',call:{toolUseId:'',name,args,ordinal:0}},{type:'done',reason:'toolUse'}];
const args={task_id:'slow',policy:'atomic',seed:47};let current;
let decisions=[false,true,true,true];let approvals=0;
const {host}=await createTestHost({dataDir:join(root,'host'),disableSessionTitle:true,
 script:[()=>call('robot_start_run',current),[{type:'text_delta',delta:'Denied'}],
  ()=>call('robot_start_run',current),()=>call('robot_start_run',current),[{type:'text_delta',delta:'Submitted'}],
  ()=>call('robot_stop_run',current),[{type:'text_delta',delta:'Stopped'}]],
 approval:async req=>{approvals++;return decisions.shift()?'allowed-once':'rejected';},
 prompter:async req=>{approvals++;return decisions.shift()?'allowed-once':'rejected';},
 runtimePluginCatalogue:[source],extensionLoader:{import:async file=>file.endsWith('/index.mjs')?
  {runtime:createRuntime(options=>createControl({...options,transport}))}:import(pathToFileURL(file).href)}});
let client;
try{
 await host.applyRuntimeTarget(target([row]));
 const workspaces=await testWorkspaceCatalog(join(root,'host'));
 const endpoint=createLocalEndpoint(host,{workspaces,pollMs:5});
 client=createClient({transport:{kind:'inproc',endpoint},journal:memoryJournal()});
 const sdkSession=await client.session.new({cwd:join(root,'host')});
 const session=host.kernel.get(sdkSession.id);
 const owner=sdkSession.id;
 const remoteOwner=owner.includes(':')?'session_'+(await import('node:crypto')).createHash('sha256').update(owner).digest('hex'):owner;
 const cache=new Map();const storage={getItem:k=>cache.get(k)||null,setItem:(k,v)=>cache.set(k,v)};
 const ui=new SessionOperations(owner,storage);
 const handle={id:owner,followUp:async(text,{commandId})=>{
   // Actual official SDK request through daemon endpoint; no fabricated ToolContext.
   const input=text.match(/参数严格为 (\{.*?\})。/);current=JSON.parse(input[1]);
   const before=await session.scan({type:'turn/end',toSeq:session.lastSeq});
   const result=await sdkSession.followUp(text,{commandId});
   const deadline=Date.now()+8000;
   while(Date.now()<deadline){
     const nodes=await session.scan({type:'turn/end',toSeq:session.lastSeq});
     if(nodes.length>before.length) return result;
     await new Promise(r=>setTimeout(r,20));
   }
   throw Error('SDK turn did not finish');
 }};
 await ui.submit('start',args,handle,await session.projectUI());
 let projected=await session.projectUI();assert.equal(timelineState(projected,ui.intent).state,'rejected');assert.equal(packets.length,0);
 ui.reconcile(projected);
 await ui.submit('start',args,handle,projected);
 projected=await session.projectUI();const receipt=ui.reconcile(projected);
 assert.ok(receipt.run_id,JSON.stringify({receipt,packets,nodes:projected.nodes.filter(n=>n.kind==='tool'||n.kind==='approval')}));assert.equal(receipt.owned,true);
 assert.equal(packets.filter(p=>p.op==='start').length,1); // Duplicate model tool call uses same UI identity.
 const raw=await transport({op:'status',owner:{installation:'test-install',session:remoteOwner},call_id:'read',args:{run_id:receipt.run_id}});
 assert.equal(raw.response.run_id,receipt.run_id);
 const foreign=await transport({op:'stop',owner:{installation:'test-install',session:'other'},call_id:'foreign',args:{run_id:receipt.run_id}});
 assert.equal(foreign.http_status,403);
 await ui.submit('stop',{run_id:receipt.run_id},handle,projected);
 assert.equal(packets.filter(p=>p.op==='stop'&&p.owner.session===remoteOwner).length,1);
 const saved=host.kernel.tools.resolve('robot_get_run');await host.applyRuntimeTarget(target([]));
 await assert.rejects(saved.execute({}, {session:{key:'owner',toolUseId:'old',depth:0},signal:new AbortController().signal}));
 await session.close();
 console.log(JSON.stringify({formal_host:true,scripted_model:true,fake_executor:true,ui_sdk_submission:true,approval_rejection_no_start:true,
 duplicate_tool_calls_single_run:true,foreign_stop_refused:true,owned_stop:true,old_handle_revoked:true,approvals,gpu_runs:0,paid_models:0}));
}finally{
 if(client)await client.close();await host.close();child.stdin.end();await new Promise(r=>child.once('close',r));lines.close();process.env.HOME=old;rmSync(root,{recursive:true,force:true});
}
