"""No SSH/model: ownership adapter over fake original API and real sqlite persistence."""
import importlib.util
from pathlib import Path
import sqlite3
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('control_client', Path(__file__).parents[1] / 'remote/control_client.py')
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)
RUN = 'run_' + 'a' * 32


class RemoteTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / 'claims.sqlite'
        self.db = sqlite3.connect(self.path)
        self.created = self.stopped = 0
        self.enabled = True
        self.unknown = False
        self.request = None

    def tearDown(self):
        self.db.close()
        self.tmp.cleanup()

    def packet(self, op='start', session='s1'):
        args = dict(task_id='task', policy='internw0', seed=47, request_id='request1') if op == 'start' else {'run_id': RUN} if op in ('status', 'stop', 'result') else {'request_id': 'request1'} if op == 'resolve' else {}
        return client.validate({'op': op, 'owner': {'installation': 'install', 'session': session}, 'call_id': 'call1', 'args': args})

    def api(self, method, path, payload=None):
        if path == '/tasks':
            return 200, {'runs_enabled': self.enabled, 'tasks': [{'task_id': 'task', 'policies': ['internw0'], 'allowed_seeds': [47]}]}
        if path == '/runs' and method == 'POST':
            if self.request is None:
                self.created += 1
                self.request = payload
            return 202, {'run_id': RUN, 'status': 'starting'}
        state = {'run_id': RUN, 'request': self.request, 'status': 'interrupted' if self.unknown else 'running',
                 'active': True, 'ownership_uncertain': self.unknown, 'native_success': None, 'workflow_success': None}
        if path == '/runs':
            return 200, {'runs': [state] if self.request else []}
        if path.endswith('/stop'):
            self.stopped += 1
            return 202, {'run_id': RUN, 'status': 'stopping', 'stop_requested': True}
        if path.endswith('/result'):
            return 202, {'run_id': RUN, 'completed': False}
        return 200, state

    def test_start_duplicate_restart(self):
        self.assertEqual(client.serve(self.packet(), self.api, self.db)['http_status'], 202)
        self.db.close()
        self.db = sqlite3.connect(self.path)
        self.assertEqual(client.serve(self.packet(), self.api, self.db)['http_status'], 200)
        self.assertEqual(self.created, 1)

    def test_response_lost_reconciles_get_without_new_run(self):
        def lose(method, path, payload=None):
            value = self.api(method, path, payload)
            if method == 'POST':
                raise ConnectionError('lost')
            return value
        with self.assertRaises(ConnectionError):
            client.serve(self.packet(), lose, self.db)
        reply = client.serve(self.packet('resolve'), self.api, self.db)
        self.assertEqual(reply['response']['run_id'], RUN)
        self.assertEqual(self.created, 1)

    def test_foreign_owner_and_unknown_refused(self):
        client.serve(self.packet(), self.api, self.db)
        self.assertEqual(client.serve(self.packet('stop', 'other'), self.api, self.db)['http_status'], 403)
        self.unknown = True
        self.assertEqual(client.serve(self.packet('stop'), self.api, self.db)['http_status'], 409)
        self.assertEqual(self.stopped, 0)
        self.unknown = False
        self.assertEqual(client.serve(self.packet('stop'), self.api, self.db)['http_status'], 202)
        self.assertEqual(self.stopped, 1)

    def test_allowlist_and_disabled(self):
        p = self.packet()
        p['args']['seed'] = 48
        self.assertEqual(client.serve(p, self.api, self.db)['http_status'], 400)
        self.enabled = False
        self.assertEqual(client.serve(self.packet(), self.api, self.db)['http_status'], 403)
        self.assertEqual(self.created, 0)

    def test_lost_response_outside_recent_listing_keeps_unknown_when_disabled(self):
        def lost(method, path, payload=None):
            result = self.api(method, path, payload)
            if method == 'POST':
                raise ConnectionError('response lost')
            return result
        with self.assertRaises(ConnectionError):
            client.serve(self.packet(), lost, self.db)
        self.enabled = False
        def old_listing(method, path, payload=None):
            if path == '/runs' and method == 'GET':
                return 200, {'runs': []}
            return self.api(method, path, payload)
        reply = client.serve(self.packet(), old_listing, self.db)
        self.assertEqual(reply['http_status'], 503)
        self.assertTrue(reply['response']['outcome_unknown'])
        self.assertEqual(self.created, 1)

    def test_injection_and_response_redaction(self):
        for key in ('shell', 'url', 'token_file', 'budget'):
            p = self.packet()
            p['args'][key] = 'bad'
            with self.assertRaises(ValueError):
                client.validate(p)
        value = client.summary({'native_success': True, 'workflow_success': False, 'completed_stage_ids': [1],
                                'error': 'executor failed Authorization: Bearer credential123 api_key=secretvalue',
                                'exit_code': 1, 'token': 'secret', 'output_directory': '/private',
                                'summary': {'native_success': None, 'workflow_success': False,
                                            'termination_reason': 'stage_failed token=hiddenvalue'},
                                'artifacts': [{'path': '../bad', 'size_bytes': 1}]})
        self.assertEqual(value['native_success'], True)
        self.assertEqual(value['workflow_success'], False)
        self.assertNotIn('secret', str(value))
        self.assertIn('executor failed', value['error'])
        for credential in ('credential123', 'secretvalue', 'hiddenvalue'):
            self.assertNotIn(credential, str(value))
        self.assertEqual(value['exit_code'], 1)
        self.assertIsNone(value['summary']['native_success'])
        self.assertIn('stage_failed', value['summary']['termination_reason'])
        self.assertEqual(value['artifacts'], [])


if __name__ == '__main__':
    unittest.main()
