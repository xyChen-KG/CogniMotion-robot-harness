"""Real runner HTTP + fake executor + control ownership adapter, isolated only."""
import importlib.util
import json
from pathlib import Path
import secrets
import sqlite3
import sys
import threading

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'services/robot_runner/tests'))
sys.path.insert(0, str(ROOT / 'services/robot_runner'))
from test_runner import RunnerTests
from server import RunnerHTTPServer
from client import request
from auth import create_token_file

spec = importlib.util.spec_from_file_location('robot_control_client', Path(__file__).parents[1] / 'remote/control_client.py')
control = importlib.util.module_from_spec(spec)
spec.loader.exec_module(control)
case = RunnerTests()
case.setUp()
# The test server already uses TemporaryDirectory and fake_executor.py only.
token_path = case.root / 'test.token'
create_token_file(token_path)
from auth import load_token
server = RunnerHTTPServer(0, case.manager, auth_token=load_token(token_path))
thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
thread.start()
db = sqlite3.connect(case.root / 'claims.sqlite')
print(json.dumps({'ready': True}), flush=True)
try:
    for line in sys.stdin:
        try:
            envelope = control.validate(json.loads(line))
            value = control.serve(envelope, lambda method, path, payload=None:
                request(server.server_port, token_path, method, path, payload), db)
        except Exception:
            value = {'http_status': 503, 'response': {'error': 'fixture_unconfirmed'}}
        print(json.dumps(value), flush=True)
finally:
    db.close()
    server.shutdown()
    server.server_close()
    thread.join(3)
    case.tearDown()
