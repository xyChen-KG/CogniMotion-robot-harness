# same/five_stage — 厨房准备

自定义连续任务，不是官方 LIBERO/Plus 发布的测试集。

|阶段|指令|官方原子条件|最终需保留|
|---|---|---|---|
|1|Put the cream cheese on the black bowl.|`on cream_cheese_1 akita_black_bowl_1`|是|
|2|Put the wine bottle on top of the wooden cabinet.|`on wine_bottle_1 wooden_cabinet_1_top_side`|是|
|3|Push the plate to the front of the stove.|`on plate_1 main_table_stove_front_region`|是|
|4|Open the middle drawer of the wooden cabinet.|`open wooden_cabinet_1_middle_region`|是|
|5|Turn on the stove.|`turnon flat_stove_1`|是|

阶段门槛额外要求目标物松爪（released），不改 native_success。历史阶段完成后，即使随后条件变 false，也不阻止后续阶段；最终按 BDDL 的当前官方条件判断。

每阶段 VLA 最多400控制步；总预算3500步（含真实关节回位），并非各局部上限之和。阶段间调用现有 reset_to_stage_start：最多1000步、末端5cm/10°，其余关节容差沿用工具默认值；最后阶段不加回位。

初始状态：seed47、index0。扰动版只将奶酪初始世界X坐标增加1cm，其余保存状态完全相同；未增加相机/语言扰动。不是完整 LIBERO-Plus 协议。

same表示原子任务来自Goal同一套件，不代表后续复合状态仍是训练分布。mixed/five_stage继承已调过奶酪和罐子位置的开发场景，不能作为未见测试集。mixed/eight_stage是Goal场景与Object资产的合成，跨场景分布变化需单独报告。

## 验证与执行

`qa/validation.json`仅是场景、绑定及谓词fixture验证。fixture会直接设置物体/关节状态，绝不是VLA实验或真实机器人动作。初始图见qa/initial_agentview.png。

从固定LIBERO运行环境执行，PYTHONPATH加入现有robot_harness_tools；不需要复制Qwen或模型代码。

```sh
python /opt/robot-harness/benchmarks/custom_long/same/five_stage/task.py validate --task-table /opt/robot-harness/benchmarks/custom_long/same/five_stage/stage_table.json
```

正式试验必须显式选择现有模型服务：Atomic用 --policy atomic --atomic-port PORT；InternW0用 --policy internw0 --intern-socket SOCKET --prompt-manifest MANIFEST（需为本阶段指令预生成T5上下文）。同时选择 --state-updater deterministic 或已部署的Qwen服务。输出目录必须全新；本次设置没有启动策略实验。
