"""Process-local custom suite; no edits to LIBERO or starHarness_Libero.

Usage: python /path/to/task.py validate|run --task-table /path/to/stage_table.json ...
The shared harness remains responsible for bounded real robot motion and scoring.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SPEC = json.loads((ROOT / "task.json").read_text())


def register_suite():
    import numpy as np
    from libero.libero import benchmark
    initial = ROOT / SPEC["initial_state"]
    if not initial.is_file():
        raise FileNotFoundError(initial)

    class CustomSuite:
        def get_task_names(self):
            return [SPEC["id"]]

        def get_task(self, task_id):
            if task_id != 0:
                raise ValueError("This custom suite contains exactly one task")
            return benchmark.Task(SPEC["id"], SPEC["instruction"], SPEC["problem"],
                                  str(ROOT), "task.bddl", str(initial))

        def get_task_bddl_file_path(self, task_id):
            self.get_task(task_id)
            return str(ROOT / "task.bddl")

        def get_task_init_states(self, task_id):
            self.get_task(task_id)
            return [np.load(initial, allow_pickle=False)]

    if SPEC["id"] in benchmark.BENCHMARK_MAPPING:
        raise ValueError("Refusing to replace a registered suite: " + SPEC["id"])
    benchmark.BENCHMARK_MAPPING[SPEC["id"]] = CustomSuite


if __name__ == "__main__":
    import sys
    from starHarness_Libero.cli import main
    if len(sys.argv) > 1 and sys.argv[1] == "run":
        register_suite()
    raise SystemExit(main())
