# starHarness_Libero

独立于现有 `qwen_supervisor*` 的 LIBERO 阶段执行系统。当前版本复现 RoboCasa v3 的职责边界：**人工填写阶段表 → 仿真条件检查 → Qwen 更新当前阶段布尔值 → 冻结 VLA 生成动作**。

没有预选任务，没有任务自动重规划、任务失败恢复、回合重跑、训练或模型下载。可按人工配置在阶段完成后调用运动工具；复位工具含有上限的运动路径规划和重规划，默认不额外回位。Qwen 当前是纯文字状态维护器，不是视觉判定器，也不自由选择动作工具。条件依赖仿真真值，因此结果明确标为 `oracle_used_for_supervision: true`，不能称为纯视觉监督或原生端到端 VLA 成绩。

## 文件位置与独立性

本地目录：`/opt/robot-harness/harnesses/starHarness_Libero/`，与 `qwen_supervisor_v3` 并列。

服务器对应目录：`/opt/robot-harness/harnesses/starHarness_Libero/`。

这里仅包含客户端与调度代码，不复制 Qwen/VLA 权重或服务端。运行时连接用户明确指定的已有本地服务；结束后断开客户端，不卸载模型，也不停止其他进程。阶段执行始终复用同一仿真场景。

## 可变长度人工阶段表

当前默认 `completion_mode: "official_predicates"`：原子目标直接调用安装中
LIBERO 的官方谓词，不另加松爪、静止、入碗几何阈值或连续确认要求。
`stable_steps` 固定为 1，条件在当前物理状态成立就完成，包括阶段开始时已成立的情况。
重复拿起/放回等过程诊断若确实需要额外事件，必须另行明确选择旧的
`stable_conditions` 模式，不能冒充官方任务判定。

`task_table.template.json` 是未填写的空模板，故意不能运行。`stages` 可以有 1、3、5、25 或更多项，没有固定阶段数量上限。每项 ID 按 `1..N` 连续编号，首次运行全部 `completed: false`。增删阶段只改 JSON，不改调度代码。

顶层字段：

- `task`：当前安装中注册的 `suite`、`task_id`、`initial_state_index`、`seed`。不默认选择标准 LIBERO、Mem 或某个任务。
- `bindings`：固定目标别名到仿真对象/区域名称的映射，如 `{"target":"具体对象名","support":"具体盘子名"}`。条件中使用 `@target`、`@support`；运行中不会自动换目标。编号仅供判定，不能假设 VLA 听懂内部对象编号。
- `completion_mode`：当前使用 `official_predicates`；只允许官方关系谓词，没有额外过程事件。
- `stable_steps`：官方模式固定为 1，不引入额外持续时间；旧诊断模式才使用连续步数。
- `budget`：总动作步、Qwen 检查间隔、状态请求上限、VLA 请求上限、总墙钟时间。阶段数量没有硬上限，但这些有限预算仍必须合理填写。
- `stages`：人工阶段列表。`instruction` 是原样交给 VLA 的指令，`max_steps` 是该阶段的 VLA 真实动作步上限，不是动作块数；可选 `post_tools` 是完成后按顺序执行的工具列表。

单条阶段的结构示意（不是可直接运行的任务）：

```json
{
  "id": 1,
  "instruction": "填写这一阶段的完整英文技能指令",
  "max_steps": 400,
  "completed": false,
  "checker": {
    "all": [
      {"predicate": "on", "args": ["@target", "@support"]}
    ]
  }
}
```

仅旧的 `stable_conditions` 模式支持 `sequence`、抓取/抬升事件及释放稳定条件。
官方模式会拒绝这些额外条件，避免无意加严基准。上例只判断官方 `On`。

仅写 `on` 不能证明执行过一次“拿起再放回”。尤其重复任务必须写过程事件，否则初始已有状态、碰动后的回落都可能被误当成完成。普通阶段检查即使没有过程事件，也不会在阶段刚激活、尚未执行任何新动作时直接通过；下文的最后阶段原生终态规则是显式例外。

每个条件可添加 `"negate": true`；这只取反该仿真条件，不执行任意代码。

| predicate | args | 判定含义 |
|---|---|---|
| `on` / `in` | 对象、支撑物或区域 | LIBERO 原生符号关系 |
| `open` / `close` | 对象/门/抽屉引用 | LIBERO 原生开合状态 |
| `turnon` / `turnoff` | 开关对象引用 | LIBERO 原生开关状态 |
| `grasped` | 对象 | 仿真夹爪抓取检查 |
| `released` | 对象 | 没有抓住，且夹爪不接触该对象 |
| `lifted` | 对象、米 | 相对本回合初始高度的抬升量 |
| `stationary` | 对象、米/秒 | 线速度不超过阈值；不检查角速度 |
| `gripper_far` | 对象、米 | 末端参考点到对象中心距离，不是表面最短距离 |
| `native_success` | 空列表 | 独立的完整任务原生成功 |

所有阶段的对象/谓词绑定都在第一次 VLA 动作之前检查。未实现的条件直接拒绝，不隐式替换。已完成行表示历史里程碑；要求后续持续保持的条件需要写进后续阶段的 `all`。

## 调度与独立评测

每个真实仿真动作后更新一次判定。按配置间隔、确认完成或环境终止时才请求 Qwen；Qwen 只能返回 `{"stage_id":1,"completed":false}`，且必须与仿真结果完全一致。错误格式最多修正一次，修正也占请求预算；网络失败不自动重试。长表完整保存于磁盘，请求仅发送当前阶段、总数和最近三条已完成阶段，因此不会因阶段数量增加而把整张表塞进上下文。

阶段确认后丢弃旧阶段剩余动作，按配置执行复位等工具，下一阶段从当前物理状态继续。每个阶段分开记录当前状态与历史里程碑：

- `stage_states[id].current_satisfied`：当前 `checker.all` 是否全部满足，每个 VLA/工具真实动作后重新读取；后来变假就记录为 `false`。过程事件与稳定窗口仍由阶段检查器独立处理。
- `stage_states[id].achieved_once`：该阶段是否曾作为当前阶段通过完整检查并确认，或作为最后阶段由当前完整任务原生成功确认。只控制流程向前推进，不因当前条件变假而撤销；最后阶段使用原生终态时保留独立的判定依据记录。
- `first_achieved_step` / `last_checked_step`：首次通过和最近一次当前条件检查的全局步号。

例如 `current_satisfied:false, achieved_once:true` 表示目标目前不满足，但不会退回、重做或阻止下一阶段；尚未通过的中间阶段不能跳过，即使后续阶段的条件碰巧已经成立。兼容旧接口的 `task_table.stages[].completed` 只表示历史里程碑，不表示当前条件仍为真。结果记录 `stage_completion_policy: "advance_once_live_conditions"`。不得重置场景、扩大预算或自动恢复。最后阶段正常情况下按自己的检查条件完成；另有明确的原生终态规则：前面阶段都已完成、当前进入最后阶段后，只要当前完整任务的原生 `native_success` 为真，立即将最后阶段及整张阶段表标记完成，丢弃剩余动作，不再等待附加松爪/脱离/稳定条件，也不执行最后阶段的 `post_tools`。不使用历史 `native_success_ever`，不据此跳过中间阶段。记录 `final_stage_completion_policy: "stage_checker_or_current_native_success"` 和 `final_stage_native_completion`；原始 `checker` 观察仍如实保存，因此最后阶段可以是 `completed:true` 而附加 `released` 仍为假。

两种模式中 `task_success` / `success` 都等于最终 `native_success`，记录 `success_authority: "final_native_success"`；
`workflow_success` 另外记录阶段流程、工具和清理是否全部完成。
例如官方目标已完成但最终复位失败，任务成功与流程失败会同时保留。
反过来，所有阶段都曾通过但最终某个官方目标变假，则 `workflow_success:true`、`success:false`；`native_success_ever` 不能代替最终成功。未标记模式的旧表仍使用 `stable_conditions` 检查规则，但也采用上述历史推进与当前状态分离，不是新任务的默认模式。

LIBERO-Mem 序列任务每个真实动作额外调用一次官方 `_check_success(inc=True)`，读取完整序列长度、实际前缀、最终条件与 overshot。中间子目标的 `done`/返回真不等于整个序列完成。普通 LIBERO 使用原生 `_check_success()`。标准版与 Mem 版安装必须各自选择正确 `PYTHONPATH`/`LIBERO_CONFIG_PATH`，不要混用同名包。

LIBERO 返回的 `done` 在其 BDDL 包装中被替换成目标成功信号，不代表仿真不允许继续。本系统原样记录该信号，但只将底层 robosuite 的真实终止标志作为环境终止，避免一次成功脉冲打断稳定复核或后续人工阶段。最终是否成功仍独立记录，不忽略步数和墙钟预算。

## VLA 接口与历史边界

- `atomic`：接已有 `Atomic_libero` websocket facade。沿用 main/wrist 视角各旋转 180°一次、官方 224×224 预处理与状态转换。每阶段清理旧动作并设置 `episode_start=True`，重置模型 thought cache；不重绕物理场景。thinking 请求不推动仿真步数，但计入全局 VLA 请求上限。不会并行连接已有活跃客户端。
- `internw0`：接已有 InternW0-Δ 私有 Unix socket。现有服务没有“只换指令但保留内部历史”的操作，因此本适配器在每个阶段重建策略会话，权重与仿真场景均不重载。报告明确为 `new_policy_session_each_stage`，**不是保留底层历史的实验**。上层阶段表始终保留。未来若要对比保留底层历史，需要单独实现、验证新的服务接口，不能用这个版本冒充。

不同模型有各自指令长度、图像和动作契约；本 harness 不保证任意模型可直接替换。VLA 仍使用原来的 OSC 动作契约；仅显式阶段复位工具临时使用关节位置控制，不暗中替换 VLA 动作。

## move_to 与阶段复位工具

两个工具位于 `motion_tools.py`，共用 harness 唯一的真实动作入口。`move_to` 使用现有固定阻抗、增量 `OSC_POSE`；阶段复位使用记录的关节角和临时固定阻抗 `JOINT_POSITION` 控制器。二者均不直接修改仿真 `qpos/qvel` 或物体状态，不调用 `env.reset()`，不需要另装 IK，也不调用或训练模型。

- `tools.move_to(target_pose, stage_id=..., **options)`：移动到世界坐标下指定的末端位置和朝向。位姿格式为 `{"position":[x,y,z],"quaternion_xyzw":[x,y,z,w]}`，位置单位米，四元数归一化后使用。不是图片像素坐标，也不是关节角。
- `tools.reset_to_stage_start(stage_id, **options)`：读取该阶段开始时记录的七个关节角，逐步输出受限关节目标增量回去；不再调用 `move_to`。未记录或关节数据不完整就拒绝，不回退为末端位姿复位，也不借用其他阶段或回合的起点。

调度器在**每个阶段真正开始、调用该阶段 VLA 前**执行 `tools.record_stage_start(stage_id)`，保存位置、朝向、夹爪读数和关节读数。位置和朝向统一来自 OSC 实际控制的 grip site，避免混用 LIBERO 观测中另一机器人部位的四元数。记录不会被阶段结束时的新状态覆盖。

复位要求**每个关节回到记录角度的容差内，同时末端位置和朝向满足原有容差**，并连续稳定确认；不自动还原夹爪开合读数。只支持空手：夹爪仍抓着物体时拒绝，避免开爪丢物，执行期间保持开爪。

关节复位适配当前单臂七关节＋单维夹爪的 LIBERO/robosuite 接口。工具期间动作是七个关节增量＋开爪，共八维，仅工具可以发送；VLA 与 `move_to` 仍是七维 OSC 动作。控制器、环境动作维度及动作缓冲在工具结束或异常时恢复，OSC 目标更新为实际当前位姿，下一阶段仍使用原 VLA 控制契约。适配不支持的机器人/控制器会拒绝，不写入共享运行环境或修改 robosuite 源码。

在需要完成后回位的阶段中添加下列字段即可，阶段原有必填字段保持不变：

```json
"post_tools": [
  {"tool": "reset_to_stage_start", "max_steps": 120}
]
```

不添加此字段就不回位；旧阶段表继续兼容。显式 `move_to` 调用可写为：

```json
{"tool":"move_to", "target_pose":{"position":[0.1,0.0,0.4],"quaternion_xyzw":[0,0,0,1]},"max_steps":120}
```

上面是格式示意，不是针对某个场景推荐的坐标。直接 Python 调用也必须使用与调度器绑定的 `MotionTools` 实例：其 `step_action` 回调负责真实动作、预算、原生判定与视频，不能另外创建并行控制循环。

`move_to` 默认路径：抬到当前/目标较高位置之上 8 cm → 高位小幅对齐朝向 → 高位平移 → 靠近目标。每步重新测量位姿、计算世界坐标旋转误差并反解 OSC 的实际缩放范围，不把绝对 XYZ 直接当动作。

复位先在独立 MuJoCo `MjData` 中检查当前场景与目标构型：直达边安全时直接使用，否则运行有上限的七维 RRTConnect。检查模型实际的机器人-环境与自碰撞几何，忽略与机器人无关的物体支撑接触；每条边以不超过 0.01 rad 的每关节间隔检查中间状态。若起点已有接触，先搜索仅减轻已有接触、不引入新接触对的短距离脱离路径。不固定抬升 8 cm，也不假定向上一定安全。碰撞副本只共享只读模型，不改正在执行的 `qpos/qvel`；执行仍通过唯一真实动作入口。

沿路径逐路点进行真实关节位置反馈，每步刷新实际物体/抽屉状态并检查近期运动边，路径失效或跟踪停滞时最多重规划两次。无进展按当前路点误差计算，允许绕行期间远离最终目标。每关节目标增量限幅，并限制相邻控制步的增量变化；这不是实际速度/加速度的硬保证。未找到路径不等于证明无解，也不返回近似解。目标仍是记录的七个关节角，不暗中改成等效 IK 位姿或安全停靠点。已在目标附近时仍执行新动作进行稳定确认。

默认工具参数（均可在调用中显式填写）：

| 参数 | 默认值 | 含义 |
|---|---|---|
| `max_steps` | move_to:120，reset:1000 | 本次工具最多真实动作步数；复位硬上限 1000，脱离/重规划后的执行同计 |
| `lift_m` | 0.08 | 仅 `move_to` 中间抬升高度，米 |
| `position_tolerance_m` | 0.01 | 最终位置容差，米 |
| `rotation_tolerance_deg` | 5 | 最终朝向容差，度 |
| `stable_steps` | 5 | 连续真实动作确认数 |
| `stall_steps` | 30 | 按当前路点误差判断无进展，不要求始终接近最终起点 |
| `max_translation_m` | 0.01 | 仅 `move_to` 单动作平移目标增量范数上限 |
| `max_rotation_rad` | 0.1 | 仅 `move_to` 单动作旋转目标增量范数上限 |
| `max_joint_step_rad` | 0.02 | 仅复位：每关节单动作目标增量上限，弧度 |
| `joint_tolerance_deg` | 1 | 仅复位：每个关节的角度容差，度 |
| `planning_timeout_seconds` | 10 | 仅复位：全部路径搜索累计上限，含碰撞副本准备，不能超过 10 秒 |
| `max_replans` | 2 | 仅复位：执行停滞/路径失效后最多重规划次数，初始规划不计入 |
| `collision_resolution_rad` | 0.01 | 仅复位：边离散检查的每关节最大间隔，不能更粗 |
| `planner_step_rad` | 0.15 | 仅复位：RRT 树扩展的七维欧氏距离 |
| `max_joint_acceleration_rad` | 0.005 | 仅复位：相邻步关节目标增量的最大变化，不是真实关节加速度上限 |

可选 `workspace:{"min":[x,y,z],"max":[x,y,z]}` 限制世界坐标包围盒；起止点、`move_to` 全部路点及每步实际位置都检查。工具版本拒绝超过 2 cm / 0.2 rad 的末端单步增量配置，复位拒绝超过 0.05 rad 的每关节目标增量或超过 5° 的关节容差。旧复位配置中的 `lift_m/max_translation_m/max_rotation_rad` 为兼容保留，但不会用于关节运动。实际参数需要在目标场景验证，不能把这些默认值当成已验证的安全设置。

阶段结束调用工具前会暂停 VLA 并丢弃旧动作；回位后使用最新观测、清空底层策略历史，再进入下一阶段。每阶段保存的是**它自己的起点**，不是无条件回到全回合最初姿态。

不再从已完成阶段的检查条件自动生成持续保护；默认 `preserve` 为空。阶段完成后，即使复位期间该目标再次变假，也继续复位和后续阶段。只有调用方显式填写的 `preserve:[条件...]` 才作为独立工具约束，在开始和每个工具动作后检查；这不是阶段完成状态的回退机制。当前五阶段任务未配置这类显式约束。

复位失败采用 `record_and_advance`：夹爪持物、目标碰撞、规划超时、无进展、单次复位步数耗尽等普通失败仅停止该次复位、记录失败，随后从实际当前观测进入下一阶段，不将复位失败伪报为成功。下一阶段如果从未完成、耗尽自身 VLA 预算，则结束回合。环境终止、总步数/墙钟耗尽、接口异常或控制器无法恢复仍必须停止。独立 `move_to` 工具保留原失败终止语义。

接触日志本身不直接终止回合，两种工具均记录 `contact_stop_enabled:false`；复位新增的预测碰撞检查可能拒绝运动边并尝试绕行，这不等于关闭碰撞。阶段表中显式的 `released(target)` 首次切换条件不变。复位 `reached` 仍要求原有关节角和末端位姿同时连续满足容差，不表示任务完成。复位失败通过 `post_tool_failures` 与独立 `post_tools_success:false` 保留，即使之后复位成功也不清除。

**限制**：`move_to` 仍不是避障规划器；复位是基于当前模型接触几何的离散规划，不是连续碰撞证明，不包含额外几何膨胀余量，也不能预测物体未来运动。窄间隙可能漏检，控制器执行误差可能造成碰撞或推挤。执行时会更新场景并重新检查，但不能宣称已验证真实硬件安全。搜索上限在每次几何查询前后检查，单次底层计算无法抢占，可能有很小的超时尾差。该能力明确使用仿真几何真值，不是纯 VLA 能力。

回位步数独立计为 `tool_steps` / `stage_tool_steps`，VLA 动作计为 `vla_steps` / `stage_steps`；二者合计必须遵守 `budget.max_steps` 与总墙钟预算，没有额外隐含额度。阶段 `max_steps` 限制 VLA 动作，工具另有单次上限。所有回位动作同样推进原生评估及 Mem 计数、更新 `native_success`、进入连续录像；不冻结或跳过仿真时间。

复位的空手、限位及预算检查仍然是工具执行保护，不是原子任务成功条件；接触本身不再是停止条件。
回位失败保留 `post_tools_success:false`、`workflow_success:false` 与独立的任务成功值，
不能把流程说成全部跑通。这是 harness 辅助控制，不是纯 VLA 成绩。

## 使用

验证只需要 Python 3.10+ 标准库，不连服务、不加载模型、不创建仿真：

```bash
python3 -B /absolute/path/starHarness_Libero/run.py validate \
  --task-table /absolute/path/filled_task_table.json
```

执行时使用已有 LIBERO 仿真解释器，安装/路径中需要 `numpy`、`robosuite`、`imageio`、`PIL` 和相应 LIBERO fork。Atomic 客户端另需现有 `openpi_client` 与 `websockets.sync`；无需训练端 `openpi` 包或另一份权重。先在选定环境验证这些依赖，脚本不会自动安装它们。MuJoCo 渲染环境变量仅在当前进程设置。

```bash
PYTHONPATH=/path/to/LIBERO/repo:/path/to/AtomicVLA/repo/packages/openpi-client/src \
LIBERO_CONFIG_PATH=/path/to/matching/libero/config \
/path/to/existing/sim/bin/python -B /absolute/path/starHarness_Libero/run.py run \
  --task-table /absolute/path/filled_task_table.json \
  --output /absolute/path/NEW_EPISODE_DIRECTORY \
  --policy atomic --atomic-port 18321 \
  --qwen-url http://127.0.0.1:18323 --render-gpu 0
```

上述端口只是已用服务接口的示意，不自动探测、启动、占卡或重启模型；执行前需要确认服务身份、空闲和渲染资源。`--state-updater deterministic` 可跳过 Qwen，作为单独明确标记的规则对照；不会被伪报成 Qwen 推理。

InternW0 先用它已有的模型解释器离线准备文本特征；一次加载 CPU 文本编码器，为所有不重复的阶段指令生成缓存，避免每次切换阶段重新编码。指令超过官方 128-token 上限直接拒绝，不截断、不下载。输出必须在对应 candidate 的 `runs/` 下，符合现有驻留服务的路径保护：

```bash
/path/to/InternW0_Delta/runtime/bin/python -B \
  /absolute/path/starHarness_Libero/prepare_intern_prompts.py \
  --task-table /absolute/path/filled_task_table.json \
  --candidate-root /opt/vla/InternW0_Delta \
  --output /opt/vla/InternW0_Delta/runs/NEW_PROMPT_DIRECTORY

/path/to/existing/sim/bin/python -B /absolute/path/starHarness_Libero/run.py run \
  --task-table /absolute/path/filled_task_table.json \
  --output /absolute/path/NEW_EPISODE_DIRECTORY \
  --policy internw0 --intern-socket /path/to/resident/policy.sock \
  --prompt-manifest /path/to/NEW_PROMPT_DIRECTORY/prompt_manifest.json \
  --qwen-url http://127.0.0.1:18323 --render-gpu 0
```

不能向已存在的输出目录运行，失败也不会清空记录后重放。SIGTERM/键盘中断尽量保存结果并释放客户端；强制杀进程/断电仍可能留下未完成记录，不能据此自行重跑。

## 输出

- `episode_claim.json`：单回合占用记录。
- `task_table_input.json` / `task_table.json`：不可变输入快照与最新完整阶段表。
- `stage_states.json`：每阶段最新的当前条件、历史里程碑及对应步号；`result.json.stage_states` 保存同一份最终状态。
- `stage_state_changes.jsonl`：当前真假或历史里程碑改变时记录变化；不影响阶段推进。
- `episode_manifest.json`：任务、初始状态/画面哈希、预算及监督方式。
- `controller_trace.jsonl` / `simulator_checks.jsonl`：阶段指令、状态更新、过程事件、稳定计数、切换边界。
- `actions.jsonl` / `policy_queries.jsonl`：真实动作和模型请求统计；thinking 请求与仿真动作分开。
- `stage_starts.json`：每阶段实际开始时的末端位姿、夹爪/关节读数及全局步号。
- `tool_events.jsonl` / `tool_results.json` / `motion_progress.jsonl`：工具调用、运动路点、每步位姿误差与停止原因；`actions.jsonl` 的 `source` 区分 VLA 和工具。
- `reset_plans.jsonl`：每次复位规划/重规划的路径、脱离边数、检查次数、搜索耗时及失败原因；不覆盖旧实验。
- `qwen_requests.jsonl`：Qwen 文字输入、原始输出、校验与耗时，没有密钥。
- `episode.mp4`：连续 main+wrist 两视角视频，初始帧加每个真实动作一帧，20 fps。
- 初始/最终 PNG、仿真状态 `.npy`、`progress.json`、`result.json`。

模型、Qwen 和实际场景的完整集成评测尚未运行；合成测试通过不等于机器人成功率。

## 无 GPU 测试

本地从 `robot harness` 目录：

```bash
python3 -B -m unittest discover -s harnesses/starHarness_Libero/tests -t . -v
```

服务器从 `robot_harness_tools` 目录：

```bash
python3 -B -m unittest discover -s starHarness_Libero/tests -t . -v
```

测试覆盖可变长度、阶段/总预算、旧动作丢弃、历史里程碑、最终原生评分与工具状态分离、客户端独占和输出防覆盖。运动测试另覆盖 RRT 绕障、中间边碰撞、单调接触脱离、最多两次重规划、复位失败继续下一阶段、下一阶段从未完成才停止、失败标记不被后续成功抹去。可用 MuJoCo 时追加 CPU 几何副本隔离测试。没有真实模型调用，合成/几何测试不等于完整机器人任务成功验证。
