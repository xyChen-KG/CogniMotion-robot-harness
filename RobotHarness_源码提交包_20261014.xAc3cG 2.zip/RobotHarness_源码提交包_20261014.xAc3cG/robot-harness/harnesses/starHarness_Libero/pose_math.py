"""Small dependency-free world-frame pose operations; quaternion order is xyzw."""
import math


def vector(value, length, name):
    if not isinstance(value, (list, tuple)) or len(value) != length or any(
            type(x) not in (int, float) or not math.isfinite(x) for x in value):
        raise ValueError(f'{name} requires {length} finite numbers')
    return [float(x) for x in value]


def norm(value):
    return math.hypot(*value)


def quaternion(value):
    value = vector(value, 4, 'quaternion_xyzw')
    length = norm(value)
    if not math.isfinite(length) or length < 1e-12:
        raise ValueError('Zero or overflowing quaternion is invalid')
    return [x / length for x in value]


def pose(value):
    if not isinstance(value, dict) or set(value) != {'position', 'quaternion_xyzw'}:
        raise ValueError('Pose requires position and quaternion_xyzw in the world frame')
    return dict(position=vector(value['position'], 3, 'position'),
                quaternion_xyzw=quaternion(value['quaternion_xyzw']))


def multiply(a, b):
    x, y, z, w = a
    u, v, s, t = b
    return [w*u + x*t + y*s - z*v, w*v - x*s + y*t + z*u,
            w*s + x*v - y*u + z*t, w*t - x*u - y*v - z*s]


def rotation_error(target, current):
    # OSC uses R_goal = R_delta @ R_current: error is WORLD-frame, not local.
    current, target = quaternion(current), quaternion(target)
    delta = multiply(target, [-current[0], -current[1], -current[2], current[3]])
    if delta[3] < 0:  # q and -q represent the same rotation; take shortest arc.
        delta = [-x for x in delta]
    length = norm(delta[:3])
    if length < 1e-12:
        return [2*x for x in delta[:3]]
    angle = 2 * math.atan2(length, max(0., delta[3]))
    return [x * angle / length for x in delta[:3]]


def errors(target, current):
    position = [a-b for a, b in zip(target['position'], current['position'])]
    rotation = rotation_error(target['quaternion_xyzw'], current['quaternion_xyzw'])
    return position, rotation


def limited(value, maximum):
    length = norm(value)
    return [x * min(1., maximum / length) for x in value] if length else list(value)


def validate_osc(contract):
    if not isinstance(contract, dict) or contract.get('type') != 'OSC_POSE' or contract.get('control_delta') is not True or contract.get('impedance_mode') != 'fixed':
        raise ValueError('Motion tools require fixed-impedance, delta OSC_POSE')
    ranges = {name: vector(contract[name], 6, name)
              for name in ('input_min', 'input_max', 'output_min', 'output_max')}
    for index in range(6):
        for prefix in ('input', 'output'):
            low, high = ranges[prefix + '_min'][index], ranges[prefix + '_max'][index]
            if not low < 0 < high:
                raise ValueError('OSC ranges must straddle zero on every pose axis')
    return ranges


def osc_action(position_delta, rotation_delta, contract):
    ranges = validate_osc(contract)
    action = []
    for index, value in enumerate(position_delta + rotation_delta):
        low, high = ranges['output_min'][index], ranges['output_max'][index]
        value = max(low, min(high, value))
        unit = (value - low) / (high - low)
        action.append(ranges['input_min'][index] + unit * (
                      ranges['input_max'][index] - ranges['input_min'][index]))
    return action + [-1.]  # Empty-hand tools keep the existing Panda gripper open.


def validate_joint_position(contract):
    if not isinstance(contract, dict) or contract.get('type') != 'JOINT_POSITION' or contract.get('control_delta') is not True or contract.get('impedance_mode') != 'fixed':
        raise ValueError('Joint resets require fixed-impedance, delta JOINT_POSITION')
    ranges = {name: vector(contract[name], 7, name)
              for name in ('input_min', 'input_max', 'output_min', 'output_max')}
    for index in range(7):
        for prefix in ('input', 'output'):
            if not ranges[prefix + '_min'][index] < 0 < ranges[prefix + '_max'][index]:
                raise ValueError('Joint action ranges must straddle zero')
    return ranges


def joint_action(delta, contract):
    """Seven joint increments in radians plus OPEN gripper; never an OSC action."""
    delta, ranges = vector(delta, 7, 'joint_delta'), validate_joint_position(contract)
    action = []
    for index, value in enumerate(delta):
        low, high = ranges['output_min'][index], ranges['output_max'][index]
        if not low <= value <= high:
            raise ValueError('Joint increment exceeds the active controller range')
        unit = (value - low) / (high - low)
        action.append(ranges['input_min'][index] + unit * (
            ranges['input_max'][index] - ranges['input_min'][index]))
    return action + [-1.]
