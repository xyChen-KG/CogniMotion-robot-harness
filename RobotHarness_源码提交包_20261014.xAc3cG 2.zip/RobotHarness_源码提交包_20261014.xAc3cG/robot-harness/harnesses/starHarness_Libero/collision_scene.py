"""MuJoCo collision queries in private MjData, sharing ONLY a read-only model.

Robot-world and self contacts use the model's actual collision meshes/masks.
Object-support contacts do not invalidate a robot path. No live qpos writes.
"""
import math


class MujocoCollisionScene:
    def __init__(self, environment, workspace=None):
        import mujoco
        import numpy as np
        self.mj, self.np = mujoco, np
        sim, robot = environment.domain.sim, environment.domain.robots[0]
        self.model, self.live = sim.model._model, sim.data._data
        self.data = mujoco.MjData(self.model)
        self.qindexes = list(robot._ref_joint_pos_indexes)
        self.dindexes = list(robot._ref_joint_vel_indexes)
        self.limits = [tuple(map(float, self.model.jnt_range[i])) for i in robot.joint_indexes]
        self.site = sim.model.site_name2id(robot.controller.eef_name)
        moving_bodies = set(int(self.model.jnt_bodyid[i]) for i in robot.joint_indexes)
        for body in range(self.model.nbody):
            parent = body
            while parent:
                if parent in moving_bodies:
                    moving_bodies.add(body)
                    break
                parent = int(self.model.body_parentid[parent])
        self.robot_geoms = {i for i in range(self.model.ngeom)
                            if int(self.model.geom_bodyid[i]) in moving_bodies}
        if not self.robot_geoms:
            raise ValueError('No moving robot collision geometry found')
        self.workspace = workspace
        self.spec = mujoco.mjtState.mjSTATE_INTEGRATION
        self.state = np.empty(mujoco.mj_stateSize(self.model, self.spec))
        self.refresh()

    def refresh(self):
        self.mj.mj_getState(self.model, self.live, self.state, self.spec)
        self.mj.mj_setState(self.model, self.data, self.state, self.spec)

    def report(self, q):
        if len(q) != 7 or any(not math.isfinite(v) or not low <= v <= high
                              for v, (low, high) in zip(q, self.limits)):
            return dict(invalid=True, contacts={})
        self.data.qpos[self.qindexes] = q  # PRIVATE hypothetical state, never live data.
        self.mj.mj_fwdPosition(self.model, self.data)
        if self.workspace and any(not low <= float(v) <= high for v, low, high in zip(
                self.data.site_xpos[self.site], self.workspace['min'], self.workspace['max'])):
            return dict(invalid=True, contacts={})
        contacts = {}
        for index in range(self.data.ncon):
            c = self.data.contact[index]
            a, b = int(c.geom1), int(c.geom2)
            if (a in self.robot_geoms or b in self.robot_geoms) and float(c.dist) < 0.:
                pair = tuple(sorted((a, b)))
                contacts[pair] = max(contacts.get(pair, 0.), -float(c.dist))
        return dict(invalid=False, contacts=contacts)

    def retreat_candidates(self, q):
        self.report(q)
        jac = self.np.zeros((3, self.model.nv))
        self.mj.mj_jacSite(self.model, self.data, jac, None, self.site)
        jac = jac[:, self.dindexes]
        inverse = jac.T @ self.np.linalg.inv(jac @ jac.T + .0025*self.np.eye(3))
        candidates = []
        for axis in ([0., 0., .04], [.04, 0., 0.], [-.04, 0., 0.],
                     [0., .04, 0.], [0., -.04, 0.], [0., 0., -.02]):
            delta = self.np.clip(inverse @ axis, -.12, .12)
            candidates.append([float(a+b) for a, b in zip(q, delta)])
        return candidates
