"""Strict data-only task tables. No task name or stage count is hard-coded."""
from __future__ import annotations

import copy
import json
import math
from pathlib import Path

# Argument types are also used to validate simulator bindings before motion.
PREDICATES = {
    'on': ('ref', 'ref'), 'in': ('ref', 'ref'),
    'open': ('ref',), 'close': ('ref',),
    'turnon': ('ref',), 'turnoff': ('ref',),
    'grasped': ('ref',), 'released': ('ref',),
    'lifted': ('ref', 'positive'), 'stationary': ('ref', 'positive'),
    'gripper_far': ('ref', 'positive'), 'native_success': (),
}
OFFICIAL_PREDICATES = {'on', 'in', 'open', 'close', 'turnon', 'turnoff', 'native_success'}


def positive_int(value, name):
    if type(value) is not int or value < 1:
        raise ValueError(f'{name} must be a positive integer')
    return value


def condition(value):
    if not isinstance(value, dict) or not {'predicate', 'args'} <= set(value) or set(value) - {'predicate', 'args', 'negate'}:
        raise ValueError('A condition requires predicate and args; only negate is optional')
    name, args = value['predicate'], value['args']
    if not isinstance(name, str) or name not in PREDICATES:
        raise ValueError(f'Unsupported predicate: {name!r}')
    if not isinstance(args, list) or len(args) != len(PREDICATES[name]):
        raise ValueError(f'Wrong arguments for {name}')
    if type(value.get('negate', False)) is not bool:
        raise ValueError('negate must be boolean')
    for item, kind in zip(args, PREDICATES[name]):
        if kind == 'ref' and (not isinstance(item, str) or not item.strip()):
            raise ValueError('Object references must be nonempty strings')
        if kind == 'positive' and (type(item) not in (int, float) or not math.isfinite(item) or item <= 0):
            raise ValueError('Metric thresholds must be finite positive numbers')
    return value


def group(value):
    if not isinstance(value, dict) or set(value) != {'all'} or not isinstance(value['all'], list) or not value['all']:
        raise ValueError('Each condition group requires a nonempty all list')
    for item in value['all']:
        condition(item)


def validate_table(table, *, fresh=True):
    expected = {'schema_version', 'task', 'stable_steps', 'bindings', 'budget', 'stages'}
    if not isinstance(table, dict) or not expected <= set(table) or set(table) - (expected | {'completion_mode'}):
        raise ValueError('Table requires: ' + ', '.join(sorted(expected)) + '; completion_mode is optional')
    mode = table.get('completion_mode', 'stable_conditions')
    if mode not in ('stable_conditions', 'official_predicates'):
        raise ValueError('Unknown completion_mode')
    if type(table['schema_version']) is not int or table['schema_version'] != 1:
        raise ValueError('Unsupported schema_version')
    task = table['task']
    if not isinstance(task, dict) or set(task) != {'suite', 'task_id', 'initial_state_index', 'seed'}:
        raise ValueError('task requires suite, task_id, initial_state_index and seed')
    if not isinstance(task['suite'], str) or not task['suite'].strip():
        raise ValueError('Fill in a registered LIBERO suite; none is selected by default')
    for key in ('task_id', 'initial_state_index', 'seed'):
        if type(task[key]) is not int or task[key] < 0:
            raise ValueError(f'task.{key} must be a nonnegative integer')
    positive_int(table['stable_steps'], 'stable_steps')
    if mode == 'official_predicates' and table['stable_steps'] != 1:
        raise ValueError('Official predicates must not add a temporal stability threshold')
    if not isinstance(table['bindings'], dict) or any(
            not isinstance(k, str) or not k or k.startswith('@') or
            not isinstance(v, str) or not v.strip() or v.startswith('@')
            for k, v in table['bindings'].items()):
        raise ValueError('bindings map alias names without @ to concrete simulator names')
    budget = table['budget']
    if not isinstance(budget, dict) or set(budget) != {'max_steps', 'check_interval_steps', 'max_state_requests', 'max_policy_queries', 'max_wall_seconds'}:
        raise ValueError('budget requires max_steps, check_interval_steps, max_state_requests, max_policy_queries, max_wall_seconds')
    for key, value in budget.items():
        positive_int(value, 'budget.' + key)
    stages = table['stages']
    if not isinstance(stages, list) or not stages:
        raise ValueError('Fill in at least one stage; the empty template cannot execute')
    # Deliberately no 3/5/16-stage limit. Model requests use a bounded summary.
    pending = False
    for index, stage in enumerate(stages, 1):
        required = {'id', 'instruction', 'max_steps', 'completed', 'checker'}
        if not isinstance(stage, dict) or not required <= set(stage) or set(stage) - (required | {'post_tools'}):
            raise ValueError('A stage requires id, instruction, max_steps, completed, checker; post_tools is optional')
        if type(stage['id']) is not int or stage['id'] != index:
            raise ValueError('Stage IDs must be consecutive integers starting at 1')
        if not isinstance(stage['instruction'], str) or not stage['instruction'].strip():
            raise ValueError('Each stage needs a nonempty instruction')
        positive_int(stage['max_steps'], 'stage.max_steps')
        if type(stage['completed']) is not bool:
            raise ValueError('completed must be boolean')
        if fresh and stage['completed']:
            raise ValueError('A new episode must start with all stages unfinished')
        if pending and stage['completed']:
            raise ValueError('Completed stages must form a consecutive prefix')
        pending |= not stage['completed']
        checker = stage['checker']
        if not isinstance(checker, dict) or not {'all'} <= set(checker) or set(checker) - {'all', 'sequence'}:
            raise ValueError('checker requires all, with an optional sequence of event groups')
        group({'all': checker['all']})
        sequence = checker.get('sequence', [])
        if not isinstance(sequence, list):
            raise ValueError('checker.sequence must be a list')
        for event in sequence:
            group(event)
        if mode == 'official_predicates':
            if sequence or any(c['predicate'] not in OFFICIAL_PREDICATES for c in checker['all']):
                raise ValueError('Official completion uses native predicates only, without extra process events')
        calls = stage.get('post_tools', [])
        if not isinstance(calls, list):
            raise ValueError('post_tools must be an ordered list')
        from .motion_tools import validate_tool_call
        for call in calls:
            validate_tool_call(call)
        conditions = checker['all'] + [c for event in sequence for c in event['all']]
        conditions += [c for call in calls for c in call.get('preserve', [])]
        for item in conditions:
            for argument, kind in zip(item['args'], PREDICATES[item['predicate']]):
                if kind == 'ref' and argument.startswith('@') and argument[1:] not in table['bindings']:
                    raise ValueError(f'Unknown alias {argument}')
    return table


def load_table(path):
    return validate_table(json.loads(Path(path).read_text(encoding='utf-8')))


def active_stage(table):
    return next((stage for stage in table['stages'] if not stage['completed']), None)


def apply_update(table, value, completed):
    stage = active_stage(table)
    if stage is None or not isinstance(value, dict) or set(value) != {'stage_id', 'completed'}:
        raise ValueError('Update must identify the current unfinished stage')
    if type(value['stage_id']) is not int or value['stage_id'] != stage['id']:
        raise ValueError('Cannot update another stage')
    if type(value['completed']) is not bool or type(completed) is not bool or value['completed'] != completed:
        raise ValueError('State update must exactly match the simulator boolean')
    result = copy.deepcopy(table)
    result['stages'][stage['id'] - 1]['completed'] = completed
    return validate_table(result, fresh=False)
