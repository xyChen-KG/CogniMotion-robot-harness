"""Bounded physical motion tools. No scene reset, IK teleport, or model calls."""
import copy
import math
import time

from .pose_math import (errors, joint_action, limited, norm, osc_action, pose,
                        validate_joint_position, validate_osc, vector)
from .reset_planner import JointReturnPlanner, SearchTimeout, checked_edge


DEFAULTS = dict(max_steps=120, lift_m=0.08, position_tolerance_m=0.01,
                rotation_tolerance_deg=5., stable_steps=5, stall_steps=30,
                max_translation_m=0.01, max_rotation_rad=0.1)
JOINT_DEFAULTS = dict(max_steps=1000, max_joint_step_rad=0.02, joint_tolerance_deg=1.,
                      planning_timeout_seconds=10., max_replans=2,
                      collision_resolution_rad=.01, planner_step_rad=.15,
                      max_joint_acceleration_rad=.005)


class MotionStopped(RuntimeError):
    """A normal bounded-stop condition from the shared physical-step dispatcher."""


def path_increment(current, waypoint, previous, maximum, acceleration):
    """Uniform path scaling: independent per-joint clipping cuts RRT corners.

    If no direction-preserving increment satisfies slew limits at a corner,
    brake the previous increment toward zero. Every command is checked again.
    """
    raw = [.5*(t-q) for t, q in zip(waypoint, current)]
    largest = max(map(abs, raw))
    low, high = 0., min(1., maximum/largest) if largest else 1.
    for value, old in zip(raw, previous):
        if abs(value) < 1e-12:
            if abs(old) > acceleration:
                high = -1.
                break
        else:
            a, b = sorted(((old-acceleration)/value, (old+acceleration)/value))
            low, high = max(low, a), min(high, b)
    if 0. <= low <= high:
        return [max(-maximum, min(maximum, high*value)) for value in raw]  # Roundoff only.
    return [max(old-acceleration, min(old+acceleration, 0.)) for old in previous]


def validate_tool_call(call):
    if not isinstance(call, dict) or call.get('tool') not in ('move_to', 'reset_to_stage_start'):
        raise ValueError('Supported motion tools: move_to, reset_to_stage_start')
    defaults = {**DEFAULTS, **(JOINT_DEFAULTS if call['tool'] == 'reset_to_stage_start' else {})}
    extra = set(call) - ({'tool', 'target_pose', 'preserve', 'workspace'} | set(defaults))
    if extra:
        raise ValueError(f'Unknown motion tool options: {sorted(extra)}')
    if call['tool'] == 'move_to':
        pose(call.get('target_pose'))
    elif 'target_pose' in call:
        raise ValueError('Reset target is captured at stage start, not supplied by the caller')
    options = {**defaults, **{k: v for k, v in call.items() if k in defaults}}
    for key in ('max_steps', 'stable_steps', 'stall_steps'):
        if type(options[key]) is not int or options[key] < 1:
            raise ValueError(f'{key} must be a positive integer')
    if 'max_replans' in options and (type(options['max_replans']) is not int or not 0 <= options['max_replans'] <= 2):
        raise ValueError('max_replans must be an integer between 0 and 2')
    for key in set(defaults) - {'max_steps', 'stable_steps', 'stall_steps', 'max_replans'}:
        value = options[key]
        if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
            raise ValueError(f'{key} must be finite and positive')
    if options['max_translation_m'] > .02 or options['max_rotation_rad'] > .2 or options['rotation_tolerance_deg'] >= 180:
        raise ValueError('Motion increments exceed this tool version\'s conservative limits')
    if call['tool'] == 'reset_to_stage_start' and (options['max_joint_step_rad'] > .05 or options['joint_tolerance_deg'] > 5.):
        raise ValueError('Joint reset increments/tolerance exceed this tool version\'s limits')
    if call['tool'] == 'reset_to_stage_start' and (options['max_steps'] > 1000
            or options['planning_timeout_seconds'] > 10. or options['collision_resolution_rad'] > .01
            or options['planner_step_rad'] > .3 or options['max_joint_acceleration_rad'] > .02):
        raise ValueError('Reset exceeds the bounded planning/execution limits')
    if 'workspace' in call:
        bounds = call['workspace']
        if not isinstance(bounds, dict) or set(bounds) != {'min', 'max'}:
            raise ValueError('workspace requires world-frame min and max vectors')
        low, high = vector(bounds['min'], 3, 'workspace.min'), vector(bounds['max'], 3, 'workspace.max')
        if any(a >= b for a, b in zip(low, high)):
            raise ValueError('workspace.min must be below max on every axis')
    if 'preserve' in call:
        if not isinstance(call['preserve'], list):
            raise ValueError('preserve must be a condition list')
        from .schema import condition
        for item in call['preserve']:
            condition(item)
    return options


class MotionTools:
    """Both tools share the harness' only action writer and full-step accounting.

    step_action(action, metadata) must execute ONE real action, update native
    scoring and recording, and raise MotionStopped on a global budget/termination.
    """
    def __init__(self, backend, step_action, get_step, store):
        self.backend, self.step_action, self.get_step, self.store = backend, step_action, get_step, store
        self.stage_starts, self.results = {}, []

    def record_stage_start(self, stage_id):
        if type(stage_id) is not int or stage_id < 1 or stage_id in self.stage_starts:
            raise ValueError('A stage start must be recorded exactly once, before that stage acts')
        state = copy.deepcopy(self.backend.end_effector_state())
        state['pose'] = pose(state['pose'])
        record = dict(stage_id=stage_id, step=self.get_step(), state=state,
                      frame='world', source='actual OSC controlled grip site')
        self.stage_starts[stage_id] = record
        self.store.snapshot('stage_starts', list(self.stage_starts.values()))
        self.store.log('tool_events', dict(event='stage_start_captured', **record))
        return copy.deepcopy(record)

    def reset_to_stage_start(self, stage_id, **options):
        if stage_id not in self.stage_starts:
            raise ValueError('Stage start has not been recorded; refusing to guess a reset target')
        settings = validate_tool_call(dict(tool='reset_to_stage_start', **copy.deepcopy(options)))
        captured = self.stage_starts[stage_id]['state']
        target, target_joints = pose(captured['pose']), vector(captured.get('joint_qpos'), 7, 'captured joint_qpos')
        preserve, workspace = options.get('preserve', []), options.get('workspace')
        for item in preserve:
            self.backend.validate_condition(item)
        initial = self.backend.end_effector_state()
        start, call_id = self.get_step(), len(self.results) + 1
        result = dict(call_id=call_id, tool='reset_to_stage_start', stage_id=stage_id,
                      start_step=start, target_pose=target, target_joint_qpos=target_joints,
                      initial_pose=pose(initial['pose']),
                      initial_joint_qpos=vector(initial.get('joint_qpos'), 7, 'initial joint_qpos'),
                      options=settings, preserve=preserve, workspace=workspace,
                      status='running', steps=0, controller_restored=False,
                      collision_free_plan=False, contact_stop_enabled=False, restored_joint_configuration=False,
                      pose_frame='world', reset_mode='collision_checked_recorded_joints',
                      planner='bounded_RRTConnect', planning_seconds=0., replans=0,
                      planning_attempts=[], collision_check_mode='discrete_model_contacts',
                      simulator_geometry_used=True, live_state_teleported=False)
        self.store.log('tool_events', dict(event='tool_start', **result))
        try:
            reason, safety = self._guard(preserve)
            if reason:
                result.update(status=reason, safety=safety)
                return result
            if workspace is not None and any(not all(a <= p <= b for p, a, b in zip(
                    point['position'], workspace['min'], workspace['max'])) for point in [result['initial_pose'], target]):
                result['status'] = 'outside_workspace'
                return result
            with self.backend.joint_reset_control(target_joints) as contract:
                validate_joint_position(contract)
                result['controller'] = contract
                if not hasattr(self.backend, 'reset_collision_scene'):
                    result['status'] = 'planner_unavailable'
                    return result  # Never silently fall back to unchecked direct return.
                scene = None
                path, waypoint_index, escape_edges = None, 1, 0
                stable, stalled, best = 0, 0, math.inf
                previous_delta = [0.] * 7
                replan_reason = 'initial_plan'
                while self.get_step() - start < settings['max_steps']:
                    state = self.backend.end_effector_state()
                    current = vector(state.get('joint_qpos'), 7, 'actual joint_qpos')
                    if path is None:
                        remaining = settings['planning_timeout_seconds'] - result['planning_seconds']
                        if remaining <= 0.:
                            result['status'] = 'planning_timeout'
                            return result
                        planning_start = time.monotonic()
                        deadline = planning_start + remaining
                        try:
                            if scene is None:
                                scene = self.backend.reset_collision_scene(workspace)
                            scene.refresh()
                            planned = JointReturnPlanner(scene, deadline=deadline,
                                resolution=settings['collision_resolution_rad'], extension=settings['planner_step_rad'],
                                seed=stage_id*1009 + result['replans']).plan(current, target_joints)
                        finally:
                            result['planning_seconds'] += time.monotonic() - planning_start
                        if result['planning_seconds'] > settings['planning_timeout_seconds'] and planned['status'] == 'planned':
                            planned.update(status='planning_timeout', path=[])
                        attempt = dict(reason=replan_reason, step=self.get_step(), **planned)
                        result['planning_attempts'].append(copy.deepcopy(attempt))
                        self.store.log('reset_plans', dict(call_id=call_id, stage_id=stage_id, **attempt))
                        if planned['status'] != 'planned':
                            result['status'] = planned['status']
                            return result
                        path, waypoint_index = planned['path'], 1
                        escape_edges = planned['escape_edges']
                        result['collision_free_plan'] = not bool(escape_edges)
                        result['contact_reducing_escape'] = bool(escape_edges)
                        stable, stalled, best = 0, 0, math.inf
                        previous_delta = [0.] * 7

                    # Progress follows the CURRENT waypoint, not final-home distance.
                    while waypoint_index < len(path)-1 and max(abs(a-b) for a, b in zip(
                            path[waypoint_index], current)) <= .01:
                        waypoint_index += 1
                        stalled, best = 0, math.inf
                    waypoint = path[waypoint_index]
                    is_escape = waypoint_index <= escape_edges
                    phase = 'contact_escape' if is_escape else 'joint_return'
                    delta = path_increment(current, waypoint, previous_delta,
                        settings['max_joint_step_rad'], settings['max_joint_acceleration_rad'])
                    command = [q+d for q, d in zip(current, delta)]
                    scene.refresh()  # Objects/drawers may have moved during physical execution.
                    try:
                        safe = checked_edge(scene, current, command,
                            resolution=settings['collision_resolution_rad'], escape=is_escape)
                    except SearchTimeout:
                        safe = False
                    if not safe:
                        replan_reason = 'path_invalidated'
                        self.store.log('tool_events', dict(event=replan_reason,
                            call_id=call_id, stage_id=stage_id, step=self.get_step()))
                        if result['replans'] >= settings['max_replans']:
                            result['status'] = 'path_invalidated'
                            return result
                        result['replans'] += 1
                        path = None
                        continue
                    self.step_action(joint_action(delta, contract), dict(source='tool',
                        tool='reset_to_stage_start', call_id=call_id, stage_id=stage_id,
                        phase=phase, action_space='JOINT_POSITION', waypoint_index=waypoint_index,
                        joint_waypoint_rad=waypoint, joint_target_rad=command, joint_delta_rad=delta))
                    previous_delta = delta
                    state = self.backend.end_effector_state()
                    current = vector(state.get('joint_qpos'), 7, 'actual joint_qpos')
                    dq = [t-q for t, q in zip(target_joints, current)]
                    dp, dr = errors(target, pose(state['pose']))
                    maximum = math.degrees(max(abs(value) for value in dq))
                    reason, safety = self._guard(preserve)
                    self.store.log('motion_progress', dict(call_id=call_id, stage_id=stage_id,
                        step=self.get_step(), phase=phase, action_space='JOINT_POSITION',
                        pose=state['pose'], joint_qpos=current, joint_error_norm_rad=norm(dq),
                        max_joint_error_deg=maximum, position_error_m=norm(dp),
                        rotation_error_deg=math.degrees(norm(dr)), safety=safety,
                        waypoint_index=waypoint_index, waypoint_error_rad=norm([a-b for a, b in zip(waypoint, current)]),
                        replans=result['replans']))
                    if reason:
                        result.update(status=reason, safety=safety)
                        return result
                    if workspace is not None and not all(a <= p <= b for p, a, b in zip(
                            state['pose']['position'], workspace['min'], workspace['max'])):
                        result['status'] = 'outside_workspace'
                        return result
                    within = (maximum <= settings['joint_tolerance_deg']
                              and norm(dp) <= settings['position_tolerance_m']
                              and math.degrees(norm(dr)) <= settings['rotation_tolerance_deg'])
                    stable = stable + 1 if within and waypoint_index == len(path)-1 else 0
                    if stable >= settings['stable_steps']:
                        result.update(status='reached', stable_steps=stable)
                        return result
                    metric = norm([a-b for a, b in zip(waypoint, current)])
                    if metric < best - 1e-4:
                        best, stalled = metric, 0
                    else:
                        stalled += 1
                    if stalled >= settings['stall_steps'] and not (within and waypoint_index == len(path)-1):
                        if result['replans'] >= settings['max_replans']:
                            result['status'] = 'no_progress'
                            return result
                        result['replans'] += 1
                        replan_reason, path = 'tracking_stall', None
                result['status'] = 'tool_step_budget_exhausted'
                return result
        except MotionStopped as error:
            result['status'] = str(error)
            return result
        except BaseException as error:
            result.update(status='error', error=repr(error))
            raise
        finally:
            final = self.backend.end_effector_state()
            joints = vector(final.get('joint_qpos'), 7, 'final joint_qpos')
            dq = [t-q for t, q in zip(target_joints, joints)]
            dp, dr = errors(target, pose(final['pose']))
            maximum = math.degrees(max(abs(value) for value in dq))
            result.update(end_step=self.get_step(), steps=self.get_step() - start,
                final_pose=pose(final['pose']), final_joint_qpos=joints,
                joint_error_norm_rad=norm(dq), max_joint_error_deg=maximum,
                restored_joint_configuration=maximum <= settings['joint_tolerance_deg'],
                controller_restored=not self.backend.joint_reset_active,
                position_error_m=norm(dp), rotation_error_deg=math.degrees(norm(dr)))
            self.results.append(copy.deepcopy(result))
            self.store.log('tool_events', dict(event='tool_end', **result))
            self.store.snapshot('tool_results', self.results)

    def call(self, call, stage):
        validate_tool_call(call)
        options = {k: copy.deepcopy(v) for k, v in call.items() if k not in ('tool', 'target_pose')}
        # Completed stages are historical milestones, not motion invariants.
        # Only caller-specified tool constraints opt in to ongoing protection;
        # never reconstruct them from a completed stage's checker.
        if call['tool'] == 'reset_to_stage_start':
            return self.reset_to_stage_start(stage['id'], **options)
        return self.move_to(call['target_pose'], stage_id=stage['id'], **options)

    def _guard(self, preserve):
        safety = self.backend.motion_safety()
        if type(safety.get('gripper_empty')) is not bool or not isinstance(safety.get('contacts'), list):
            raise ValueError('Malformed robot motion safety response')
        if not safety['gripper_empty']:
            return 'empty_gripper_required', safety
        # Contact is diagnostic only. Keep it in motion_progress, but do not
        # stop a return/move merely because an arm or finger touches something.
        if safety.get('native_overshot', False):
            return 'native_overshot', safety
        for item in preserve:
            value = self.backend.evaluate_condition(item)
            if type(value) is not bool:
                raise ValueError('Protected conditions must return booleans')
            if not (not value if item.get('negate', False) else value):
                return 'protected_condition_lost', dict(condition=item, **safety)
        return None, safety

    def move_to(self, target_pose, *, stage_id, _tool='move_to', **options):
        if type(stage_id) is not int or stage_id < 1:
            raise ValueError('Motion tool stage_id must be a positive integer')
        call = dict(tool=_tool, **copy.deepcopy(options))
        if _tool == 'move_to':
            call['target_pose'] = target_pose
        settings = validate_tool_call(call)
        target = pose(target_pose)
        preserve, workspace = options.get('preserve', []), options.get('workspace')
        for item in preserve:
            self.backend.validate_condition(item)
        contract = self.backend.motion_contract()
        validate_osc(contract)  # Reject a changed controller before physical motion.
        initial = pose(self.backend.end_effector_state()['pose'])
        high = max(initial['position'][2], target['position'][2]) + settings['lift_m']
        lift = dict(position=[*initial['position'][:2], high], quaternion_xyzw=initial['quaternion_xyzw'])
        aligned = dict(position=lift['position'], quaternion_xyzw=target['quaternion_xyzw'])
        above = dict(position=[*target['position'][:2], high], quaternion_xyzw=target['quaternion_xyzw'])
        waypoints = [('lift', lift), ('align', aligned), ('translate', above), ('approach', target)]
        dp, dr = errors(target, initial)
        if norm(dp) <= settings['position_tolerance_m'] and math.degrees(norm(dr)) <= settings['rotation_tolerance_deg']:
            waypoints = [('approach', target)]
        start, call_id = self.get_step(), len(self.results) + 1
        result = dict(call_id=call_id, tool=_tool, stage_id=stage_id, start_step=start,
                      target_pose=target, initial_pose=initial, options=settings,
                      preserve=preserve, workspace=workspace, controller=contract,
                      status='running', steps=0, collision_free_plan=False, contact_stop_enabled=False,
                      restored_joint_configuration=False, pose_frame='world')
        self.store.log('tool_events', dict(event='tool_start', **result))
        try:
            reason, safety = self._guard(preserve)
            if reason:
                result.update(status=reason, safety=safety)
                return result
            if workspace is not None and any(
                not all(a <= p <= b for p, a, b in zip(point['position'], workspace['min'], workspace['max']))
                for point in [initial] + [value for _, value in waypoints]):
                result['status'] = 'outside_workspace'
                return result
            phase_index, stable, stalled, best = 0, 0, 0, math.inf
            while self.get_step() - start < settings['max_steps']:
                phase, waypoint = waypoints[phase_index]
                current = pose(self.backend.end_effector_state()['pose'])
                dp, dr = errors(waypoint, current)
                within = norm(dp) <= settings['position_tolerance_m'] and math.degrees(norm(dr)) <= settings['rotation_tolerance_deg']
                if within and phase_index < len(waypoints) - 1:
                    phase_index += 1
                    best, stalled = math.inf, 0
                    continue
                action = osc_action(limited([.5*x for x in dp], settings['max_translation_m']),
                                    limited([.5*x for x in dr], settings['max_rotation_rad']), contract)
                self.step_action(action, dict(source='tool', tool=_tool, call_id=call_id,
                                               stage_id=stage_id, phase=phase))
                current = pose(self.backend.end_effector_state()['pose'])
                dp, dr = errors(waypoint, current)
                reason, safety = self._guard(preserve)
                self.store.log('motion_progress', dict(call_id=call_id, stage_id=stage_id,
                    step=self.get_step(), phase=phase, pose=current, position_error_m=norm(dp),
                    rotation_error_deg=math.degrees(norm(dr)), safety=safety))
                if reason:
                    result.update(status=reason, safety=safety)
                    return result
                if workspace is not None and not all(a <= p <= b for p, a, b in zip(
                        current['position'], workspace['min'], workspace['max'])):
                    result['status'] = 'outside_workspace'
                    return result
                within = norm(dp) <= settings['position_tolerance_m'] and math.degrees(norm(dr)) <= settings['rotation_tolerance_deg']
                if phase_index == len(waypoints) - 1:
                    stable = stable + 1 if within else 0
                    if stable >= settings['stable_steps']:
                        result.update(status='reached', stable_steps=stable)
                        return result
                metric = norm(dp) + .05 * norm(dr)
                if metric < best - 1e-4:
                    best, stalled = metric, 0
                else:
                    stalled += 1
                if stalled >= settings['stall_steps'] and not within:
                    result['status'] = 'no_progress'
                    return result
            result['status'] = 'tool_step_budget_exhausted'
            return result
        except MotionStopped as error:
            result['status'] = str(error)
            return result
        except BaseException as error:
            result.update(status='error', error=repr(error))
            raise
        finally:
            result.update(end_step=self.get_step(), steps=self.get_step() - start)
            final = pose(self.backend.end_effector_state()['pose'])
            dp, dr = errors(target, final)
            result.update(final_pose=final, position_error_m=norm(dp), rotation_error_deg=math.degrees(norm(dr)))
            self.results.append(copy.deepcopy(result))
            self.store.log('tool_events', dict(event='tool_end', **result))
            self.store.snapshot('tool_results', self.results)
