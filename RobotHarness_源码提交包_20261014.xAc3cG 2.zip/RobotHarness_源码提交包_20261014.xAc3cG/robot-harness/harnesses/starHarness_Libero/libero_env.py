"""Lazy LIBERO imports, immutable target bindings, and explicit Mem scoring."""
from __future__ import annotations

import hashlib
import math
from contextlib import contextmanager
from pathlib import Path

from .schema import PREDICATES
from .pose_math import validate_osc, vector


def _expression(domain, expression):
    """Read-only goal evaluation. Never call Mem's stateful _eval_goal here."""
    if not isinstance(expression, list) or not expression:
        raise ValueError('Malformed native goal expression')
    op = expression[0]
    if isinstance(op, list):
        return all(_expression(domain, item) for item in expression)
    if op == 'and':
        return all(_expression(domain, item) for item in expression[1:])
    if op == 'or':
        return any(_expression(domain, item) for item in expression[1:])
    if op == 'not':
        return not _expression(domain, expression[1])
    return bool(domain._eval_predicate(expression))


class NativeTracker:
    def __init__(self, domain):
        self.domain = domain
        goal = domain.parsed_problem['goal_state']
        root = goal[0] if len(goal) == 1 and isinstance(goal[0], list) else goal
        self.sequences = []
        if root and root[0] == 'sequence':
            self.sequences = [root[1:]]
        elif root and root[0] == 'or' and any(child[0] == 'sequence' for child in root[1:]):
            if not all(child[0] == 'sequence' for child in root[1:]):
                raise ValueError('Mixed sequential/native alternatives are not supported')
            self.sequences = [child[1:] for child in root[1:]]
        if self.sequences and not all(hasattr(domain, name) for name in ('_satisfied_subgoals', '_overshot')):
            raise ValueError('Sequence task requires the LIBERO-Mem environment, not standard LIBERO')
        self.steps_updated = 0

    def after_action(self, step):
        if step != self.steps_updated + 1:
            raise ValueError('Native evaluator must advance exactly once per executed action')
        self.steps_updated = step
        if self.sequences:
            self.domain._check_success(inc=True)
        return self.read()

    def read(self):
        if not self.sequences:
            return dict(success=bool(self.domain._check_success()), mode='standard_native',
                        completed_subgoals=None, overshot=False)
        satisfied = self.domain._satisfied_subgoals
        success = not self.domain._overshot and any(
            len(satisfied) >= len(sequence) and satisfied[:len(sequence)] == sequence
            and _expression(self.domain, sequence[-1]) for sequence in self.sequences)
        return dict(success=bool(success), mode='mem_full_sequence',
                    completed_subgoals=len(satisfied), overshot=bool(self.domain._overshot))


class LiberoEnvironment:
    def __init__(self, table, *, render_gpu=0, settling_steps=10, image_size=256):
        self.table = table
        self.render_gpu, self.settling_steps, self.image_size = render_gpu, settling_steps, image_size
        self.env = self.domain = self.native = None
        self.steps = 0
        self.initial_positions = {}
        self.bindings = dict(table['bindings'])
        self.metadata = {}
        self._joint_reset_active = False

    def reset(self):
        if self.env is not None:
            raise RuntimeError('A harness episode may initialize its physical scene only once')
        import numpy as np
        from libero.libero import benchmark
        from libero.libero.envs import OffScreenRenderEnv
        task_spec = self.table['task']
        suite_class = benchmark.get_benchmark_dict().get(task_spec['suite'])
        if suite_class is None:
            raise ValueError('Suite is not registered in the selected LIBERO installation')
        suite = suite_class()
        task_id = task_spec['task_id']
        names = suite.get_task_names()
        if task_id >= len(names):
            raise ValueError('task_id is outside this suite')
        task = suite.get_task(task_id)
        bddl = Path(suite.get_task_bddl_file_path(task_id))
        states = suite.get_task_init_states(task_id)
        if task_spec['initial_state_index'] >= len(states):
            raise ValueError('initial_state_index is outside the official initial state pool')
        initial = np.asarray(states[task_spec['initial_state_index']])
        np.random.seed(task_spec['seed'])
        self.env = OffScreenRenderEnv(bddl_file_name=str(bddl),
            camera_heights=self.image_size, camera_widths=self.image_size,
            render_gpu_device_id=self.render_gpu,
            horizon=self.table['budget']['max_steps'] + self.settling_steps + 1)
        self.env.seed(task_spec['seed'])
        self.env.reset()
        observation = self.env.set_init_state(initial)
        self.domain = self.env.env
        self.native = NativeTracker(self.domain)
        for _ in range(self.settling_steps):
            observation, _, _, _ = self.env.step([0., 0., 0., 0., 0., 0., -1.])
        if self.native.sequences and self.domain._satisfied_subgoals:
            raise ValueError('Native sequence unexpectedly progressed during settling')
        for name, body_id in self.domain.obj_body_id.items():
            self.initial_positions[name] = self.domain.sim.data.body_xpos[body_id].copy()
        self.metadata = dict(task_name=task.name, bddl=str(bddl),
            bddl_sha256=hashlib.sha256(bddl.read_bytes()).hexdigest(),
            initial_state_sha256=hashlib.sha256(initial.tobytes()).hexdigest(),
            initial_image_sha256={key: hashlib.sha256(observation[key].tobytes()).hexdigest()
                                 for key in ('agentview_image', 'robot0_eye_in_hand_image')},
            scene_initializations=1, settling_steps=self.settling_steps,
            render_gpu=self.render_gpu, control_hz=20, bindings=dict(self.bindings))
        self.latest_observation = observation
        return observation

    def resolve(self, reference):
        return self.bindings[reference[1:]] if reference.startswith('@') else reference

    def validate_condition(self, item):
        for argument, kind in zip(item['args'], PREDICATES[item['predicate']]):
            if kind == 'ref':
                name = self.resolve(argument)
                if name not in self.domain.object_states_dict:
                    raise ValueError(f'Unknown LIBERO object/site: {name}')
        # Check predicate API compatibility now, before sending any policy action.
        self.evaluate_condition(item)

    def evaluate_condition(self, item):
        name = item['predicate']
        args = [self.resolve(value) if kind == 'ref' else value
                for value, kind in zip(item['args'], PREDICATES[name])]
        if name == 'native_success':
            return self.native.read()['success']
        if name in ('on', 'in', 'open', 'close', 'turnon', 'turnoff'):
            return bool(self.domain._eval_predicate([name, *args]))
        obj = self.domain.get_object(args[0])
        gripper = self.domain.robots[0].gripper
        grasped = bool(self.domain._check_grasp(gripper, obj.contact_geoms))
        if name == 'grasped':
            return grasped
        if name == 'released':
            return not grasped and not bool(self.domain.check_contact(gripper, obj))
        if args[0] not in self.initial_positions:
            raise ValueError(f'{name} requires an object body, not a region/site')
        position = self.domain.sim.data.body_xpos[self.domain.obj_body_id[args[0]]]
        if name == 'lifted':
            return bool(position[2] - self.initial_positions[args[0]][2] >= args[1])
        if name == 'stationary':
            return bool(math.sqrt(sum(float(v)**2 for v in self.domain.sim.data.get_body_xvelp(obj.root_body))) <= args[1])
        if name == 'gripper_far':
            robot = self.domain.robots[0]
            eef = self.domain.sim.data.site_xpos[robot.eef_site_id]
            return bool(math.dist(eef, position) >= args[1])
        raise ValueError('Unsupported predicate')

    def step(self, action):
        expected = 8 if self._joint_reset_active else 7
        vector(action, expected, 'active controller action')
        observation, _, raw_done, info = self.env.step(action)
        self.latest_observation = observation
        self.steps += 1
        native = self.native.after_action(self.steps)
        # LIBERO's BDDLBaseDomain replaces returned done with _check_success().
        # That is a goal signal, NOT the robosuite episode-termination flag.
        # Continuing permits stable confirmation and further manual stages.
        # Preserve the actual robosuite horizon flag separately for both forks.
        terminal = bool(self.domain.done)
        return observation, dict(native=native, raw_env_done=bool(raw_done),
                                 terminated=terminal, info_keys=sorted(info))

    def native_status(self):
        return self.native.read()

    def end_effector_state(self):
        from robosuite.utils.transform_utils import mat2quat
        robot, sim = self.domain.robots[0], self.domain.sim
        # Use the actual OSC-controlled grip site for BOTH position and rotation.
        # LIBERO's observation quaternion can refer to a different robot body.
        site = sim.model.site_name2id(robot.controller.eef_name)
        return dict(pose=dict(position=sim.data.site_xpos[site].tolist(),
                    quaternion_xyzw=mat2quat(sim.data.site_xmat[site].reshape(3, 3)).tolist()),
                    gripper_qpos=sim.data.qpos[robot._ref_gripper_joint_pos_indexes].tolist(),
                    joint_qpos=sim.data.qpos[robot._ref_joint_pos_indexes].tolist())

    def motion_contract(self):
        controller = self.domain.robots[0].controller
        if not (getattr(controller, 'use_ori', False) and getattr(controller, 'use_delta', False)
                and getattr(controller, 'name_suffix', '') == 'POSE'):
            raise ValueError('Motion tools support only the existing delta OSC_POSE controller')
        return dict(type='OSC_POSE', control_delta=bool(controller.use_delta),
                    impedance_mode=controller.impedance_mode,
                    **{name: getattr(controller, name).tolist()
                       for name in ('input_min', 'input_max', 'output_min', 'output_max')})

    @property
    def joint_reset_active(self):
        return self._joint_reset_active

    def joint_reset_contract(self):
        """Read-only compatibility check. Never change the VLA controller here."""
        if self._joint_reset_active:
            raise RuntimeError('A joint reset is already active')
        validate_osc(self.motion_contract())
        domain, robot = self.domain, self.domain.robots[0]
        if (len(domain.robots) != 1 or len(robot.joint_indexes) != 7
                or len(robot._ref_joint_pos_indexes) != 7 or len(robot._ref_joint_vel_indexes) != 7
                or robot.controller.control_dim != 6 or not robot.has_gripper
                or robot.gripper.dof != 1 or domain.action_dim != 7):
            raise ValueError('Joint reset adapter requires one seven-joint arm and one gripper action')
        limits = [domain.sim.model.jnt_range[index].tolist() for index in robot.joint_indexes]
        if not all(bool(domain.sim.model.jnt_limited[index]) for index in robot.joint_indexes):
            raise ValueError('Joint reset requires explicit limits for every arm joint')
        for low, high in limits:
            if not math.isfinite(low) or not math.isfinite(high) or low >= high:
                raise ValueError('Invalid arm joint limits')
        return dict(type='JOINT_POSITION', control_delta=True, impedance_mode='fixed',
                    input_min=[-1.] * 7, input_max=[1.] * 7,
                    output_min=[-.05] * 7, output_max=[.05] * 7,
                    joint_limits_rad=limits, kp=50., damping_ratio=1.)

    @contextmanager
    def joint_reset_control(self, target_joint_qpos):
        """Temporarily swap ONLY the controller; no qpos/qvel writes or scene reset."""
        target = vector(target_joint_qpos, 7, 'captured joint_qpos')
        contract = self.joint_reset_contract()
        if any(not low <= value <= high for value, (low, high) in zip(target, contract['joint_limits_rad'])):
            raise ValueError('Captured joint target is outside the robot joint limits')
        from robosuite.controllers.joint_pos import JointPositionController
        from robosuite.utils.buffers import DeltaBuffer
        domain, robot = self.domain, self.domain.robots[0]
        original, action_dim, recent = robot.controller, domain._action_dim, robot.recent_actions
        joint = JointPositionController(
            sim=domain.sim, eef_name=original.eef_name,
            joint_indexes=dict(joints=robot.joint_indexes, qpos=robot._ref_joint_pos_indexes,
                               qvel=robot._ref_joint_vel_indexes),
            actuator_range=robot.torque_limits, policy_freq=robot.control_freq,
            input_min=contract['input_min'], input_max=contract['input_max'],
            output_min=contract['output_min'], output_max=contract['output_max'],
            kp=contract['kp'], damping_ratio=contract['damping_ratio'], impedance_mode='fixed',
            qpos_limits=[[pair[index] for pair in contract['joint_limits_rad']] for index in (0, 1)])
        joint.update_base_pose(robot.base_pos, robot.base_ori)
        joint.update(force=True)
        joint.reset_goal()
        try:
            robot.controller = joint
            robot.recent_actions = DeltaBuffer(dim=8)
            domain._action_dim = 8
            self._joint_reset_active = True
            yield contract
        finally:
            robot.controller, robot.recent_actions = original, recent
            domain._action_dim = action_dim
            self._joint_reset_active = False
            # Discard stale pre-reset OSC goals before the next VLA action.
            original.update(force=True)
            original.reset_goal()

    def motion_safety(self):
        domain, robot, sim = self.domain, self.domain.robots[0], self.domain.sim
        gripper_empty = not any(bool(domain._check_grasp(robot.gripper, obj.contact_geoms))
                                for obj in domain.objects_dict.values())
        geoms = set(robot.robot_model.contact_geoms) | set(robot.gripper.contact_geoms)
        ids = {sim.model.geom_name2id(name) for name in geoms}
        contacts = []
        for index in range(sim.data.ncon):
            contact = sim.data.contact[index]
            # Reject external contacts of the whole arm/gripper, not just fingers.
            if contact.geom1 in ids or contact.geom2 in ids:
                contacts.append(dict(geom1=sim.model.geom_id2name(contact.geom1),
                                     geom2=sim.model.geom_id2name(contact.geom2)))
        return dict(gripper_empty=gripper_empty, contacts=contacts,
                    native_overshot=bool(self.native.read().get('overshot', False)))

    def reset_collision_scene(self, workspace=None):
        from .collision_scene import MujocoCollisionScene
        return MujocoCollisionScene(self, workspace)

    def snapshot(self, path):
        import numpy as np
        np.save(path, self.env.get_sim_state())

    def close(self):
        if self.env is not None:
            self.env.close()
