"""Clients only: reuse resident policies, never load or kill model processes."""
from __future__ import annotations

from collections import deque
import hashlib
import json
from multiprocessing.connection import Client
import os
from pathlib import Path
import subprocess
import tempfile
import time


class ServiceLease:
    """Cooperative client lease, independent of a particular output directory."""
    def __init__(self, identity):
        import fcntl
        folder = Path(tempfile.gettempdir()) / f'starHarness_Libero-{os.getuid()}'
        folder.mkdir(mode=0o700, exist_ok=True)
        name = hashlib.sha256(identity.encode()).hexdigest() + '.lock'
        self.handle = (folder / name).open('a+')
        try:
            fcntl.flock(self.handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BaseException:
            self.handle.close()
            raise RuntimeError('This policy already has a starHarness_Libero client')

    def close(self):
        self.handle.close()


def raw_observation(observation):
    # Only real sensor/proprioception fields reach a VLA; no goals or oracle state.
    return {key: observation[key].copy() for key in (
        'agentview_image', 'robot0_eye_in_hand_image', 'robot0_joint_pos',
        'robot0_eef_pos', 'robot0_eef_quat', 'robot0_gripper_qpos')}


class AtomicResidentPolicy:
    def __init__(self, port, store, *, replan_steps=10):
        if type(port) is not int or not 1 <= port <= 65535 or replan_steps < 1:
            raise ValueError('Invalid local port or replan_steps')
        self.port, self.store, self.replan_steps = port, store, replan_steps
        self.pending, self.ws, self.lease = deque(), None, None
        self.queries = 0
        self.metadata = dict(candidate='AtomicVLA', policy_history_mode='reset_thought_cache_each_stage',
                             scene_reset_by_policy=False, model_unloaded_on_close=False,
                             policy_resets=0, queries=0)

    def begin_episode(self, task, max_queries):
        import websockets.sync.client
        from openpi_client import msgpack_numpy
        self.max_queries, self.msgpack = max_queries, msgpack_numpy
        self.lease = ServiceLease(f'atomic:127.0.0.1:{self.port}')
        # The existing facade has global policy state; do not attach beside another client.
        probe = subprocess.run(['ss', '-Htn', 'state', 'established', f'( sport = :{self.port} )'],
                               capture_output=True, text=True, check=True)
        if probe.stdout.strip():
            raise RuntimeError('Resident AtomicVLA already has a connected client; left untouched')
        self.ws = websockets.sync.client.connect(f'ws://127.0.0.1:{self.port}',
                        open_timeout=12, close_timeout=5, max_size=None, compression=None)
        packet = self.ws.recv(timeout=12)
        if isinstance(packet, str):
            raise RuntimeError('Unexpected model handshake')
        metadata = self.msgpack.unpackb(packet)
        if metadata.get('candidate') != 'AtomicVLA' or metadata.get('config') != 'Atomic_libero':
            raise RuntimeError('This client requires the existing Atomic_libero facade')
        self.metadata['service'] = {key: str(metadata[key]) for key in ('candidate', 'config')}

    def set_stage(self, stage, observation, step):
        discarded = len(self.pending)
        self.pending.clear()
        self.instruction, self.episode_start = stage['instruction'], True
        self.metadata['policy_resets'] += 1
        return dict(discarded_actions=discarded, policy_history_reset=True,
                    reset_scope='AtomicVLA thought cache only; physical scene unchanged')

    def act(self, observation, step):
        import numpy as np
        from openpi_client import image_tools
        from robosuite.utils.transform_utils import quat2axisangle
        while not self.pending:
            if self.queries >= self.max_queries:
                raise RuntimeError('Policy query budget exhausted (thinking queries included)')
            main = np.ascontiguousarray(observation['agentview_image'][::-1, ::-1])
            wrist = np.ascontiguousarray(observation['robot0_eye_in_hand_image'][::-1, ::-1])
            payload = {
                'observation/image': image_tools.convert_to_uint8(image_tools.resize_with_pad(main, 224, 224)),
                'observation/wrist_image': image_tools.convert_to_uint8(image_tools.resize_with_pad(wrist, 224, 224)),
                'observation/state': np.concatenate([observation['robot0_eef_pos'],
                    quat2axisangle(observation['robot0_eef_quat'].copy()), observation['robot0_gripper_qpos']]).astype(np.float32),
                'prompt': self.instruction, 'episode_start': self.episode_start, 'reset': 0}
            self.queries += 1
            self.metadata['queries'] = self.queries
            start = time.monotonic()
            self.ws.send(self.msgpack.Packer().pack(payload))
            packet = self.ws.recv(timeout=180)
            if isinstance(packet, str):
                raise RuntimeError(packet)
            response = self.msgpack.unpackb(packet)
            self.episode_start = False
            actions = np.asarray(response['actions'])
            if actions.ndim != 2 or actions.shape[1] != 7 or len(actions) < self.replan_steps or not np.isfinite(actions).all():
                raise ValueError('Invalid AtomicVLA action chunk')
            thinking = response.get('is_thinking')
            if type(thinking) is not bool:
                raise ValueError('AtomicVLA must report is_thinking explicitly')
            self.store.log('policy_queries', dict(query=self.queries, step=step,
                instruction=self.instruction, is_thinking=thinking,
                seconds=time.monotonic() - start, returned_actions=len(actions)))
            if not thinking:
                self.pending.extend(actions[:self.replan_steps].tolist())
        return self.pending.popleft()

    def observe(self, observation, step, done):
        pass  # The official websocket policy consumes sensors on infer().

    def pause_for_tool(self, observation, step):
        discarded = len(self.pending)
        self.pending.clear()
        self.episode_start = True
        return dict(discarded_actions=discarded, inference_suspended=True,
                    next_stage_resets_policy_history=True)

    def close(self):
        try:
            if self.ws is not None:
                self.ws.close()
        finally:
            if self.lease is not None:
                self.lease.close()


class InternResidentPolicy:
    """Existing IPC supports per-stage session reset, NOT retained-history switching.

    This adapter records that limitation honestly rather than silently patching a
    shared server. An eventual preserved-history interface can be a new adapter.
    """
    def __init__(self, socket_path, prompt_manifest, store):
        self.socket_path, self.store = Path(socket_path).resolve(), store
        manifest_path = Path(prompt_manifest).resolve()
        manifest = json.loads(manifest_path.read_text())
        if manifest.get('schema_version') != 1 or not isinstance(manifest.get('prompts'), list):
            raise ValueError('Prompt manifest requires schema_version:1 and prompts:[]')
        self.prompts = {}
        for entry in manifest['prompts']:
            if set(entry) != {'instruction', 'context_file', 'sha256'} or entry['instruction'] in self.prompts:
                raise ValueError('Invalid or duplicated prompt entry')
            path = Path(entry['context_file'])
            if not path.is_absolute() or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
                raise ValueError('Prepared official T5 context is absent or checksum differs')
            self.prompts[entry['instruction']] = entry
        self.connection = self.lease = None
        self.active = False
        self.queries = 0
        self.metadata = dict(candidate='InternW0-Delta',
            policy_history_mode='new_policy_session_each_stage', policy_resets=0, queries=0,
            scene_reset_by_policy=False, model_unloaded_on_close=False)

    def validate_instructions(self, stages):
        missing = [stage['id'] for stage in stages if stage['instruction'] not in self.prompts]
        if missing:
            raise ValueError(f'Prepare exact official prompt contexts for stages {missing} before running')

    def begin_episode(self, task, max_queries):
        self.task, self.max_queries = task, max_queries
        self.lease = ServiceLease('intern:' + str(self.socket_path))
        state = json.loads(self.socket_path.with_name('server_state.json').read_text())
        if state['status'] != 'ready_idle':
            raise RuntimeError('Resident InternW0-Delta is occupied; left untouched')
        self.connection = Client(str(self.socket_path), family='AF_UNIX')
        if not self.connection.poll(12):
            raise TimeoutError('Resident policy handshake timed out')
        metadata = self.connection.recv()
        if metadata.get('candidate') != 'InternW0-Delta' or metadata.get('pid') != state['pid']:
            raise ValueError('Unexpected resident policy identity')
        if self.request({'op': 'health'}).get('status') != 'ready_idle':
            raise RuntimeError('Resident policy is not idle')
        self.metadata['service'] = dict(candidate=str(metadata['candidate']), pid=int(metadata['pid']))

    def request(self, value):
        self.connection.send(value)
        if not self.connection.poll(180):
            raise TimeoutError('Resident policy request timed out; never automatically replay')
        result = self.connection.recv()
        if 'error' in result:
            raise RuntimeError(result['error'])
        return result

    def set_stage(self, stage, observation, step):
        if self.active:
            self.request({'op': 'end_episode'})
            self.active = False
        entry = self.prompts[stage['instruction']]
        self.request(dict(op='reset', suite=self.task['suite'], task_id=self.task['task_id'],
            instruction=stage['instruction'], seed=self.task['seed'], context_file=entry['context_file'],
            context_sha256=entry['sha256'], client_pid=os.getpid()))
        self.active, self.stage_start = True, step
        self.metadata['policy_resets'] += 1
        return dict(discarded_actions='server queue disposed with old policy session',
                    policy_history_reset=True, reset_scope='policy only; physical scene unchanged')

    def act(self, observation, step):
        if self.queries >= self.max_queries:
            raise RuntimeError('Policy query budget exhausted')
        result = self.request(dict(op='act', observation=raw_observation(observation),
                                   step=step - self.stage_start))
        if result['replanned']:
            self.queries += 1
            self.metadata['queries'] = self.queries
            self.store.log('policy_queries', dict(query=self.queries, step=step,
                stage_step=step - self.stage_start, seconds=result.get('seconds'),
                peak_allocated_mib=result.get('peak_allocated_mib')))
        return result['action']

    def observe(self, observation, step, done):
        self.request(dict(op='observe', observation=raw_observation(observation), done=bool(done)))

    def pause_for_tool(self, observation, step):
        if self.active:
            self.request({'op': 'end_episode'})
            self.active = False
        return dict(discarded_actions='old resident session ended', inference_suspended=True,
                    next_stage_resets_policy_history=True)

    def close(self):
        try:
            if self.connection is not None:
                try:
                    if self.active:
                        self.request({'op': 'end_episode'})
                        self.active = False
                    self.request({'op': 'disconnect'})
                finally:
                    self.connection.close()
        finally:
            if self.lease is not None:
                self.lease.close()
