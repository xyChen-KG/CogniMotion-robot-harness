"""Manual, variable-length stage supervision for frozen LIBERO policies."""

__version__ = '0.1.0'
