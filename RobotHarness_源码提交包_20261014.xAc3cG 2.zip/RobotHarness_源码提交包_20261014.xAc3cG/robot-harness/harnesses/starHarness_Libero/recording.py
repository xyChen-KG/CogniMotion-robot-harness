"""One continuous, correctly oriented two-camera video across all stages."""
from pathlib import Path
import os
import time


class VideoRecorder:
    def __init__(self, folder, fps=20):
        self.folder, self.fps, self.writer = Path(folder), fps, None
        self.metadata = dict(video='episode.mp4', fps=fps, frames=0, camera_views=['agentview', 'wrist'],
                             source_images_rotated_180_degrees=True)
        self.context = dict(stage_id=None, source='starting', tool=None)
        self.preview = None
        preview_fps = float(os.environ.get('ROBOT_PREVIEW_FPS', '0'))
        if preview_fps:
            from .preview import PreviewExporter
            self.preview = PreviewExporter(folder, preview_fps)
        self.metadata['preview'] = dict(enabled=self.preview is not None, fps=preview_fps)

    def set_context(self, *, stage_id, source, tool=None):
        self.context = dict(stage_id=stage_id, source=source, tool=tool)

    def capture(self, observation, step):
        import numpy as np
        import imageio.v2 as imageio
        from PIL import Image
        main = np.ascontiguousarray(observation['agentview_image'][::-1, ::-1])
        wrist = np.ascontiguousarray(observation['robot0_eye_in_hand_image'][::-1, ::-1])
        frame = np.concatenate([main, wrist], axis=1)
        captured = time.time()
        if self.writer is None:
            self.writer = imageio.get_writer(str(self.folder / 'episode.mp4'), fps=self.fps)
            Image.fromarray(frame).save(self.folder / 'initial_frame.png')
        self.writer.append_data(frame)
        self.last_frame = frame
        self.last_capture = (step, dict(self.context), captured)
        self.metadata['frames'] += 1
        if self.preview is not None:
            self.preview.offer(frame, step, self.context, captured)

    def close(self):
        if self.writer is not None:
            from PIL import Image
            self.writer.close()
            Image.fromarray(self.last_frame).save(self.folder / 'final_frame.png')
        if self.preview is not None:
            if hasattr(self, 'last_capture'):
                step, context, captured = self.last_capture
                if step != self.preview.last_offered_step:
                    self.preview.offer(self.last_frame, step, context, captured, force=True)
            self.metadata['preview'].update(self.preview.close())
        self.metadata['duration_seconds'] = self.metadata['frames'] / self.fps
