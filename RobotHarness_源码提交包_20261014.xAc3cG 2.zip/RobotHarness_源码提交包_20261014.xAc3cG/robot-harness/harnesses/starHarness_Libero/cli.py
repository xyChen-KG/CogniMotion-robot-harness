"""Validation is dependency-free; execution explicitly selects existing services."""
import argparse
import json
import os
import signal

from .schema import load_table


def main(argv=None):
    parser = argparse.ArgumentParser(prog='starHarness_Libero')
    commands = parser.add_subparsers(dest='command', required=True)
    validate = commands.add_parser('validate', help='Validate only; no model, network or simulation')
    validate.add_argument('--task-table', required=True)
    run = commands.add_parser('run', help='Run exactly one fresh scene, no retries')
    run.add_argument('--task-table', required=True)
    run.add_argument('--output', required=True, help='New output directory; existing paths are rejected')
    run.add_argument('--policy', required=True, choices=['atomic', 'internw0'])
    run.add_argument('--atomic-port', type=int)
    run.add_argument('--intern-socket')
    run.add_argument('--prompt-manifest', help='Exact precomputed official T5 contexts for InternW0')
    run.add_argument('--state-updater', choices=['qwen', 'deterministic'], default='qwen')
    run.add_argument('--qwen-url', help='Existing local Qwen HTTP service')
    run.add_argument('--render-gpu', type=int, default=0)
    run.add_argument('--settling-steps', type=int, default=10)
    run.add_argument('--atomic-replan-steps', type=int, default=10)
    args = parser.parse_args(argv)
    try:
        table = load_table(args.task_table)
    except (ValueError, OSError) as error:
        parser.error(str(error))
    if args.command == 'validate':
        print(json.dumps(dict(valid=True, stages=len(table['stages']), task=table['task'],
                         max_steps=table['budget']['max_steps'], models_loaded=False)))
        return 0
    if args.settling_steps < 0 or args.render_gpu < 0 or args.atomic_replan_steps < 1:
        parser.error('Invalid rendering, settling or action-chunk setting')
    if args.policy == 'atomic' and args.atomic_port is None:
        parser.error('--atomic-port is required for the existing AtomicVLA facade')
    if args.policy == 'internw0' and not (args.intern_socket and args.prompt_manifest):
        parser.error('--intern-socket and --prompt-manifest are required')
    if args.state_updater == 'qwen' and not args.qwen_url:
        parser.error('--qwen-url is required; Qwen is not automatically started')
    # Configure only this process, before importing MuJoCo. No global changes.
    os.environ.setdefault('MUJOCO_GL', 'egl')
    os.environ.setdefault('PYOPENGL_PLATFORM', 'egl')
    os.environ['MUJOCO_EGL_DEVICE_ID'] = str(args.render_gpu)
    from .controller import Controller
    from .libero_env import LiberoEnvironment
    from .policies import AtomicResidentPolicy, InternResidentPolicy
    from .qwen import DeterministicUpdater, QwenUpdater
    from .recording import VideoRecorder
    from .storage import EpisodeStore
    store = EpisodeStore(args.output, table)
    try:
        policy = (AtomicResidentPolicy(args.atomic_port, store, replan_steps=args.atomic_replan_steps)
                  if args.policy == 'atomic' else InternResidentPolicy(args.intern_socket, args.prompt_manifest, store))
        if hasattr(policy, 'validate_instructions'):
            policy.validate_instructions(table['stages'])
        updater = (QwenUpdater(args.qwen_url, store, table['budget']['max_state_requests'])
                   if args.state_updater == 'qwen' else DeterministicUpdater())
        env = LiberoEnvironment(table, render_gpu=args.render_gpu, settling_steps=args.settling_steps)
        previous_handler = signal.getsignal(signal.SIGTERM)
        def interrupted(signum, frame):
            raise InterruptedError(f'Termination signal {signum}; no automatic replay')
        signal.signal(signal.SIGTERM, interrupted)
        try:
            result = Controller(table, env, policy, updater, store, VideoRecorder(store.path)).run()
        finally:
            signal.signal(signal.SIGTERM, previous_handler)
    except Exception as error:
        store.snapshot('result', dict(status='error', phase='configuration', error=repr(error),
                       success=False, simulation_started=False, automatic_trial_retry=False))
        store.close()
        raise
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result['status'] == 'complete' else 1
