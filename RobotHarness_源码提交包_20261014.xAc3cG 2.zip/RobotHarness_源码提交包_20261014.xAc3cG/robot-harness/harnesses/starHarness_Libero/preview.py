"""Optional latest-only JPEG side channel. Never renders or steps a simulator."""
from __future__ import annotations

import base64
import io
import math
from pathlib import Path
import queue
import threading
import time

from .storage import save_json


def encode_jpeg(frame):
    from PIL import Image
    buffer = io.BytesIO()
    Image.fromarray(frame).save(buffer, format='JPEG', quality=80)
    return buffer.getvalue()


class PreviewExporter:
    def __init__(self, folder, fps=4, *, encoder=encode_jpeg):
        if not math.isfinite(fps) or not 0 < fps <= 10:
            raise ValueError('Preview FPS must be in (0, 10]')
        self.folder, self.interval, self.encoder = Path(folder), 1 / fps, encoder
        self.pending = queue.Queue(maxsize=1)
        self.stop_event = threading.Event()
        self.last_offer = float('-inf')
        self.last_offered_step = None
        self.published = self.dropped = 0
        self.last_error = None
        self.closed = False
        self.thread = threading.Thread(target=self._work, name='robot-preview', daemon=True)
        self.thread.start()

    def offer(self, frame, step, context, captured_epoch, *, force=False):
        if self.closed:
            return
        now = time.monotonic()
        if not force and now - self.last_offer < self.interval:
            return
        # The queue owns a copy, never a simulator-owned observation buffer.
        try:
            item = (frame.copy(), int(step), dict(context), float(captured_epoch))
        except Exception as error:
            self.last_error = type(error).__name__
            return
        self.last_offer, self.last_offered_step = now, step
        try:
            self.pending.put_nowait(item)
        except queue.Full:
            try:
                self.pending.get_nowait()
                self.dropped += 1
            except queue.Empty:
                pass
            try:
                self.pending.put_nowait(item)
            except queue.Full:
                self.dropped += 1

    def _work(self):
        while not self.stop_event.is_set() or not self.pending.empty():
            try:
                frame, step, context, captured = self.pending.get(timeout=0.1)
            except queue.Empty:
                continue
            try:
                jpeg = self.encoder(frame)
                if not jpeg.startswith(b'\xff\xd8') or not jpeg.endswith(b'\xff\xd9') or len(jpeg) > 1_000_000:
                    raise ValueError('Invalid or oversized preview JPEG')
                packet = dict(version=1, frame_id=step, step=step, captured_epoch=captured,
                    published_epoch=time.time(), width=int(frame.shape[1]), height=int(frame.shape[0]),
                    camera_views=['agentview', 'wrist'], image_mime='image/jpeg',
                    image_base64=base64.b64encode(jpeg).decode('ascii'), **context)
                # ONE atomically replaced JSON packet: image and metadata cannot tear.
                save_json(self.folder / 'preview.json', packet)
                self.published += 1
                self.last_error = None
            except Exception as error:
                # Preview failures never alter robot motion, success or video recording.
                self.last_error = type(error).__name__

    def close(self):
        self.closed = True
        self.stop_event.set()
        self.thread.join(timeout=1.5)
        return dict(published_frames=self.published, dropped_preview_frames=self.dropped,
                    error=self.last_error, worker_alive=self.thread.is_alive())
