"""Optional offline CPU preparation of all unique manual stage instructions.

Run with the existing InternW0 model interpreter. This does not load the VLA,
connect to any service, move a robot, download assets, or train anything.
"""
import argparse
import hashlib
import os
from pathlib import Path
import sys
import time

if __package__:
    from .schema import load_table
    from .storage import save_json
else:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from starHarness_Libero.schema import load_table
    from starHarness_Libero.storage import save_json


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--task-table', required=True)
    parser.add_argument('--candidate-root', required=True)
    parser.add_argument('--output', required=True, help='New directory under candidate-root/runs')
    args = parser.parse_args(argv)
    table = load_table(args.task_table)
    root, output = Path(args.candidate_root).resolve(), Path(args.output).resolve()
    if not output.is_relative_to(root / 'runs'):
        parser.error('The existing resident server accepts contexts only under candidate-root/runs')
    backbones = root / 'backbones'
    encoder_path = backbones / 'DiffSynth-Studio/Wan-Series-Converted-Safetensors/models_t5_umt5-xxl-enc-bf16.safetensors'
    tokenizer_path = backbones / 'Wan-AI/Wan2.1-T2V-1.3B/google/umt5-xxl'
    if not encoder_path.is_file() or not tokenizer_path.is_dir():
        parser.error('Existing official encoder/tokenizer assets are required; nothing is downloaded')
    output.mkdir(parents=True, exist_ok=False)
    os.environ.update(CUDA_VISIBLE_DEVICES='', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
        DIFFSYNTH_SKIP_DOWNLOAD='true', TOKENIZERS_PARALLELISM='false',
        WAM_CHECKPOINT_ROOT=str(backbones),
        WAM_VLM_PATH=str(backbones / 'Alibaba-DAMO-Academy/RynnBrain1.1-2B'))
    sys.path[:0] = [str(root / 'repo'), str(root / 'repo/src')]
    import torch
    from wam.model.backbones.wan22.helpers.loader import _load_registered_model
    from wam.model.backbones.wan22.wan_video_text_encoder import HuggingfaceTokenizer
    from wam.datasets.lerobot.robot_video_dataset import DEFAULT_PROMPT
    torch.set_num_threads(8)
    tokenizer = HuggingfaceTokenizer(name=str(tokenizer_path), seq_len=128, clean='whitespace')
    instructions = list(dict.fromkeys(stage['instruction'] for stage in table['stages']))
    prepared = []
    for text in instructions:
        wrapped = DEFAULT_PROMPT.format(task=text)
        count = len(tokenizer.tokenizer(wrapped, add_special_tokens=True)['input_ids'])
        if count > 128:
            raise ValueError(f'Instruction exceeds the official 128-token context; not truncated: {text!r}')
        prepared.append((text, wrapped, count))
    encoder = _load_registered_model(str(encoder_path), 'wan_video_text_encoder',
                                     torch_dtype=torch.bfloat16, device='cpu').eval()
    encoder.requires_grad_(False)
    manifest, receipts = {'schema_version': 1, 'prompts': []}, []
    for index, (text, wrapped, count) in enumerate(prepared, 1):
        began = time.monotonic()
        with torch.inference_mode():
            ids, mask = tokenizer(wrapped, return_mask=True, add_special_tokens=True)
            mask = mask.to(dtype=torch.bool)
            context = encoder(ids, mask).masked_fill(~mask.unsqueeze(-1), 0)
            if tuple(context.shape) != (1, 128, 4096) or not torch.isfinite(context).all():
                raise ValueError('Unexpected official prompt context')
            path = output / f'prompt_{index:04d}.pt'
            torch.save({text: (context.cpu(), torch.ones_like(mask))}, path)
        entry = dict(instruction=text, context_file=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        manifest['prompts'].append(entry)
        receipts.append(dict(**entry, wrapped_prompt=wrapped, tokens=count, device='cpu',
                             encoder='official frozen T5', elapsed_seconds=time.monotonic() - began))
    save_json(output / 'encoding_receipts.json', receipts)
    save_json(output / 'prompt_manifest.json', manifest)
    print(f'Prepared {len(instructions)} unique instructions for {len(table["stages"])} stages: {output / "prompt_manifest.json"}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
