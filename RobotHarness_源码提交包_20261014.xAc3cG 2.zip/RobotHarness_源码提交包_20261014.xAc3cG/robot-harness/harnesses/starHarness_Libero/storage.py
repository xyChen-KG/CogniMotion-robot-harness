"""Exclusive episode artifacts and atomic snapshots, without replay/resume."""
import json
import os
from pathlib import Path
import time


def save_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('w', encoding='utf-8') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)


class EpisodeStore:
    def __init__(self, path, table):
        self.path = Path(path).resolve()
        self.path.mkdir(parents=True, exist_ok=False)
        save_json(self.path / 'episode_claim.json', dict(pid=os.getpid(), started_epoch=time.time(),
                  max_episodes=1, automatic_replay=False))
        save_json(self.path / 'task_table_input.json', table)
        save_json(self.path / 'task_table.json', table)
        self.handles = {}

    def log(self, name, value):
        if name not in self.handles:
            self.handles[name] = (self.path / (name + '.jsonl')).open('x', encoding='utf-8')
        self.handles[name].write(json.dumps(value, ensure_ascii=False, allow_nan=False) + '\n')
        self.handles[name].flush()

    def snapshot(self, name, value):
        save_json(self.path / (name + '.json'), value)

    def close(self):
        for handle in self.handles.values():
            handle.close()
