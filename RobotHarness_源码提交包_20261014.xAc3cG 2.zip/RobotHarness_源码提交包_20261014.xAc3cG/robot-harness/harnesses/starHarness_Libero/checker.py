"""Stateful events plus stable final conditions; no language-model judgments."""
from __future__ import annotations

from .schema import validate_table


class StageChecker:
    def __init__(self, backend, table):
        validate_table(table)
        self.backend = backend
        self.stable_steps = table['stable_steps']
        self.official_only = table.get('completion_mode') == 'official_predicates'
        self.stage_id = None
        self.last_step = None
        self.event_index = self.consecutive = 0
        # Bind and check ALL stages before the first policy action.
        for stage in table['stages']:
            conditions = stage['checker']['all'] + [c for event in stage['checker'].get('sequence', []) for c in event['all']]
            for item in conditions:
                backend.validate_condition(item)

    def _group(self, conditions):
        checks = []
        for item in conditions:
            value = self.backend.evaluate_condition(item)
            if type(value) is not bool:
                raise ValueError('Simulator conditions must return booleans')
            checks.append({'condition': item, 'completed': not value if item.get('negate', False) else value})
        return checks

    def current_conditions(self, stage):
        """Read current end-state conditions without advancing event/stability history."""
        checks = self._group(stage['checker']['all'])
        return dict(current_satisfied=all(item['completed'] for item in checks), checks=checks)

    def evaluate(self, stage, step):
        if self.last_step is not None and step < self.last_step:
            raise ValueError('Control steps must be monotonic')
        if self.official_only:
            # Native predicates are instantaneous, including at a stage boundary.
            # Do not impose one extra action, release, settling, or event history.
            self.stage_id, self.last_step = stage['id'], step
            checks = self._group(stage['checker']['all'])
            raw = all(item['completed'] for item in checks)
            return dict(stage_id=stage['id'], step=step, raw_completed=raw,
                        completed=raw, consecutive_steps=int(raw), sequence_index=0,
                        sequence_length=0, sequence_event_advanced=False,
                        event_checks=[], checks=checks, completion_mode='official_predicates')
        if stage['id'] != self.stage_id:
            self.stage_id = stage['id']
            self.event_index = self.consecutive = 0
            self.last_step = step  # New events require a NEW executed action.
            fresh = False
        else:
            fresh = step != self.last_step
        sequence = stage['checker'].get('sequence', [])
        events = []
        advanced = False
        if self.event_index < len(sequence):
            events = self._group(sequence[self.event_index]['all'])
            if fresh and all(item['completed'] for item in events):
                self.event_index += 1
                advanced = True
        checks = self._group(stage['checker']['all'])
        raw = self.event_index == len(sequence) and all(item['completed'] for item in checks)
        if fresh:
            adjacent = step == self.last_step + 1
            # Do not count an event and its final confirmation on the same action.
            self.consecutive = ((self.consecutive + 1 if adjacent else 1)
                                if raw and not advanced else 0)
            self.last_step = step
        elif not raw:
            self.consecutive = 0
        return dict(stage_id=stage['id'], step=step, raw_completed=raw,
                    completed=raw and self.consecutive >= self.stable_steps,
                    consecutive_steps=self.consecutive, sequence_index=self.event_index,
                    sequence_length=len(sequence), sequence_event_advanced=advanced,
                    event_checks=events, checks=checks)
