"""Direct-file entry point, usable beside the existing server-side harnesses."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from starHarness_Libero.cli import main

if __name__ == '__main__':
    raise SystemExit(main())
