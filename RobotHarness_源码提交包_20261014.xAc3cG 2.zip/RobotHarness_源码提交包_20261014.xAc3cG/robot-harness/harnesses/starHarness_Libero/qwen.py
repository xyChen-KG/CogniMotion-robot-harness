"""Reuse a local Qwen service for TEXT-ONLY authoritative state updates."""
import json
import time
import urllib.request
from urllib.parse import urlparse

from .schema import active_stage, apply_update


class DeterministicUpdater:
    mode = 'simulator_deterministic_state'

    def __init__(self):
        self.requests = 0

    def update(self, table, check):
        return {'stage_id': active_stage(table)['id'], 'completed': check['completed']}


class QwenUpdater:
    mode = 'simulator_with_qwen_state'

    def __init__(self, url, store, max_requests, timeout=60):
        parsed = urlparse(url)
        if parsed.scheme != 'http' or parsed.hostname not in ('127.0.0.1', 'localhost', '::1') or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ('', '/'):
            raise ValueError('Only an existing loopback HTTP Qwen service is supported; no cloud/API keys')
        self.url, self.store = url.rstrip('/'), store
        self.max_requests, self.timeout, self.requests = max_requests, timeout, 0
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def update(self, table, check):
        stage = active_stage(table)
        if stage is None or stage['id'] != check['stage_id'] or type(check['completed']) is not bool:
            raise ValueError('Check must refer to the current stage')
        # Full table stays on disk; arbitrarily many stages do not overflow context.
        completed = [s for s in table['stages'] if s['completed']]
        context = dict(current_stage={'id': stage['id'], 'instruction': stage['instruction']},
                       stage_count=len(table['stages']), completed_count=len(completed),
                       recent_completed=[{'id': s['id'], 'instruction': s['instruction']} for s in completed[-3:]],
                       simulator_check={k: check[k] for k in ('stage_id', 'step', 'completed')})
        body = dict(model='Qwen3-VL-4B-Instruct', temperature=0, max_tokens=96, messages=[
            {'role': 'system', 'content': 'Return only JSON with exactly stage_id and completed. Copy simulator_check.stage_id and simulator_check.completed exactly. Use a JSON boolean. Do not plan, inspect images, infer success, change instructions, or provide recovery.'},
            {'role': 'user', 'content': json.dumps(context, ensure_ascii=False)}])
        for attempt in range(2):
            if self.requests >= self.max_requests:
                raise RuntimeError('State request budget exhausted')
            self.requests += 1
            record = dict(request=self.requests, attempt=attempt + 1, body=body, started_epoch=time.time())
            try:
                request = urllib.request.Request(self.url + '/v1/chat/completions',
                    data=json.dumps(body).encode(), headers={'Content-Type': 'application/json'})
                with self.opener.open(request, timeout=self.timeout) as response:
                    envelope = json.load(response)
                record['response'] = envelope
                if envelope.get('model') not in ('Qwen3-VL-4B-Instruct', 'Qwen/Qwen3-VL-4B-Instruct'):
                    raise ValueError('Unexpected model at the Qwen endpoint')
                choice = envelope['choices'][0]
                if choice['finish_reason'] != 'stop':
                    raise ValueError('Truncated Qwen response')
                text = choice['message']['content'].strip()
                if text.startswith('```') and text.endswith('```'):
                    text = '\n'.join(text.splitlines()[1:-1])
                value = json.loads(text)
                apply_update(table, value, check['completed'])  # Validate without mutation.
                record['parsed'] = value
                return value
            except (ValueError, KeyError, IndexError, TypeError) as error:
                record['error'] = repr(error)
                if attempt == 1:
                    raise ValueError('Qwen state update rejected twice') from error
            except Exception as error:
                record['error'] = repr(error)
                raise  # No network retries or hidden extra inference.
            finally:
                record['elapsed_seconds'] = time.time() - record['started_epoch']
                self.store.log('qwen_requests', record)
