"""Bounded joint-space RRTConnect; geometry comes from an explicit scene.

No model calls, installation, live-state writes, IK substitution or task repair.
Edges are discretely collision checked, not certified continuous swept volumes.
"""
import math
import random
import time


class SearchTimeout(Exception):
    pass


def distance(a, b):
    return math.dist(a, b)


class JointReturnPlanner:
    def __init__(self, scene, *, deadline, resolution=.01, extension=.15, seed=0):
        self.scene, self.deadline = scene, deadline
        self.resolution, self.extension = resolution, extension
        self.random = random.Random(seed)  # Never perturb the VLA/environment RNG.
        self.checks = 0

    def check_time(self):
        if time.monotonic() >= self.deadline:
            raise SearchTimeout()

    def report(self, q):
        self.check_time()
        value = self.scene.report(q)
        self.checks += 1
        self.check_time()
        return value

    def edge(self, a, b, *, escape=False):
        """Check intermediate arm configurations, including both endpoints."""
        count = max(1, math.ceil(max(abs(x-y) for x, y in zip(a, b)) / self.resolution))
        previous = self.report(a)
        if previous['invalid'] or (previous['contacts'] and not escape):
            return False
        for index in range(1, count + 1):
            q = [x + (y-x)*index/count for x, y in zip(a, b)]
            current = self.report(q)
            if current['invalid']:
                return False
            if escape:
                # Only existing pairs may persist, with non-increasing penetration.
                if any(pair not in previous['contacts'] or depth > previous['contacts'][pair] + 1e-6
                       for pair, depth in current['contacts'].items()):
                    return False
            elif current['contacts']:
                return False
            previous = current
        return True

    def escape(self, start):
        path, current = [list(start)], list(start)
        for _ in range(12):
            before = self.report(current)
            if before['invalid']:
                return None
            if not before['contacts']:
                return path
            best, score = None, sum(before['contacts'].values())
            candidates = self.scene.retreat_candidates(current)
            # Cartesian retreat candidates first; bounded random joint alternatives.
            candidates += [[q + self.random.uniform(-.12, .12) for q in current] for _ in range(48)]
            for candidate in candidates:
                after = self.report(candidate)
                value = sum(after['contacts'].values())
                if (not after['invalid'] and value < score - 1e-6
                        and self.edge(current, candidate, escape=True)):
                    best, score = candidate, value
                    if not after['contacts']:
                        break
            if best is None:
                return None
            current = list(best)
            path.append(current)
        return path if not self.report(current)['contacts'] else None

    @staticmethod
    def branch(tree, index):
        path = []
        while index is not None:
            q, index = tree[index]
            path.append(q)
        return list(reversed(path))

    def extend(self, tree, target):
        self.check_time()
        index = min(range(len(tree)), key=lambda i: distance(tree[i][0], target))
        q = tree[index][0]
        length = distance(q, target)
        if length < 1e-10:
            return index, True
        fraction = min(1., self.extension / length)
        nxt = [x + (y-x)*fraction for x, y in zip(q, target)]
        if not self.edge(q, nxt):
            return None, False
        tree.append((nxt, index))
        return len(tree)-1, fraction == 1.

    def plan(self, start, goal):
        began = time.monotonic()
        result = dict(status='planning_timeout', path=[], escape_edges=0,
                      algorithm='RRTConnect', approximate_solution=False)
        try:
            goal_report = self.report(goal)
            if goal_report['invalid'] or goal_report['contacts']:
                result['status'] = 'goal_in_collision' if goal_report['contacts'] else 'invalid_goal'
                return result
            first = self.report(start)
            if first['invalid']:
                result['status'] = 'invalid_start'
                return result
            prefix = self.escape(start) if first['contacts'] else [list(start)]
            if prefix is None:
                result['status'] = 'start_in_contact'
                return result
            free_start = prefix[-1]
            result['escape_edges'] = len(prefix)-1
            if self.edge(free_start, goal):
                result.update(status='planned', algorithm='checked_direct', path=prefix + [list(goal)])
                return result
            left, right, left_is_start = [(free_start, None)], [(list(goal), None)], True
            # Memory and search are both bounded, even with a mocked/slow clock.
            for _ in range(4000):
                self.check_time()
                sample = (right[0][0] if self.random.random() < .15 else
                          [self.random.uniform(low, high) for low, high in self.scene.limits])
                index, _ = self.extend(left, sample)
                if index is not None:
                    target = left[index][0]
                    for _ in range(256):
                        other, connected = self.extend(right, target)
                        if other is None:
                            break
                        if connected:
                            a, b = self.branch(left, index), self.branch(right, other)
                            route = a + list(reversed(b))[1:] if left_is_start else b + list(reversed(a))[1:]
                            result.update(status='planned', path=prefix[:-1] + route)
                            return result
                left, right, left_is_start = right, left, not left_is_start
            result['status'] = 'search_limit_reached'
            return result
        except SearchTimeout:
            result['status'] = 'planning_timeout'
            return result
        finally:
            result.update(collision_checks=self.checks, search_seconds=time.monotonic()-began)


def checked_edge(scene, a, b, *, resolution=.01, escape=False):
    """Short execution lookahead, separate from the cumulative search budget."""
    return JointReturnPlanner(scene, deadline=time.monotonic()+1., resolution=resolution).edge(a, b, escape=escape)
