import copy
from types import SimpleNamespace
import unittest

from ..libero_env import LiberoEnvironment, NativeTracker
from .helpers import table


class Domain:
    def __init__(self, goal, truth=True):
        self.parsed_problem = {'goal_state': goal}
        self._satisfied_subgoals = []
        self._overshot = False
        self.truth = truth
        self.calls = []

    def _check_success(self, inc=False):
        self.calls.append(inc)
        return self.truth

    def _eval_predicate(self, expression):
        return self.truth


def seq(count=3):
    return ['sequence', *[['and', ['on', 'bowl', 'plate']] for _ in range(count)]]


class NativeTests(unittest.TestCase):
    def test_standard_success(self):
        domain = Domain([['on', 'bowl', 'plate']])
        tracker = NativeTracker(domain)
        self.assertTrue(tracker.read()['success'])
        self.assertEqual(tracker.read()['mode'], 'standard_native')
        self.assertFalse(any(domain.calls))

    def test_mem_intermediate_true_is_not_full_success(self):
        goal = seq()
        domain = Domain([goal], truth=True)
        domain._satisfied_subgoals = copy.deepcopy(goal[1:2])
        tracker = NativeTracker(domain)
        self.assertFalse(tracker.read()['success'])
        self.assertEqual(tracker.read()['completed_subgoals'], 1)
        self.assertEqual(domain.calls, [])

    def test_mem_full_sequence_and_final_state_required(self):
        goal = seq()
        domain = Domain([goal])
        domain._satisfied_subgoals = copy.deepcopy(goal[1:])
        tracker = NativeTracker(domain)
        self.assertTrue(tracker.read()['success'])
        domain.truth = False
        self.assertFalse(tracker.read()['success'])

    def test_mem_overshoot_always_fails(self):
        goal = seq()
        domain = Domain([goal])
        domain._satisfied_subgoals = goal[1:]
        domain._overshot = True
        self.assertFalse(NativeTracker(domain).read()['success'])

    def test_counter_advanced_exactly_once_per_action(self):
        domain = Domain([seq()])
        tracker = NativeTracker(domain)
        tracker.after_action(1)
        tracker.read()
        tracker.read()
        tracker.after_action(2)
        self.assertEqual(domain.calls, [True, True])
        with self.assertRaises(ValueError):
            tracker.after_action(2)
        with self.assertRaises(ValueError):
            tracker.after_action(4)

    def test_or_sequences_match_actual_completed_prefix(self):
        first = seq(2)
        other = ['sequence', ['and', ['open', 'cabinet']], ['and', ['close', 'cabinet']]]
        domain = Domain([['or', first, other]])
        domain._satisfied_subgoals = copy.deepcopy(other[1:])
        self.assertTrue(NativeTracker(domain).read()['success'])
        domain._satisfied_subgoals = [first[1], other[2]]
        self.assertFalse(NativeTracker(domain).read()['success'])

    def test_sequence_with_standard_environment_fails_early(self):
        domain = Domain([seq()])
        del domain._overshot
        with self.assertRaises(ValueError):
            NativeTracker(domain)

    def test_mixed_or_goal_rejected_not_silently_reinterpreted(self):
        domain = Domain([['or', seq(2), ['and', ['open', 'cabinet']]]])
        with self.assertRaises(ValueError):
            NativeTracker(domain)

    def test_libero_success_pulse_does_not_end_physical_scene(self):
        environment = LiberoEnvironment(table())
        environment.domain = Domain([['on', 'bowl', 'plate']], truth=True)
        environment.domain.done = False
        environment.native = NativeTracker(environment.domain)
        environment.env = SimpleNamespace(step=lambda action: ({}, 1., True, {}))
        _, result = environment.step([0.] * 7)
        self.assertTrue(result['raw_env_done'])
        self.assertTrue(result['native']['success'])
        self.assertFalse(result['terminated'])

    def test_real_robosuite_termination_is_preserved(self):
        environment = LiberoEnvironment(table())
        environment.domain = Domain([['on', 'bowl', 'plate']], truth=False)
        environment.domain.done = True
        environment.native = NativeTracker(environment.domain)
        environment.env = SimpleNamespace(step=lambda action: ({}, 0., False, {}))
        _, result = environment.step([0.] * 7)
        self.assertFalse(result['raw_env_done'])
        self.assertTrue(result['terminated'])
