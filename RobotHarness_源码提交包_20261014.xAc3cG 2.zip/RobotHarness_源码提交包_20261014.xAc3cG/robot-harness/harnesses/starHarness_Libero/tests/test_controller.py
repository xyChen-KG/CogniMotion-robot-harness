import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from ..controller import Controller
from ..qwen import DeterministicUpdater
from ..storage import EpisodeStore
from .helpers import FakeEnvironment, FakePolicy, NullRecorder, table


class ControllerTests(unittest.TestCase):
    def test_official_final_atomic_goal_is_independent_of_full_task(self):
        task = table(1)
        task['completion_mode'] = 'official_predicates'
        result = self.run_case(task, FakeEnvironment(native_at=None))
        self.assertEqual(result['steps'], 1)
        self.assertTrue(result['all_stages_completed'])
        self.assertTrue(result['workflow_success'])
        self.assertFalse(result['task_success'])
        self.assertFalse(result['success'])

    def test_official_native_success_does_not_require_manual_milestones(self):
        task = table(2)
        task['completion_mode'] = 'official_predicates'
        result = self.run_case(task, FakeEnvironment(goals=lambda s, c: False, native_at=1, terminate_at=1))
        self.assertTrue(result['task_success'])
        self.assertTrue(result['success'])
        self.assertFalse(result['all_stages_completed'])
        self.assertFalse(result['workflow_success'])

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)

    def run_case(self, task=None, env=None, policy=None, updater=None):
        self.task = task or table()
        self.env, self.policy = env or FakeEnvironment(), policy or FakePolicy()
        self.recorder = NullRecorder()
        self.folder = Path(self.temp.name) / 'episode'
        store = EpisodeStore(self.folder, self.task)
        self.controller = Controller(self.task, self.env, self.policy,
                                     updater or DeterministicUpdater(), store, self.recorder)
        return self.controller.run()

    def test_many_stages_one_scene_and_continuous_frames(self):
        for count in (1, 3, 5, 25):
            with self.subTest(count=count):
                self.folder = Path(self.temp.name) / f'episode{count}'
                task, env, policy, recorder = table(count), FakeEnvironment(native_at=count), FakePolicy(), NullRecorder()
                result = Controller(task, env, policy, DeterministicUpdater(),
                                    EpisodeStore(self.folder, task), recorder).run()
                self.assertTrue(result['success'])
                self.assertEqual(result['completed_stage_ids'], list(range(1, count + 1)))
                self.assertEqual(env.resets, 1)
                self.assertEqual(recorder.metadata['frames'], result['steps'] + 1)
                self.assertEqual(policy.closed, 1)

    def test_old_actions_are_discarded_at_transition(self):
        result = self.run_case()
        trace = [json.loads(line) for line in (self.folder / 'controller_trace.jsonl').read_text().splitlines()]
        starts = [row for row in trace if row['event'] == 'stage_start']
        self.assertEqual(starts[1]['policy_boundary']['discarded_actions'], 4)
        self.assertEqual(self.policy.acted, [(1, 0), (2, 1)])
        self.assertTrue(result['success'])

    def test_stage_budget_no_recovery(self):
        task = table(1)
        task['stages'][0]['max_steps'] = 2
        result = self.run_case(task, FakeEnvironment(goals=lambda s, c: False, native_at=None))
        self.assertEqual(result['steps'], 2)
        self.assertEqual(result['termination_reason'], 'stage_step_budget_exhausted')
        self.assertFalse(result['success'])
        self.assertEqual(self.policy.starts, [(1, 0)])

    def test_total_budget(self):
        task = table(1)
        task['budget']['max_steps'] = 2
        result = self.run_case(task, FakeEnvironment(goals=lambda s, c: False, native_at=None))
        self.assertEqual(result['steps'], 2)
        self.assertEqual(result['termination_reason'], 'total_step_budget_exhausted')

    def test_last_stage_does_not_wait_for_full_native_success(self):
        task = table(1)
        result = self.run_case(task, FakeEnvironment(native_at=3))
        self.assertEqual(result['steps'], 1)
        self.assertFalse(result['native_success'])
        self.assertTrue(result['all_stages_completed'])
        self.assertTrue(result['workflow_success'])
        self.assertFalse(result['task_success'])
        self.assertFalse(result['success'])
        self.assertEqual(result['stage_completion_policy'], 'advance_once_live_conditions')

    def test_final_native_success_bypasses_release_without_falsifying_observation(self):
        task = table(2)
        task['stages'][-1]['checker']['all'].append({'predicate': 'released', 'args': ['object_2']})
        def goals(step, item):
            return item['predicate'] == 'on' and step >= int(item['args'][0].split('_')[-1])
        result = self.run_case(task, FakeEnvironment(goals=goals, native_at=2))
        self.assertEqual(result['termination_reason'], 'final_stage_native_success')
        self.assertEqual(result['steps'], 2)
        self.assertEqual(result['completed_stage_ids'], [1, 2])
        self.assertTrue(result['all_stages_completed'])
        self.assertTrue(result['workflow_success'])
        self.assertTrue(result['success'])
        self.assertEqual(self.policy.pending, 0)
        self.assertEqual(self.policy.acted, [(1, 0), (2, 1)])
        self.assertFalse(result['stage_states']['2']['current_satisfied'])
        self.assertTrue(result['stage_states']['2']['achieved_once'])
        self.assertFalse(result['stage_states']['2']['checks'][-1]['completed'])
        receipt = result['final_stage_native_completion']
        self.assertFalse(receipt['stage_checker_completed'])
        self.assertEqual(receipt['step'], 2)
        traces = [json.loads(line) for line in (self.folder / 'controller_trace.jsonl').read_text().splitlines()]
        event = next(row for row in traces if row['event'] == 'final_stage_native_complete')
        self.assertEqual(event['policy_boundary']['discarded_actions'], 4)
        self.assertFalse(event['checker_observation']['checks'][-1]['completed'])

    def test_final_native_success_at_stage_and_global_step_cap_stops_immediately(self):
        task = table(1)
        task['stages'][0]['max_steps'] = task['budget']['max_steps'] = 2
        result = self.run_case(task, FakeEnvironment(goals=lambda s, c: False, native_at=2, terminate_at=2))
        self.assertEqual(result['steps'], 2)
        self.assertEqual(result['termination_reason'], 'final_stage_native_success')
        self.assertTrue(result['all_stages_completed'])
        self.assertTrue(result['success'])

    def test_native_success_can_finish_on_entering_final_stage_without_a_new_action(self):
        result = self.run_case(table(2), FakeEnvironment(
            goals=lambda s, c: c['args'][0] == 'object_1' and s >= 1, native_at=1))
        self.assertEqual(result['steps'], 1)
        self.assertEqual(result['stage_steps']['2'], 0)
        self.assertEqual(result['completed_stage_ids'], [1, 2])
        self.assertTrue(result['workflow_success'])

    def test_past_native_success_is_not_enough_in_final_stage(self):
        class TransientNative(FakeEnvironment):
            def native_status(self):
                return {'success': self.steps == 1}
        task = table(2)
        task['stages'][-1]['max_steps'] = 2
        result = self.run_case(task, TransientNative(goals=lambda s, c:
            c['args'][0] == 'object_1' and s >= 2))
        self.assertTrue(result['native_success_ever'])
        self.assertFalse(result['native_success'])
        self.assertEqual(result['completed_stage_ids'], [1])
        self.assertFalse(result['all_stages_completed'])
        self.assertIsNone(result['final_stage_native_completion'])

    def test_final_native_success_uses_no_updater_call_for_override(self):
        class OnlyFirstStageUpdater(DeterministicUpdater):
            def update(self, task, check):
                if check['stage_id'] == 2:
                    raise AssertionError('Native terminal override needs no model request')
                return super().update(task, check)
        result = self.run_case(table(2), FakeEnvironment(
            goals=lambda s, c: c['args'][0] == 'object_1' and s >= 1, native_at=1),
            updater=OnlyFirstStageUpdater())
        self.assertEqual(result['status'], 'complete')
        self.assertTrue(result['all_stages_completed'])

    def test_previous_goal_loss_does_not_reopen_or_block_later_stages(self):
        def goals(step, item):
            index = int(item['args'][0].split('_')[-1])
            return step == 1 if index == 1 else step >= 2
        result = self.run_case(table(2), FakeEnvironment(goals=goals, native_at=None))
        self.assertEqual(result['steps'], 2)
        self.assertEqual(result['completed_stage_ids'], [1, 2])
        self.assertEqual(self.policy.starts, [(1, 0), (2, 1)])
        self.assertTrue(all(stage['completed'] for stage in self.controller.table['stages']))
        self.assertFalse(self.env.evaluate_condition(self.task['stages'][0]['checker']['all'][0]))
        self.assertTrue(result['workflow_success'])
        self.assertFalse(result['native_success'])
        self.assertFalse(result['task_success'])
        self.assertFalse(result['success'])
        self.assertEqual(result['currently_satisfied_stage_ids'], [2])
        first = result['stage_states']['1']
        self.assertFalse(first['current_satisfied'])
        self.assertTrue(first['achieved_once'])
        self.assertEqual(first['first_achieved_step'], 1)
        self.assertEqual(first['last_checked_step'], 2)
        saved = json.loads((self.folder / 'stage_states.json').read_text())
        self.assertEqual(saved, result['stage_states'])

    def test_never_achieved_stage_cannot_skip_to_an_already_satisfied_future_goal(self):
        task = table(2)
        task['stages'][0]['max_steps'] = 2
        env = FakeEnvironment(goals=lambda step, item: item['args'][0] == 'object_2', native_at=None)
        result = self.run_case(task, env)
        self.assertEqual(result['termination_reason'], 'stage_step_budget_exhausted')
        self.assertEqual(self.policy.starts, [(1, 0)])
        self.assertEqual(result['completed_stage_ids'], [])
        self.assertEqual(result['currently_satisfied_stage_ids'], [2])
        self.assertFalse(result['stage_states']['1']['achieved_once'])
        self.assertFalse(result['stage_states']['2']['achieved_once'])
        self.assertIsNone(result['stage_states']['1']['first_achieved_step'])

    def test_live_goal_can_become_false_and_true_again_without_repeating_stage(self):
        def goals(step, item):
            if item['args'][0] == 'object_1':
                return step == 1 or step >= 3
            return step >= 3
        result = self.run_case(table(2), FakeEnvironment(goals=goals, native_at=None))
        self.assertEqual(result['completed_stage_ids'], [1, 2])
        self.assertEqual([sid for sid, step in self.policy.starts], [1, 2])
        self.assertEqual(result['stage_states']['1']['first_achieved_step'], 1)
        rows = [json.loads(line) for line in (self.folder / 'stage_state_changes.jsonl').read_text().splitlines()]
        rows = [row for row in rows if row['stage_id'] == 1 and row['step'] >= 2]
        self.assertEqual([(row['step'], row['current_satisfied'], row['achieved_once']) for row in rows],
                         [(2, False, True), (3, True, True)])

    def test_success_uses_final_official_outcome_in_both_completion_modes(self):
        for mode in ('stable_conditions', 'official_predicates'):
            with self.subTest(mode=mode):
                task = table(2)
                task['completion_mode'] = mode
                env = FakeEnvironment(goals=lambda step, item: False, native_at=1, terminate_at=1)
                result = Controller(task, env, FakePolicy(), DeterministicUpdater(),
                    EpisodeStore(Path(self.temp.name) / mode, task), NullRecorder()).run()
                self.assertTrue(result['native_success'])
                self.assertTrue(result['task_success'])
                self.assertTrue(result['success'])
                self.assertFalse(result['workflow_success'])
                self.assertEqual(result['completed_stage_ids'], [])
                self.assertEqual(result['success_authority'], 'final_native_success')

    def test_native_early_success_does_not_invent_manual_milestones(self):
        result = self.run_case(table(2), FakeEnvironment(goals=lambda s, c: False, native_at=1, terminate_at=1))
        self.assertTrue(result['native_success'])
        self.assertFalse(result['all_stages_completed'])
        self.assertTrue(result['success'])
        self.assertFalse(result['workflow_success'])
        self.assertEqual(result['steps'], 1)

    def test_interruption_does_not_start_next_stage(self):
        result = self.run_case(table(2), FakeEnvironment(native_at=None, terminate_at=1))
        self.assertEqual(result['completed_stage_ids'], [1])
        self.assertEqual(self.policy.starts, [(1, 0)])
        self.assertFalse(result['success'])

    def test_invalid_action_is_interface_failure_before_motion(self):
        result = self.run_case(policy=FakePolicy([float('nan')] * 7))
        self.assertEqual(result['status'], 'error')
        self.assertEqual(result['steps'], 0)
        self.assertEqual(self.env.closed, 1)
        self.assertEqual(self.recorder.closed, 1)

    def test_vla_cannot_emit_eight_joint_action_values(self):
        result = self.run_case(policy=FakePolicy([0.] * 8))
        self.assertEqual(result['status'], 'error')
        self.assertEqual(result['steps'], 0)

    def test_slow_inference_cannot_move_after_wall_clock_budget(self):
        task = table(1)
        task['budget']['max_wall_seconds'] = 1
        with patch(Controller.__module__ + '.time.monotonic', side_effect=[0., 0., 2., 2.]):
            result = self.run_case(task)
        self.assertEqual(result['termination_reason'], 'wall_clock_budget_exhausted')
        self.assertEqual(result['steps'], 0)
        self.assertFalse(result['success'])

    def test_keyboard_interrupt_saves_result_and_closes_clients(self):
        class InterruptedPolicy(FakePolicy):
            def act(self, observation, step):
                raise KeyboardInterrupt()
        result = self.run_case(policy=InterruptedPolicy())
        self.assertEqual(result['status'], 'error')
        self.assertEqual(result['steps'], 0)
        self.assertEqual(self.policy.closed, 1)
        self.assertEqual(self.env.closed, 1)
        self.assertEqual(json.loads((self.folder / 'result.json').read_text())['status'], 'error')

    def test_wrong_qwen_stage_cannot_mutate_state(self):
        class BadUpdater(DeterministicUpdater):
            def update(self, task, check):
                return {'stage_id': 2, 'completed': True}
        result = self.run_case(updater=BadUpdater())
        self.assertEqual(result['status'], 'error')
        self.assertEqual(result['completed_stage_ids'], [])
        self.assertEqual(result['steps'], 0)

    def test_initial_on_does_not_pass_repeated_lift_events(self):
        task = table(3)
        for stage in task['stages']:
            stage['max_steps'] = 2
            stage['checker']['sequence'] = [{'all': [{'predicate': 'lifted', 'args': ['object_1', .03]}]}]
        result = self.run_case(task, FakeEnvironment(goals=lambda s, c: c['predicate'] == 'on', native_at=0))
        self.assertEqual(result['completed_stage_ids'], [])
        self.assertFalse(result['workflow_success'])
        self.assertTrue(result['success'])  # The independent synthetic native oracle is true.
        self.assertTrue(result['stage_states']['1']['current_satisfied'])
        self.assertFalse(result['stage_states']['1']['achieved_once'])

    def test_cleanup_errors_are_reported(self):
        class BadClose(FakePolicy):
            def close(self):
                raise RuntimeError('simulated close error')
        result = self.run_case(policy=BadClose())
        self.assertEqual(result['status'], 'error')
        self.assertTrue(result['success'])
        self.assertTrue(result['native_success'])
        self.assertFalse(result['workflow_success'])
        self.assertEqual(result['cleanup_errors'][0]['component'], 'policy')

    def test_existing_episode_is_never_overwritten(self):
        self.run_case()
        before = (self.folder / 'result.json').read_bytes()
        with self.assertRaises(FileExistsError):
            EpisodeStore(self.folder, table())
        self.assertEqual((self.folder / 'result.json').read_bytes(), before)

    def test_input_table_remains_immutable(self):
        task = table()
        self.run_case(task)
        self.assertFalse(any(s['completed'] for s in task['stages']))
        saved = json.loads((self.folder / 'task_table_input.json').read_text())
        self.assertEqual(saved, task)
