import contextlib
from collections import deque
import copy
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from ..cli import main
from ..policies import AtomicResidentPolicy, InternResidentPolicy, ServiceLease
from ..qwen import QwenUpdater
from ..storage import EpisodeStore
from .helpers import table


class Opener:
    def __init__(self, responses):
        self.responses, self.bodies = list(responses), []

    def open(self, request, timeout):
        self.bodies.append(json.loads(request.data))
        result = self.responses.pop(0)
        if isinstance(result, BaseException):
            raise result
        return io.BytesIO(json.dumps(result).encode())


def envelope(value, finish='stop'):
    return {'model': 'Qwen3-VL-4B-Instruct', 'choices': [
        {'finish_reason': finish, 'message': {'content': json.dumps(value)}}]}


class InterfaceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.task = table()
        self.store = EpisodeStore(Path(self.temp.name) / 'episode', self.task)
        self.addCleanup(self.store.close)
        self.check = {'stage_id': 1, 'step': 0, 'completed': False}

    def updater(self, responses, max_requests=10):
        updater = QwenUpdater('http://127.0.0.1:18323', self.store, max_requests)
        updater.opener = Opener(responses)
        return updater

    def test_qwen_updates_only_from_simulator_result(self):
        updater = self.updater([envelope({'stage_id': 1, 'completed': False})])
        value = updater.update(self.task, self.check)
        self.assertEqual(value, {'stage_id': 1, 'completed': False})
        self.assertEqual(updater.requests, 1)

    def test_wrong_boolean_one_format_retry(self):
        updater = self.updater([envelope({'stage_id': 1, 'completed': True}),
                                envelope({'stage_id': 1, 'completed': False})])
        self.assertFalse(updater.update(self.task, self.check)['completed'])
        self.assertEqual(updater.requests, 2)

    def test_two_invalid_responses_fail_without_advancing(self):
        updater = self.updater([envelope({'stage_id': 2, 'completed': True})] * 2)
        with self.assertRaises(ValueError):
            updater.update(self.task, self.check)
        self.assertFalse(self.task['stages'][0]['completed'])

    def test_truncation_is_not_accepted(self):
        updater = self.updater([envelope({'stage_id': 1, 'completed': False}, 'length')] * 2)
        with self.assertRaises(ValueError):
            updater.update(self.task, self.check)

    def test_other_model_is_not_accepted_as_qwen(self):
        response = envelope({'stage_id': 1, 'completed': False})
        response['model'] = 'some-other-model'
        updater = self.updater([response, response])
        with self.assertRaises(ValueError):
            updater.update(self.task, self.check)
        self.assertEqual(updater.requests, 2)

    def test_request_budget_includes_corrections(self):
        updater = self.updater([envelope({'stage_id': 1, 'completed': True})], max_requests=1)
        with self.assertRaises(RuntimeError):
            updater.update(self.task, self.check)
        self.assertEqual(updater.requests, 1)

    def test_network_errors_are_not_retried(self):
        updater = self.updater([TimeoutError('synthetic')])
        with self.assertRaises(TimeoutError):
            updater.update(self.task, self.check)
        self.assertEqual(updater.requests, 1)

    def test_long_stage_table_has_bounded_request_context(self):
        task = table(1000)
        for stage in task['stages'][:999]:
            stage['completed'] = True
        updater = self.updater([envelope({'stage_id': 1000, 'completed': False})])
        updater.update(task, {'stage_id': 1000, 'step': 999, 'completed': False})
        context = json.loads(updater.opener.bodies[0]['messages'][1]['content'])
        self.assertEqual(context['stage_count'], 1000)
        self.assertEqual(context['completed_count'], 999)
        self.assertEqual(len(context['recent_completed']), 3)
        self.assertNotIn('task_table', context)

    def test_remote_and_credential_urls_are_rejected(self):
        for url in ('https://example.com', 'http://example.com', 'http://u:p@localhost:80',
                    'http://localhost:80/api', 'http://localhost:80?token=secret'):
            with self.subTest(url=url), self.assertRaises(ValueError):
                QwenUpdater(url, self.store, 10)

    def test_validate_cli_imports_no_model_or_simulator_packages(self):
        source = Path(self.temp.name) / 'table.json'
        source.write_text(json.dumps(table(25)))
        package = __package__.rsplit('.tests', 1)[0]
        root = str(Path(__file__).resolve().parents[len(package.split('.')) + 1])
        code = (f'import sys; from {package}.cli import main; '
                f'main(["validate", "--task-table", {str(source)!r}]); '
                'assert not any(x in sys.modules for x in ("numpy", "torch", "libero", "transformers"))')
        completed = subprocess.run([sys.executable, '-B', '-c', code], cwd=root, capture_output=True, text=True)
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertEqual(json.loads(completed.stdout)['stages'], 25)

    def test_empty_template_rejected_before_output_creation(self):
        template = Path(__file__).resolve().parents[1] / 'task_table.template.json'
        output = Path(self.temp.name) / 'must_not_exist'
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            main(['run', '--task-table', str(template), '--output', str(output), '--policy', 'atomic'])
        self.assertFalse(output.exists())

    def test_service_lease_is_exclusive_and_recoverable(self):
        identity = 'test:' + self.temp.name
        first = ServiceLease(identity)
        try:
            with self.assertRaises(RuntimeError):
                ServiceLease(identity)
        finally:
            first.close()
        second = ServiceLease(identity)
        second.close()

    def test_intern_prompt_manifest_exact_instruction_and_hash(self):
        context = Path(self.temp.name) / 'contexts.pt'
        context.write_bytes(b'fake-test-context-never-loaded-by-a-model')
        manifest = Path(self.temp.name) / 'manifest.json'
        manifest.write_text(json.dumps({'schema_version': 1, 'prompts': [dict(
            instruction='Complete skill 1.', context_file=str(context),
            sha256=hashlib.sha256(context.read_bytes()).hexdigest())]}))
        client = InternResidentPolicy(Path(self.temp.name) / 'policy.sock', manifest, self.store)
        client.validate_instructions(table(1)['stages'])
        with self.assertRaises(ValueError):
            client.validate_instructions(table(2)['stages'])
        context.write_bytes(b'changed')
        with self.assertRaises(ValueError):
            InternResidentPolicy(Path(self.temp.name) / 'policy.sock', manifest, self.store)

    def test_intern_stage_switch_resets_policy_not_scene(self):
        client = InternResidentPolicy.__new__(InternResidentPolicy)
        client.active, client.metadata = True, {'policy_resets': 1}
        client.task = self.task['task']
        client.prompts = {'next': {'context_file': '/fake/context.pt', 'sha256': 'fake'}}
        calls = []
        client.request = lambda item: calls.append(copy.deepcopy(item)) or {}
        result = client.set_stage({'id': 2, 'instruction': 'next'}, {'sensor': 20}, 20)
        self.assertEqual([c['op'] for c in calls], ['end_episode', 'reset'])
        self.assertTrue(result['policy_history_reset'])
        self.assertEqual(client.stage_start, 20)
        self.assertEqual(client.metadata['policy_resets'], 2)

    def test_intern_pauses_session_without_loading_or_resetting_a_model(self):
        client = InternResidentPolicy.__new__(InternResidentPolicy)
        client.active = True
        calls = []
        client.request = lambda value: calls.append(value) or {}
        boundary = client.pause_for_tool({}, 10)
        self.assertEqual(calls, [{'op': 'end_episode'}])
        self.assertFalse(client.active)
        self.assertTrue(boundary['inference_suspended'])

    def test_atomic_pauses_and_discards_stale_actions(self):
        client = AtomicResidentPolicy(18321, self.store)
        client.pending = deque([[1.] * 7, [2.] * 7])
        boundary = client.pause_for_tool({}, 10)
        self.assertEqual(boundary['discarded_actions'], 2)
        self.assertEqual(len(client.pending), 0)
        self.assertTrue(client.episode_start)
