import json
import tempfile
import threading
import time
import unittest
from pathlib import Path

from ..preview import PreviewExporter


class Frame:
    shape = (256, 512, 3)
    def copy(self):
        return Frame()


class PreviewTests(unittest.TestCase):
    def test_latest_only_metadata_matches_image(self):
        entered, release = threading.Event(), threading.Event()
        def encode(frame):
            entered.set()
            release.wait(1)
            return b'\xff\xd8test\xff\xd9'
        with tempfile.TemporaryDirectory() as folder:
            exporter = PreviewExporter(folder, encoder=encode)
            exporter.offer(Frame(), 1, {'stage_id': 1, 'source': 'vla', 'tool': None}, time.time(), force=True)
            self.assertTrue(entered.wait(1))
            for step in range(2, 50):
                exporter.offer(Frame(), step, {'stage_id': 2, 'source': 'tool', 'tool': 'reset'}, 123.0, force=True)
            self.assertEqual(exporter.pending.qsize(), 1)
            release.set()
            stats = exporter.close()
            packet = json.loads((Path(folder) / 'preview.json').read_text())
            self.assertEqual((packet['step'], packet['stage_id'], packet['source'], packet['captured_epoch']), (49, 2, 'tool', 123.0))
            self.assertFalse(stats['worker_alive'])
            self.assertGreater(stats['dropped_preview_frames'], 0)

    def test_encoding_and_copy_failures_do_not_escape(self):
        def fail(frame):
            raise RuntimeError('encoder unavailable')
        with tempfile.TemporaryDirectory() as folder:
            exporter = PreviewExporter(folder, encoder=fail)
            exporter.offer(Frame(), 1, {}, 1, force=True)
            self.assertEqual(exporter.close()['error'], 'RuntimeError')
            self.assertFalse((Path(folder) / 'preview.json').exists())
            exporter = PreviewExporter(folder)
            exporter.offer(object(), 1, {}, 1, force=True)
            self.assertEqual(exporter.close()['error'], 'AttributeError')

    def test_fps_validation_and_throttling(self):
        for fps in (0, -1, 11, float('nan'), float('inf')):
            with self.assertRaises(ValueError):
                PreviewExporter('.', fps)
        with tempfile.TemporaryDirectory() as folder:
            exporter = PreviewExporter(folder, 1, encoder=lambda _: b'\xff\xd8x\xff\xd9')
            for step in range(20):
                exporter.offer(Frame(), step, {}, 1)
            self.assertEqual(exporter.last_offered_step, 0)
            exporter.close()
