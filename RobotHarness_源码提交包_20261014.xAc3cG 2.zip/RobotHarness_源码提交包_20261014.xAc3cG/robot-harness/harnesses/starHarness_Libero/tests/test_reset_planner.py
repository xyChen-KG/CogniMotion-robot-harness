"""Synthetic planning tests and optional CPU-only real MuJoCo isolation tests."""
import importlib.util
import math
import time
from types import SimpleNamespace as NS
import unittest

from ..reset_planner import JointReturnPlanner, checked_edge


class Scene:
    limits = [(-1.5, 1.5)] * 7
    def __init__(self, obstacle=lambda q: {}):
        self.obstacle = obstacle
    def report(self, q):
        return dict(invalid=any(not -1.5 <= x <= 1.5 for x in q), contacts=self.obstacle(q))
    def retreat_candidates(self, q):
        return [[q[0]-.12, *q[1:]]]


class PlannerTests(unittest.TestCase):
    def planner(self, scene, seconds=2.):
        return JointReturnPlanner(scene, deadline=time.monotonic()+seconds, seed=47)

    def test_direct_path_checks_intermediate_configurations(self):
        scene = Scene(lambda q: {(1, 9): .01} if .4 < q[0] < .6 and abs(q[1]) < .15 else {})
        start, goal = [0.] * 7, [1., 0., 0., 0., 0., 0., 0.]
        self.assertFalse(checked_edge(scene, start, goal))
        result = self.planner(scene).plan(start, goal)
        self.assertEqual(result['status'], 'planned', result)
        self.assertEqual(result['algorithm'], 'RRTConnect')
        self.assertEqual(result['path'][0], start)
        self.assertEqual(result['path'][-1], goal)
        self.assertFalse(result['approximate_solution'])
        self.assertTrue(all(checked_edge(scene, a, b) for a, b in zip(result['path'], result['path'][1:])))
        self.assertTrue(any(abs(q[1]) >= .15 for q in result['path']))

    def test_invalid_goal_never_returns_an_approximate_solution(self):
        scene = Scene(lambda q: {(1, 2): .01} if q[0] > .8 else {})
        result = self.planner(scene).plan([0.] * 7, [1.] + [0.] * 6)
        self.assertEqual(result['status'], 'goal_in_collision')
        self.assertEqual(result['path'], [])

    def test_existing_contact_requires_a_monotone_escape(self):
        scene = Scene(lambda q: {(1, 9): q[0]} if q[0] > 0 else {})
        start, goal = [.08] + [0.] * 6, [-.5] + [0.] * 6
        self.assertFalse(checked_edge(scene, start, goal))
        result = self.planner(scene).plan(start, goal)
        self.assertEqual(result['status'], 'planned', result)
        self.assertGreater(result['escape_edges'], 0)
        self.assertTrue(checked_edge(scene, result['path'][0], result['path'][1], escape=True))

    def test_escape_cannot_whitelist_new_contact_pairs(self):
        scene = Scene(lambda q: {(1, 9): .02} if q[0] >= 0 else {(1, 10): .01})
        self.assertFalse(checked_edge(scene, [0.] * 7, [-.1] + [0.] * 6, escape=True))

    def test_expired_deadline_is_timeout_not_proof_of_no_path(self):
        result = self.planner(Scene(), seconds=-1.).plan([0.] * 7, [.5] * 7)
        self.assertEqual(result['status'], 'planning_timeout')
        self.assertEqual(result['path'], [])

    def test_path_can_move_away_from_final_goal_to_get_around_obstacle(self):
        scene = Scene(lambda q: {(1, 9): .01} if .1 < q[0] < .3 and abs(q[1]) < .3 else {})
        result = self.planner(scene).plan([0.] * 7, [.4] + [0.] * 6)
        self.assertEqual(result['status'], 'planned', result)
        self.assertTrue(any(math.dist(b, result['path'][-1]) > math.dist(a, result['path'][-1])
                            for a, b in zip(result['path'], result['path'][1:])))


@unittest.skipUnless(importlib.util.find_spec('mujoco'), 'MuJoCo available only in server sim runtime')
class MujocoSceneTests(unittest.TestCase):
    def test_collision_queries_use_private_data_and_do_not_change_live_state(self):
        import mujoco
        import numpy as np
        from ..collision_scene import MujocoCollisionScene
        # Seven real hinge joints, one movable external obstacle and a control site.
        body = '<body name="arm0" pos="0 0 1"><joint name="j0" axis="0 0 1" range="-1.5 1.5"/>'
        body += '<geom type="sphere" size=".04" pos=".3 0 0" mass="1"/>'
        for i in range(1, 7):
            body += f'<body name="arm{i}"><joint name="j{i}" axis="0 0 1" range="-1.5 1.5"/><inertial pos="0 0 0" mass="1" diaginertia=".1 .1 .1"/>'
        body += '<site name="grip" pos=".3 0 0"/>' + '</body>' * 7
        model = mujoco.MjModel.from_xml_string('<mujoco><compiler angle="radian"/><worldbody>' + body +
            '<body name="obstacle" pos="0 .3 1"><freejoint/><geom type="sphere" size=".06" mass="1"/></body></worldbody></mujoco>')
        live = mujoco.MjData(model)
        mujoco.mj_forward(model, live)
        robot = NS(_ref_joint_pos_indexes=list(range(7)), joint_indexes=list(range(7)),
                   _ref_joint_vel_indexes=list(range(7)),
                   controller=NS(eef_name='grip'))
        wrapped = NS(_model=model, site_name2id=lambda name: mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, name))
        env = NS(domain=NS(sim=NS(model=wrapped, data=NS(_data=live)), robots=[robot]))
        scene = MujocoCollisionScene(env)
        before = live.qpos.copy(), live.qvel.copy(), live.time
        self.assertFalse(scene.report([0.] * 7)['contacts'])
        self.assertTrue(scene.report([math.pi/2-.1] + [0.] * 6)['contacts'])
        np.testing.assert_array_equal(live.qpos, before[0])
        np.testing.assert_array_equal(live.qvel, before[1])
        self.assertEqual(live.time, before[2])
        # A moved object must invalidate the old geometry after refresh.
        live.qpos[7:10] = [.3, 0., 1.]
        scene.refresh()
        self.assertTrue(scene.report([0.] * 7)['contacts'])


if __name__ == '__main__':
    unittest.main()
