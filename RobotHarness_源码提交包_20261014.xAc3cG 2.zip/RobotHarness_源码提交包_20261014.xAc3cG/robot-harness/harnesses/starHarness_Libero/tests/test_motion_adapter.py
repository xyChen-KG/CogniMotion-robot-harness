"""Adapter contracts with stand-ins for MuJoCo arrays; no simulator is imported."""
import sys
from types import ModuleType, SimpleNamespace as NS
import unittest
from unittest.mock import patch

from ..libero_env import LiberoEnvironment
from .helpers import table


class Array:
    def __init__(self, values):
        self.values = values

    def tolist(self):
        return list(self.values)

    def __getitem__(self, key):
        if isinstance(key, list):
            return Array([self.values[i] for i in key])
        return self.values[key]

    def reshape(self, *shape):
        return self


class MotionAdapterTests(unittest.TestCase):
    def setUp(self):
        self.env = LiberoEnvironment(table())
        self.controller = NS(eef_name='actual_control_site', use_ori=True, use_delta=True,
            name_suffix='POSE', control_dim=6, impedance_mode='fixed', input_min=Array([-1.] * 6),
            input_max=Array([1.] * 6), output_min=Array([-.05] * 3 + [-.5] * 3),
            output_max=Array([.05] * 3 + [.5] * 3))
        self.robot = NS(controller=self.controller, eef_site_id=99,
            _ref_gripper_joint_pos_indexes=[0, 1], _ref_joint_pos_indexes=list(range(2, 9)),
            _ref_joint_vel_indexes=list(range(7)), joint_indexes=list(range(7)),
            has_gripper=True, recent_actions=object(), control_freq=20,
            base_pos=[0., 0., 0.], base_ori=[1., 0., 0., 0.], torque_limits=([-87.] * 7, [87.] * 7),
            robot_model=NS(contact_geoms=['arm']), gripper=NS(contact_geoms=['finger'], dof=1))
        self.site_queries = []
        def site(name):
            self.site_queries.append(name)
            return 0
        model = NS(site_name2id=site, geom_name2id={'arm': 1, 'finger': 2}.__getitem__,
                   geom_id2name=lambda index: f'geom_{index}',
                   jnt_range=[Array([-2., 2.]) for _ in range(7)], jnt_limited=[True] * 7)
        self.data = NS(site_xpos=Array([Array([.1, .2, .3])]),
            site_xmat=Array([Array([1., 0., 0., 0., 1., 0., 0., 0., 1.])]),
            qpos=Array([.04, -.04, .5, .6, 0., 0., 0., 0., 0.]), ncon=0, contact=[])
        self.env.domain = NS(robots=[self.robot], sim=NS(model=model, data=self.data),
            action_dim=7, _action_dim=7,
            objects_dict={'bowl': NS(contact_geoms=['bowl'])}, _check_grasp=lambda *args: False)
        self.env.native = NS(read=lambda: {'success': False, 'overshot': False})

    def test_capture_uses_control_site_for_position_and_orientation(self):
        modules = {name: ModuleType(name) for name in
                   ('robosuite', 'robosuite.utils', 'robosuite.utils.transform_utils')}
        matrices = []
        def mat2quat(value):
            matrices.append(value.tolist())
            return Array([0., 0., 0., 1.])
        modules['robosuite.utils.transform_utils'].mat2quat = mat2quat
        with patch.dict(sys.modules, modules):
            state = self.env.end_effector_state()
        self.assertEqual(self.site_queries, ['actual_control_site'])
        self.assertEqual(state['pose']['position'], [.1, .2, .3])
        self.assertEqual(state['pose']['quaternion_xyzw'], [0., 0., 0., 1.])
        self.assertEqual(state['joint_qpos'], [.5, .6, 0., 0., 0., 0., 0.])
        self.assertEqual(len(matrices), 1)

    def test_controller_ranges_are_read_not_guessed(self):
        contract = self.env.motion_contract()
        self.assertEqual(contract['output_max'], [.05] * 3 + [.5] * 3)
        self.controller.use_delta = False
        with self.assertRaises(ValueError):
            self.env.motion_contract()

    def test_external_and_self_contacts_are_reported(self):
        self.data.ncon = 3
        self.data.contact = [NS(geom1=1, geom2=8), NS(geom1=1, geom2=2), NS(geom1=8, geom2=9)]
        safety = self.env.motion_safety()
        self.assertEqual(len(safety['contacts']), 2)
        self.assertTrue(safety['gripper_empty'])
        self.env.domain._check_grasp = lambda *args: True
        self.assertFalse(self.env.motion_safety()['gripper_empty'])

    def controller_modules(self):
        modules = {name: ModuleType(name) for name in ('robosuite', 'robosuite.controllers',
            'robosuite.controllers.joint_pos', 'robosuite.utils', 'robosuite.utils.buffers')}
        class JointController:
            def __init__(self, **kwargs):
                self.kwargs = kwargs
                self.eef_name = kwargs['eef_name']
            def update_base_pose(self, *args):
                pass
            def update(self, **kwargs):
                pass
            def reset_goal(self):
                pass
        modules['robosuite.controllers.joint_pos'].JointPositionController = JointController
        modules['robosuite.utils.buffers'].DeltaBuffer = lambda dim: NS(dim=dim)
        self.refreshes = []
        self.controller.update = lambda **kwargs: self.refreshes.append(kwargs)
        self.controller.reset_goal = lambda: self.refreshes.append('fresh_goal')
        return modules

    def test_joint_contract_is_read_only(self):
        before = self.data.qpos.tolist()
        contract = self.env.joint_reset_contract()
        self.assertEqual(contract['type'], 'JOINT_POSITION')
        self.assertEqual(len(contract['joint_limits_rad']), 7)
        self.assertIs(self.robot.controller, self.controller)
        self.assertEqual(self.data.qpos.tolist(), before)
        self.assertEqual(self.env.domain._action_dim, 7)

    def test_joint_controller_switch_is_scoped_and_restores_on_exception(self):
        original_buffer, before = self.robot.recent_actions, self.data.qpos.tolist()
        modules = self.controller_modules()
        with patch.dict(sys.modules, modules):
            with self.assertRaisesRegex(RuntimeError, 'interrupted'):
                with self.env.joint_reset_control([0.] * 7) as contract:
                    self.assertTrue(self.env.joint_reset_active)
                    self.assertEqual(self.env.domain._action_dim, 8)
                    self.assertEqual(self.robot.recent_actions.dim, 8)
                    self.assertIsNot(self.robot.controller, self.controller)
                    self.assertEqual(self.robot.controller.kwargs['qpos_limits'], [[-2.] * 7, [2.] * 7])
                    with self.assertRaises(RuntimeError):
                        with self.env.joint_reset_control([0.] * 7):
                            pass
                    raise RuntimeError('interrupted')
        self.assertFalse(self.env.joint_reset_active)
        self.assertIs(self.robot.controller, self.controller)
        self.assertIs(self.robot.recent_actions, original_buffer)
        self.assertEqual(self.env.domain._action_dim, 7)
        self.assertEqual(self.data.qpos.tolist(), before)
        self.assertEqual(self.refreshes, [{'force': True}, 'fresh_goal'])

    def test_bad_joint_target_rejected_before_controller_switch(self):
        for target in ([0.] * 6, [float('nan')] * 7, [3.] * 7):
            with self.subTest(target=target), self.assertRaises(ValueError):
                with self.env.joint_reset_control(target):
                    self.fail('Invalid target was accepted')
        self.assertIs(self.robot.controller, self.controller)
        self.assertFalse(self.env.joint_reset_active)

    def test_action_dimension_fails_closed_before_simulation_step(self):
        with self.assertRaises(ValueError):
            self.env.step([0.] * 8)
        self.env._joint_reset_active = True
        with self.assertRaises(ValueError):
            self.env.step([0.] * 7)
