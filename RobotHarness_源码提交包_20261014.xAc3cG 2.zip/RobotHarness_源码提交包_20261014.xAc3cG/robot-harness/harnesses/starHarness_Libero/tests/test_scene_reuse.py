import copy
import tempfile
import unittest
from pathlib import Path

from ..controller import Controller
from ..qwen import DeterministicUpdater
from ..storage import EpisodeStore
from .helpers import FakeEnvironment, FakePolicy, NullRecorder, table


class SceneReuseTests(unittest.TestCase):
    def run_command(self, root, name, task, env, **options):
        return Controller(task, env, FakePolicy(), DeterministicUpdater(),
                          EpisodeStore(Path(root) / name, task), NullRecorder()).run(
                              keep_environment=True, native_final_override=False, **options)

    def test_two_commands_share_one_physical_scene(self):
        with tempfile.TemporaryDirectory() as root:
            env = FakeEnvironment(native_at=0)
            first = table(1)
            a = self.run_command(root, 'a', first, env)
            second = copy.deepcopy(first)
            second['stages'][0]['checker']['all'][0]['args'][0] = 'object_2'
            b = self.run_command(root, 'b', second, env, initial_observation=env.latest_observation)
            self.assertEqual(env.resets, 1)
            self.assertFalse(env.closed)
            self.assertEqual(a['steps'], 1)
            self.assertEqual(b['steps'], 1)
            self.assertEqual(env.steps, 2)
            self.assertTrue(b['all_stages_completed'])

    def test_full_native_goal_cannot_skip_interactive_subgoal(self):
        with tempfile.TemporaryDirectory() as root:
            env = FakeEnvironment(goals=lambda s, c: False, native_at=0)
            task = table(1)
            task['stages'][0]['max_steps'] = 2
            result = self.run_command(root, 'a', task, env)
            self.assertTrue(result['native_success'])
            self.assertFalse(result['all_stages_completed'])
            self.assertEqual(result['steps'], 2)

    def test_compiled_catalog_plan_automatically_transitions_in_retained_scene(self):
        import sys
        sys.path.insert(0,str(Path(__file__).resolve().parents[3]/'services/robot_runner'))
        from scenes import plan_table
        with tempfile.TemporaryDirectory() as root:
            base=table(3)
            env=FakeEnvironment(native_at=None)
            observation=env.reset()
            selected=plan_table(base,[3,1],{})
            policy=FakePolicy()
            result=Controller(selected,env,policy,DeterministicUpdater(),
                EpisodeStore(Path(root)/'planned',selected),NullRecorder()).run(
                initial_observation=observation,keep_environment=True,native_final_override=False)
            self.assertEqual(env.resets,1)
            self.assertFalse(env.closed)
            self.assertEqual(policy.starts,[(1,0),(2,3)])
            self.assertEqual(result['completed_stage_ids'],[1,2])
            self.assertTrue(result['all_stages_completed'])
            self.assertFalse(result['native_success'])

    def test_stop_keeps_scene_and_saves_result(self):
        with tempfile.TemporaryDirectory() as root:
            env = FakeEnvironment(goals=lambda s, c: False, native_at=None)
            result = self.run_command(root, 'a', table(1), env,
                                      stop_requested=lambda: env.steps >= 1)
            self.assertEqual(result['status'], 'stopped')
            self.assertEqual(result['steps'], 1)
            self.assertFalse(env.closed)
            self.assertIsNotNone(env.latest_observation)
