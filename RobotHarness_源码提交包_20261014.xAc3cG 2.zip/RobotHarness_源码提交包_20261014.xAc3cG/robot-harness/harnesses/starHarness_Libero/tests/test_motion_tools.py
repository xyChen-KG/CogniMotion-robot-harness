"""Ideal synthetic kinematics only; these tests do not establish collision safety."""
import copy
import json
import math
from contextlib import contextmanager
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from ..controller import Controller
from ..motion_tools import MotionTools, path_increment, validate_tool_call
from ..pose_math import (errors, joint_action, multiply, norm, osc_action, pose,
                        quaternion, rotation_error, validate_osc)
from ..qwen import DeterministicUpdater
from ..schema import validate_table
from ..storage import EpisodeStore
from .helpers import FakeEnvironment, FakePolicy, NullRecorder, table


class MotionEnvironment(FakeEnvironment):
    def __init__(self, *, frozen=False, held=False, collision_at=None, lost_at=None):
        super().__init__()
        self.position, self.rotation = [0., 0., .3], [0., 0., 0., 1.]
        self.frozen, self.held = frozen, held
        self.collision_at, self.lost_at = collision_at, lost_at
        self.applied = []
        self.joint_reset_active = False
        self.nullspace = 0.
        self.controller_switches = []

    def end_effector_state(self):
        return dict(pose=dict(position=list(self.position), quaternion_xyzw=list(self.rotation)),
                    gripper_qpos=[.04, -.04], joint_qpos=[self.position[0], self.position[1], self.position[2] - .3,
                        *rotation_error(self.rotation, [0., 0., 0., 1.]), self.nullspace])

    def joint_reset_contract(self):
        validate_osc(self.motion_contract())
        return dict(type='JOINT_POSITION', control_delta=True, impedance_mode='fixed',
                    input_min=[-1.] * 7, input_max=[1.] * 7,
                    output_min=[-.05] * 7, output_max=[.05] * 7,
                    joint_limits_rad=[[-3.2, 3.2]] * 7)

    def reset_collision_scene(self, workspace=None):
        class SyntheticFreeScene:
            limits = [(-3.2, 3.2)] * 7
            def refresh(self):
                pass
            def report(self, q):
                return dict(invalid=any(not -3.2 <= x <= 3.2 for x in q), contacts={})
            def retreat_candidates(self, q):
                return []
        return SyntheticFreeScene()  # Explicit ideal geometry; not physical safety evidence.

    @contextmanager
    def joint_reset_control(self, target):
        contract = self.joint_reset_contract()
        self.joint_reset_active = True
        self.controller_switches.append('JOINT_POSITION')
        try:
            yield contract
        finally:
            self.joint_reset_active = False
            self.controller_switches.append('OSC_POSE')

    def motion_contract(self):
        return dict(type='OSC_POSE', control_delta=True, impedance_mode='fixed',
                    input_min=[-1.] * 6, input_max=[1.] * 6,
                    output_min=[-.05] * 3 + [-.5] * 3, output_max=[.05] * 3 + [.5] * 3)

    def motion_safety(self):
        contact = self.collision_at is not None and self.steps >= self.collision_at
        return dict(gripper_empty=not self.held, contacts=[{'synthetic': True}] if contact else [])

    def evaluate_condition(self, item):
        return self.lost_at is None or self.steps < self.lost_at

    def step(self, action):
        self.applied.append(list(action))
        if self.joint_reset_active:
            assert len(action) == 8
            if not self.frozen:
                joints = [q + .05*a for q, a in zip(self.end_effector_state()['joint_qpos'], action[:7])]
                self.position = [joints[0], joints[1], .3 + joints[2]]
                angle = norm(joints[3:6])
                self.rotation = ([x * math.sin(angle / 2) / angle for x in joints[3:6]] + [math.cos(angle / 2)]
                                 if angle > 1e-12 else [0., 0., 0., 1.])
                self.nullspace = joints[6]
            return FakeEnvironment.step(self, action)
        assert len(action) == 7
        if not self.frozen:
            self.position = [p + .05*d for p, d in zip(self.position, action[:3])]
            rotation = [.5*d for d in action[3:6]]
            angle = norm(rotation)
            if angle > 1e-12:
                delta = [x * math.sin(angle / 2) / angle for x in rotation] + [math.cos(angle / 2)]
                self.rotation = quaternion(multiply(delta, self.rotation))
        return super().step(action)


class PoseMathTests(unittest.TestCase):
    def test_path_increment_preserves_planned_direction_under_joint_limits(self):
        delta = path_increment([0.] * 7, [.15, -.07, .004, 0., 0., 0., 0.], [0.] * 7, .02, .005)
        self.assertAlmostEqual(delta[0]/.15, delta[1]/-.07)
        self.assertAlmostEqual(delta[0]/.15, delta[2]/.004)
        self.assertLessEqual(max(map(abs, delta)), .005)

    def test_path_increment_brakes_when_corner_cannot_meet_slew_limit(self):
        delta = path_increment([0.] * 7, [-.1] + [0.] * 6, [.02] + [0.] * 6, .02, .005)
        self.assertAlmostEqual(delta[0], .015)

    def test_joint_action_has_seven_scaled_joints_and_open_gripper(self):
        result = joint_action([.02, -.02, 0., 0., 0., 0., .01], MotionEnvironment().joint_reset_contract())
        self.assertEqual(len(result), 8)
        for value, expected in zip(result, [.4, -.4, 0., 0., 0., 0., .2, -1.]):
            self.assertAlmostEqual(value, expected)
        with self.assertRaises(ValueError):
            joint_action([.1] * 7, MotionEnvironment().joint_reset_contract())
    def test_scaling_matches_current_osc_contract(self):
        action = osc_action([.01, -.01, 0.], [.1, -.1, 0.], MotionEnvironment().motion_contract())
        for value, expected in zip(action, [.2, -.2, 0., .2, -.2, 0., -1.]):
            self.assertAlmostEqual(value, expected)

    def test_quaternion_sign_is_not_a_rotation_difference(self):
        self.assertLess(norm(rotation_error([0., 0., 0., -1.], [0., 0., 0., 1.])), 1e-10)

    def test_rotation_error_is_world_frame_left_multiplication(self):
        current = [math.sin(.4), 0., 0., math.cos(.4)]
        delta = [0., 0., math.sin(.2), math.cos(.2)]
        target = multiply(delta, current)
        error = rotation_error(target, current)
        self.assertAlmostEqual(error[0], 0.)
        self.assertAlmostEqual(error[1], 0.)
        self.assertAlmostEqual(error[2], .4)

    def test_shortest_rotation_wrap(self):
        current = [0., 0., math.sin(math.radians(179) / 2), math.cos(math.radians(179) / 2)]
        target = [0., 0., math.sin(math.radians(-179) / 2), math.cos(math.radians(-179) / 2)]
        self.assertAlmostEqual(math.degrees(norm(rotation_error(target, current))), 2.)

    def test_bad_pose_rejected(self):
        for value in ({}, {'position': [0., 0., .3], 'quaternion_xyzw': [0.] * 4},
                      {'position': [float('nan'), 0., .3], 'quaternion_xyzw': [0., 0., 0., 1.]},
                      {'position': [True, 0., .3], 'quaternion_xyzw': [0., 0., 0., 1.]}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                pose(value)


class MotionToolsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store = EpisodeStore(Path(self.temp.name) / 'tools', table())
        self.addCleanup(self.store.close)

    def tools(self, env=None):
        self.env = env or MotionEnvironment()
        self.metadata = []
        def step(action, metadata):
            self.metadata.append(metadata)
            self.env.step(action)
        return MotionTools(self.env, step, lambda: self.env.steps, self.store)

    def test_stage_capture_is_immutable_and_only_once(self):
        tools = self.tools()
        record = tools.record_stage_start(1)
        record['state']['pose']['position'][0] = 99.
        self.env.position[0] = .2
        self.assertEqual(tools.stage_starts[1]['state']['pose']['position'][0], 0.)
        with self.assertRaises(ValueError):
            tools.record_stage_start(1)
        self.assertEqual(self.env.steps, 0)

    def test_reset_requires_a_real_captured_start(self):
        tools = self.tools()
        with self.assertRaises(ValueError):
            tools.reset_to_stage_start(1)
        self.assertEqual(self.env.steps, 0)

    def test_reset_uses_physical_actions_and_restores_pose(self):
        tools = self.tools()
        captured = tools.record_stage_start(1)['state']['pose']
        self.env.position = [.15, .1, .3]
        self.env.rotation = [0., 0., math.sin(.4), math.cos(.4)]
        result = tools.reset_to_stage_start(1, max_steps=200)
        dp, dr = errors(captured, self.env.end_effector_state()['pose'])
        self.assertEqual(result['status'], 'reached')
        self.assertLessEqual(norm(dp), .01)
        self.assertLessEqual(math.degrees(norm(dr)), 5.)
        self.assertEqual(result['steps'], len(self.env.applied))
        self.assertEqual(self.env.resets, 0)
        phases = {row['phase'] for row in self.metadata}
        self.assertEqual(phases, {'joint_return'})
        self.assertTrue(result['restored_joint_configuration'])
        self.assertTrue(result['controller_restored'])
        self.assertEqual(self.env.controller_switches, ['JOINT_POSITION', 'OSC_POSE'])
        self.assertTrue(all(len(action) == 8 for action in self.env.applied))
        self.assertTrue(all(row['action_space'] == 'JOINT_POSITION' for row in self.metadata))
        self.assertTrue(all(max(map(abs, row['joint_delta_rad'])) <= .02 for row in self.metadata))
        self.assertTrue(all(action[-1] == -1. for action in self.env.applied))

    def test_same_end_effector_pose_does_not_skip_different_joint_configuration(self):
        tools = self.tools()
        tools.record_stage_start(1)
        self.env.nullspace = .5
        with patch.object(tools, 'move_to', side_effect=AssertionError('Reset must not delegate to OSC')):
            result = tools.reset_to_stage_start(1, max_steps=100)
        self.assertEqual(result['status'], 'reached')
        self.assertLessEqual(result['max_joint_error_deg'], 1.)
        self.assertGreater(result['steps'], 5)

    def test_missing_joint_capture_is_rejected_not_fallback_to_pose(self):
        tools = self.tools()
        tools.record_stage_start(1)
        del tools.stage_starts[1]['state']['joint_qpos']
        with self.assertRaises(ValueError):
            tools.reset_to_stage_start(1)
        self.assertEqual(self.env.steps, 0)

    def test_stage_joint_capture_is_immutable(self):
        tools = self.tools()
        record = tools.record_stage_start(1)
        record['state']['joint_qpos'][6] = 99.
        self.env.nullspace = .5
        result = tools.reset_to_stage_start(1)
        self.assertEqual(result['target_joint_qpos'][6], 0.)
        self.assertEqual(result['status'], 'reached')

    def test_matching_joints_without_matching_pose_cannot_pass(self):
        tools = self.tools()
        tools.record_stage_start(1)
        # Stand-in for a corrupted pose capture; joint success cannot hide it.
        tools.stage_starts[1]['state']['pose']['position'][0] = .2
        result = tools.reset_to_stage_start(1, stall_steps=3)
        self.assertEqual(result['status'], 'no_progress')
        self.assertTrue(result['restored_joint_configuration'])
        self.assertGreater(result['position_error_m'], .01)

    def test_controller_restored_after_step_exception(self):
        tools = self.tools()
        tools.record_stage_start(1)
        def fail(*args):
            raise RuntimeError('synthetic step failure')
        tools.step_action = fail
        with self.assertRaises(RuntimeError):
            tools.reset_to_stage_start(1)
        self.assertFalse(self.env.joint_reset_active)
        self.assertTrue(tools.results[-1]['controller_restored'])
        self.assertEqual(tools.results[-1]['status'], 'error')

    def test_already_at_target_still_requires_fresh_stable_actions(self):
        tools = self.tools()
        tools.record_stage_start(1)
        result = tools.reset_to_stage_start(1)
        self.assertEqual(result['status'], 'reached')
        self.assertEqual(result['steps'], 5)

    def test_absolute_move_to_is_a_separate_callable_tool(self):
        tools = self.tools()
        target = dict(position=[.1, .05, .32], quaternion_xyzw=[0., 0., 0., 1.])
        result = tools.move_to(target, stage_id=1)
        self.assertEqual(result['tool'], 'move_to')
        self.assertEqual(result['status'], 'reached')
        self.assertLessEqual(result['position_error_m'], .01)

    def test_holding_object_never_opens_gripper_and_drops_it(self):
        tools = self.tools(MotionEnvironment(held=True))
        tools.record_stage_start(1)
        result = tools.reset_to_stage_start(1)
        self.assertEqual(result['status'], 'empty_gripper_required')
        self.assertEqual(self.env.applied, [])

    def test_contact_before_motion_is_logged_but_does_not_block(self):
        tools = self.tools(MotionEnvironment(collision_at=0))
        tools.record_stage_start(1)
        result = tools.reset_to_stage_start(1)
        self.assertEqual(result['status'], 'reached')
        self.assertFalse(result['contact_stop_enabled'])
        self.assertEqual(self.env.steps, 5)
        rows = [json.loads(line) for line in (self.store.path / 'motion_progress.jsonl').read_text().splitlines()]
        self.assertTrue(all(row['safety']['contacts'] for row in rows))

    def test_contact_during_joint_return_does_not_stop_motion(self):
        tools = self.tools(MotionEnvironment(collision_at=2))
        tools.record_stage_start(1)
        self.env.position[0] = .2
        result = tools.reset_to_stage_start(1)
        self.assertEqual(result['status'], 'reached')
        self.assertGreater(self.env.steps, 2)
        rows = [json.loads(line) for line in (self.store.path / 'motion_progress.jsonl').read_text().splitlines()]
        self.assertTrue(any(row['safety']['contacts'] for row in rows))
        self.assertTrue(result['controller_restored'])

    def test_contact_during_move_to_does_not_stop_motion(self):
        tools = self.tools(MotionEnvironment(collision_at=2))
        result = tools.move_to(dict(position=[.1, .05, .32], quaternion_xyzw=[0., 0., 0., 1.]), stage_id=1)
        self.assertEqual(result['status'], 'reached')
        self.assertFalse(result['contact_stop_enabled'])
        self.assertGreater(self.env.steps, 2)
        rows = [json.loads(line) for line in (self.store.path / 'motion_progress.jsonl').read_text().splitlines()]
        self.assertTrue(any(row['safety']['contacts'] for row in rows))

    def test_completed_goal_loss_with_contact_does_not_stop_return(self):
        tools = self.tools(MotionEnvironment(collision_at=0, lost_at=2))
        tools.record_stage_start(1)
        self.env.position[0] = .2
        result = tools.call({'tool': 'reset_to_stage_start'}, table()['stages'][0])
        self.assertEqual(result['status'], 'reached')
        self.assertGreater(self.env.steps, 2)
        self.assertEqual(result['preserve'], [])
        rows = [json.loads(line) for line in (self.store.path / 'motion_progress.jsonl').read_text().splitlines()]
        self.assertTrue(all(row['safety']['contacts'] for row in rows))

    def test_empty_preserve_does_not_add_completed_goal_protection(self):
        tools = self.tools(MotionEnvironment(lost_at=2))
        tools.record_stage_start(1)
        self.env.position[0] = .2
        result = tools.call({'tool': 'reset_to_stage_start', 'preserve': []}, table()['stages'][0])
        self.assertEqual(result['status'], 'reached')
        self.assertGreater(self.env.steps, 2)
        self.assertEqual(result['preserve'], [])

    def test_explicit_preserve_remains_an_opt_in_tool_constraint(self):
        tools = self.tools(MotionEnvironment(collision_at=0, lost_at=2))
        tools.record_stage_start(1)
        self.env.position[0] = .2
        stage = table()['stages'][0]
        result = tools.call({'tool': 'reset_to_stage_start', 'preserve': stage['checker']['all']}, stage)
        self.assertEqual(result['status'], 'protected_condition_lost')
        self.assertEqual(self.env.steps, 2)
        self.assertTrue(result['safety']['contacts'])

    def test_move_to_does_not_implicitly_protect_a_completed_goal(self):
        tools = self.tools(MotionEnvironment(lost_at=2))
        result = tools.call({'tool': 'move_to',
            'target_pose': dict(position=[.1, .05, .32], quaternion_xyzw=[0., 0., 0., 1.])},
            table()['stages'][0])
        self.assertEqual(result['status'], 'reached')
        self.assertGreater(self.env.steps, 2)
        self.assertEqual(result['preserve'], [])

    def test_stalled_motion_is_bounded(self):
        tools = self.tools(MotionEnvironment(frozen=True))
        tools.record_stage_start(1)
        self.env.position[0] = .2
        result = tools.reset_to_stage_start(1, stall_steps=3)
        self.assertEqual(result['status'], 'no_progress')
        self.assertLessEqual(self.env.steps, 12)
        self.assertEqual(result['replans'], 2)
        self.assertEqual(len(result['planning_attempts']), 3)

    def test_tool_step_budget(self):
        tools = self.tools()
        tools.record_stage_start(1)
        self.env.position[0] = .2
        result = tools.reset_to_stage_start(1, max_steps=2)
        self.assertEqual(result['status'], 'tool_step_budget_exhausted')
        self.assertEqual(self.env.steps, 2)

    def test_planning_time_is_shared_across_replans_not_ten_seconds_each(self):
        tools = self.tools(MotionEnvironment(frozen=True))
        tools.record_stage_start(1)
        self.env.position[0] = .2
        clock = [0.]
        deadlines = []
        class SlowPlanner:
            def __init__(self, scene, *, deadline, **kwargs):
                self.deadline = deadline
                deadlines.append(deadline-clock[0])
            def plan(self, current, target):
                remaining = self.deadline-clock[0]
                clock[0] += min(4., remaining)
                return dict(status='planned' if remaining >= 4. else 'planning_timeout',
                    path=[current, target] if remaining >= 4. else [], escape_edges=0)
        with patch('time.monotonic', side_effect=lambda: clock[0]), patch(
                MotionTools.__module__ + '.JointReturnPlanner', SlowPlanner):
            result = tools.reset_to_stage_start(1, stall_steps=2)
        self.assertEqual(result['status'], 'planning_timeout')
        self.assertEqual(deadlines, [10., 6., 2.])
        self.assertEqual(result['planning_seconds'], 10.)
        self.assertLessEqual(result['replans'], 2)
        self.assertTrue(result['controller_restored'])

    def test_detour_progress_does_not_require_approaching_final_home(self):
        tools = self.tools()
        tools.record_stage_start(1)
        self.env.position[0] = .2
        class DetourPlanner:
            def __init__(self, *args, **kwargs):
                pass
            def plan(self, current, target):
                return dict(status='planned', path=[current, [.4, .2, 0., 0., 0., 0., 0.], target], escape_edges=0)
        with patch(MotionTools.__module__ + '.JointReturnPlanner', DetourPlanner):
            result = tools.reset_to_stage_start(1, stall_steps=3, max_steps=200)
        self.assertEqual(result['status'], 'reached', result)
        self.assertEqual(result['replans'], 0)
        self.assertGreater(max(action[0] for action in self.env.applied), 0.)

    def test_workspace_checks_waypoints_before_motion(self):
        tools = self.tools()
        result = tools.move_to(dict(position=[.2, 0., .3], quaternion_xyzw=[0., 0., 0., 1.]),
            stage_id=1, workspace={'min': [-1., -1., .1], 'max': [1., 1., .35]})
        self.assertEqual(result['status'], 'outside_workspace')
        self.assertEqual(self.env.steps, 0)

    def test_joint_return_checks_initial_and_target_workspace(self):
        tools = self.tools()
        tools.record_stage_start(1)
        self.env.position[0] = .2
        result = tools.reset_to_stage_start(1, workspace={'min': [-.1, -.1, .1], 'max': [.1, .1, .5]})
        self.assertEqual(result['status'], 'outside_workspace')
        self.assertEqual(self.env.steps, 0)

    def test_changed_controller_rejected_before_actions(self):
        tools = self.tools()
        tools.record_stage_start(1)
        self.env.motion_contract = lambda: {'type': 'JOINT_POSITION'}
        with self.assertRaises(ValueError):
            tools.reset_to_stage_start(1)
        self.assertEqual(self.env.steps, 0)

    def test_schema_accepts_optional_tools_and_rejects_bad_calls(self):
        task = table()
        task['stages'][0]['post_tools'] = [{'tool': 'reset_to_stage_start', 'max_steps': 100}]
        validate_table(task)
        for call in ({'tool': 'reset_to_stage_start', 'target_pose': {}},
                     {'tool': 'move_to'}, {'tool': 'teleport'},
                     {'tool': 'reset_to_stage_start', 'max_steps': True},
                     {'tool': 'reset_to_stage_start', 'max_translation_m': .5},
                     {'tool': 'reset_to_stage_start', 'max_joint_step_rad': .1},
                     {'tool': 'reset_to_stage_start', 'joint_tolerance_deg': 10},
                     {'tool': 'reset_to_stage_start', 'max_steps': 1001},
                     {'tool': 'reset_to_stage_start', 'planning_timeout_seconds': 11},
                     {'tool': 'reset_to_stage_start', 'max_replans': 3},
                     {'tool': 'reset_to_stage_start', 'max_replans': True},
                     {'tool': 'reset_to_stage_start', 'collision_resolution_rad': .02},
                     {'tool': 'move_to', 'target_pose': {'position': [0., 0., .3], 'quaternion_xyzw': [0., 0., 0., 1.]}, 'max_joint_step_rad': .02},
                     {'tool': 'reset_to_stage_start', 'skip_collision_check': True}):
            with self.subTest(call=call), self.assertRaises(ValueError):
                validate_tool_call(call)

    def test_tool_preserve_aliases_are_validated(self):
        task = table()
        task['stages'][0]['post_tools'] = [{'tool': 'reset_to_stage_start',
            'preserve': [{'predicate': 'on', 'args': ['@missing', 'target']}]}]
        with self.assertRaises(ValueError):
            validate_table(task)


class MotionIntegrationTests(unittest.TestCase):
    def test_official_final_native_success_skips_a_would_fail_post_reset(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        task = table(1)
        task['completion_mode'] = 'official_predicates'
        task['stages'][0]['post_tools'] = [{'tool': 'reset_to_stage_start'}]
        env = MotionEnvironment(held=True)
        env.native_at = 0
        result = Controller(task, env, FakePolicy([.4, 0., 0., 0., 0., 0., -1.]),
                            DeterministicUpdater(), EpisodeStore(Path(temp.name) / 'episode', task),
                            NullRecorder()).run()
        self.assertTrue(result['native_success'])
        self.assertTrue(result['task_success'])
        self.assertTrue(result['success'])
        self.assertTrue(result['post_tools_success'])
        self.assertTrue(result['workflow_success'])
        self.assertEqual(result['termination_reason'], 'final_stage_native_success')
        self.assertEqual(result['steps'], 0)
        self.assertEqual(result['tool_results'], [])
        self.assertEqual(env.controller_switches, [])

    def run_case(self, *, maximum=200, env=None, count=2):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.folder = Path(temp.name) / 'episode'
        task = table(count)
        task['budget']['max_steps'] = maximum
        task['stages'][0]['post_tools'] = [{'tool': 'reset_to_stage_start'}]
        self.env = env or MotionEnvironment()
        self.policy, self.recorder = FakePolicy([.4, 0., 0., 0., 0., 0., -1.]), NullRecorder()
        return Controller(task, self.env, self.policy, DeterministicUpdater(),
                          EpisodeStore(self.folder, task), self.recorder).run()

    def test_continuous_scene_shared_budget_and_new_stage_capture(self):
        env = MotionEnvironment()
        env.native_at = None  # Exercise both stages, without the native terminal override.
        result = self.run_case(env=env)
        self.assertTrue(result['workflow_success'], result)
        self.assertEqual(result['vla_steps'], 2)
        self.assertGreaterEqual(result['tool_steps'], 5)
        self.assertEqual(result['steps'], result['vla_steps'] + result['tool_steps'])
        self.assertEqual(self.env.resets, 1)
        self.assertEqual(self.recorder.metadata['frames'], result['steps'] + 1)
        self.assertEqual(len(self.policy.observed), 2)
        self.assertEqual(len(self.policy.acted), 2)
        starts = json.loads((self.folder / 'stage_starts.json').read_text())
        self.assertEqual([row['stage_id'] for row in starts], [1, 2])
        self.assertEqual(starts[0]['step'], 0)
        self.assertEqual(starts[1]['step'], result['tool_steps'] + 1)
        self.assertLessEqual(norm(starts[1]['state']['pose']['position'][:2]), .01)
        actions = [json.loads(line) for line in (self.folder / 'actions.jsonl').read_text().splitlines()]
        self.assertEqual(sum(row['source'] == 'tool' for row in actions), result['tool_steps'])
        self.assertEqual([row['step'] for row in actions], list(range(1, result['steps'] + 1)))
        self.assertTrue(all(len(row['action']) == (8 if row['source'] == 'tool' else 7) for row in actions))
        self.assertFalse(self.env.joint_reset_active)

    def test_failed_return_starts_next_stage_without_claiming_reset_success(self):
        result = self.run_case(env=MotionEnvironment(held=True))
        self.assertEqual(result['termination_reason'], 'final_stage_native_success')
        self.assertFalse(result['post_tools_success'])
        self.assertFalse(result['workflow_success'])
        self.assertTrue(result['success'])
        self.assertEqual(self.policy.starts, [(1, 0), (2, 1)])
        self.assertEqual(result['tool_steps'], 0)
        self.assertTrue(result['post_tool_failures'][0]['continued'])

    def test_failed_return_then_never_successful_next_stage_stops_before_third(self):
        class SecondStageFails(MotionEnvironment):
            def evaluate_condition(self, item):
                return item['args'][0] == 'object_1' and self.steps >= 1
        result = self.run_case(env=SecondStageFails(held=True), count=3)
        self.assertEqual(result['termination_reason'], 'stage_step_budget_exhausted')
        self.assertEqual(result['completed_stage_ids'], [1])
        self.assertEqual([sid for sid, _ in self.policy.starts], [1, 2])
        self.assertFalse(result['stage_states']['2']['achieved_once'])

    def test_failure_flag_is_not_erased_by_later_successful_reset(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        task, env = table(3), MotionEnvironment(held=True)
        env.native_at = None  # Keep the third reset exercised for this sticky-flag test.
        task['budget']['max_steps'] = 200
        for stage in task['stages']:
            stage['post_tools'] = [{'tool': 'reset_to_stage_start'}]
        original = env.motion_safety
        def safety():
            env.held = env.steps < 2
            return original()
        env.motion_safety = safety
        result = Controller(task, env, FakePolicy(), DeterministicUpdater(),
            EpisodeStore(Path(temp.name) / 'episode', task), NullRecorder()).run()
        self.assertEqual(result['completed_stage_ids'], [1, 2, 3])
        self.assertEqual([r['status'] for r in result['tool_results']], ['empty_gripper_required', 'reached', 'reached'])
        self.assertFalse(result['post_tools_success'])
        self.assertFalse(result['workflow_success'])

    def test_reset_interface_error_is_fatal_not_an_ordinary_warning(self):
        env = MotionEnvironment()
        env.reset_collision_scene = lambda *args: (_ for _ in ()).throw(RuntimeError('synthetic interface failure'))
        result = self.run_case(env=env)
        self.assertEqual(result['status'], 'error')
        self.assertEqual(result['termination_reason'], 'interface_or_runtime_error')
        self.assertFalse(result['post_tools_success'])
        self.assertEqual([sid for sid, _ in self.policy.starts], [1])
        self.assertFalse(env.joint_reset_active)

    def test_goal_lost_during_reset_is_latched_and_next_stage_runs(self):
        class GoalLostDuringReset(MotionEnvironment):
            def __init__(self):
                super().__init__(collision_at=2)
                self.native_at = None

            def evaluate_condition(self, item):
                if item['args'][0] == 'object_1':
                    return self.steps < 2
                return self.steps >= 2

        result = self.run_case(env=GoalLostDuringReset())
        self.assertEqual(result['termination_reason'], 'all_stages_complete')
        self.assertEqual(result['completed_stage_ids'], [1, 2])
        self.assertEqual([sid for sid, step in self.policy.starts], [1, 2])
        self.assertTrue(result['post_tools_success'])
        self.assertTrue(result['workflow_success'])
        self.assertEqual(result['tool_results'][0]['preserve'], [])
        self.assertFalse(result['native_success'])
        self.assertFalse(result['task_success'])
        self.assertFalse(result['success'])
        self.assertFalse(result['stage_states']['1']['current_satisfied'])
        self.assertTrue(result['stage_states']['1']['achieved_once'])
        self.assertEqual(result['stage_states']['1']['first_achieved_step'], 1)
        rows = [json.loads(line) for line in (self.folder / 'stage_state_changes.jsonl').read_text().splitlines()]
        loss = next(row for row in rows if row['stage_id'] == 1 and row['step'] == 2)
        self.assertFalse(loss['current_satisfied'])
        self.assertTrue(loss['achieved_once'])

    def test_final_native_success_does_not_execute_invalidating_post_tools(self):
        class NativeSuccessLost(MotionEnvironment):
            def native_status(self):
                return {'success': self.steps == 1}

        result = self.run_case(env=NativeSuccessLost(), count=1)
        self.assertTrue(result['all_stages_completed'])
        self.assertTrue(result['post_tools_success'])
        self.assertTrue(result['workflow_success'])
        self.assertTrue(result['native_success_ever'])
        self.assertTrue(result['native_success'])
        self.assertTrue(result['task_success'])
        self.assertTrue(result['success'])
        self.assertEqual(result['steps'], 1)
        self.assertEqual(result['tool_steps'], 0)
        self.assertEqual(result['tool_results'], [])

    def test_contact_only_does_not_prevent_next_stage(self):
        result = self.run_case(env=MotionEnvironment(collision_at=1))
        self.assertTrue(result['success'], result)
        self.assertTrue(result['post_tools_success'])
        self.assertEqual(result['completed_stage_ids'], [1, 2])
        self.assertEqual([sid for sid, step in self.policy.starts], [1, 2])
        self.assertFalse(result['tool_results'][0]['contact_stop_enabled'])

    def test_return_cannot_bypass_global_step_budget(self):
        result = self.run_case(maximum=2)
        self.assertEqual(result['steps'], 2)
        self.assertEqual(result['tool_steps'], 1)
        self.assertEqual(result['stage_steps']['1'], 1)
        self.assertEqual(result['termination_reason'], 'post_tool_total_step_budget_exhausted')
        self.assertFalse(result['workflow_success'])
        self.assertTrue(result['success'])  # Native task true is independent of a tool budget stop.
        self.assertEqual(len(self.policy.starts), 1)

    def test_return_cannot_bypass_wall_clock_budget(self):
        env = MotionEnvironment()
        with patch(Controller.__module__ + '.time.monotonic', side_effect=lambda: 100. if env.steps >= 2 else 0.):
            result = self.run_case(env=env)
        self.assertEqual(result['termination_reason'], 'post_tool_wall_clock_budget_exhausted')
        self.assertEqual(result['steps'], 2)
        self.assertEqual(result['tool_steps'], 1)
        self.assertEqual(len(self.policy.starts), 1)

    def test_final_stage_tool_failure_is_not_reported_as_success(self):
        result = self.run_case(env=MotionEnvironment(held=True), count=1)
        self.assertTrue(result['all_stages_completed'])
        self.assertFalse(result['post_tools_success'])
        self.assertFalse(result['success'])

    def test_no_tools_preserves_old_behavior(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        task = table()
        result = Controller(task, FakeEnvironment(), FakePolicy(), DeterministicUpdater(),
            EpisodeStore(Path(temp.name) / 'episode', task), NullRecorder()).run()
        self.assertEqual(result['steps'], 2)
        self.assertEqual(result['tool_steps'], 0)
        self.assertEqual(result['tool_results'], [])
        self.assertTrue(result['success'])
