"""Replay saved actions to a reset boundary, then exercise ONLY the new reset.

No policy/model calls. A new diagnostic scene/output; original artifacts immutable.
This is not a fresh VLA rollout and must not count as a task success evaluation.
"""
import argparse
from contextlib import ExitStack
import importlib.util
import json
from pathlib import Path
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--task-leaf', required=True)
    parser.add_argument('--episode', required=True)
    parser.add_argument('--boundary-step', type=int, required=True)
    parser.add_argument('--stage-id', type=int, required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--render-gpu', type=int, default=1)
    args = parser.parse_args()
    import numpy as np
    from starHarness_Libero.libero_env import LiberoEnvironment
    from starHarness_Libero.motion_tools import MotionTools
    from starHarness_Libero.recording import VideoRecorder
    from starHarness_Libero.schema import load_table
    from starHarness_Libero.storage import EpisodeStore
    leaf, episode = Path(args.task_leaf), Path(args.episode)
    table = load_table(leaf / 'stage_table.json')
    spec = importlib.util.spec_from_file_location('replay_custom_suite', leaf / 'task.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.register_suite()
    store = EpisodeStore(args.output, table)
    recorder = VideoRecorder(store.path)
    env = LiberoEnvironment(table, render_gpu=args.render_gpu, image_size=256)
    report = dict(kind='reset_replay_diagnostic', paid_api_requests=0, model_calls=0,
                  vla_performance_evaluation=False, boundary_step=args.boundary_step)
    began = time.monotonic()
    try:
        obs = env.reset()
        np.testing.assert_allclose(env.env.get_sim_state(), np.load(episode / 'initial_sim_state.npy'), atol=1e-8, rtol=0.)
        old_tools = json.loads((episode / 'tool_results.json').read_text())
        targets = {row['call_id']: row['target_joint_qpos'] for row in old_tools}
        rows = [json.loads(line) for line in (episode / 'actions.jsonl').read_text().splitlines()]
        if len(rows) < args.boundary_step or rows[args.boundary_step-1]['step'] != args.boundary_step:
            raise ValueError('Replay boundary is not present in source action log')
        active, group = ExitStack(), None
        try:
            for row in rows[:args.boundary_step]:
                key = row.get('call_id') if row.get('action_space') == 'JOINT_POSITION' else None
                if key != group:
                    active.close()
                    if key is not None:
                        active.enter_context(env.joint_reset_control(targets[key]))
                    group = key
                obs, _ = env.step(row['action'])
                if env.steps % 250 == 0:
                    print('REPLAY', env.steps, flush=True)
        finally:
            active.close()
        env.snapshot(store.path / 'boundary_sim_state.npy')
        report['boundary_conditions'] = [env.evaluate_condition(c) for c in table['stages'][args.stage_id-1]['checker']['all']]
        recorder.capture(obs, 0)
        start = env.steps
        def step(action, metadata):
            observation, detail = env.step(action)
            store.log('actions', dict(step=env.steps, action=action, **metadata))
            recorder.capture(observation, env.steps-start)
            if detail['terminated']:
                from starHarness_Libero.motion_tools import MotionStopped
                raise MotionStopped('environment_terminated')
        tools = MotionTools(env, step, lambda: env.steps, store)
        starts = json.loads((episode / 'stage_starts.json').read_text())
        tools.stage_starts[args.stage_id] = next(row for row in starts if row['stage_id'] == args.stage_id)
        stage = table['stages'][args.stage_id-1]
        reset = tools.call(stage['post_tools'][0], stage)
        report.update(reset=reset, final_conditions=[env.evaluate_condition(c) for c in stage['checker']['all']],
                      native_success=env.native_status()['success'], elapsed_seconds=time.monotonic()-began)
        env.snapshot(store.path / 'final_sim_state.npy')
        print(json.dumps(report), flush=True)
    finally:
        recorder.close()
        env.close()
        store.snapshot('diagnostic_result', report)
        store.close()


if __name__ == '__main__':
    main()
