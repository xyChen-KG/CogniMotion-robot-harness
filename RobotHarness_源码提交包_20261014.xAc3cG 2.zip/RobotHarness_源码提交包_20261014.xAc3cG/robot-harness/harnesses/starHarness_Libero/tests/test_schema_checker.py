import copy
import unittest

from ..checker import StageChecker
from ..schema import active_stage, apply_update, validate_table
from .helpers import FakeEnvironment, table


class SchemaTests(unittest.TestCase):
    def test_official_mode_rejects_extra_success_thresholds(self):
        for change in ('stability', 'release', 'sequence'):
            task = table(1)
            task['completion_mode'] = 'official_predicates'
            if change == 'stability':
                task['stable_steps'] = 10
            elif change == 'release':
                task['stages'][0]['checker']['all'].append({'predicate': 'released', 'args': ['object_1']})
            else:
                task['stages'][0]['checker']['sequence'] = [{'all': [{'predicate': 'on', 'args': ['object_1', 'target']}]}]
            with self.subTest(change=change), self.assertRaises(ValueError):
                validate_table(task)

    def test_official_mode_accepts_native_relations_and_preserves_tool_options(self):
        task = table(5)
        task['completion_mode'] = 'official_predicates'
        task['stages'][0]['post_tools'] = [{'tool': 'reset_to_stage_start', 'stable_steps': 5}]
        self.assertEqual(validate_table(task)['stable_steps'], 1)

    def test_variable_lengths_without_fixed_cap(self):
        for count in (1, 3, 5, 25, 1000):
            with self.subTest(count=count):
                self.assertEqual(len(validate_table(table(count))['stages']), count)

    def test_empty_stages_rejected(self):
        with self.assertRaises(ValueError):
            validate_table(table(0))

    def test_invalid_numeric_and_boolean_fields(self):
        for section, key, value in [('task', 'seed', True), ('budget', 'max_steps', 0),
                                    ('budget', 'max_wall_seconds', float('nan'))]:
            task = table()
            task[section][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                validate_table(task)
        task = table()
        task['stages'][0]['max_steps'] = True
        with self.assertRaises(ValueError):
            validate_table(task)

    def test_stage_ids_are_consecutive(self):
        task = table()
        task['stages'][1]['id'] = 7
        with self.assertRaises(ValueError):
            validate_table(task)

    def test_fresh_and_prefix_guards(self):
        task = table()
        task['stages'][1]['completed'] = True
        with self.assertRaises(ValueError):
            validate_table(task)
        with self.assertRaises(ValueError):
            validate_table(task, fresh=False)
        task['stages'][0]['completed'] = True
        validate_table(task, fresh=False)

    def test_unknown_alias_and_predicate_rejected(self):
        task = table()
        task['stages'][0]['checker']['all'][0]['args'][0] = '@missing'
        with self.assertRaises(ValueError):
            validate_table(task)
        task['bindings']['missing'] = 'object_1'
        validate_table(task)
        task['stages'][0]['checker']['all'][0]['predicate'] = 'eval_python'
        with self.assertRaises(ValueError):
            validate_table(task)

    def test_nonfinite_threshold_and_wrong_arity(self):
        for args in (['bowl', float('inf')], ['bowl', -1], ['bowl'], ['bowl', True]):
            task = table()
            task['stages'][0]['checker']['all'] = [{'predicate': 'lifted', 'args': args}]
            with self.subTest(args=args), self.assertRaises(ValueError):
                validate_table(task)

    def test_update_changes_only_current_boolean(self):
        original = table()
        changed = apply_update(original, {'stage_id': 1, 'completed': True}, True)
        self.assertFalse(original['stages'][0]['completed'])
        self.assertTrue(changed['stages'][0]['completed'])
        self.assertEqual(active_stage(changed)['id'], 2)
        self.assertEqual(changed['stages'][0]['instruction'], original['stages'][0]['instruction'])

    def test_bad_updates_cannot_skip_or_invent_completion(self):
        for patch in ({'stage_id': 2, 'completed': True}, {'stage_id': 1, 'completed': 'true'},
                      {'stage_id': True, 'completed': True}, {'stage_id': 1, 'completed': False},
                      {'stage_id': 1, 'completed': True, 'instruction': 'replacement'}):
            with self.subTest(patch=patch), self.assertRaises(ValueError):
                apply_update(table(), patch, True)

    def test_checker_groups_must_be_nonempty(self):
        task = table()
        task['stages'][0]['checker']['all'] = []
        with self.assertRaises(ValueError):
            validate_table(task)


class CheckerTests(unittest.TestCase):
    def test_current_condition_read_does_not_reset_active_stage_stability(self):
        task, checker = self.make(stable=2)
        self.flags['on'] = True
        first, second = task['stages']
        checker.evaluate(first, 0)
        self.assertFalse(checker.evaluate(first, 1)['completed'])
        for _ in range(3):
            self.assertTrue(checker.current_conditions(second)['current_satisfied'])
        self.assertTrue(checker.evaluate(first, 2)['completed'])

    def test_current_condition_snapshot_can_go_false_after_completion(self):
        task, checker = self.make(stable=1)
        self.flags['on'] = True
        stage = task['stages'][0]
        checker.evaluate(stage, 0)
        self.assertTrue(checker.evaluate(stage, 1)['completed'])
        self.flags['on'] = False
        snapshot = checker.current_conditions(stage)
        self.assertFalse(snapshot['current_satisfied'])
        self.assertFalse(snapshot['checks'][0]['completed'])
        self.assertEqual(checker.last_step, 1)

    def test_official_predicate_is_immediate_even_without_new_action(self):
        task = table(1)
        task['completion_mode'] = 'official_predicates'
        checker = StageChecker(FakeEnvironment(goals=lambda s, c: True), task)
        self.assertTrue(checker.evaluate(task['stages'][0], 0)['completed'])

    def test_official_mode_does_not_insert_release_or_stability_checks(self):
        task = table(2)
        task['completion_mode'] = 'official_predicates'
        observed = []
        def official(step, condition):
            observed.append(condition['predicate'])
            return condition['predicate'] == 'on'
        checker = StageChecker(FakeEnvironment(goals=official), task)
        self.assertTrue(checker.evaluate(task['stages'][0], 0)['completed'])
        self.assertTrue(checker.evaluate(task['stages'][1], 0)['completed'])
        self.assertEqual(set(observed), {'on'})

    def make(self, stable=2, sequence=None):
        task = table(2, stable)
        if sequence is not None:
            task['stages'][0]['checker']['sequence'] = sequence
        self.flags = {}
        env = FakeEnvironment(goals=lambda step, item: self.flags.get(item['predicate'], False))
        return task, StageChecker(env, task)

    def test_initial_true_not_immediate_completion(self):
        task, checker = self.make(stable=1)
        self.flags['on'] = True
        self.assertFalse(checker.evaluate(task['stages'][0], 0)['completed'])
        self.assertTrue(checker.evaluate(task['stages'][0], 1)['completed'])

    def test_stability_requires_adjacent_actions(self):
        task, checker = self.make()
        self.flags['on'] = True
        stage = task['stages'][0]
        checker.evaluate(stage, 0)
        self.assertFalse(checker.evaluate(stage, 1)['completed'])
        self.assertFalse(checker.evaluate(stage, 1)['completed'])
        self.assertFalse(checker.evaluate(stage, 3)['completed'])
        self.assertTrue(checker.evaluate(stage, 4)['completed'])

    def test_false_resets_stable_counter(self):
        task, checker = self.make()
        stage = task['stages'][0]
        checker.evaluate(stage, 0)
        self.flags['on'] = True
        checker.evaluate(stage, 1)
        self.flags['on'] = False
        self.assertEqual(checker.evaluate(stage, 2)['consecutive_steps'], 0)

    def test_repeated_on_cannot_replace_lift_event(self):
        event = {'all': [{'predicate': 'grasped', 'args': ['object_1']},
                         {'predicate': 'lifted', 'args': ['object_1', 0.03]}]}
        task, checker = self.make(stable=1, sequence=[event])
        self.flags['on'] = True
        for step in range(10):
            self.assertFalse(checker.evaluate(task['stages'][0], step)['completed'])
        self.flags.update(grasped=True, lifted=True, on=False)
        self.assertEqual(checker.evaluate(task['stages'][0], 10)['sequence_index'], 1)
        self.flags.update(grasped=False, lifted=False, on=True)
        self.assertTrue(checker.evaluate(task['stages'][0], 11)['completed'])

    def test_only_one_event_per_action_and_no_initial_event(self):
        event = {'all': [{'predicate': 'grasped', 'args': ['object_1']}]}
        task, checker = self.make(stable=1, sequence=[event, copy.deepcopy(event)])
        self.flags.update(grasped=True, on=True)
        stage = task['stages'][0]
        self.assertEqual(checker.evaluate(stage, 0)['sequence_index'], 0)
        self.assertEqual(checker.evaluate(stage, 1)['sequence_index'], 1)
        self.assertEqual(checker.evaluate(stage, 1)['sequence_index'], 1)
        self.assertFalse(checker.evaluate(stage, 2)['completed'])
        self.assertTrue(checker.evaluate(stage, 3)['completed'])

    def test_stage_boundary_clears_event_and_stability_state(self):
        task, checker = self.make(stable=1)
        self.flags['on'] = True
        checker.evaluate(task['stages'][0], 0)
        self.assertTrue(checker.evaluate(task['stages'][0], 1)['completed'])
        self.assertFalse(checker.evaluate(task['stages'][1], 1)['completed'])
        self.assertTrue(checker.evaluate(task['stages'][1], 2)['completed'])

    def test_negated_conditions(self):
        task = table(1, 1)
        task['stages'][0]['checker']['all'][0]['negate'] = True
        checker = StageChecker(FakeEnvironment(goals=lambda s, c: False), task)
        checker.evaluate(task['stages'][0], 0)
        self.assertTrue(checker.evaluate(task['stages'][0], 1)['completed'])

    def test_non_boolean_backend_and_reversed_time_rejected(self):
        task = table()
        checker = StageChecker(FakeEnvironment(goals=lambda s, c: 1), task)
        with self.assertRaises(ValueError):
            checker.evaluate(task['stages'][0], 0)
        task, checker = self.make()
        checker.evaluate(task['stages'][0], 2)
        with self.assertRaises(ValueError):
            checker.evaluate(task['stages'][0], 1)

    def test_all_stage_bindings_are_checked(self):
        task = table(25)
        env = FakeEnvironment()
        StageChecker(env, task)
        self.assertEqual(len(env.validated), 25)
