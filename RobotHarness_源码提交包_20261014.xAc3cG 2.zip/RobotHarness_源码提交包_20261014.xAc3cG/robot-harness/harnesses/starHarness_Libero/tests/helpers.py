"""Dependency-free synthetic fixtures, explicitly not robot performance tests."""
import copy


def table(count=2, stable_steps=1):
    return dict(schema_version=1, task=dict(suite='test_suite', task_id=0, initial_state_index=0, seed=47),
        stable_steps=stable_steps, bindings={},
        budget=dict(max_steps=max(10, count * 3), check_interval_steps=2,
                    max_state_requests=1000, max_policy_queries=1000, max_wall_seconds=60),
        stages=[dict(id=i, instruction=f'Complete skill {i}.', max_steps=10, completed=False,
                     checker={'all': [{'predicate': 'on', 'args': [f'object_{i}', 'target']}]})
                for i in range(1, count + 1)])


class FakeEnvironment:
    def __init__(self, *, goals=None, native_at=2, terminate_at=None):
        self.steps = self.resets = self.closed = 0
        self.goals = goals
        self.native_at, self.terminate_at = native_at, terminate_at
        self.metadata = {'synthetic': True}
        self.validated = []
        self.snapshots = []

    def reset(self):
        self.resets += 1
        if self.resets > 1:
            raise AssertionError('Physical scene was reset')
        return {'sensor': self.steps}

    def native_status(self):
        return {'success': self.native_at is not None and self.steps >= self.native_at}

    def end_effector_state(self):
        return dict(pose=dict(position=[0., 0., .3], quaternion_xyzw=[0., 0., 0., 1.]),
                    gripper_qpos=[.04, -.04], joint_qpos=[0.] * 7)

    def validate_condition(self, item):
        self.validated.append(copy.deepcopy(item))

    def evaluate_condition(self, item):
        if self.goals is not None:
            return self.goals(self.steps, item)
        return self.steps >= int(item['args'][0].split('_')[-1])

    def step(self, action):
        self.steps += 1
        return {'sensor': self.steps}, dict(native=self.native_status(),
            terminated=self.terminate_at is not None and self.steps >= self.terminate_at,
            raw_env_done=self.terminate_at is not None and self.steps >= self.terminate_at)

    def snapshot(self, path):
        self.snapshots.append(str(path))

    def close(self):
        self.closed += 1


class FakePolicy:
    def __init__(self, action=None):
        self.action = [0.] * 7 if action is None else action
        self.starts, self.acted, self.observed = [], [], []
        self.closed = self.pending = 0
        self.metadata = {'synthetic': True}

    def begin_episode(self, task, max_queries):
        self.task = task

    def set_stage(self, stage, observation, step):
        self.starts.append((stage['id'], step))
        discarded = self.pending
        self.pending = 0
        return {'discarded_actions': discarded, 'policy_history_reset': True}

    def act(self, observation, step):
        assert set(observation) == {'sensor'}, 'Oracle state leaked into VLA observation'
        self.acted.append((self.starts[-1][0], step))
        self.pending = 4
        return self.action

    def observe(self, observation, step, done):
        self.observed.append((step, done))

    def pause_for_tool(self, observation, step):
        discarded = self.pending
        self.pending = 0
        return {'discarded_actions': discarded, 'inference_suspended': True}

    def close(self):
        self.closed += 1


class NullRecorder:
    def __init__(self):
        self.metadata = {'synthetic': True, 'frames': 0}
        self.closed = 0

    def capture(self, observation, step):
        self.metadata['frames'] += 1

    def close(self):
        self.closed += 1
