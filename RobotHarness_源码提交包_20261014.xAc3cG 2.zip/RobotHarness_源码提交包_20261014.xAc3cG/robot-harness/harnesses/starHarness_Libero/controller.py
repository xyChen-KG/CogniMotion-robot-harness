"""One scene, latched stages, best-effort bounded reset; no task-level retries."""
from __future__ import annotations

import copy
import math
import time
import traceback

from .checker import StageChecker
from .motion_tools import MotionStopped, MotionTools
from .pose_math import validate_osc
from .schema import active_stage, apply_update, validate_table


class Controller:
    def __init__(self, table, environment, policy, updater, store, recorder):
        self.table = copy.deepcopy(validate_table(table))
        self.environment, self.policy, self.updater = environment, policy, updater
        self.store, self.recorder = store, recorder

    def run(self, *, initial_observation=None, keep_environment=False,
            stop_requested=None, native_final_override=True):
        """Defaults retain fresh-episode CLI semantics.

        Interactive scene actors supply the actual latest observation and retain
        the environment. Policy history and action queues are still per-command.
        A full-scene goal must not masquerade as a different interactive subgoal.
        """
        table, env, policy, updater, store = self.table, self.environment, self.policy, self.updater, self.store
        result = dict(status='starting', harness='starHarness_Libero', schema_version=1,
            task=table['task'], supervision_mode=updater.mode, oracle_used_for_supervision=True,
            qwen_input_modality='text_only' if updater.mode == 'simulator_with_qwen_state' else 'none',
            stage_count=len(table['stages']), steps=0, completed_stage_ids=[],
            stage_steps={str(s['id']): 0 for s in table['stages']},
            vla_steps=0, tool_steps=0, stage_tool_steps={str(s['id']): 0 for s in table['stages']},
            post_tools_success=True,
            post_tool_failures=[], reset_failure_policy='record_and_advance',
            success=False, native_success=False, native_success_ever=False,
            all_stages_completed=False, scene_reset_between_stages=False,
            stage_completion_policy='advance_once_live_conditions',
            final_stage_completion_policy='stage_checker_or_current_native_success',
            final_stage_native_completion=None,
            success_authority='final_native_success',
            currently_satisfied_stage_ids=[],
            stage_states={str(s['id']): dict(current_satisfied=None, achieved_once=False,
                first_achieved_step=None, last_checked_step=None, checks=[]) for s in table['stages']},
            recovery=False, automatic_trial_retry=False, autonomous_stopping_tested=False,
            started_epoch=time.time(), budget=table['budget'])
        began = time.monotonic()
        budget = table['budget']
        result['completion_mode'] = table.get('completion_mode', 'stable_conditions')
        if not native_final_override:
            result['final_stage_completion_policy'] = 'registered_stage_checker_only'
        terminated = False
        tools = None
        def check_stop():
            if stop_requested is not None and stop_requested():
                raise InterruptedError('command_stopped_by_user')
        try:
            check_stop()
            observation = env.reset() if initial_observation is None else initial_observation
            env.latest_observation = observation
            checker = StageChecker(env, table)
            native = env.native_status()
            result.update(status='running', environment=env.metadata,
                          native_success=native['success'], native_success_ever=native['success'])
            env.snapshot(store.path / 'initial_sim_state.npy')
            self.recorder.capture(observation, 0)

            def refresh_stage_states():
                # Live conditions may become false again. Only the historical
                # milestone in task_table.completed controls forward progress.
                for row in table['stages']:
                    key = str(row['id'])
                    previous = result['stage_states'][key]
                    live = checker.current_conditions(row)
                    first = previous['first_achieved_step']
                    if row['completed'] and first is None:
                        first = result['steps']
                    state = dict(**live, achieved_once=row['completed'],
                                 first_achieved_step=first, last_checked_step=result['steps'])
                    result['stage_states'][key] = state
                    if (previous['current_satisfied'], previous['achieved_once']) != (
                            state['current_satisfied'], state['achieved_once']):
                        store.log('stage_state_changes', dict(step=result['steps'], stage_id=row['id'], **state))
                result['currently_satisfied_stage_ids'] = [row['id'] for row in table['stages']
                    if result['stage_states'][str(row['id'])]['current_satisfied']]

            refresh_stage_states()
            store.snapshot('stage_states', result['stage_states'])
            store.snapshot('episode_manifest', result)

            def physical_step(action, metadata):
                nonlocal observation, native, terminated
                check_stop()
                if terminated:
                    raise MotionStopped('environment_terminated')
                if result['steps'] >= budget['max_steps']:
                    raise MotionStopped('total_step_budget_exhausted')
                if time.monotonic() - began > budget['max_wall_seconds']:
                    raise MotionStopped('wall_clock_budget_exhausted')
                stage_id, source = metadata.get('stage_id'), metadata.get('source')
                if type(stage_id) is not int or str(stage_id) not in result['stage_steps'] or source not in ('vla', 'tool'):
                    raise ValueError('Unknown stage or action source; refusing physical motion')
                action = [float(value) for value in action]
                action_space = metadata.get('action_space', 'OSC_POSE')
                if action_space == 'JOINT_POSITION':
                    if (source != 'tool' or metadata.get('tool') != 'reset_to_stage_start'
                            or not getattr(env, 'joint_reset_active', False)):
                        raise ValueError('Joint actions are exclusive to an active joint reset')
                    expected = 8
                elif action_space == 'OSC_POSE' and not getattr(env, 'joint_reset_active', False):
                    expected = 7
                else:
                    raise ValueError('Action space does not match the active controller')
                if len(action) != expected or not all(math.isfinite(value) for value in action):
                    raise ValueError(f'Exactly {expected} finite action values are required')
                observation, step_result = env.step(action)
                env.latest_observation = observation
                result['steps'] += 1
                result[source + '_steps'] += 1
                counter = 'stage_steps' if source == 'vla' else 'stage_tool_steps'
                result[counter][str(stage_id)] += 1
                native, terminated = step_result['native'], step_result['terminated']
                if type(native['success']) is not bool:
                    raise ValueError('Native success must be boolean')
                result['native_success'] = native['success']
                result['native_success_ever'] |= native['success']
                refresh_stage_states()
                store.log('actions', dict(step=result['steps'], action=action, native=native,
                          raw_env_done=step_result['raw_env_done'], **metadata))
                if hasattr(self.recorder, 'set_context'):
                    self.recorder.set_context(stage_id=stage_id, source=source, tool=metadata.get('tool'))
                self.recorder.capture(observation, result['steps'])
                if source == 'vla':
                    policy.observe(observation, result['steps'], done=bool(
                        terminated or result['steps'] >= budget['max_steps']))
                if result['steps'] % budget['check_interval_steps'] == 0:
                    store.snapshot('stage_states', result['stage_states'])
                    store.snapshot('progress', result)

            tools = MotionTools(env, physical_step, lambda: result['steps'], store)
            if any(stage.get('post_tools') for stage in table['stages']):
                validate_osc(env.motion_contract())
                for stage in table['stages']:
                    for call in stage.get('post_tools', []):
                        if call['tool'] == 'reset_to_stage_start':
                            env.joint_reset_contract()
                        for condition in call.get('preserve', []):
                            env.validate_condition(condition)
            policy.begin_episode(table['task'], budget['max_policy_queries'])
            current_id, next_update = None, 0
            while True:
                check_stop()
                stage = active_stage(table)
                if stage is None:
                    result['termination_reason'] = 'all_stages_complete'
                    break
                if time.monotonic() - began > budget['max_wall_seconds']:
                    result['termination_reason'] = 'wall_clock_budget_exhausted'
                    break
                if stage['id'] != current_id and result['steps'] >= budget['max_steps']:
                    result['termination_reason'] = 'total_step_budget_exhausted'
                    break
                if stage['id'] != current_id:
                    tools.record_stage_start(stage['id'])
                    boundary = policy.set_stage(stage, observation, result['steps'])
                    store.log('controller_trace', dict(event='stage_start', step=result['steps'],
                              stage_id=stage['id'], instruction=stage['instruction'], policy_boundary=boundary))
                    current_id, next_update = stage['id'], result['steps']
                check = checker.evaluate(stage, result['steps'])
                # Earlier stages remain latched milestones. In the LAST stage,
                # current full-task native success may finish the workflow even
                # when an extra release/stability/process check is still false.
                check['native_success'] = native['success']
                store.log('simulator_checks', check)
                if native_final_override and stage['id'] == table['stages'][-1]['id'] and native['success']:
                    update = dict(stage_id=stage['id'], completed=True)
                    table = apply_update(table, update, native['success'])
                    result['completed_stage_ids'].append(stage['id'])
                    result['final_stage_native_completion'] = dict(
                        stage_id=stage['id'], step=result['steps'], native_success=True,
                        authority='current_full_task_native_success',
                        stage_checker_completed=check['completed'],
                        checker_observation=copy.deepcopy(check))
                    # No more VLA actions or final post-tools after native success.
                    # Keep raw checker conditions and earlier tool failures honest.
                    pause = policy.pause_for_tool(observation, result['steps'])
                    store.log('controller_trace', dict(event='final_stage_native_complete',
                        **result['final_stage_native_completion'], update=update,
                        policy_boundary=pause, skipped_post_tools=copy.deepcopy(stage.get('post_tools', []))))
                    refresh_stage_states()
                    store.snapshot('task_table', table)
                    store.snapshot('stage_states', result['stage_states'])
                    store.snapshot('progress', result)
                    result['termination_reason'] = 'final_stage_native_success'
                    break
                if check['completed'] or result['steps'] >= next_update or terminated:
                    update = updater.update(table, check)
                    table = apply_update(table, update, check['completed'])
                    store.snapshot('task_table', table)
                    store.log('controller_trace', dict(event='state_update', step=result['steps'],
                              check=check, update=update))
                    next_update = result['steps'] + budget['check_interval_steps']
                    if update['completed']:
                        result['completed_stage_ids'].append(stage['id'])
                        refresh_stage_states()
                        store.snapshot('stage_states', result['stage_states'])
                        store.snapshot('progress', result)
                        calls = stage.get('post_tools', [])
                        if calls:
                            store.snapshot('progress', result)
                            pause = policy.pause_for_tool(observation, result['steps'])
                            store.log('controller_trace', dict(event='vla_paused_for_tools',
                                step=result['steps'], stage_id=stage['id'], policy_boundary=pause))
                            for call in calls:
                                try:
                                    tool_result = tools.call(call, stage)
                                except (Exception, KeyboardInterrupt):
                                    result['post_tools_success'] = False
                                    result['post_tool_failures'].append(dict(stage_id=stage['id'], tool=call['tool'],
                                        status='interface_or_runtime_error', step=result['steps'], continued=False))
                                    raise  # Interface faults are not ordinary reset failures.
                                if tool_result['status'] != 'reached':
                                    result['post_tools_success'] = False  # Sticky across later successes.
                                    fatal = (tool_result['status'] in ('environment_terminated',
                                        'total_step_budget_exhausted', 'wall_clock_budget_exhausted', 'error')
                                        or tool_result.get('controller_restored') is False)
                                    failure = dict(stage_id=stage['id'], tool=call['tool'],
                                        status=tool_result['status'], step=result['steps'],
                                        continued=bool(call['tool'] == 'reset_to_stage_start' and not fatal
                                                       and active_stage(table) is not None))
                                    result['post_tool_failures'].append(failure)
                                    store.log('controller_trace', dict(event='post_tool_failed', **failure))
                                    store.snapshot('progress', result)
                                    if fatal or call['tool'] != 'reset_to_stage_start':
                                        result['termination_reason'] = 'post_tool_' + tool_result['status']
                                        break
                                    # Reset is best-effort. Skip remaining post-tools and
                                    # start the next VLA stage from the ACTUAL new observation.
                                    break
                            if result.get('termination_reason', '').startswith('post_tool_'):
                                break
                        # set_stage MUST discard old queued actions. Never reset env.
                        if not terminated:
                            continue
                if terminated:
                    result['termination_reason'] = 'environment_terminated'
                    break
                if result['steps'] >= budget['max_steps']:
                    result['termination_reason'] = 'total_step_budget_exhausted'
                    break
                if result['stage_steps'][str(stage['id'])] >= stage['max_steps']:
                    result['termination_reason'] = 'stage_step_budget_exhausted'
                    break
                action = [float(value) for value in policy.act(observation, result['steps'])]
                check_stop()  # A stop received during inference discards its actions.
                if len(action) != 7 or not all(math.isfinite(value) for value in action):
                    raise ValueError('Policy must supply exactly seven finite action values')
                if time.monotonic() - began > budget['max_wall_seconds']:
                    result['termination_reason'] = 'wall_clock_budget_exhausted'
                    break  # Slow inference must not allow a late physical action.
                try:
                    physical_step(action, dict(source='vla', stage_id=stage['id']))
                except MotionStopped as error:
                    result['termination_reason'] = str(error)
                    break
            result['status'] = 'complete'
            env.snapshot(store.path / 'final_sim_state.npy')
        except InterruptedError as error:
            result.update(status='stopped', termination_reason='command_stopped_by_user', error=str(error))
            env.snapshot(store.path / 'final_sim_state.npy')
        except (Exception, KeyboardInterrupt) as error:
            result.update(status='error', termination_reason='interface_or_runtime_error',
                          error=repr(error), traceback=traceback.format_exc())
        finally:
            cleanup_errors = []
            cleanup_operations = [('policy', policy.close), ('recorder', self.recorder.close)]
            if not keep_environment:
                cleanup_operations.append(('environment', env.close))
            for name, cleanup in cleanup_operations:
                try:
                    cleanup()
                except Exception as error:
                    cleanup_errors.append(dict(component=name, error=repr(error)))
            result.update(all_stages_completed=active_stage(table) is None,
                completed_stage_ids=[s['id'] for s in table['stages'] if s['completed']],
                state_requests=updater.requests, policy=getattr(policy, 'metadata', {}),
                elapsed_seconds=time.monotonic() - began, finished_epoch=time.time(),
                cleanup_errors=cleanup_errors, recording=self.recorder.metadata)
            result['environment_retained'] = keep_environment
            result['native_final_override'] = native_final_override
            result['tool_results'] = [] if tools is None else tools.results
            result['task_success'] = bool(result['native_success'])
            result['workflow_success'] = bool(result['status'] == 'complete' and result['all_stages_completed']
                                             and result['post_tools_success'] and not cleanup_errors)
            # Only the final official outcome scores the task in either mode.
            # Historical milestones, post-tools and cleanup are reported apart.
            result['success'] = result['task_success']
            if cleanup_errors:
                result['status'] = 'error'
            store.snapshot('task_table', table)
            store.snapshot('stage_states', result['stage_states'])
            store.snapshot('result', result)
            store.close()
            self.table = table
        return result
