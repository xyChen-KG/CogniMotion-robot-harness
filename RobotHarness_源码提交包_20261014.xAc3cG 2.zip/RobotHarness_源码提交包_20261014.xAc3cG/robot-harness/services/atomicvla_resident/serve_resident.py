"""Local-only facade; keep upstream policy/weights/transforms unchanged."""
import argparse
import json
import os
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--candidate', choices=['AtomicVLA', 'pi05'], required=True)
parser.add_argument('--port', type=int, required=True)
parser.add_argument('--ready-file', required=True)
args = parser.parse_args()
root = Path(os.environ.get('VLA_ROOT', '/opt/vla')) / args.candidate
os.environ.setdefault('OPENPI_DATA_HOME', str(root / 'cache'))
os.environ.setdefault('XLA_PYTHON_CLIENT_PREALLOCATE', 'false')
os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')
os.environ.setdefault('WANDB_MODE', 'disabled')
import jax
from openpi.policies import policy_config
from openpi.training import config
from openpi.serving import websocket_policy_server

name = 'Atomic_libero' if args.candidate == 'AtomicVLA' else 'pi05_libero'
checkpoint = root / 'weights' / ('libero' if args.candidate == 'AtomicVLA' else 'pi05_libero')
policy = policy_config.create_trained_policy(config.get_config(name), checkpoint)

class LocalFacade:
    @property
    def metadata(self):
        return {**policy.metadata, 'candidate': args.candidate, 'config': name,
                'explicit_episode_reset': 'episode_start=True'}

    def infer(self, obs):
        obs = dict(obs)
        episode_start = obs.pop('episode_start', False)
        obs.pop('reset', None)
        if episode_start and hasattr(policy, 'reset'):
            policy.reset()
        result = policy.infer(obs)
        if args.candidate == 'AtomicVLA':
            result = {**result, 'is_thinking': bool(policy.is_thinking)}
        return result

    def reset(self):
        if hasattr(policy, 'reset'):
            policy.reset()

Path(args.ready_file).write_text(json.dumps({'candidate': args.candidate, 'config': name,
    'checkpoint': str(checkpoint), 'devices': [str(x) for x in jax.devices()],
    'pid': os.getpid(), 'status': 'weights_loaded_server_starting'}, indent=2))
print('WEIGHTS_LOADED', args.candidate, [str(x) for x in jax.devices()], flush=True)
websocket_policy_server.WebsocketPolicyServer(LocalFacade(), host='127.0.0.1', port=args.port,
                                               metadata=LocalFacade().metadata).serve_forever()
