"""Stop only the verified controller belonging to this resident service."""
import json
import os
import signal
import time
from pathlib import Path

OUT = Path(__file__).resolve().parent
state = json.loads((OUT / 'service_state.json').read_text())
pid = state['controller_pid']
process = Path('/proc', str(pid))
if not process.exists():
    print('Controller already absent; no signal sent')
    raise SystemExit(0)
if process.stat().st_uid != os.getuid():
    raise RuntimeError('Controller is not owned by current user; refusing to signal')
ticks = (process / 'stat').read_text().rsplit(')', 1)[1].split()[19]
arguments = (process / 'cmdline').read_bytes().split(b'\x00')
if ticks != state['controller_start_ticks'] or str(OUT / 'start.py').encode() not in arguments:
    raise RuntimeError('PID identity changed; refusing to signal')
os.kill(pid, signal.SIGTERM)
deadline = time.monotonic() + 35
while time.monotonic() < deadline:
    latest = json.loads((OUT / 'service_state.json').read_text())
    if latest.get('status') == 'stopped' and latest.get('owned_model_exited'):
        print('Stopped; model process exited and GPU memory released')
        break
    time.sleep(1)
else:
    raise RuntimeError('Stop not confirmed; inspect this service without signaling other processes')
