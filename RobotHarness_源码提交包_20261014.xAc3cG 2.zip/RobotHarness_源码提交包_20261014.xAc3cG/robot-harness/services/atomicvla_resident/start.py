"""Persistent, loop-free idle AtomicVLA service; own only its model child."""
import fcntl
import json
import os
import signal
import socket
import subprocess
import sys
import time
import traceback
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/opt/vla/AtomicVLA')
GPU = os.environ['ROBOT_GPU']
PORT = 18321
server = None
stop_requested = False
state = dict(status='preflight', controller_pid=os.getpid(), server_pid=None,
             model='Atomic_libero', gpu_uuid=GPU, port=PORT, bind_host='127.0.0.1',
             simulation_started=False, inference_requests_sent=0,
             auto_restart=False, gpu_resource_gate_enabled=False)


def start_ticks(pid):
    return Path('/proc', str(pid), 'stat').read_text().rsplit(')', 1)[1].split()[19]


def save():
    temporary = OUT / 'service_state.json.tmp'
    temporary.write_text(json.dumps(state, indent=2) + '\n')
    temporary.replace(OUT / 'service_state.json')


def request_stop(signum, _frame):
    global stop_requested
    stop_requested = True
    state.update(status='stopping', stop_signal=signum)
    save()
    raise SystemExit(0)


state['controller_start_ticks'] = start_ticks(os.getpid())
signal.signal(signal.SIGTERM, request_stop)
signal.signal(signal.SIGINT, request_stop)

with (OUT / 'service.lock').open('a+') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    try:
        with socket.socket() as probe:
            if probe.connect_ex(('127.0.0.1', PORT)) == 0:
                raise RuntimeError('Port occupied; existing service left untouched')
        head = subprocess.check_output(['git', '-C', str(ROOT / 'repo'), 'rev-parse', 'HEAD'], text=True).strip()
        dirty = subprocess.check_output(['git', '-C', str(ROOT / 'repo'), 'status', '--porcelain'], text=True)
        if head != 'c3583055adde0a491a11ffe08c15ca6459a64254' or dirty:
            raise RuntimeError('AtomicVLA source revision or clean-state check failed')
        manifest = json.loads((ROOT.parent / 'manifests/atomic.download.json').read_text())
        if not manifest.get('download_complete') or manifest.get('revision') != '633dd6ac2b04ff59938b93ebdd10d1ae84d52bef':
            raise RuntimeError('Verified local AtomicVLA checkpoint manifest missing')
        for entry in manifest['files']:
            path = ROOT / 'weights/libero' / entry['name']
            if not path.is_file() or path.stat().st_size != entry['size']:
                raise RuntimeError('Checkpoint file absent or wrong size: ' + entry['name'])
        state.update(code_head=head, checkpoint_revision=manifest['revision'],
                     initial_gpu_stats=subprocess.check_output(['nvidia-smi', '-i', GPU,
                         '--query-gpu=index,memory.free,utilization.gpu', '--format=csv,noheader,nounits'], text=True).strip())
        environment = os.environ.copy()
        environment.update(CUDA_VISIBLE_DEVICES=GPU, XLA_PYTHON_CLIENT_PREALLOCATE='false',
            XLA_PYTHON_CLIENT_MEM_FRACTION='0.4', OPENPI_DATA_HOME=str(ROOT / 'cache'),
            HF_HOME=str(ROOT / 'cache/huggingface'), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
            PYTHONPATH=str(OUT / 'extra_deps'), PYTHONDONTWRITEBYTECODE='1',
            TOKENIZERS_PARALLELISM='false', WANDB_MODE='disabled',
            OMP_NUM_THREADS='4', OPENBLAS_NUM_THREADS='4', MKL_NUM_THREADS='4',
            JAX_COMPILATION_CACHE_DIR=str(OUT / 'jax_compile_cache'),
            NO_PROXY='127.0.0.1,localhost', no_proxy='127.0.0.1,localhost')
        compiler = ROOT / 'runtime/lib/python3.11/site-packages/nvidia/cuda_nvcc/bin'
        if not (compiler / 'ptxas').is_file():
            raise RuntimeError('Existing local CUDA compiler missing')
        environment['PATH'] = str(compiler) + os.pathsep + environment.get('PATH', '')
        with (OUT / 'server.log').open('x') as logfile:
            server = subprocess.Popen([str(ROOT / 'runtime/bin/python'), '-u', str(OUT / 'serve_resident.py'),
                '--candidate', 'AtomicVLA', '--port', str(PORT), '--ready-file', str(OUT / 'server_ready.json')],
                cwd=OUT, env=environment, stdin=subprocess.DEVNULL, stdout=logfile, stderr=subprocess.STDOUT)
        state.update(status='loading_model', server_pid=server.pid, server_start_ticks=start_ticks(server.pid))
        save()
        deadline = time.monotonic() + 600
        while time.monotonic() < deadline:
            if server.poll() is not None:
                raise RuntimeError(f'Model exited before ready: {server.returncode}')
            if (OUT / 'server_ready.json').is_file():
                import websockets.sync.client
                from openpi_client import msgpack_numpy
                try:
                    with websockets.sync.client.connect(f'ws://127.0.0.1:{PORT}', proxy=None,
                            compression=None, max_size=None, open_timeout=5, close_timeout=2) as connection:
                        metadata = msgpack_numpy.unpackb(connection.recv(timeout=5))
                    if metadata.get('candidate') != 'AtomicVLA' or metadata.get('config') != 'Atomic_libero':
                        raise RuntimeError('Unexpected inference server identity')
                    state.update(status='ready', websocket_metadata=metadata,
                                 ready_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
                    save()
                    print('READY ' + json.dumps(state), flush=True)
                    break
                except (ConnectionRefusedError, TimeoutError):
                    pass
            time.sleep(2)
        else:
            raise RuntimeError('Model startup exceeded 600 seconds')
        # Keep weights loaded without sending observations, generating actions,
        # allocating filler tensors, or running a hardware-wait loop.
        return_code = server.wait()
        raise RuntimeError(f'Resident model exited unexpectedly: {return_code}')
    except Exception:
        state.update(status='failed', error=traceback.format_exc())
        print(state['error'], flush=True)
    finally:
        if server is not None and server.poll() is None:
            server.terminate()
            try:
                server.wait(timeout=20)
            except subprocess.TimeoutExpired:
                server.kill()
                server.wait(timeout=10)
        if stop_requested:
            state['status'] = 'stopped'
        state['owned_model_exited'] = server is None or server.poll() is not None
        save()

raise SystemExit(1 if state['status'] == 'failed' else 0)
