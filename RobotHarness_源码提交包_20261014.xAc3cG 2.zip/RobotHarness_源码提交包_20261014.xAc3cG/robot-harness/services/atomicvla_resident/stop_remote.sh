#!/bin/sh
# Stop only the verified controller and its own model process.
exec ssh -o BatchMode=yes -o ConnectTimeout=12 -o ClearAllForwardings=yes robot-gpu '/opt/vla/AtomicVLA/runtime/bin/python -B /opt/vla/AtomicVLA/resident_20261011.UqijnW/stop.py'
