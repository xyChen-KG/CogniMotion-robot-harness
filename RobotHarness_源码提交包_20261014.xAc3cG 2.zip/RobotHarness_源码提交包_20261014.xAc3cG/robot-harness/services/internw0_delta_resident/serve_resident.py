"""Local, serial resident bridge; upstream model and policy code stay unchanged."""
import argparse
import fcntl
import hashlib
import json
import logging
from multiprocessing.connection import Listener
import os
from pathlib import Path
import time
import traceback

import hydra
from omegaconf import OmegaConf
import torch

from eval.libero_plus.server import _build_runtime, _write_resolved_contract
from eval.libero_plus.online_policy import OnlinePolicySession
from eval.profiler import Profiler

BASE = Path(os.environ.get('INTERNW0_ROOT', '/opt/vla/InternW0_Delta'))
REVISION = '00524e29e160b2f092bf6c5a47e325301a31fb90'


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def strict_audit(model, path):
    checkpoint = torch.load(path, map_location='meta', weights_only=True, mmap=True)
    result = {}
    for name in ('mot', 'proprio_encoder', 'action_proprio_encoder'):
        actual, trained = getattr(model, name).state_dict(), checkpoint[name]
        missing = sorted(set(actual) - set(trained))
        incompatible = [key for key in trained if key not in actual
                        or tuple(trained[key].shape) != tuple(actual[key].shape)]
        result[name] = dict(checkpoint_tensors=len(trained), model_tensors=len(actual),
                            missing=missing, incompatible=incompatible)
        if missing or incompatible:
            raise ValueError('Incomplete trained weights: ' + name)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--service-dir', type=Path, required=True)
    args = parser.parse_args()
    root = args.service_dir.resolve()
    root.mkdir(parents=True, exist_ok=True)
    os.umask(0o077)
    os.chmod(root, 0o700)
    lock = (root / 'service.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    state_path, socket_path = root / 'server_state.json', root / 'policy.sock'
    if state_path.exists() or socket_path.exists():
        raise RuntimeError('Service directory is occupied; never overwrite/restart automatically')
    logging.basicConfig(level=logging.INFO)
    torch.set_num_threads(4)
    state = dict(status='loading', pid=os.getpid(), gpu_uuid=os.environ['CUDA_VISIBLE_DEVICES'],
                 model='InternRobotics/InternW0-Delta-Libero', checkpoint_revision=REVISION,
                 frozen=True, paid_api_requests=0, serial_clients=True,
                 network_exposure='private Unix socket only', resident_after_disconnect=True,
                 automatic_restart=False, sessions=0, queries=0, started_epoch=time.time())
    save(state_path, state)
    listener = conn = policy = None
    try:
        with hydra.initialize_config_dir(config_dir=str(BASE / 'repo/configs'), version_base='1.3'):
            cfg = hydra.compose(config_name='sim_libero_plus', overrides=[
                'seed=47', 'model.load_text_encoder=false',
                f'ckpt={BASE}/weights/InternW0-Delta-Libero/libero.pt',
                f'EVALUATION.dataset_stats_path={BASE}/repo/assets/stats/libero.json',
                f'EVALUATION.output_dir={root}', 'EVALUATION.device=cuda:0'])
        runtime = _build_runtime(cfg, Profiler(enabled=False))
        runtime.model.requires_grad_(False)
        state['checkpoint_audit'] = strict_audit(runtime.model, Path(cfg.ckpt))
        (root / 'resolved_config.yaml').write_text(OmegaConf.to_yaml(cfg, resolve=True))
        _write_resolved_contract(cfg, runtime, socket_path)
        metadata = dict(candidate='InternW0-Delta', model=state['model'], checkpoint_revision=REVISION,
                        source_revision='90801baa3bdc7829c1e4989edfe3d0fb2410ea6a',
                        action_horizon=runtime.action_horizon, replan_steps=10,
                        pid=os.getpid(), gpu_uuid=state['gpu_uuid'], resident=True)
        listener = Listener(str(socket_path), family='AF_UNIX')
        state.update(status='ready_idle', allocated_mib=torch.cuda.memory_allocated()/1024**2,
                     reserved_mib=torch.cuda.memory_reserved()/1024**2, ready_epoch=time.time())
        save(state_path, state)
        print('RESIDENT_READY ' + json.dumps(metadata), flush=True)
        while True:
            conn = listener.accept()  # Blocking I/O: no GPU work while idle.
            conn.send(metadata)
            try:
                while True:
                    if not conn.poll(600):
                        raise TimeoutError('Idle client timed out; model remains resident')
                    request = conn.recv()
                    op = request['op']
                    if op == 'health':
                        conn.send({**metadata, 'status':state['status']})
                    elif op == 'reset':
                        if policy is not None:
                            raise ValueError('End the occupied episode before starting another')
                        path = Path(request['context_file']).resolve()
                        if not path.is_relative_to(BASE / 'runs'):
                            raise ValueError('Prompt cache must be inside this candidate run directory')
                        if sha256(path) != request['context_sha256']:
                            raise ValueError('Prompt cache checksum mismatch')
                        contexts = torch.load(path, map_location='cpu', weights_only=True)
                        text = str(request['instruction'])
                        context, mask = contexts[text]
                        if tuple(context.shape) != (1,128,4096) or tuple(mask.shape) != (1,128):
                            raise ValueError('Unexpected official prompt context shape')
                        rng = torch.Generator(device='cpu').manual_seed(int(request['seed'])).get_state()
                        policy = OnlinePolicySession(model=runtime.model, processor=runtime.processor,
                            cfg=cfg, action_horizon=runtime.action_horizon, input_w=runtime.input_w,
                            input_h=runtime.input_h, model_device=runtime.model_device,
                            torch_rng_state=rng, profiler=None)
                        policy.reset(task_suite_name=request['suite'], task_id=int(request['task_id']),
                                     task_description=text)
                        policy.prompt_context = context.to(runtime.model_device)
                        policy.prompt_context_mask = mask.to(runtime.model_device)
                        state.update(status='serving', active_instruction=text,
                                     sessions=state['sessions']+1, client_pid=request.get('client_pid'))
                        save(state_path, state)
                        conn.send({'reset':True, 'memory_reset_count':1})
                    elif op == 'act':
                        if policy is None:
                            raise ValueError('No active episode')
                        began = time.monotonic()
                        with torch.inference_mode():
                            result = policy.act(request['observation'], timestep=int(request['step']))
                        torch.cuda.synchronize()
                        result.update(seconds=time.monotonic()-began,
                                      peak_allocated_mib=torch.cuda.max_memory_allocated()/1024**2)
                        if result['replanned']:
                            state['queries'] += 1
                            state['last_step'] = int(request['step'])
                            save(state_path, state)
                        conn.send(result)
                    elif op == 'observe':
                        if policy is None:
                            raise ValueError('No active episode')
                        with torch.inference_mode():
                            result = policy.observe(request['observation'], done=bool(request['done']))
                        conn.send(result)
                    elif op == 'end_episode':
                        if policy is not None:
                            policy.close()
                            policy = None
                        torch.cuda.synchronize()
                        state.update(status='ready_idle', active_instruction=None, client_pid=None,
                                     last_episode_end_epoch=time.time(),
                                     allocated_mib=torch.cuda.memory_allocated()/1024**2,
                                     reserved_mib=torch.cuda.memory_reserved()/1024**2)
                        save(state_path, state)
                        conn.send({'ended':True, 'model_still_resident':True})
                    elif op == 'disconnect':
                        conn.send({'disconnected':True, 'model_still_resident':True})
                        break
                    else:
                        raise ValueError('Unsupported operation: ' + str(op))
            except (EOFError, BrokenPipeError, ConnectionResetError):
                pass
            except (ValueError, KeyError, TimeoutError):
                error = traceback.format_exc()
                state['last_client_error'] = error
                try:
                    conn.send({'error':error})
                except (BrokenPipeError, EOFError, ConnectionResetError):
                    pass
            finally:
                if policy is not None:
                    policy.close()
                    policy = None
                conn.close()
                conn = None
                state.update(status='ready_idle', active_instruction=None, client_pid=None)
                save(state_path, state)
    except BaseException:
        state.update(status='error', error=traceback.format_exc(), finished_epoch=time.time())
        save(state_path, state)
        print(state['error'], flush=True)
        raise
    finally:
        if policy is not None:
            policy.close()
        if conn is not None:
            conn.close()
        if listener is not None:
            listener.close()
        lock.close()


if __name__ == '__main__':
    main()
