"""One detached scene actor, sharing the legacy run manager's exclusive slot.

Only registered scene/stage IDs are accepted. Durable request claims precede
launch/mailbox delivery; unknown process identity retains the slot, never replay.
"""
from __future__ import annotations

import copy
import math
import os
from pathlib import Path
import re
import subprocess
from subprocess import Popen
import time
import uuid

from files import identity, private_directory, process_state, read_json, save_json
from preview_reader import read_preview

SCENE = re.compile(r'scene_[a-f0-9]{32}\Z')
COMMAND = re.compile(r'cmd_[a-f0-9]{32}\Z')
OWNER = re.compile(r'[a-f0-9]{64}\Z')
REQUEST = re.compile(r'[A-Za-z0-9_-]{1,128}\Z')


def command_table(base, stage_id, consumed):
    """Registered instructions/predicates unchanged; budgets shared by revision."""
    return plan_table(base, [stage_id], consumed)


def plan_table(base, stage_ids, consumed):
    """Compile only catalog IDs; no planner-defined actions, tests or budgets."""
    registered = {s['id']: s for s in base['stages']}
    if (not isinstance(stage_ids, list) or not 1 <= len(stage_ids) <= 32
            or any(type(i) is not int or i not in registered for i in stage_ids)
            or len(set(stage_ids)) != len(stage_ids)):
        raise ValueError('Plan must contain 1–32 distinct registered stage IDs')
    table = copy.deepcopy(base)
    table['stages'] = [copy.deepcopy(registered[i]) for i in stage_ids]
    for index, stage in enumerate(table['stages'], 1):
        stage['id'] = index
    used = {'max_steps':consumed.get('steps',0),
            'max_policy_queries':consumed.get('policy_queries',0),
            'max_wall_seconds':math.ceil(consumed.get('active_elapsed_seconds',0)),
            'max_state_requests':consumed.get('state_requests',0)}
    for key,value in used.items():
        table['budget'][key] -= value
        if table['budget'][key] <= 0:
            raise ValueError('Scene shared budget exhausted: ' + key)
    return table


def command_record(command_id, requested_revision, outcome):
    # A reset's resulting revision differs from its requested revision.
    return {'command_id':command_id,'requested_revision':requested_revision,
            'revision':requested_revision,**outcome}


class SceneManager:
    def __init__(self, runs):
        self.runs = runs
        self.records, self.children = {}, {}
        for folder in runs.root.glob('scene_*'):
            record = read_json(folder / 'record.json')
            if folder.is_symlink() or not isinstance(record, dict) or record.get('scene_id') != folder.name:
                raise RuntimeError('Unreadable scene record; cannot forget a possible live actor')
            self.records[folder.name] = record

    def error(self, status, message):
        from manager import APIError
        raise APIError(status, message)

    def folder(self, scene_id):
        if not isinstance(scene_id, str) or not SCENE.fullmatch(scene_id) or scene_id not in self.records:
            self.error(404, 'Unknown scene_id')
        return self.runs.root / scene_id

    def reconcile(self, record):
        folder = self.folder(record['scene_id'])
        state = read_json(folder / 'actor_state.json') or {}
        owned = state.get('identity') or record.get('identity')
        observed = process_state(owned)
        child = self.children.get(record['scene_id'])
        if child is not None and child.poll() is not None:
            del self.children[record['scene_id']]
            observed = 'gone'  # Our unreaped Popen child is authoritative.
        elif child is not None:
            observed = 'alive'
        if record.get('spawn_failed'):
            observed = 'gone'
        active = observed != 'gone'
        status = state.get('status', 'opening') if observed == 'alive' else (
            'closed' if state.get('status') == 'closed' else 'failed' if observed == 'gone' else 'interrupted')
        return {**state, 'scene_id': record['scene_id'], 'active': active, 'status': status,
                'ownership_uncertain': observed == 'unknown', 'request': {k: record['request'][k]
                    for k in ('task_id', 'policy', 'seed')}, 'created_at': record['created_at']}

    def active(self):
        return any(self.reconcile(row)['active'] for row in self.records.values())

    def listing(self):
        with self.runs.lock:
            rows = sorted(self.records.values(), key=lambda r: r['created_at'], reverse=True)
            return {'scenes': [self.public(row['scene_id']) for row in rows[:10]]}

    def public(self, scene_id):
        record = self.records[self.folder(scene_id).name]
        state = self.reconcile(record)
        # PID, owner and private paths are not needed in browser responses.
        keys = ('scene_id', 'request', 'created_at', 'status', 'active', 'ownership_uncertain',
                'revision', 'steps', 'vla_steps', 'tool_steps', 'remaining_steps',
                'native_success', 'current_command_id', 'current_stage_id', 'initializations',
                'policy_queries','active_elapsed_seconds','state_requests',
                'plan_protocol','plan_stage_count','plan_stage_index',
                'error', 'updated_at', 'commands', 'initial_state_hash', 'state_hash', 'idle_expiry')
        value = {k: state.get(k) for k in keys}
        value['commands'] = (state.get('commands') or [])[-16:]  # Full history remains on disk.
        return value

    def check_owner(self, scene_id, owner):
        folder = self.folder(scene_id)
        if not isinstance(owner, str) or not OWNER.fullmatch(owner) or self.records[scene_id]['owner'] != owner:
            self.error(403, 'This scene belongs to another authorized principal')
        return folder

    def open(self, request):
        expected = {'task_id', 'policy', 'seed', 'request_id', 'owner'}
        if (not isinstance(request, dict) or set(request) != expected
                or not isinstance(request['task_id'], str) or not re.fullmatch(r'[A-Za-z0-9._-]{1,128}', request['task_id'])
                or request['policy'] not in ('atomic', 'internw0')
                or not isinstance(request['owner'], str) or not OWNER.fullmatch(request['owner'])
                or not isinstance(request['request_id'], str) or not REQUEST.fullmatch(request['request_id'])
                or type(request['seed']) is not int):
            self.error(400, 'Invalid registered scene request')
        with self.runs.lock:
            for record in self.records.values():
                if record['owner'] == request['owner'] and record['request']['request_id'] == request['request_id']:
                    if record['request'] != request:
                        self.error(409, 'Request identity was already used with different parameters')
                    return {**self.public(record['scene_id']), 'idempotent': True}
            if not self.runs.enable_runs:
                self.error(403, 'Scene execution is disabled')
            task = self.runs.registry.tasks.get(request['task_id'])
            if not task or request['policy'] not in task['policies'] or request['seed'] not in task['allowed_seeds']:
                self.error(400, 'Scene, policy or seed is not registered')
            if self.active() or any(self.runs._reconcile(r)['active'] for r in self.runs.records.values()):
                self.error(409, 'An active/uncertain scene or task owns the exclusive slot')
            scene_id = 'scene_' + uuid.uuid4().hex
            folder = self.runs.root / scene_id
            try:
                table, launch = self.runs.registry.prepare(request['task_id'], request['policy'], request['seed'], folder)
            except (OSError, ValueError, KeyError, TypeError):
                self.error(422, 'Registered scene inputs/cache unavailable or changed')
            private_directory(folder)
            private_directory(folder / 'commands')
            private_directory(folder / 'stops')
            record = dict(scene_id=scene_id, owner=request['owner'], request=copy.deepcopy(request),
                          created_at=time.time(), identity=None, spawn_failed=False)
            self.records[scene_id] = record
            save_json(folder / 'record.json', record)
            save_json(folder / 'task_table.json', table)
            spec = dict(task=task, table=table, policy=request['policy'], launch=launch)
            save_json(folder / 'scene_spec.json', spec)
            try:
                with (folder / 'actor.log').open('x') as log:
                    actor = Popen([task['python'], '-B', '-u',
                        str(Path(__file__).with_name('scene_actor.py')), str(folder)],
                        cwd=launch['cwd'], env=launch['env'], stdin=subprocess.DEVNULL,
                        stdout=log, stderr=subprocess.STDOUT, start_new_session=True, close_fds=True)
                self.children[scene_id] = actor
                record['identity'] = identity(actor.pid)
                save_json(folder / 'record.json', record)
            except OSError:
                record['spawn_failed'] = scene_id not in self.children
                save_json(folder / 'record.json', record)
                self.error(503, 'Scene launch failed; request remains claimed')
            return {**self.public(scene_id), 'idempotent': False}

    def command(self, scene_id, request):
        required = {'owner', 'request_id', 'revision', 'operation'}
        if (not isinstance(request, dict) or not required <= set(request)
                or set(request) - (required | {'stage_id', 'plan'})
                or not isinstance(request['request_id'], str) or not REQUEST.fullmatch(request['request_id'])
                or type(request['revision']) is not int
                or request['operation'] not in ('execute', 'execute_plan', 'reset', 'close', 'stop')):
            self.error(400, 'Invalid scene command')
        if (request['operation'] == 'execute') != ('stage_id' in request):
            self.error(400, 'Only execute requires a registered stage_id')
        if (request['operation'] == 'execute_plan') != ('plan' in request):
            self.error(400, 'Only execute_plan requires a validated plan')
        if 'plan' in request:
            plan = request['plan']
            if (not isinstance(plan, dict) or set(plan) != {'planning_request_id','goal','stage_ids','scene_step'}
                    or not isinstance(plan['planning_request_id'], str) or not REQUEST.fullmatch(plan['planning_request_id'])
                    or not isinstance(plan['goal'], str) or not 1 <= len(plan['goal'].strip()) <= 2000
                    or type(plan['scene_step']) is not int or plan['scene_step'] < 0):
                self.error(400, 'Invalid bounded plan envelope')
        with self.runs.lock:
            folder = self.check_owner(scene_id, request['owner'])
            # A retried stop is bound to the ORIGINAL command, never a later one.
            stop_path = folder / 'stops' / (request['request_id'] + '.json')
            old_stop = read_json(stop_path)
            if old_stop:
                if old_stop['request'] != request:
                    self.error(409, 'Stop identity was already used with different parameters')
                current = old_stop['command_id']
                if current:
                    save_json(folder / 'commands' / current / 'stop.json', {'at': old_stop['at']})
                return {'scene_id': scene_id, 'command_id': current, 'stop_requested': bool(current), 'idempotent': True}
            state = self.reconcile(self.records[scene_id])
            commands = sorted((folder / 'commands').glob('cmd_*'))
            for directory in commands:
                old = read_json(directory / 'request.json')
                if old and old.get('request_id') == request['request_id']:
                    if old != request:
                        self.error(409, 'Command identity was already used with different parameters')
                    return {'scene_id': scene_id, 'command_id': directory.name, 'idempotent': True}
                if (request['operation']=='execute_plan' and old and old.get('revision')==request['revision']
                        and old.get('plan',{}).get('planning_request_id')==request['plan']['planning_request_id']):
                    self.error(409, 'This plan is already claimed; do not execute it with a new request ID')
            if len(commands) >= 128 and request['operation'] not in ('close','stop'):
                self.error(409, 'Scene command limit reached; close it before opening another')
            if not state['active'] or state['ownership_uncertain'] or state['status'] in ('failed', 'closed'):
                self.error(409, 'Scene actor is not available; it will not be replayed')
            if request['revision'] != state.get('revision'):
                self.error(409, 'Scene revision changed; refresh before another operation')
            if request['operation'] == 'stop':
                current = state.get('current_command_id')
                if current is None:
                    pending = next((d for d in commands if not (d/'done.json').exists()
                                    and (read_json(d/'request.json') or {}).get('operation') in ('execute','execute_plan')),None)
                    current = pending.name if pending is not None else None
                save_json(stop_path, {'request': request, 'command_id': current, 'at': time.time()})
                if current:
                    save_json(folder / 'commands' / current / 'stop.json', {'at': time.time()})
                return {'scene_id': scene_id, 'command_id': current, 'stop_requested': bool(current)}
            if state['status'] not in ('idle', 'exhausted'):
                self.error(409, 'Wait for the current operation to finish or stop it')
            # Also check durable mailboxes not yet consumed by the actor.
            if any(not (d / 'done.json').exists() for d in commands):
                self.error(409, 'One command is pending; no implicit queue')
            if request['operation'] in ('execute', 'execute_plan'):
                spec = read_json(folder / 'scene_spec.json')
                if request['operation'] == 'execute' and (type(request['stage_id']) is not int or request['stage_id'] not in
                        {s['id'] for s in spec['table']['stages']}):
                    self.error(400, 'Stage is not in this registered scene catalog')
                if request['operation'] == 'execute_plan':
                    if state.get('plan_protocol') != 1:
                        self.error(409, 'This scene predates planning support; explicitly close and reopen it')
                    if request['plan']['scene_step'] != state.get('steps'):
                        self.error(409, 'Scene changed since planning; generate a new plan')
                    try:
                        plan_table(spec['table'], request['plan']['stage_ids'], state)
                    except (ValueError, KeyError, TypeError):
                        self.error(400, 'Unregistered, duplicate stages or exhausted shared plan budget')
                if state['status'] == 'exhausted':
                    self.error(409, 'Scene control budget exhausted; explicitly reset or close')
            command_id = 'cmd_' + uuid.uuid4().hex
            directory = private_directory(folder / 'commands' / command_id)
            save_json(directory / 'request.json', request)  # Claim before actor can observe it.
            return {'scene_id': scene_id, 'command_id': command_id, 'idempotent': False}

    def frame(self, scene_id):
        state = self.public(scene_id)
        try:
            value = read_preview(self.folder(scene_id), scene_id, state['active'])
        except (OSError, ValueError, KeyError, TypeError):
            value = {'available':False,'mode':'unavailable','frame':None}
        # Idle frame is a deliberately frozen physical scene, not a stale stream.
        value['mode'] = 'idle' if state['status'] in ('idle', 'exhausted') else value['mode']
        return value
