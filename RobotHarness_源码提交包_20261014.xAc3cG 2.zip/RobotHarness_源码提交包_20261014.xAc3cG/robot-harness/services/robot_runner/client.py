"""Loopback-only operator CLI; read the API token from a private file, never argv."""
from __future__ import annotations

import argparse
import http.client
import json
from pathlib import Path

from auth import load_token


def request(port, token_file, method, path, payload=None):
    token = load_token(token_file)
    headers = {'Authorization': 'Bearer ' + token.decode('ascii')}
    body = None
    if payload is not None:
        headers['Content-Type'] = 'application/json'
        body = json.dumps(payload, allow_nan=False)
    # No configurable remote URL, redirects or ambient HTTP proxy handling.
    connection = http.client.HTTPConnection('127.0.0.1', port, timeout=15)
    try:
        connection.request(method, path, body=body, headers=headers)
        response = connection.getresponse()
        return response.status, json.loads(response.read())
    finally:
        connection.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=18431)
    parser.add_argument('--token-file', type=Path,
                        default=Path(__file__).resolve().parent / 'private/api.token')
    commands = parser.add_subparsers(dest='operation', required=True)
    commands.add_parser('health')
    commands.add_parser('tasks')
    for name in ('status', 'result', 'stop'):
        commands.add_parser(name).add_argument('run_id')
    start = commands.add_parser('start', help='Starts real motion ONLY when server execution is enabled')
    start.add_argument('--task-id', required=True)
    start.add_argument('--policy', choices=['atomic', 'internw0'], required=True)
    start.add_argument('--seed', type=int, required=True)
    start.add_argument('--request-id', required=True, help='Keep unchanged when retrying the SAME request')
    args = parser.parse_args(argv)
    if not 1 <= args.port <= 65535:
        parser.error('Invalid loopback port')
    payload = None
    method = 'GET'
    if args.operation in ('health', 'tasks'):
        path = '/' + args.operation
    elif args.operation == 'start':
        path, method = '/runs', 'POST'
        payload = {key: getattr(args, key) for key in ('task_id', 'policy', 'seed', 'request_id')}
    else:
        if len(args.run_id) != 36 or not args.run_id.startswith('run_') or any(
                c not in '0123456789abcdef' for c in args.run_id[4:]):
            parser.error('Invalid run_id')
        path = '/runs/' + args.run_id
        if args.operation in ('result', 'stop'):
            path += '/' + args.operation
        if args.operation == 'stop':
            method, payload = 'POST', {}
    try:
        status, value = request(args.port, args.token_file, method, path, payload)
    except (OSError, ValueError, http.client.HTTPException):
        # Do not echo credentials, headers or untrusted exception messages.
        print(json.dumps({'error': 'Cannot read private token or contact loopback robot_runner'}))
        return 1
    print(json.dumps({'http_status': status, 'response': value}, ensure_ascii=False, indent=2))
    return 0 if 200 <= status < 300 else 1


if __name__ == '__main__':
    raise SystemExit(main())
