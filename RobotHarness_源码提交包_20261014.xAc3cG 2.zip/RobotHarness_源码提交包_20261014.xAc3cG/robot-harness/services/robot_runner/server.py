"""Loopback HTTP facade over the existing CLI. Python 3.10+, standard library."""
from __future__ import annotations

import argparse
import hmac
import json
from pathlib import Path
import re
import signal
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from auth import load_token, validate_token
from manager import APIError, RunManager

MAX_BODY = 8192


def object_pairs(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('Duplicate JSON key')
        value[key] = item
    return value


def reject_constant(value):
    raise ValueError('Non-finite JSON number')


class RunnerHTTPServer(ThreadingHTTPServer):
    daemon_threads = False
    # Reuse closed connections' TIME_WAIT addresses during a same-port restart.
    # No SO_REUSEPORT: a second live listener must still fail to bind.
    allow_reuse_address = True

    def __init__(self, port, manager, *, auth_token):
        self.manager = manager
        self._auth_token = validate_token(auth_token)
        super().__init__(('127.0.0.1', port), Handler)


class Handler(BaseHTTPRequestHandler):
    server_version = 'RobotRunner/0.1'
    sys_version = ''

    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, format, *args):
        pass  # No bodies, headers, credentials or user-supplied URLs in logs.

    def reply(self, status, value):
        body = json.dumps(value, ensure_ascii=False, allow_nan=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        if status == 401:
            self.send_header('WWW-Authenticate', 'Bearer realm="robot_runner"')
        self.end_headers()
        self.wfile.write(body)

    def permitted(self):
        if self.headers.get('Origin') is not None:
            raise APIError(403, 'Browser origins are not accepted')
        hosts = self.headers.get_all('Host', [])
        if len(hosts) != 1 or not re.fullmatch(r'(localhost|127\.0\.0\.1)(:[0-9]+)?', hosts[0]):
            raise APIError(403, 'Loopback Host required')
        credentials = self.headers.get_all('Authorization', [])
        if len(credentials) != 1:
            raise APIError(401, 'Valid Bearer authentication required')
        scheme, separator, token = credentials[0].partition(' ')
        try:
            supplied = token.encode('ascii')
        except UnicodeError:
            raise APIError(401, 'Valid Bearer authentication required') from None
        if (not separator or scheme.lower() != 'bearer'
                or not hmac.compare_digest(supplied, self.server._auth_token)):
            raise APIError(401, 'Valid Bearer authentication required')

    def body(self):
        if self.headers.get('Transfer-Encoding') is not None:
            raise APIError(400, 'Transfer-Encoding is not supported')
        lengths = self.headers.get_all('Content-Length', [])
        if len(lengths) != 1 or not lengths[0].isdigit():
            raise APIError(411, 'A single Content-Length is required')
        length = int(lengths[0])
        if length > MAX_BODY:
            raise APIError(413, 'Request body too large')
        if self.headers.get('Content-Type', '').split(';', 1)[0].strip().lower() != 'application/json':
            raise APIError(415, 'application/json required')
        try:
            raw = self.rfile.read(length)
            if len(raw) != length:
                raise ValueError('Incomplete body')
            return json.loads(raw.decode('utf-8'), object_pairs_hook=object_pairs,
                              parse_constant=reject_constant)
        except (ValueError, UnicodeError, OSError):
            raise APIError(400, 'Invalid JSON body')

    def dispatch(self):
        self.permitted()
        manager = self.server.manager
        if self.command == 'GET' and self.path == '/health':
            return 200, {'service': 'robot_runner', 'version': '0.1.0',
                         'runs_enabled': manager.enable_runs, 'max_active_runs': 1}
        if self.command == 'GET' and self.path == '/tasks':
            return 200, manager.tasks()
        if self.command == 'GET' and self.path == '/runs':
            return 200, manager.list_runs()
        if self.command == 'POST' and self.path == '/runs':
            value = manager.create(self.body())
            return (200 if value['idempotent'] else 202), value
        if self.command == 'GET' and self.path == '/scenes':
            return 200, manager.scenes.listing()
        if self.command == 'POST' and self.path == '/scenes':
            value = manager.scenes.open(self.body())
            return (200 if value['idempotent'] else 202), value
        scene = re.fullmatch(r'/scenes/(scene_[a-f0-9]{32})(?:/(commands|frame))?', self.path)
        if scene:
            scene_id, operation = scene.groups()
            with manager.lock:
                if self.command == 'GET' and operation is None:
                    return 200, manager.scenes.public(scene_id)
                if self.command == 'GET' and operation == 'frame':
                    return 200, manager.scenes.frame(scene_id)
                if self.command == 'POST' and operation == 'commands':
                    value = manager.scenes.command(scene_id, self.body())
                    return (200 if value.get('idempotent') else 202), value
        match = re.fullmatch(r'/runs/(run_[a-f0-9]{32})(?:/(stop|result|frame|details))?', self.path)
        if match:
            run_id, operation = match.groups()
            if self.command == 'GET' and operation is None:
                return 200, manager.get(run_id)
            if self.command == 'GET' and operation == 'result':
                return manager.result(run_id)
            if self.command == 'GET' and operation == 'frame':
                return 200, manager.frame(run_id)
            if self.command == 'GET' and operation == 'details':
                return 200, manager.details(run_id)
            if self.command == 'POST' and operation == 'stop':
                if self.body() != {}:
                    raise APIError(400, 'stop accepts only an empty JSON object')
                value = manager.stop(run_id)
                return (202 if value['stop_requested'] else 200), value
        raise APIError(404, 'Unknown route')

    def handle_request_method(self):
        try:
            status, value = self.dispatch()
        except APIError as error:
            status, value = error.status, {'error': error.message}
        except Exception:
            status, value = 500, {'error': 'Internal error; inspect private service state'}
        try:
            self.reply(status, value)
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            pass  # Client disconnect must not cancel/replay a run.

    do_GET = handle_request_method
    do_POST = handle_request_method


def main(argv=None):
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--registry', type=Path, default=here / 'registry.empty.json')
    parser.add_argument('--state-dir', type=Path, default=here / 'state')
    parser.add_argument('--port', type=int, default=18431)
    parser.add_argument('--token-file', type=Path, required=True,
                        help='Private API token file; never pass the token itself on the command line')
    parser.add_argument('--enable-runs', action='store_true', help='Explicit operator opt-in; not experimental authorization')
    args = parser.parse_args(argv)
    if not 0 <= args.port <= 65535:
        parser.error('Invalid port')
    try:
        auth_token = load_token(args.token_file)
    except ValueError as error:
        parser.error(str(error))
    manager = RunManager(args.state_dir, args.registry, enable_runs=args.enable_runs)
    stop = threading.Event()
    server = None

    def interrupted(signum, frame):
        stop.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, interrupted)
    try:
        server = RunnerHTTPServer(args.port, manager, auth_token=auth_token)
        server.timeout = 0.2
        print(json.dumps({'event': 'ready', 'host': '127.0.0.1', 'port': server.server_port,
                          'runs_enabled': args.enable_runs}), flush=True)
        while not stop.is_set():
            server.handle_request()
            with manager.lock:
                for record in manager.records.values():
                    if record.get('active'):
                        manager._reconcile(record)
    finally:
        if server is not None:
            server.server_close()  # Wait for handlers, but not robot workers.
        manager.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
