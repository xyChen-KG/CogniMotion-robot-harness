"""Fixed scene-control SSH entrypoint. JSON stdin, no client URLs or file paths."""
import json
from pathlib import Path
import sys

from client import request
from scenes import SCENE


def main():
    try:
        raw = sys.stdin.buffer.read(8193)
        if len(raw) > 8192:
            raise ValueError('Request too large')
        def pairs(items):
            value = {}
            for key, item in items:
                if key in value:
                    raise ValueError('Duplicate key')
                value[key] = item
            return value
        packet = json.loads(raw, object_pairs_hook=pairs,
                            parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
        if not isinstance(packet, dict) or set(packet) != {'op', 'input'}:
            raise ValueError('Invalid request')
        op, args = packet['op'], packet['input']
        if not isinstance(args, dict):
            raise ValueError('Object required')
        if op == 'open':
            method, path, payload = 'POST', '/scenes', args
        elif op == 'command' and isinstance(args.get('scene_id'), str) and SCENE.fullmatch(args['scene_id']):
            method, path = 'POST', '/scenes/' + args['scene_id'] + '/commands'
            payload = {k: v for k, v in args.items() if k != 'scene_id'}
        else:
            raise ValueError('Only fixed scene commands are supported')
        status, body = request(18431, Path(__file__).resolve().parent / 'private/api.token', method, path, payload)
        print(json.dumps({'http_status': status, 'response': body}, ensure_ascii=False))
        return 0  # HTTP conflicts are explicit responses, never implicit retries.
    except Exception:
        print(json.dumps({'http_status': 503, 'response': {'error': 'Scene service unreachable; do not replay with a new request identity'}}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
