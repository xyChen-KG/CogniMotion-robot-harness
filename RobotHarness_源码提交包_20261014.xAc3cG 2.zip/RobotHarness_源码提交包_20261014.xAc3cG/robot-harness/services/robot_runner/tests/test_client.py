"""Operator CLI regression tests using only the test loopback service."""
import contextlib
import io
import json
from pathlib import Path
import sys
import threading
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from auth import create_token_file, load_token
from client import main
from server import RunnerHTTPServer
import test_runner


class ClientTests(unittest.TestCase):
    def setUp(self):
        self.case = test_runner.RunnerTests()
        self.case.setUp()
        self.token_file = self.case.root / 'api.token'
        create_token_file(self.token_file)
        self.token = load_token(self.token_file)
        self.server = RunnerHTTPServer(0, self.case.manager, auth_token=self.token)
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={'poll_interval': 0.02}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)
        self.case.tearDown()

    def invoke(self, args):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = main(['--port', str(self.server.server_port), '--token-file', str(self.token_file)] + args)
        self.assertNotIn(self.token.decode('ascii'), output.getvalue())
        return code, json.loads(output.getvalue())

    def test_read_only_commands_and_disabled_start(self):
        for command in ('health', 'tasks'):
            code, reply = self.invoke([command])
            self.assertEqual(code, 0)
            self.assertEqual(reply['http_status'], 200)
        self.case.manager.enable_runs = False
        code, reply = self.invoke(['start', '--task-id', 'success', '--policy', 'atomic',
                                  '--seed', '47', '--request-id', 'must-stay-disabled'])
        self.assertEqual(code, 1)
        self.assertEqual(reply['http_status'], 403)
        self.assertFalse(self.case.manager.records)

    def test_start_status_stop_and_result(self):
        code, reply = self.invoke(['start', '--task-id', 'slow', '--policy', 'atomic',
                                  '--seed', '47', '--request-id', 'client-smoke'])
        self.case.handles.extend(self.case.manager.children.values())
        self.assertEqual(code, 0)
        run_id = reply['response']['run_id']
        self.case.wait(run_id, lambda v: v['status'] == 'running')
        self.assertEqual(self.invoke(['status', run_id])[0], 0)
        self.assertEqual(self.invoke(['stop', run_id])[0], 0)
        self.case.wait(run_id)
        code, reply = self.invoke(['result', run_id])
        self.assertEqual(code, 0)
        self.assertEqual(reply['response']['status'], 'stopped')

    def test_missing_token_error_is_sanitized(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = main(['--token-file', str(self.case.root / 'missing.token'), 'health'])
        self.assertEqual(code, 1)
        self.assertEqual(json.loads(output.getvalue()), {
            'error': 'Cannot read private token or contact loopback robot_runner'})
