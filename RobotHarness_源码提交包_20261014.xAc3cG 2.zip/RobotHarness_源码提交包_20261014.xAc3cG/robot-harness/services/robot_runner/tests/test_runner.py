import concurrent.futures
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from files import identity, read_json, save_json, sha256
from manager import APIError, RunManager


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='robot_runner_test_')
        self.root = Path(self.temporary.name)
        self.fake = HERE / 'tests/fake_executor.py'
        tasks = []
        for mode in ('success', 'task_failure', 'native_only', 'workflow_only', 'slow',
                     'validation_failure', 'no_result', 'executor_error'):
            table_path = self.root / (mode + '.json')
            save_json(table_path, {'task': {'suite': mode, 'seed': 47},
                                  'budget': {'max_steps': 40},
                                  'stages': [{'id': 1, 'instruction': 'test', 'completed': False}]})
            tasks.append({'id': mode, 'title': mode, 'python': sys.executable,
                          'entrypoint': str(self.fake), 'task_table': str(table_path),
                          'cwd': str(self.root), 'env': {}, 'allowed_seeds': [47, 48],
                          'policies': {'atomic': {'atomic_port': 18321, 'atomic_replan_steps': 10}},
                          'sha256': {str(self.fake): sha256(self.fake), str(table_path): sha256(table_path)},
                          'render_gpu': 0, 'settling_steps': 0})
        self.registry = self.root / 'registry.json'
        save_json(self.registry, {'version': 1, 'tasks': tasks})
        self.manager = RunManager(self.root / 'state', self.registry, enable_runs=True)
        self.handles = []

    def tearDown(self):
        # Stop only the guardians created by this test via their private mailbox.
        for folder in (self.root / 'state').glob('run_*'):
            worker = read_json(folder / 'worker_state.json') or {}
            if not worker.get('finished_at'):
                save_json(folder / 'stop.json', {'test_cleanup': True})
        deadline = time.monotonic() + 6
        while time.monotonic() < deadline:
            pending = [p for p in self.handles if p.poll() is None]
            pending += [p for p in self.manager.children.values() if p.poll() is None]
            if not pending:
                break
            time.sleep(0.05)
        for p in self.handles + list(self.manager.children.values()):
            if p.poll() is None:
                # Owned, unreaped test subprocess, never an external PID.
                p.terminate()
            p.wait(timeout=5)
        self.manager.close()
        self.temporary.cleanup()

    def request(self, mode='success', request_id='request1'):
        return {'task_id': mode, 'policy': 'atomic', 'seed': 47, 'request_id': request_id}

    def start(self, mode='success', request_id='request1'):
        value = self.manager.create(self.request(mode, request_id))
        if value['run_id'] in self.manager.children:
            self.handles.append(self.manager.children[value['run_id']])
        return value['run_id']

    def wait(self, run_id, predicate=lambda v: not v['active']):
        deadline = time.monotonic() + 7
        while time.monotonic() < deadline:
            value = self.manager.get(run_id)
            if predicate(value):
                return value
            time.sleep(0.04)
        self.fail('Timed out waiting: ' + repr(value))

    def test_normal_end_and_artifacts(self):
        run_id = self.start()
        status = self.wait(run_id)
        self.assertEqual(status['status'], 'finished')
        self.assertEqual((status['vla_steps'], status['tool_steps'], status['stage_count']), (7, 2, 1))
        code, result = self.manager.result(run_id)
        self.assertEqual(code, 200)
        self.assertTrue(result['summary']['native_success'])
        self.assertIn('episode/episode.mp4', [a['path'] for a in result['artifacts']])
        self.assertIsNone(self.manager.tasks()['tasks'][0].get('command'))

    def test_repeated_observation_does_not_rewrite_identical_record(self):
        run_id = self.start()
        self.wait(run_id)
        with patch('manager.save_json', wraps=save_json) as saved:
            for _ in range(3):
                self.manager.get(run_id)
                self.manager.frame(run_id)
                self.manager.list_runs()
            self.assertEqual(saved.call_count, 0)

    def test_task_failure_is_finished_not_crash(self):
        run_id = self.start('task_failure')
        self.assertEqual(self.wait(run_id)['status'], 'finished')
        self.assertFalse(self.manager.result(run_id)[1]['summary']['native_success'])

    def test_native_and_workflow_preserved_independently(self):
        for mode, native, workflow in [('native_only', True, False), ('workflow_only', False, False)]:
            run_id = self.start(mode, mode)
            self.wait(run_id)
            summary = self.manager.result(run_id)[1]['summary']
            self.assertEqual(summary['native_success'], native)
            self.assertEqual(summary['workflow_success'], workflow)

    def test_start_and_validation_failure(self):
        with patch('manager.subprocess.Popen', side_effect=OSError('simulated exec failure')):
            run_id = self.start()
        self.assertEqual(self.manager.get(run_id)['status'], 'start_failed')
        self.assertEqual(self.manager.create(self.request())['run_id'], run_id)
        second = self.start('validation_failure', 'validation')
        self.assertEqual(self.wait(second)['status'], 'start_failed')

    def test_stop_and_pending_result(self):
        run_id = self.start('slow')
        self.wait(run_id, lambda v: v['status'] == 'running')
        self.assertEqual(self.manager.result(run_id)[0], 202)
        self.assertTrue(self.manager.stop(run_id)['stop_requested'])
        self.assertEqual(self.wait(run_id)['status'], 'stopped')
        self.assertTrue(self.manager.result(run_id)[1]['result_available'])
        self.assertFalse(self.manager.stop(run_id)['stop_requested'])

    def test_duplicate_and_conflicting_requests(self):
        run_id = self.start('slow')
        self.assertEqual(self.manager.create(self.request('slow'))['run_id'], run_id)
        with self.assertRaises(APIError) as error:
            self.manager.create(self.request('success'))
        self.assertEqual(error.exception.status, 409)

    def test_concurrent_rejection(self):
        def submit(index):
            try:
                return self.manager.create(self.request('slow', 'concurrent' + str(index)))
            except APIError as error:
                return error.status
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            values = list(pool.map(submit, [1, 2]))
        self.assertEqual(sum(isinstance(v, dict) for v in values), 1)
        self.assertIn(409, values)
        self.handles.extend(self.manager.children.values())

    def test_restart_live_and_completed_no_replay(self):
        run_id = self.start('slow')
        self.wait(run_id, lambda v: v['status'] == 'running')
        self.manager.close()
        self.manager = RunManager(self.root / 'state', self.registry, enable_runs=True)
        self.assertTrue(self.manager.get(run_id)['active'])
        self.assertEqual(self.manager.create(self.request('slow'))['run_id'], run_id)
        self.manager.stop(run_id)
        self.wait(run_id)
        self.manager.close()
        self.manager = RunManager(self.root / 'state', self.registry, enable_runs=True)
        self.assertEqual(self.manager.get(run_id)['status'], 'stopped')
        self.assertEqual(self.manager.create(self.request('slow'))['run_id'], run_id)
        self.assertFalse(self.manager.children)

    def test_restart_query_failure_retains_slot_and_refuses_stop(self):
        run_id = self.start('slow')
        self.wait(run_id, lambda v: v['status'] == 'running')
        guardian = self.handles[-1]
        self.manager.close()
        with patch('files._read_process_identity', side_effect=PermissionError('query unavailable')):
            self.manager = RunManager(self.root / 'state', self.registry, enable_runs=True)
            status = self.manager.get(run_id)
            self.assertIsNone(guardian.poll())  # The regression's process is truly alive.
            self.assertEqual(status['status'], 'interrupted')
            self.assertTrue(status['active'])
            self.assertTrue(status['ownership_uncertain'])
            self.assertEqual(self.manager.result(run_id)[0], 202)
            self.assertEqual(self.manager.create(self.request('slow'))['run_id'], run_id)
            with self.assertRaises(APIError) as error:
                self.manager.create(self.request('success', 'must_not_start'))
            self.assertEqual(error.exception.status, 409)
            with self.assertRaises(APIError) as error:
                self.manager.stop(run_id)
            self.assertEqual(error.exception.status, 409)
            self.assertFalse((self.root / 'state' / run_id / 'stop.json').exists())
        # Once queries recover, attach to the SAME run, never replay it.
        self.assertTrue(self.manager.get(run_id)['active'])
        self.assertFalse(self.manager.get(run_id)['ownership_uncertain'])
        self.manager.stop(run_id)
        self.assertEqual(self.wait(run_id)['status'], 'stopped')

    def test_terminal_state_does_not_override_unknown_guardian(self):
        run_id = self.start()
        self.wait(run_id)
        self.manager.close()
        with patch('files._read_process_identity', side_effect=subprocess.TimeoutExpired('ps', 2)):
            self.manager = RunManager(self.root / 'state', self.registry, enable_runs=True)
            status = self.manager.get(run_id)
            self.assertTrue(status['active'])
            self.assertTrue(status['ownership_uncertain'])
            with self.assertRaises(APIError):
                self.manager.create(self.request('success', 'must_wait'))
        self.assertEqual(self.manager.get(run_id)['status'], 'finished')
        self.assertFalse(self.manager.get(run_id)['active'])

    def test_gone_guardian_unknown_child_retains_slot(self):
        run_id = 'run_' + 'c' * 32
        folder = self.root / 'state' / run_id
        folder.mkdir()
        guardian = {'pid': 101, 'birth': 'guardian', 'platform': 'linux'}
        child = {'pid': 102, 'birth': 'child', 'platform': 'linux'}
        record = {'run_id': run_id, 'request': self.request(), 'status': 'running',
                  'worker_identity': guardian, 'active': True}
        self.manager.records[run_id] = record
        self.manager._save(record)
        save_json(folder / 'worker_state.json', {'status': 'running', 'worker_identity': guardian,
                  'child_identity': child, 'child_spawn_attempted': True, 'child_exit_observed': False})
        def query(pid):
            if pid == guardian['pid']:
                raise ProcessLookupError(pid)
            raise PermissionError('child query unavailable')
        with patch('files._read_process_identity', side_effect=query):
            status = self.manager.get(run_id)
            self.assertTrue(status['active'])
            self.assertTrue(status['ownership_uncertain'])
            with self.assertRaises(APIError):
                self.manager.create(self.request('success', 'second'))
        # Positive absence evidence, not a timeout, can release the slot.
        with patch('files._read_process_identity', side_effect=ProcessLookupError()):
            self.assertFalse(self.manager.get(run_id)['active'])

    def test_missing_identity_is_interrupted_and_blocks(self):
        run_id = 'run_' + 'a' * 32
        folder = self.root / 'state' / run_id
        folder.mkdir()
        save_json(folder / 'record.json', {'run_id': run_id, 'request': self.request(),
                                          'status': 'starting', 'worker_identity': None})
        self.manager.close()
        self.manager = RunManager(self.root / 'state', self.registry, enable_runs=True)
        self.assertEqual(self.manager.get(run_id)['status'], 'interrupted')
        with self.assertRaises(APIError):
            self.manager.stop(run_id)
        with self.assertRaises(APIError):
            self.manager.create(self.request('success', 'another'))

    def test_pid_reuse_is_never_signalled(self):
        run_id = 'run_' + 'b' * 32
        folder = self.root / 'state' / run_id
        folder.mkdir()
        other = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(4)'])
        self.handles.append(other)
        wrong = identity(other.pid)
        wrong['birth'] += '-old'
        record = {'run_id': run_id, 'request': self.request(), 'status': 'running',
                  'worker_identity': wrong, 'active': True}
        self.manager.records[run_id] = record
        self.manager._save(record)
        save_json(folder / 'worker_state.json', {'status': 'running', 'worker_identity': wrong,
                                               'child_spawn_attempted': False})
        self.assertEqual(self.manager.get(run_id)['status'], 'interrupted')
        self.manager.stop(run_id)
        self.assertIsNone(other.poll())
        other.terminate()  # Only this test's own Popen handle.
        other.wait()

    def test_no_result_and_runtime_failure(self):
        run_id = self.start('no_result')
        self.assertEqual(self.wait(run_id)['status'], 'interrupted')
        self.assertFalse(self.manager.result(run_id)[1]['result_available'])
        second = self.start('executor_error', 'error')
        self.assertEqual(self.wait(second)['status'], 'failed')

    def test_validation_and_hash_pinning(self):
        for payload in [dict(self.request(), budget=9999), dict(self.request(), seed=True),
                        dict(self.request(), task_id='../bad')]:
            with self.assertRaises(APIError):
                self.manager.create(payload)
        (self.root / 'success.json').write_text('{}')
        with self.assertRaises(APIError) as error:
            self.manager.create(self.request())
        self.assertEqual(error.exception.status, 422)
        self.assertFalse(self.manager.records)

    def test_default_disable_and_state_lock(self):
        with self.assertRaises(RuntimeError):
            RunManager(self.root / 'state', self.registry)
        self.manager.enable_runs = False
        with self.assertRaises(APIError) as error:
            self.manager.create(self.request())
        self.assertEqual(error.exception.status, 403)

