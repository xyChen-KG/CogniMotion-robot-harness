import json
import os
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch, Mock

import test_runner
from files import identity, read_json, save_json
from manager import APIError, RunManager
from scenes import command_table,command_record,plan_table


class SceneManagerTests(unittest.TestCase):
    def setUp(self):
        self.fixture = test_runner.RunnerTests()
        self.fixture.setUp()
        self.manager = self.fixture.manager
        self.owner = 'a' * 64
    def tearDown(self):
        self.manager.scenes.children.clear()  # Synthetic Popen mock, no real actor.
        self.fixture.tearDown()
    def open_scene(self):
        request = dict(task_id='success',policy='atomic',seed=47,request_id='open1',owner=self.owner)
        fake = SimpleNamespace(pid=os.getpid(), poll=lambda:None)
        with patch('scenes.Popen',return_value=fake):
            result = self.manager.scenes.open(request)
        self.scene_id = result['scene_id']
        self.folder = self.manager.scenes.folder(self.scene_id)
        save_json(self.folder/'actor_state.json',dict(identity=identity(os.getpid()),status='idle',revision=1,
                  steps=0,current_command_id=None))
        return request,result
    def command(self, op='execute', **change):
        return dict(owner=self.owner,request_id='command1',revision=1,operation=op,
                    **({'stage_id':1} if op=='execute' else {}),**change)
    def test_open_is_idempotent_and_does_not_launch_a_vla_cli(self):
        request,result=self.open_scene()
        launched=Mock()
        with patch('scenes.Popen',launched):
            self.assertTrue(self.manager.scenes.open(request)['idempotent'])
            launched.assert_not_called()
        self.assertFalse((self.folder/'episode').exists())
        with self.assertRaises(APIError) as error:
            self.manager.create(self.fixture.request())
        self.assertEqual(error.exception.status,409)
    def test_mailbox_claims_and_rejects_implicit_queue(self):
        self.open_scene()
        a=self.manager.scenes.command(self.scene_id,self.command())
        b=self.manager.scenes.command(self.scene_id,self.command())
        self.assertEqual(a['command_id'],b['command_id'])
        self.assertTrue(b['idempotent'])
        with self.assertRaises(APIError):
            self.manager.scenes.command(self.scene_id,{**self.command(),'request_id':'different'})
    def test_owner_revision_and_unknown_stage_are_enforced(self):
        self.open_scene()
        for change in ({'owner':'b'*64},{'revision':2},{'stage_id':99},{'path':'/tmp'}, {'stage_id':True}):
            with self.assertRaises(APIError):
                self.manager.scenes.command(self.scene_id,{**self.command(),**change})
    def test_restart_attaches_to_actor_without_replay(self):
        self.open_scene()
        self.manager.close()
        launched=Mock()
        with patch('scenes.Popen',launched):
            other=RunManager(self.manager.root,self.fixture.registry,enable_runs=True)
            self.assertTrue(other.scenes.active())
            launched.assert_not_called()
            other.close()
    def test_unknown_identity_keeps_slot(self):
        self.open_scene()
        self.manager.scenes.children.clear()
        with patch('scenes.process_state',return_value='unknown'):
            self.assertTrue(self.manager.scenes.active())
            self.assertTrue(self.manager.scenes.public(self.scene_id)['ownership_uncertain'])
    def test_retried_stop_never_stops_a_new_command(self):
        self.open_scene()
        a=self.manager.scenes.command(self.scene_id,self.command())['command_id']
        state=read_json(self.folder/'actor_state.json')
        state.update(status='executing',current_command_id=a)
        save_json(self.folder/'actor_state.json',state)
        stop={**self.command('stop'),'request_id':'stop1'}
        first=self.manager.scenes.command(self.scene_id,stop)
        state.update(current_command_id=None,status='idle')
        save_json(self.folder/'actor_state.json',state)
        again=self.manager.scenes.command(self.scene_id,stop)
        self.assertEqual(first['command_id'],again['command_id'])
        self.assertTrue(again['idempotent'])

    def test_stop_pending_command_before_actor_consumes_mailbox(self):
        self.open_scene()
        command_id=self.manager.scenes.command(self.scene_id,self.command())['command_id']
        stop={**self.command('stop'),'request_id':'stop_pending'}
        reply=self.manager.scenes.command(self.scene_id,stop)
        self.assertEqual(reply['command_id'],command_id)
        self.assertTrue((self.folder/'commands'/command_id/'stop.json').is_file())

    def test_reset_record_retains_requested_and_resulting_revisions(self):
        row=command_record('cmd_test',1,{'status':'reset','revision':2})
        self.assertEqual(row['revision'],2)
        self.assertEqual(row['requested_revision'],1)

    def test_command_budget_is_cumulative_without_changing_registered_stage(self):
        from copy import deepcopy
        from harnesses.starHarness_Libero.tests.helpers import table
        base=table(2);before=deepcopy(base)
        result=command_table(base,2,dict(steps=2,policy_queries=3,state_requests=4,active_elapsed_seconds=2.3))
        self.assertEqual(base,before)
        self.assertEqual(result['stages'][0]['id'],1)
        self.assertEqual(result['stages'][0]['instruction'],base['stages'][1]['instruction'])
        self.assertEqual(result['budget']['max_steps'],base['budget']['max_steps']-2)
        self.assertEqual(result['budget']['max_policy_queries'],base['budget']['max_policy_queries']-3)
        self.assertEqual(result['budget']['max_wall_seconds'],base['budget']['max_wall_seconds']-3)
        with self.assertRaises(ValueError):command_table(base,1,{'steps':base['budget']['max_steps']})

    def test_plan_compiles_exact_skills_in_requested_order_with_shared_budget(self):
        from copy import deepcopy
        from harnesses.starHarness_Libero.tests.helpers import table
        base=table(3);before=deepcopy(base)
        result=plan_table(base,[3,1],{'steps':2})
        self.assertEqual(base,before)
        self.assertEqual([s['id'] for s in result['stages']],[1,2])
        for new,old in zip(result['stages'],[base['stages'][2],base['stages'][0]]):
            self.assertEqual({k:v for k,v in new.items() if k!='id'}, {k:v for k,v in old.items() if k!='id'})
        self.assertEqual(result['budget']['max_steps'],base['budget']['max_steps']-2)
        for ids in ([],[True],[99],[1,1],'1',[1]*33):
            with self.assertRaises(ValueError):plan_table(base,ids,{})

    def test_plan_claim_stale_rejection_and_stop_are_bound_to_the_same_operation(self):
        self.open_scene()
        plan={'planning_request_id':'plan_'+'a'*32,'goal':'Do the registered skill.','stage_ids':[1],'scene_step':0}
        request={**self.command('execute_plan'),'plan':plan}
        with self.assertRaises(APIError):self.manager.scenes.command(self.scene_id,request)
        state=read_json(self.folder/'actor_state.json');state['plan_protocol']=1;save_json(self.folder/'actor_state.json',state)
        spec=read_json(self.folder/'scene_spec.json')
        spec['table']['budget'].update(max_policy_queries=100,max_state_requests=100,max_wall_seconds=60)
        save_json(self.folder/'scene_spec.json',spec)
        for change in ({'scene_step':1},{'stage_ids':[1,1]},{'stage_ids':[99]},{'max_steps':99999}):
            with self.assertRaises(APIError):self.manager.scenes.command(self.scene_id,{**request,'plan':{**plan,**change}})
        first=self.manager.scenes.command(self.scene_id,request)
        self.assertEqual(first['command_id'],self.manager.scenes.command(self.scene_id,request)['command_id'])
        with self.assertRaises(APIError):self.manager.scenes.command(self.scene_id,{**request,'request_id':'new-id-same-plan'})
        stop=self.manager.scenes.command(self.scene_id,{**self.command('stop'),'request_id':'stop-plan'})
        self.assertEqual(stop['command_id'],first['command_id'])
        self.assertTrue((self.folder/'commands'/first['command_id']/'stop.json').exists())
