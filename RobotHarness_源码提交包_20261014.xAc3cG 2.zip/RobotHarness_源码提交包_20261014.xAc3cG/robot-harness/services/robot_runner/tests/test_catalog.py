"""Public config display from hash-pinned registrations only, no robot."""
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from registry import Registry
from files import save_json,sha256

class CatalogTests(unittest.TestCase):
    def test_real_table_redacted_and_changed_table_unknown(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);table=root/'table.json';entry=root/'entry.py';entry.write_text('# fixture')
            budget={'max_steps':3500,'check_interval_steps':10,'max_state_requests':300,'max_policy_queries':250,'max_wall_seconds':1200}
            save_json(table,{'task':{'suite':'fixture','seed':47},'stages':[{'id':1,'instruction':'Place the bowl.','max_steps':400,'completed':False,
                'checker':{'secret_internal_binding':'do-not-publish'}}],'budget':budget,'stable_steps':1,'completion_mode':'official_predicates'})
            task={'id':'task','title':'Task','python':sys.executable,'entrypoint':str(entry),'task_table':str(table),'cwd':tmp,
                'env':{},'allowed_seeds':[47],'policies':{'atomic':{'atomic_port':18321,'atomic_replan_steps':10}},
                'sha256':{str(entry):sha256(entry),str(table):sha256(table)},'render_gpu':0,'settling_steps':0}
            path=root/'registry.json';save_json(path,{'version':1,'tasks':[task]})
            registry=Registry(path);row=registry.listing()[0]
            self.assertTrue(row['configuration_available']);self.assertEqual(row['budget'],budget)
            self.assertEqual(row['stages'],[{'id':1,'instruction':'Place the bowl.','max_steps':400,'checker':None,'post_tools':[]}])
            self.assertNotIn(tmp,json.dumps(row));self.assertNotIn('secret_internal_binding',json.dumps(row))
            folder = root.resolve() / 'state' / 'run_fixture'
            _, launch = registry.prepare('task', 'atomic', 47, Path(os.path.relpath(folder)))
            for argv in (launch['command'], launch['validate_command']):
                self.assertEqual(Path(argv[argv.index('--task-table') + 1]), folder / 'task_table.json')
            self.assertEqual(Path(launch['command'][launch['command'].index('--output') + 1]), folder / 'episode')
            table.write_text('{}');bad=registry.listing()[0]
            self.assertFalse(bad['configuration_available']);self.assertIsNone(bad['budget']);self.assertIsNone(bad['stages'])
            table.unlink();table.symlink_to(entry)
            self.assertFalse(registry.listing()[0]['configuration_available'])

if __name__=='__main__':unittest.main()
