"""CLI startup smoke tests, empty registry and execution disabled."""
import http.client
import json
from pathlib import Path
import select
import subprocess
import sys
import tempfile
import time
import unittest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from auth import create_token_file, load_token
from files import save_json, sha256


class CLITests(unittest.TestCase):
    def test_relative_state_dir_with_different_executor_cwd(self):
        with tempfile.TemporaryDirectory(prefix='robot_runner_relative_') as temporary:
            root = Path(temporary)
            service_cwd, executor_cwd = root / 'service cwd', root / 'executor cwd'
            service_cwd.mkdir(); executor_cwd.mkdir()
            token_file = root / 'api.token'
            create_token_file(token_file)
            token = load_token(token_file)
            table, registry = root / 'table.json', root / 'registry.json'
            fake = HERE / 'tests/fake_executor.py'
            save_json(table, {'task': {'suite': 'success', 'seed': 47}, 'budget': {'max_steps': 40},
                              'stages': [{'id': 1, 'instruction': 'test', 'completed': False}]})
            save_json(registry, {'version': 1, 'tasks': [{
                'id': 'success', 'title': 'success', 'python': sys.executable,
                'entrypoint': str(fake), 'task_table': str(table), 'cwd': str(executor_cwd),
                'env': {}, 'allowed_seeds': [47],
                'policies': {'atomic': {'atomic_port': 18321, 'atomic_replan_steps': 10}},
                'sha256': {str(fake): sha256(fake), str(table): sha256(table)},
                'render_gpu': 0, 'settling_steps': 0}]})
            child = subprocess.Popen([sys.executable, '-B', '-u', str(HERE / 'server.py'),
                '--token-file', str(token_file), '--registry', str(registry),
                '--state-dir', 'state', '--enable-runs', '--port', '0'], cwd=service_cwd,
                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            run_id = None
            try:
                self.assertTrue(select.select([child.stdout], [], [], 5)[0])
                ready = json.loads(child.stdout.readline())
                def request(method, route, body=None):
                    client = http.client.HTTPConnection('127.0.0.1', ready['port'], timeout=5)
                    try:
                        client.request(method, route, json.dumps(body) if body is not None else None,
                            {'Authorization': 'Bearer ' + token.decode('ascii'), 'Content-Type': 'application/json'})
                        reply = client.getresponse()
                        return reply.status, json.loads(reply.read())
                    finally:
                        client.close()
                params = {'task_id': 'success', 'policy': 'atomic', 'seed': 47, 'request_id': 'relative-cwd'}
                code, started = request('POST', '/runs', params)
                self.assertEqual(code, 202)
                run_id = started['run_id']
                deadline = time.monotonic() + 5
                while time.monotonic() < deadline:
                    _, status = request('GET', '/runs/' + run_id)
                    if not status['active']:
                        break
                    time.sleep(.04)
                self.assertEqual(status['status'], 'finished', status)
                _, result = request('GET', '/runs/' + run_id + '/result')
                self.assertTrue(result['summary']['native_success'])
                output = Path(result['output_directory'])
                self.assertTrue(output.is_absolute())
                self.assertEqual(output.parent, service_cwd.resolve() / 'state' / run_id)
                self.assertTrue((output / 'episode.mp4').is_file())
                spec = json.loads((output.parent / 'launch.json').read_text())
                for argv in (spec['command'], spec['validate_command']):
                    self.assertEqual(Path(argv[argv.index('--task-table') + 1]), output.parent / 'task_table.json')
                self.assertEqual(Path(spec['command'][spec['command'].index('--output') + 1]), output)
                self.assertFalse((executor_cwd / 'state').exists())
                self.assertEqual(request('POST', '/runs', params)[1]['run_id'], run_id)
            finally:
                # Only the fake run and service created by this test are touched.
                if run_id:
                    save_json(service_cwd / 'state' / run_id / 'stop.json', {'test_cleanup': True})
                if child.poll() is None:
                    child.terminate()
                stdout, stderr = child.communicate(timeout=5)
                self.assertNotIn(token, stdout + stderr)

    def test_missing_or_public_token_fails_before_state_creation(self):
        with tempfile.TemporaryDirectory(prefix='robot_runner_cli_test_') as temporary:
            root = Path(temporary)
            state = root / 'state'
            command = [sys.executable, '-B', str(HERE / 'server.py'), '--port', '0',
                       '--state-dir', str(state)]
            result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5)
            self.assertEqual(result.returncode, 2)
            self.assertFalse(state.exists())
            token_file = root / 'api.token'
            create_token_file(token_file)
            token = load_token(token_file)
            token_file.chmod(0o644)
            result = subprocess.run(command + ['--token-file', str(token_file)],
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5)
            self.assertEqual(result.returncode, 2)
            self.assertFalse(state.exists())
            self.assertNotIn(token, result.stdout + result.stderr)

    def test_real_cli_loads_token_and_serves_only_authenticated_requests(self):
        with tempfile.TemporaryDirectory(prefix='robot_runner_cli_test_') as temporary:
            root = Path(temporary)
            token_file = root / 'api.token'
            create_token_file(token_file)
            token = load_token(token_file)
            command = [sys.executable, '-B', '-u', str(HERE / 'server.py'),
                       '--token-file', str(token_file), '--port', '0',
                       '--registry', str(HERE / 'registry.empty.json'), '--state-dir', str(root / 'state')]
            child = subprocess.Popen(command, stdin=subprocess.DEVNULL,
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            ready_line = b''
            try:
                self.assertTrue(select.select([child.stdout], [], [], 5)[0], 'CLI readiness timed out')
                ready_line = child.stdout.readline()
                ready = json.loads(ready_line)
                self.assertEqual(ready['event'], 'ready')
                self.assertFalse(ready['runs_enabled'])
                for auth, expected in ((False, 401), (True, 200)):
                    client = http.client.HTTPConnection('127.0.0.1', ready['port'], timeout=5)
                    try:
                        headers = {'Authorization': 'Bearer ' + token.decode('ascii')} if auth else {}
                        client.request('GET', '/tasks', headers=headers)
                        response = client.getresponse()
                        body = json.loads(response.read())
                        self.assertEqual(response.status, expected)
                        if auth:
                            self.assertEqual(body['tasks'], [])
                    finally:
                        client.close()
            finally:
                if child.poll() is None:
                    child.terminate()  # Only this test's own, execution-disabled service.
                try:
                    stdout, stderr = child.communicate(timeout=5)
                except subprocess.TimeoutExpired:
                    child.kill()
                    stdout, stderr = child.communicate(timeout=5)
                self.assertNotIn(token, ready_line + stdout + stderr)
            self.assertEqual(child.returncode, 0)
            self.assertEqual(stderr, b'')
