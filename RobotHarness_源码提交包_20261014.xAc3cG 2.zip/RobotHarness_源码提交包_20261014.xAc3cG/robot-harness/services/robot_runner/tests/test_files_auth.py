"""Process-query failure and private credential regression tests."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from auth import create_token_file, load_token
from files import identity, process_state, same_process


class ProcessStateTests(unittest.TestCase):
    def test_live_identity_and_reused_pid(self):
        saved = identity(os.getpid())
        self.assertIsInstance(saved, dict)
        self.assertEqual(process_state(saved), 'alive')
        self.assertTrue(same_process(saved))
        self.assertEqual(process_state(dict(saved, birth='not-the-saved-birth')), 'gone')

    def test_unknown_is_not_gone(self):
        saved = {'pid': 100, 'birth': 'saved'}
        failures = [PermissionError(), OSError('I/O failure'), ValueError(), IndexError(),
                    subprocess.TimeoutExpired('ps', 2), subprocess.CalledProcessError(1, 'ps')]
        for failure in failures:
            with self.subTest(failure=type(failure).__name__):
                with patch('files._read_process_identity', side_effect=failure):
                    self.assertEqual(process_state(saved), 'unknown')
                    self.assertFalse(same_process(saved))
        with patch('files._read_process_identity', return_value=None):
            self.assertEqual(process_state(saved), 'unknown')
        with patch('files._read_process_identity', side_effect=ProcessLookupError()):
            self.assertEqual(process_state(saved), 'gone')
        for saved in (None, {}, {'pid': True}, {'pid': -1}):
            self.assertEqual(process_state(saved), 'unknown')

    def test_linux_proc_absence_vs_query_failure(self):
        saved = {'pid': 100, 'birth': '42', 'boot': 'test-boot', 'platform': 'linux'}
        boot_path = '/proc/sys/kernel/random/boot_id'
        pid_path = '/proc/100/stat'
        fields = ['S'] + ['0'] * 18 + ['42']
        values = {boot_path: 'test-boot\n', pid_path: '100 (test process) ' + ' '.join(fields)}
        def read(path):
            value = values[str(path)]
            if isinstance(value, Exception):
                raise value
            return value
        with patch('files.sys.platform', 'linux'), patch('files.Path.read_text', autospec=True, side_effect=read):
            self.assertEqual(process_state(saved), 'alive')
            values[pid_path] = FileNotFoundError()
            with patch('files.os.kill', side_effect=ProcessLookupError()):
                self.assertEqual(process_state(saved), 'gone')
            with patch('files.os.kill', return_value=None):
                self.assertEqual(process_state(saved), 'unknown')
            with patch('files.os.kill', side_effect=PermissionError()):
                self.assertEqual(process_state(saved), 'unknown')
            values[pid_path] = PermissionError()
            self.assertEqual(process_state(saved), 'unknown')
            values[boot_path] = FileNotFoundError()
            self.assertEqual(process_state(saved), 'unknown')  # procfs unavailable != PID exit.
            values[boot_path] = 'test-boot'
            values[pid_path] = '100 (test process) Z ' + ' '.join(fields[1:])
            self.assertEqual(process_state(saved), 'gone')

    def test_mac_ps_failure_requires_positive_absence(self):
        saved = {'pid': 100, 'birth': 'saved', 'platform': 'darwin'}
        with patch('files.sys.platform', 'darwin'), patch('files.subprocess.check_output',
                side_effect=subprocess.CalledProcessError(1, 'ps')):
            with patch('files.os.kill', return_value=None) as probe:
                self.assertEqual(process_state(saved), 'unknown')
                probe.assert_called_once_with(100, 0)
            with patch('files.os.kill', side_effect=PermissionError()):
                self.assertEqual(process_state(saved), 'unknown')
            with patch('files.os.kill', side_effect=ProcessLookupError()):
                self.assertEqual(process_state(saved), 'gone')


class TokenFileTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='robot_runner_auth_test_')
        self.root = Path(self.temporary.name)
        self.path = self.root / 'api.token'

    def tearDown(self):
        self.temporary.cleanup()

    def test_private_token_roundtrip_and_never_overwrite(self):
        create_token_file(self.path)
        token = load_token(self.path)
        self.assertEqual(len(token), 43)
        self.assertEqual(self.path.stat().st_mode & 0o777, 0o600)
        with self.assertRaises(FileExistsError):
            create_token_file(self.path)
        self.assertEqual(load_token(self.path), token)
        self.path.chmod(0o400)
        self.assertEqual(load_token(self.path), token)

    def test_missing_public_symlink_and_fifo_rejected(self):
        with self.assertRaises(ValueError):
            load_token(self.path)
        create_token_file(self.path)
        self.path.chmod(0o644)
        with self.assertRaises(ValueError):
            load_token(self.path)
        self.path.chmod(0o600)
        link = self.root / 'symlink.token'
        link.symlink_to(self.path)
        with self.assertRaises(ValueError):
            load_token(link)
        fifo = self.root / 'fifo.token'
        os.mkfifo(fifo, 0o600)
        with self.assertRaises(ValueError):
            load_token(fifo)  # O_NONBLOCK: do not hang opening an attacker-supplied FIFO.

    def test_other_owner_and_invalid_contents_rejected_without_echo(self):
        create_token_file(self.path)
        info = self.path.stat()
        with patch('auth.os.getuid', return_value=info.st_uid + 1):
            with self.assertRaises(ValueError):
                load_token(self.path)
        for contents in (b'short', b'A' * 129, b'A' * 43 + b'\n\n', b'A' * 42 + b' ', b'A' * 42 + b'\xff'):
            self.path.write_bytes(contents)
            with self.assertRaises(ValueError) as error:
                load_token(self.path)
            self.assertNotIn(repr(contents), str(error.exception))

    def test_generator_refuses_public_parent_without_chmod(self):
        public = self.root / 'public'
        public.mkdir(mode=0o755)
        public.chmod(0o755)
        with self.assertRaises(ValueError):
            create_token_file(public / 'api.token')
        self.assertEqual(public.stat().st_mode & 0o777, 0o755)
        self.assertFalse((public / 'api.token').exists())
