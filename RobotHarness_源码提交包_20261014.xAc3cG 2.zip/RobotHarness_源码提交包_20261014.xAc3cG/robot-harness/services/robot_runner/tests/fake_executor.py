"""TEST ONLY: simulate current CLI/files. No robot, model or network imports."""
import argparse
import json
from pathlib import Path
import signal
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from files import read_json, save_json

parser = argparse.ArgumentParser()
parser.add_argument('command', choices=['validate', 'run'])
parser.add_argument('--task-table', required=True)
parser.add_argument('--output')
args, unused = parser.parse_known_args()
table = read_json(args.task_table)
mode = table['task']['suite']
if args.command == 'validate':
    if mode == 'validation_failure':
        raise SystemExit(2)
    print(json.dumps({'valid': True}))
    raise SystemExit(0)
if mode == 'no_result':
    raise SystemExit(3)
output = Path(args.output)
output.mkdir(exist_ok=False)
save_json(output / 'task_table.json', table)
save_json(output / 'episode_claim.json', {'pid': __import__('os').getpid()})
stop = False


def stopped(signum, frame):
    global stop
    stop = True


signal.signal(signal.SIGTERM, stopped)
progress = {'status': 'running', 'stage_count': 1, 'vla_steps': 7, 'tool_steps': 2,
            'steps': 9, 'completed_stage_ids': [],
            'stage_states': {'1': {'achieved_once': False, 'current_satisfied': False}}}
save_json(output / 'progress.json', progress)
(output / 'controller_trace.jsonl').write_text('{"event":"stage_start","stage_id":1,"step":0}\n')
# Test file only; do not claim playable video.
(output / 'episode.mp4').write_bytes(b'test artifact, not real video')
deadline = time.monotonic() + (2.5 if mode == 'slow' else 0.25)
while time.monotonic() < deadline and not stop:
    time.sleep(0.02)
native = mode not in ('task_failure', 'workflow_only', 'executor_error')
result = dict(progress, status='error' if stop or mode == 'executor_error' else 'complete',
              native_success=native and not stop, success=native and not stop,
              task_success=native and not stop, workflow_success=mode == 'success',
              all_stages_completed=mode != 'native_only',
              completed_stage_ids=[] if mode == 'native_only' else [1],
              elapsed_seconds=0.3, termination_reason='signal' if stop else 'finished',
              error='Termination signal 15' if stop else 'simulated interface error' if mode == 'executor_error' else None)
save_json(output / 'result.json', result)
raise SystemExit(1 if result['status'] == 'error' else 0)
