"""Real loopback HTTP, fake executor only: no models, simulation or paid calls."""
import http.client
import json
from pathlib import Path
import secrets
import sys
import threading
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from manager import RunManager
from server import RunnerHTTPServer
from files import save_json, sha256
from registry import Registry
import test_runner


class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.case = test_runner.RunnerTests()
        self.case.setUp()
        self.token = secrets.token_urlsafe(32).encode('ascii')
        self.open_server()

    def open_server(self):
        self.server = RunnerHTTPServer(0, self.case.manager, auth_token=self.token)
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={'poll_interval': 0.02}, daemon=True)
        self.thread.start()

    def close_server(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)

    def tearDown(self):
        self.close_server()
        self.case.tearDown()

    def request(self, method, path, payload=None, *, authenticated=True, headers=None, raw=None):
        headers = dict(headers or {})
        if authenticated:
            headers.setdefault('Authorization', 'Bearer ' + self.token.decode('ascii'))
        if payload is not None or raw is not None:
            headers.setdefault('Content-Type', 'application/json')
        body = raw if raw is not None else json.dumps(payload) if payload is not None else None
        client = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        try:
            client.request(method, path, body=body, headers=headers)
            response = client.getresponse()
            return response.status, json.loads(response.read()), dict(response.getheaders())
        finally:
            client.close()

    def test_all_routes_require_authentication_before_side_effects(self):
        run_id = 'run_' + 'a' * 32
        routes = [('GET', '/health', None), ('GET', '/tasks', None),
                  ('GET','/scenes',None),('POST','/scenes',{}),
                  ('POST','/scenes/scene_'+'a'*32+'/commands',{}),
                  ('GET', '/runs/' + run_id + '/details', None),
                  ('GET', '/runs', None), ('GET', '/runs/' + run_id + '/frame', None),
                  ('POST', '/runs', self.case.request()), ('GET', '/runs/' + run_id, None),
                  ('GET', '/runs/' + run_id + '/result', None),
                  ('POST', '/runs/' + run_id + '/stop', {})]
        for method, path, payload in routes:
            for headers in ({}, {'Authorization': 'Bearer incorrect'}, {'Authorization': 'Basic incorrect'}):
                with self.subTest(method=method, path=path, credential_type=list(headers)):
                    code, body, reply_headers = self.request(method, path, payload,
                        authenticated=False, headers=headers)
                    self.assertEqual(code, 401)
                    self.assertIn('WWW-Authenticate', reply_headers)
                    self.assertNotIn(self.token.decode('ascii'), json.dumps(body))
        self.assertFalse(self.case.manager.records)
        self.assertFalse(self.case.manager.children)

    def test_list_and_frame_are_read_only(self):
        self.assertEqual(self.request('GET', '/runs')[1], {'runs': []})
        run_id = self.case.start()
        self.case.wait(run_id)
        runs = self.request('GET', '/runs')[1]['runs']
        self.assertEqual([r['run_id'] for r in runs], [run_id])
        code, packet, _ = self.request('GET', '/runs/' + run_id + '/frame')
        self.assertEqual(code, 200)
        self.assertFalse(packet['available'])
        self.assertEqual(len(self.case.manager.records), 1)
        code, details, _ = self.request('GET', '/runs/' + run_id + '/details')
        self.assertEqual(code, 200); self.assertEqual(details['run_id'], run_id)
        self.assertEqual(len(self.case.manager.records), 1)
        self.assertEqual(self.request('GET', '/runs/' + run_id + '/details?path=/private')[0], 404)

    def test_task_catalog_is_public_hash_pinned_and_read_only(self):
        table_path = self.case.root / 'success.json'
        table = {'task': {'suite': 'success', 'seed': 47}, 'completion_mode': 'stable_conditions',
                 'stable_steps': 1, 'private_note': '/private/never-publish',
                 'budget': {'max_steps': 3500, 'check_interval_steps': 10, 'max_state_requests': 300,
                            'max_policy_queries': 250, 'max_wall_seconds': 1200},
                 'stages': [{'id': 1, 'instruction': 'Put the bowl on the plate.', 'max_steps': 400,
                             'completed': False, 'private_note': 'never-publish'}]}
        registry = json.loads(self.case.registry.read_text())
        def pin(value):
            save_json(table_path, value)
            registry['tasks'][0]['sha256'][str(table_path)] = sha256(table_path)
            save_json(self.case.registry, registry)
            self.case.manager.registry = Registry(self.case.registry)
        pin(table)
        code, result, _ = self.request('GET', '/tasks')
        self.assertEqual(code, 200)
        row = result['tasks'][0]
        self.assertTrue(row['configuration_available'])
        self.assertEqual(row['stages'], [{'id': 1, 'instruction': 'Put the bowl on the plate.', 'max_steps': 400,'checker':None,'post_tools':[]}])
        self.assertEqual(row['budget'], table['budget'])
        self.assertEqual((row['completion_mode'], row['stable_steps']), ('stable_conditions', 1))
        self.assertNotIn('never-publish', json.dumps(result))
        self.assertNotIn(str(self.case.root), json.dumps(result))
        save_json(table_path, dict(table, stable_steps=2))  # Not repinned.
        row = self.request('GET', '/tasks')[1]['tasks'][0]
        self.assertFalse(row['configuration_available']); self.assertIsNone(row['stages'])
        for value in ([], dict(table, stages=[None]), dict(table, stages=[table['stages'][0]] * 2),
                      dict(table, budget={'max_steps': True})):
            with self.subTest(value=value):
                pin(value)
                code, result, _ = self.request('GET', '/tasks')
                self.assertEqual(code, 200)
                self.assertFalse(result['tasks'][0]['configuration_available'])
        table_path.unlink()
        table_path.symlink_to(self.case.registry)
        self.assertFalse(self.request('GET', '/tasks')[1]['tasks'][0]['configuration_available'])
        self.assertFalse(self.case.manager.records); self.assertFalse(self.case.manager.children)

    def test_authenticated_http_lifecycle_and_unauthorized_stop(self):
        request = self.case.request('slow', 'http_lifecycle')
        code, created, _ = self.request('POST', '/runs', request)
        self.case.handles.extend(self.case.manager.children.values())
        self.assertEqual(code, 202)
        run_id = created['run_id']
        self.case.wait(run_id, lambda v: v['status'] == 'running')
        code, duplicate, _ = self.request('POST', '/runs', request)
        self.assertEqual(code, 200)
        self.assertEqual(duplicate['run_id'], run_id)
        self.assertEqual(self.request('POST', '/runs', self.case.request('success', 'conflict'))[0], 409)
        self.assertEqual(self.request('GET', '/runs/' + run_id)[0], 200)
        self.assertEqual(self.request('GET', '/runs/' + run_id + '/result')[0], 202)
        self.assertEqual(self.request('POST', '/runs/' + run_id + '/stop', {}, authenticated=False)[0], 401)
        folder = self.case.root / 'state' / run_id
        self.assertFalse((folder / 'stop.json').exists())
        self.assertTrue(self.case.manager.get(run_id)['active'])
        self.assertEqual(self.request('POST', '/runs/' + run_id + '/stop', {})[0], 202)
        self.case.wait(run_id)
        code, result, _ = self.request('GET', '/runs/' + run_id + '/result')
        self.assertEqual(code, 200)
        self.assertEqual(result['status'], 'stopped')
        self.assertFalse(result['summary']['native_success'])
        # Auth headers must not leak into any run artifact, including launch.json.
        for artifact in folder.rglob('*'):
            if artifact.is_file():
                self.assertNotIn(self.token, artifact.read_bytes())

    def test_duplicate_authorization_headers_rejected(self):
        client = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        try:
            client.putrequest('GET', '/tasks')
            for _ in range(2):
                client.putheader('Authorization', 'Bearer ' + self.token.decode('ascii'))
            client.endheaders()
            response = client.getresponse()
            self.assertEqual(response.status, 401)
            response.read()
        finally:
            client.close()

    def test_loopback_origin_and_json_protections_preserved(self):
        self.assertEqual(self.request('GET', '/tasks')[0], 200)
        self.assertEqual(self.request('GET', '/tasks', headers={'Host': 'untrusted.invalid'})[0], 403)
        self.assertEqual(self.request('GET', '/tasks', headers={'Origin': 'http://localhost:4177'})[0], 403)
        for raw in ('{"task_id":"success","task_id":"slow"}', '{"seed":NaN}'):
            self.assertEqual(self.request('POST', '/runs', raw=raw)[0], 400)
        self.assertEqual(self.request('POST', '/runs', raw='x' * 8193)[0], 413)
        self.assertFalse(self.case.manager.records)

    def test_http_restart_and_client_disconnect_do_not_replay(self):
        request = self.case.request('slow', 'disconnected')
        client = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        client.request('POST', '/runs', body=json.dumps(request), headers={
            'Authorization': 'Bearer ' + self.token.decode('ascii'), 'Content-Type': 'application/json'})
        client.close()  # Drop the response; the idempotency claim must survive.
        deadline = time.monotonic() + 3
        while not self.case.manager.records and time.monotonic() < deadline:
            time.sleep(0.02)
        self.assertEqual(len(self.case.manager.records), 1)
        self.case.handles.extend(self.case.manager.children.values())
        run_id = next(iter(self.case.manager.records))
        self.case.wait(run_id, lambda v: v['status'] == 'running')
        guardian = self.case.handles[-1]
        self.close_server()
        self.case.manager.close()
        self.assertIsNone(guardian.poll())
        self.case.manager = RunManager(self.case.root / 'state', self.case.registry, enable_runs=True)
        self.open_server()
        code, duplicate, _ = self.request('POST', '/runs', request)
        self.assertEqual(code, 200)
        self.assertEqual(duplicate['run_id'], run_id)
        self.assertFalse(self.case.manager.children)  # Attached; no new guardian.
        self.assertEqual(self.request('POST', '/runs/' + run_id + '/stop', {})[0], 202)
        self.case.wait(run_id)

    def test_programmatic_server_cannot_disable_authentication(self):
        with self.assertRaises(TypeError):
            RunnerHTTPServer(0, self.case.manager)
        for token in (None, b'', b'short'):
            with self.assertRaises(ValueError):
                RunnerHTTPServer(0, self.case.manager, auth_token=token)

    def test_same_port_restart_after_requests_without_stealing_live_listener(self):
        port = self.server.server_port
        self.assertEqual(self.request('GET', '/health')[0], 200)
        with self.assertRaises(OSError):
            RunnerHTTPServer(port, self.case.manager, auth_token=self.token)
        self.close_server()
        self.server = RunnerHTTPServer(port, self.case.manager, auth_token=self.token)
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={'poll_interval': 0.02}, daemon=True)
        self.thread.start()
        self.assertEqual(self.server.server_port, port)
        self.assertEqual(self.request('GET', '/health')[0], 200)
