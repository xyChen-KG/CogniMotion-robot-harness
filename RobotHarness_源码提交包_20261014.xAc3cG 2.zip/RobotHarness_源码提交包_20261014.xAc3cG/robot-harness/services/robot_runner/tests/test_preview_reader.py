import base64
import json
from pathlib import Path
import struct
import sys
import tempfile
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from preview_reader import read_preview, validate_packet
from registry import Registry
import test_runner


def packet():
    return dict(version=1, frame_id=13, step=13, width=512, height=256,
        captured_epoch=time.time() - 1, published_epoch=time.time(), stage_id=2,
        source='vla', tool=None, camera_views=['agentview', 'wrist'], image_mime='image/jpeg',
        image_base64=base64.b64encode(b'\xff\xd8x\xff\xd9').decode())


class PreviewReaderTests(unittest.TestCase):
    def test_live_final_archive_and_missing(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self.assertFalse(read_preview(root, 'run', True)['available'])
            value = packet(); value['ignored'] = 'not exposed'
            (root / 'preview.json').write_text(json.dumps(value))
            live = read_preview(root, 'run', True)
            self.assertEqual(live['mode'], 'live')
            self.assertGreater(live['frame_age_seconds'], .9)
            self.assertNotIn('ignored', live['frame'])
            self.assertEqual(read_preview(root, 'run', False)['mode'], 'final')
            (root / 'preview.json').unlink()
            (root / 'final_frame.png').write_bytes(b'\x89PNG\r\n\x1a\n' + b'\0' * 8 + struct.pack('>II', 512, 256))
            old = read_preview(root, 'run', False)
            self.assertEqual(old['mode'], 'archive')
            self.assertIsNone(old['frame']['step'])

    def test_bad_packets_and_symlinks_rejected(self):
        for change in ({'width': 9999}, {'step': True}, {'captured_epoch': float('nan')},
                       {'image_base64': 'bad@'}, {'source': 'unknown'}, {'camera_views': ['agentview']}):
            with self.assertRaises((ValueError, TypeError)):
                validate_packet(dict(packet(), **change))
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            target = root / 'other'; target.write_text('{}')
            (root / 'preview.json').symlink_to(target)
            with self.assertRaises(ValueError):
                read_preview(root, 'run', True)

    def test_preview_fps_allowlist(self):
        case = test_runner.RunnerTests(); case.setUp()
        try:
            config = json.loads(case.registry.read_text())
            for fps in ('4', '0', '10'):
                config['tasks'][0]['env']['ROBOT_PREVIEW_FPS'] = fps
                case.registry.write_text(json.dumps(config))
                Registry(case.registry)
            for fps in ('nan', 'inf', '-1', '11', 'invalid'):
                config['tasks'][0]['env']['ROBOT_PREVIEW_FPS'] = fps
                case.registry.write_text(json.dumps(config))
                with self.assertRaises(ValueError):
                    Registry(case.registry)
        finally:
            case.tearDown()
