import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from details_reader import read_details
from files import save_json
import test_runner


class DetailsTests(unittest.TestCase):
    def setUp(self):
        self.case = test_runner.RunnerTests(); self.case.setUp()
        self.run_id = self.case.start(); self.case.wait(self.run_id)
        self.folder = self.case.root / 'state' / self.run_id

    def tearDown(self):
        self.case.tearDown()

    def test_latched_history_final_conditions_and_native_are_independent(self):
        table = {'stages': [{'id': 1, 'instruction': 'Turn on the stove.', 'completed': True, 'max_steps': 400}]}
        save_json(self.folder / 'episode/task_table.json', table)
        result = {'stage_states': {'1': {'achieved_once': True, 'current_satisfied': False,
            'first_achieved_step': 9, 'last_checked_step': 10,
            'checks': [{'condition': {'predicate': 'released', 'args': ['secret']}, 'completed': False}]}},
            'steps': 10, 'native_success': True, 'workflow_success': True,
            'termination_reason': 'final_stage_native_success'}
        save_json(self.folder / 'episode/result.json', result)
        details = self.case.manager.details(self.run_id)
        self.assertTrue(details['stages'][0]['achieved_once'])
        self.assertFalse(details['stages'][0]['current_satisfied'])
        self.assertTrue(details['native_success']); self.assertTrue(details['workflow_success'])
        self.assertEqual(details['stages'][0]['checks'], [{'predicate': 'released', 'satisfied': False}])
        self.assertNotIn('secret', json.dumps(details))

    def test_logs_are_summarized_not_raw_and_bounded(self):
        secret = 'sk-secret-credential /private/token https://evil.invalid'
        row = {'event': 'tool_end', 'tool': 'reset_to_stage_start', 'stage_id': 1,
               'end_step': 9, 'status': 'reached', 'error': secret, 'options': {'token': secret}}
        (self.folder / 'episode/tool_events.jsonl').write_text((json.dumps(row) + '\n') * 1000)
        result = json.loads((self.folder / 'episode/result.json').read_text())
        result.update(termination_reason=secret, error=secret)
        save_json(self.folder / 'episode/result.json', result)
        details = self.case.manager.details(self.run_id)
        self.assertNotIn(secret, json.dumps(details)); self.assertNotIn(str(self.folder), json.dumps(details))
        self.assertTrue(details['log_summary']['truncated'])
        self.assertLessEqual(len(details['log_summary']['entries']), 80)
        self.assertFalse(details['log_summary']['raw_logs_exposed'])
        self.assertEqual(details['termination_reason'], 'unrecognized_reason')

    def test_missing_corrupt_symlink_and_oversize_records_are_unknown(self):
        path = self.folder / 'episode/task_table.json'
        path.unlink()
        (self.folder / 'task_table.json').unlink()
        self.assertFalse(self.case.manager.details(self.run_id)['details_available'])
        path.symlink_to(self.case.registry)
        self.assertFalse(self.case.manager.details(self.run_id)['details_available'])
        path.unlink(); path.write_bytes(b'x' * 262145)
        self.assertFalse(self.case.manager.details(self.run_id)['details_available'])
        path.write_text('{invalid')
        self.assertFalse(self.case.manager.details(self.run_id)['details_available'])
        with self.assertRaises(Exception):
            self.case.manager.details('../../private')

    def test_details_never_preloads_unbounded_episode_json_via_status(self):
        from manager import read_json
        def guarded(path):
            self.assertNotIn('episode', Path(path).parts)
            return read_json(path)
        with patch('manager.read_json', side_effect=guarded):
            self.assertEqual(self.case.manager.details(self.run_id)['run_id'], self.run_id)

    def test_phase_comes_from_actions_and_tool_records_not_frames(self):
        status = {'run_id': self.run_id, 'active': True, 'current_stage': 1}
        events = self.folder / 'episode/tool_events.jsonl'
        events.write_text(json.dumps({'event': 'tool_start', 'tool': 'reset_to_stage_start', 'start_step': 9}) + '\n')
        details = read_details(self.folder, status)
        self.assertEqual(details['execution_phase'], 'reset')
        self.assertIsNone(details['native_success'])  # Not final while active.
        self.assertEqual(read_details(self.folder, dict(status, ownership_uncertain=True))['execution_phase'], 'unknown')
        self.assertEqual(read_details(self.folder, dict(status, active=False))['execution_phase'], 'ended')
