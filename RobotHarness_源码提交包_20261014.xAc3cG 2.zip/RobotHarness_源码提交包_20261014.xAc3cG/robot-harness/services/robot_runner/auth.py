"""Private API-token files. Tokens never enter argv, run state or service logs."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import secrets
import stat

TOKEN_PATTERN = re.compile(rb'[A-Za-z0-9_-]{43,128}\Z')


def validate_token(token):
    if not isinstance(token, bytes) or not TOKEN_PATTERN.fullmatch(token):
        raise ValueError('API token must be 43-128 URL-safe ASCII characters')
    return token


def load_token(path):
    """Reject symlinks, non-files, other owners and group/world permissions."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, 'rb') as handle:
            info = os.fstat(handle.fileno())
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                    or stat.S_IMODE(info.st_mode) not in (0o600, 0o400)):
                raise ValueError('API token file must be a private, user-owned regular file (0600 or 0400)')
            token = handle.read(130)
    except OSError:
        raise ValueError('Cannot open private API token file') from None
    # Accept just one trailing newline, not whitespace inside the token.
    return validate_token(token.removesuffix(b'\n'))


def create_token_file(path):
    """Create once with 256 random bits; never print or overwrite a token."""
    path = Path(path)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    parent = path.parent.stat()
    if (path.parent.is_symlink() or parent.st_uid != os.getuid()
            or stat.S_IMODE(parent.st_mode) & 0o077):
        raise ValueError('Token directory must be private and user-owned (0700)')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as handle:
        handle.write(secrets.token_urlsafe(32).encode('ascii') + b'\n')
        handle.flush()
        os.fsync(handle.fileno())


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--create-token-file', type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        create_token_file(args.create_token_file)
    except (OSError, ValueError):
        parser.error('Cannot create token: use a new path in a private directory; existing files are never overwritten')
    print('Private API token file created; contents not displayed.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
