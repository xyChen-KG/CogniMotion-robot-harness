"""Bounded, read-only preview access; no PIL, model or simulator imports."""
import base64
import json
import math
from pathlib import Path
import stat
import struct
import time

MAX_PACKET = 2_000_000


def safe_bytes(path):
    path = Path(path)
    if path.is_symlink() or path.parent.is_symlink():
        raise ValueError('Preview symlinks are forbidden')
    info = path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_PACKET:
        raise ValueError('Invalid preview artifact')
    with path.open('rb') as handle:
        value = handle.read(MAX_PACKET + 1)
    if len(value) > MAX_PACKET:
        raise ValueError('Preview too large')
    return value


def validate_packet(packet):
    if not isinstance(packet, dict) or packet.get('version') != 1:
        raise ValueError('Invalid preview version')
    for key in ('step', 'frame_id', 'width', 'height'):
        if type(packet.get(key)) is not int or packet[key] < 0:
            raise ValueError('Invalid preview metadata')
    if not 1 <= packet['width'] <= 2048 or not 1 <= packet['height'] <= 2048:
        raise ValueError('Invalid preview dimensions')
    if packet.get('camera_views') != ['agentview', 'wrist'] or packet.get('image_mime') != 'image/jpeg':
        raise ValueError('Invalid preview views/type')
    for key in ('captured_epoch', 'published_epoch'):
        if type(packet.get(key)) not in (float, int) or not math.isfinite(packet[key]):
            raise ValueError('Invalid preview time')
    if packet.get('stage_id') is not None and (type(packet['stage_id']) is not int or packet['stage_id'] < 1):
        raise ValueError('Invalid preview stage')
    if packet.get('source') not in ('starting', 'vla', 'tool', 'idle'):
        raise ValueError('Invalid preview source')
    raw = base64.b64decode(packet['image_base64'], validate=True)
    if not raw.startswith(b'\xff\xd8') or not raw.endswith(b'\xff\xd9'):
        raise ValueError('Invalid preview JPEG')
    # Return only this wire schema, never arbitrary fields from an artifact.
    keys = ('version', 'frame_id', 'step', 'width', 'height', 'camera_views', 'image_mime',
            'image_base64', 'captured_epoch', 'published_epoch', 'stage_id', 'source', 'tool')
    return {key: packet.get(key) for key in keys}


def read_preview(episode, run_id, active):
    episode = Path(episode)
    preview = episode / 'preview.json'
    if preview.exists() or preview.is_symlink():
        packet = validate_packet(json.loads(safe_bytes(preview)))
        return {'run_id': run_id, 'available': True, 'mode': 'live' if active else 'final',
                'frame': packet, 'frame_age_seconds': max(0, time.time() - packet['captured_epoch'])}
    # Older runs have no live channel. Label their existing PNG explicitly as archive.
    archive = episode / ('initial_frame.png' if active else 'final_frame.png')
    if not archive.exists() and not archive.is_symlink():
        return {'run_id': run_id, 'available': False, 'mode': 'waiting', 'frame': None}
    raw = safe_bytes(archive)
    if raw[:8] != b'\x89PNG\r\n\x1a\n' or len(raw) < 24:
        return {'run_id': run_id, 'available': False, 'mode': 'unavailable', 'frame': None}
    width, height = struct.unpack('>II', raw[16:24])
    if not 1 <= width <= 2048 or not 1 <= height <= 2048:
        raise ValueError('Invalid archive dimensions')
    return {'run_id': run_id, 'available': True, 'mode': 'archive',
        'frame_age_seconds': None, 'frame': {'frame_id': 'archive-' + str(archive.stat().st_mtime_ns),
        'step': None, 'stage_id': None, 'source': 'archive', 'tool': None,
        'width': width, 'height': height, 'camera_views': ['agentview', 'wrist'],
        'image_mime': 'image/png', 'image_base64': base64.b64encode(raw).decode('ascii')}}
