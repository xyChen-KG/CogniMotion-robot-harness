"""Single-slot persistent run manager; task success is never re-scored here."""
from __future__ import annotations

import fcntl
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
import time
import uuid

from files import identity, private_directory, process_state, read_json, same_process, save_json
from registry import NAME, Registry
from preview_reader import read_preview
from details_reader import read_details, document

TERMINAL = {'finished', 'failed', 'start_failed', 'stopped', 'interrupted'}
RESULT_KEYS = ('status', 'success', 'task_success', 'workflow_success', 'native_success',
               'native_success_ever', 'all_stages_completed', 'completed_stage_ids',
               'stage_states', 'post_tools_success', 'post_tool_failures', 'termination_reason',
               'steps', 'vla_steps', 'tool_steps', 'elapsed_seconds', 'recording', 'error',
               'completion_mode', 'success_authority', 'final_stage_native_completion')


class APIError(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message
        super().__init__(message)


def last_line(path):
    try:
        if path.is_symlink():
            return None
        with path.open('rb') as handle:
            handle.seek(0, 2)
            end = handle.tell()
            handle.seek(max(0, end - 65536))
            lines = handle.read().splitlines()
        for line in reversed(lines):
            try:
                value = json.loads(line)
                if isinstance(value, dict):
                    return value
            except ValueError:
                continue
    except OSError:
        pass
    return None


class RunManager:
    def __init__(self, root, registry, *, enable_runs=False):
        # Validate ownership/symlinks first, then bind relative CLI input to the
        # service's cwd once. Guardians/executors run from other directories.
        self.root = private_directory(root).resolve()
        self.claim = (self.root / 'service.lock').open('a')
        try:
            fcntl.flock(self.claim, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.claim.close()
            raise RuntimeError('Another service owns this state directory')
        try:
            self.registry = Registry(registry)
        except Exception:
            self.claim.close()
            raise
        self.enable_runs = enable_runs
        self.lock = threading.RLock()
        self.children = {}
        self.closed = False
        self.records = {}
        self.requests = {}
        for folder in sorted(self.root.glob('run_*')):
            if not folder.is_dir() or folder.is_symlink():
                continue
            record = read_json(folder / 'record.json')
            if not isinstance(record, dict) or record.get('run_id') != folder.name:
                self.claim.close()
                raise RuntimeError('Unreadable run record; refusing to forget a possible active task')
            request_id = record['request']['request_id']
            if request_id in self.requests:
                self.claim.close()
                raise RuntimeError('Duplicate persistent request id')
            self.records[folder.name] = record
            self.requests[request_id] = folder.name
        with self.lock:
            for record in self.records.values():
                self._reconcile(record)
        from scenes import SceneManager
        self.scenes = SceneManager(self)

    def close(self):
        # Does NOT stop workers or robot tasks. They are detached from HTTP/SSH.
        with self.lock:
            if not self.closed:
                self.claim.close()
                self.closed = True

    def _folder(self, run_id):
        if not re.fullmatch(r'run_[a-f0-9]{32}', run_id) or run_id not in self.records:
            raise APIError(404, 'Unknown run_id')
        return self.root / run_id

    def _save(self, record):
        save_json(self.root / record['run_id'] / 'record.json', record)

    def _reconcile(self, record):
        before = dict(record)
        folder = self.root / record['run_id']
        worker = read_json(folder / 'worker_state.json')
        started = read_json(folder / 'worker_started.json')
        owned = (worker or {}).get('worker_identity') or (started or {}).get('identity') or record.get('worker_identity')
        guardian_state = process_state(owned)
        child_state = process_state((worker or {}).get('child_identity'))
        if child_state == 'unknown' and isinstance(worker, dict) and (
                worker.get('child_exit_observed') is True
                or worker.get('child_spawn_attempted') is False):
            # A parent's persisted wait()/no-spawn evidence is authoritative.
            child_state = 'gone'
        known = record['run_id'] in self.children
        if known:
            parent = self.children[record['run_id']]
            if parent.poll() is not None:
                del self.children[record['run_id']]
                known = False
        record['worker_identity'] = owned
        record['ownership_uncertain'] = False
        if guardian_state == 'alive' or known:
            record['status'] = worker.get('status', 'starting') if isinstance(worker, dict) else 'starting'
            record['active'] = True  # Slot retained until guardian has actually exited.
            record['error'] = (worker or {}).get('error')
        elif (guardian_state == 'gone' and child_state == 'gone'
              and isinstance(worker, dict) and worker.get('status') in TERMINAL
              and (worker.get('child_exit_observed') or not worker.get('child_spawn_attempted', True))):
            record.update(status=worker['status'], active=False, error=worker.get('error'),
                          finished_at=worker.get('finished_at'), exit_code=worker.get('exit_code'))
        elif (record.get('status') == 'start_failed' and owned is None
              and worker is None and started is None):
            record['active'] = False
        else:
            result = document(folder, 'episode/result.json')
            # Failed queries, missing identities/state and a surviving child all
            # retain the slot. Only positive exit evidence may release it.
            uncertain = guardian_state == 'unknown' or child_state != 'gone'
            record.update(status='interrupted', active=uncertain, ownership_uncertain=uncertain,
                          error='Cannot confirm owned process/normal exit; never automatically replayed')
            if isinstance(result, dict):
                record['result_available'] = True
        # Frequent observer GETs should not fsync identical ownership records.
        # All process checks still run; actual status/ownership changes persist.
        if record != before:
            self._save(record)
        return record

    def tasks(self):
        return {'runs_enabled': self.enable_runs, 'tasks': self.registry.listing(),
                'supported_policies': ['atomic', 'internw0'], 'max_active_runs': 1}

    def list_runs(self):
        with self.lock:
            records = sorted(self.records.values(), key=lambda r: r.get('created_at', 0), reverse=True)[:20]
            return {'runs': [self.get(r['run_id']) for r in records]}

    def frame(self, run_id):
        with self.lock:
            folder = self._folder(run_id)
            record = self._reconcile(self.records[run_id])
            try:
                return read_preview(folder / 'episode', run_id, record['active'])
            except (OSError, ValueError, KeyError, TypeError):
                return {'run_id': run_id, 'available': False, 'mode': 'unavailable', 'frame': None,
                        'error': 'Preview artifact unreadable; robot execution is unaffected'}

    def details(self, run_id):
        with self.lock:
            folder = self._folder(run_id)
            record = self._reconcile(self.records[run_id])
            # Do not call get(): it reads legacy episode JSON without display caps.
            return read_details(folder, {'run_id': run_id, 'active': record['active'],
                'ownership_uncertain': record.get('ownership_uncertain'), 'error': record.get('error')})

    def create(self, request):
        if not isinstance(request, dict) or set(request) != {'task_id', 'policy', 'seed', 'request_id'}:
            raise APIError(400, 'Exactly task_id, policy, seed, request_id are required')
        for key in ('task_id', 'policy', 'request_id'):
            if not isinstance(request[key], str) or not NAME.fullmatch(request[key]):
                raise APIError(400, 'Invalid ' + key)
        if type(request['seed']) is not int or not 0 <= request['seed'] <= 2147483647:
            raise APIError(400, 'seed must be a nonnegative integer')
        with self.lock:
            if self.closed:
                raise APIError(503, 'Service is closing')
            if request['request_id'] in self.requests:
                run_id = self.requests[request['request_id']]
                record = self.records[run_id]
                if record['request'] != request:
                    raise APIError(409, 'request_id already used with different parameters')
                self._reconcile(record)
                return {'run_id': run_id, 'status': record['status'], 'idempotent': True}
            if not self.enable_runs:
                raise APIError(403, 'Task execution disabled; operator must explicitly enable it')
            if self.scenes.active():
                raise APIError(409, 'An open or uncertain scene owns the exclusive execution slot')
            task = self.registry.tasks.get(request['task_id'])
            if task is None or request['policy'] not in task['policies'] or request['seed'] not in task['allowed_seeds']:
                raise APIError(400, 'Task, policy or seed is not registered')
            for record in self.records.values():
                if self._reconcile(record)['active']:
                    raise APIError(409, 'One task is active or its ownership is uncertain; no queue')
            run_id = 'run_' + uuid.uuid4().hex
            folder = self.root / run_id
            try:
                table, launch = self.registry.prepare(request['task_id'], request['policy'], request['seed'], folder)
            except (OSError, ValueError, KeyError, TypeError) as error:
                raise APIError(422, 'Registered configuration unavailable: ' + str(error)[:300]) from error
            folder.mkdir(mode=0o700, exist_ok=False)
            record = {'run_id': run_id, 'request': dict(request), 'status': 'starting',
                      'active': True, 'created_at': time.time(), 'finished_at': None,
                      'worker_identity': None, 'exit_code': None, 'error': None,
                      'ownership_uncertain': False, 'output_directory': str(folder / 'episode')}
            self.records[run_id] = record
            self.requests[request['request_id']] = run_id
            self._save(record)  # Durable idempotency claim BEFORE launching anything.
            try:
                save_json(folder / 'task_table.json', table)
                save_json(folder / 'launch.json', launch)
                with (folder / 'guardian.log').open('x') as log:
                    worker_env = {k: os.environ[k] for k in ('PATH', 'HOME', 'LANG', 'TMPDIR') if k in os.environ}
                    worker_env['PYTHONDONTWRITEBYTECODE'] = '1'
                    worker = subprocess.Popen([sys.executable, '-B', '-u',
                        str(Path(__file__).with_name('worker.py')), str(folder)],
                        stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                        start_new_session=True, close_fds=True, env=worker_env)
                self.children[run_id] = worker
                record['worker_identity'] = identity(worker.pid)
                self._save(record)
            except OSError as error:
                if run_id in self.children:
                    record.update(error='Guardian launched but persistence failed; ownership requires inspection')
                else:
                    record.update(status='start_failed', active=False, finished_at=time.time(), error=str(error)[:500])
                self._save(record)
            return {'run_id': run_id, 'status': record['status'], 'idempotent': False}

    def get(self, run_id):
        with self.lock:
            folder = self._folder(run_id)
            record = self._reconcile(self.records[run_id])
            result = read_json(folder / 'episode/result.json')
            progress = read_json(folder / 'episode/progress.json')
            evidence = result if isinstance(result, dict) else progress if isinstance(progress, dict) else {}
            trace = last_line(folder / 'episode/controller_trace.jsonl') or {}
            action = last_line(folder / 'episode/actions.jsonl') or {}
            stage = action.get('stage_id')
            if trace.get('event') == 'stage_start':
                stage = trace.get('stage_id')
            elif stage is None:
                stage = trace.get('stage_id') or (trace.get('check') or {}).get('stage_id')
            elapsed = evidence.get('elapsed_seconds')
            worker = read_json(folder / 'worker_state.json') or {}
            if elapsed is None and isinstance(worker.get('started_at'), (int, float)):
                end = worker.get('finished_at') or time.time()
                elapsed = max(0, end - worker['started_at'])
            return {'run_id': run_id, 'status': record['status'], 'active': record['active'],
                    'created_at': record.get('created_at'), 'finished_at': record.get('finished_at'),
                    'request': record['request'], 'current_stage': stage,
                    'stage_count': evidence.get('stage_count'),
                    'vla_steps': evidence.get('vla_steps'), 'tool_steps': evidence.get('tool_steps'),
                    'steps': evidence.get('steps'), 'elapsed_seconds': elapsed,
                    'native_success': evidence.get('native_success'),
                    'workflow_success': evidence.get('workflow_success'),
                    'error': record.get('error') or evidence.get('error'),
                    'exit_code': record.get('exit_code'),
                    'ownership_uncertain': record.get('ownership_uncertain', False),
                    'stop_requested': (folder / 'stop.json').exists(),
                    'progress_is_snapshot': True,
                    'completed_stage_ids': evidence.get('completed_stage_ids'),
                    'stage_states': evidence.get('stage_states')}

    def stop(self, run_id):
        with self.lock:
            folder = self._folder(run_id)
            record = self._reconcile(self.records[run_id])
            if not record['active']:
                return {'run_id': run_id, 'status': record['status'], 'stop_requested': False,
                        'message': 'Run already ended; no process was signalled'}
            if not same_process(record.get('worker_identity')):
                raise APIError(409, 'Cannot verify live guardian ownership; no PID was signalled')
            # No signal-by-PID here. This private mailbox is consumed only by
            # the verified guardian, which signals its own Popen child.
            if not (folder / 'stop.json').exists():
                save_json(folder / 'stop.json', {'run_id': run_id, 'requested_at': time.time()})
            return {'run_id': run_id, 'status': 'stopping', 'stop_requested': True}

    def result(self, run_id):
        with self.lock:
            folder = self._folder(run_id)
            record = self._reconcile(self.records[run_id])
            if record['active']:
                return 202, {'run_id': run_id, 'status': record['status'], 'completed': False,
                             'error': record.get('error')}
            raw = read_json(folder / 'episode/result.json')
            summary = {key: raw.get(key) for key in RESULT_KEYS} if isinstance(raw, dict) else None
            artifacts = []
            for path in sorted(folder.rglob('*')):
                relative = path.relative_to(folder)
                if path.is_symlink() or any((folder / Path(*relative.parts[:i])).is_symlink()
                                           for i in range(1, len(relative.parts))):
                    continue
                if not path.is_file() or path.name.endswith('.tmp'):
                    continue
                if relative.parts[0] == 'episode' or str(relative) in (
                        'record.json', 'task_table.json', 'guardian.log', 'executor.log',
                        'validation.log', 'worker_state.json'):
                    try:
                        artifacts.append({'path': str(relative), 'size_bytes': path.stat().st_size})
                    except OSError:
                        continue
            return 200, {'run_id': run_id, 'status': record['status'], 'completed': True,
                         'result_available': isinstance(raw, dict), 'summary': summary,
                         'error': record.get('error'), 'output_directory': str(folder / 'episode'),
                         'artifacts': artifacts}

