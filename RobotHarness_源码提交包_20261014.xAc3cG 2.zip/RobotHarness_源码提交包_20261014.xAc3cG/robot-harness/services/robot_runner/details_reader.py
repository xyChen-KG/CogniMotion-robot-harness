"""Bounded public run details. Fixed artifacts only; never expose raw logs/paths."""
import json
import os
import stat

EVENTS = {'stage_start', 'state_update', 'vla_paused_for_tools', 'final_stage_native_complete',
          'post_tool_failed', 'stage_start_captured', 'tool_start', 'tool_end',
          'collision_replan', 'tracking_replan', 'stage_state_change'}
TOOLS = {'reset_to_stage_start', 'move_to', 'release'}
REASONS = {'all_stages_complete', 'final_stage_native_success', 'stage_step_budget_exhausted',
           'total_step_budget_exhausted', 'wall_clock_budget_exhausted', 'environment_terminated',
           'interface_or_runtime_error', 'signal', 'finished'}
TOOL_STATUS = {'running', 'reached', 'no_progress', 'planning_failed', 'tracking_failed',
               'interface_or_runtime_error',
               'tool_step_budget_exhausted', 'total_step_budget_exhausted', 'wall_clock_budget_exhausted',
               'environment_terminated', 'error', 'outside_workspace', 'preserve_condition_failed',
               'collision', 'collision_detected', 'no_collision_free_path', 'controller_not_restored'}
PREDICATES = {'on', 'in', 'open', 'close', 'turnon', 'turnoff', 'released', 'lifted', 'near', 'above'}


def number(value):
    return value if type(value) is int and 0 <= value <= 2**53 - 1 else None


def boolean(value):
    return value if type(value) is bool else None


def reason(value):
    if value is None:
        return None
    if isinstance(value, str) and value in REASONS:
        return value
    if isinstance(value, str) and value.startswith('post_tool_') and value[10:] in TOOL_STATUS:
        return value
    return 'unrecognized_reason'  # Do not relay arbitrary exceptions or secret-looking text.


def artifact(folder, relative, limit=262144, tail=False):
    """Open beneath a fixed run directory, refusing symlinks at every component."""
    directory = os.open(folder, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        parts = relative.split('/')
        for part in parts[:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
            os.close(directory)
            directory = child
        fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
        with os.fdopen(fd, 'rb') as handle:
            info = os.fstat(handle.fileno())
            if not stat.S_ISREG(info.st_mode) or (not tail and info.st_size > limit):
                raise ValueError('Artifact unavailable')
            clipped = tail and info.st_size > limit
            if clipped:
                handle.seek(-limit, 2)
            raw = handle.read(limit + 1)
            if len(raw) > limit:
                raise ValueError('Artifact exceeds limit')
            return raw, clipped
    finally:
        os.close(directory)


def document(folder, relative):
    try:
        value = json.loads(artifact(folder, relative)[0])
        return value if isinstance(value, dict) else None
    except (OSError, ValueError, TypeError):
        return None


def rows(folder, relative):
    try:
        raw, clipped = artifact(folder, relative, 65536, tail=True)
        lines = raw.splitlines()
        if clipped:
            lines = lines[1:]
        values = []
        for line in lines:
            try:
                value = json.loads(line)
                if isinstance(value, dict):
                    values.append(value)
            except (ValueError, UnicodeError):
                continue
        return values, bool(clipped or len(values) > 80)
    except (OSError, ValueError):
        return [], False


def read_details(folder, status):
    final = document(folder, 'episode/result.json')
    progress = document(folder, 'episode/progress.json')
    evidence = final if final is not None else progress or {}
    table = document(folder, 'episode/task_table.json') or document(folder, 'task_table.json') or {}
    states = evidence.get('stage_states')
    states = states if isinstance(states, dict) else {}
    source_stages = table.get('stages')
    source_stages = source_stages if isinstance(source_stages, list) and len(source_stages) <= 32 else []
    stages, seen = [], set()
    for stage in source_stages:
        if not isinstance(stage, dict) or number(stage.get('id')) in (None, 0) or stage['id'] in seen:
            continue
        seen.add(stage['id'])
        instruction = stage.get('instruction')
        if not isinstance(instruction, str) or len(instruction) > 2048:
            instruction = None
        state = states.get(str(stage['id']), {})
        state = state if isinstance(state, dict) else {}
        checks = state.get('checks')
        checks = checks if isinstance(checks, list) else []
        public_checks = []
        for check in checks[:32]:
            if not isinstance(check, dict):
                continue
            condition = check.get('condition')
            predicate = condition.get('predicate') if isinstance(condition, dict) else None
            public_checks.append({'predicate': predicate if isinstance(predicate, str) and predicate in PREDICATES else 'other',
                                  'satisfied': boolean(check.get('completed'))})
        counter = lambda key: number(evidence[key].get(str(stage['id']))) if isinstance(evidence.get(key), dict) else None
        stages.append({'id': stage['id'], 'instruction': instruction,
            'max_steps': number(stage.get('max_steps')),
            'achieved_once': boolean(state.get('achieved_once', stage.get('completed'))),
            'current_satisfied': boolean(state.get('current_satisfied')),
            'first_achieved_step': number(state.get('first_achieved_step')),
            'last_checked_step': number(state.get('last_checked_step')),
            'vla_steps': counter('stage_steps'), 'tool_steps': counter('stage_tool_steps'), 'checks': public_checks})
    trace, clipped_trace = rows(folder, 'episode/controller_trace.jsonl')
    actions, _ = rows(folder, 'episode/actions.jsonl')
    action = actions[-1] if actions else {}
    latest = trace[-1] if trace else {}
    current_stage = number(action.get('stage_id')) or number(status.get('current_stage'))
    if latest.get('event') == 'stage_start':
        current_stage = number(latest.get('stage_id'))
    elif current_stage is None:
        current_stage = number(latest.get('stage_id'))
    tools, clipped_tools = rows(folder, 'episode/tool_events.jsonl')
    changes, clipped_changes = rows(folder, 'episode/stage_state_changes.jsonl')
    logs = []
    for source, values in [('controller', trace), ('tool', tools), ('stage', changes)]:
        for row in values:
            event = 'stage_state_change' if source == 'stage' else row.get('event')
            if not isinstance(event, str) or event not in EVENTS:
                continue
            tool = row.get('tool')
            tool_status = row.get('status')
            logs.append({'source': source, 'event': event,
                'step': number(row.get('step', row.get('end_step', row.get('start_step')))),
                'stage_id': number(row.get('stage_id', (row.get('check') or {}).get('stage_id') if isinstance(row.get('check'), dict) else None)),
                'tool': tool if isinstance(tool, str) and tool in TOOLS else None,
                'status': tool_status if isinstance(tool_status, str) and tool_status in TOOL_STATUS else None,
                'achieved_once': boolean(row.get('achieved_once')),
                'current_satisfied': boolean(row.get('current_satisfied'))})
    logs.sort(key=lambda row: row['step'] if row['step'] is not None else -1)
    phase = 'unknown'
    if status.get('active') is False:
        phase = 'ended'
    elif not status.get('ownership_uncertain'):
        last_tool = tools[-1] if tools else {}
        if last_tool.get('event') == 'tool_start':
            phase = 'reset' if last_tool.get('tool') == 'reset_to_stage_start' else 'motion_tool'
        else:
            if latest.get('event') == 'vla_paused_for_tools':
                phase = 'between_stages'
            elif latest.get('event') == 'stage_start' or action.get('source') == 'vla':
                phase = 'vla'
            elif action.get('source') == 'tool':
                phase = 'between_stages' if last_tool.get('event') == 'tool_end' else 'unknown'
    failures = evidence.get('post_tool_failures')
    failures = failures if isinstance(failures, list) else []
    public_failures = []
    for failure in failures[:32]:
        if isinstance(failure, dict):
            public_failures.append({'stage_id': number(failure.get('stage_id')),
                'status': failure.get('status') if isinstance(failure.get('status'), str) and failure['status'] in TOOL_STATUS else 'other',
                'continued': boolean(failure.get('continued'))})
    return {'run_id': status['run_id'], 'details_available': bool(stages),
        'stages': stages, 'execution_phase': phase, 'phase_is_recorded_evidence': True,
        'current_stage': current_stage, 'snapshot_step': number(evidence.get('steps')),
        'final_result_available': final is not None and status.get('active') is False,
        'native_success': boolean(final.get('native_success')) if final and status.get('active') is False else None,
        'workflow_success': boolean(final.get('workflow_success')) if final and status.get('active') is False else None,
        'termination_reason': reason(evidence.get('termination_reason')),
        'error_recorded': bool(status.get('error') or evidence.get('error')),
        'post_tool_failures': public_failures,
        'log_summary': {'entries': logs[-80:], 'truncated': bool(clipped_trace or clipped_tools or clipped_changes or len(logs) > 80),
                        'raw_logs_exposed': False, 'sources': ['controller_trace', 'tool_events', 'stage_state_changes']}}
