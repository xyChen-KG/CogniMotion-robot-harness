"""Detached, bounded scene owner. No models loaded until an explicit command.

Scene open/reset uses the registered initial state. Commands reuse the SAME env;
stop discards actions, close frees only simulation and policy client leases.
"""
from __future__ import annotations

import copy
import fcntl
import hashlib
import math
import os
from pathlib import Path
import runpy
import signal
import sys
import time

from files import identity, read_json, save_json
from scenes import plan_table, command_record


def run(folder):
    folder = Path(folder).resolve()
    claim = (folder / 'actor.lock').open('a')
    fcntl.flock(claim, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if (folder / 'actor_started.json').exists():
        raise RuntimeError('A claimed scene actor cannot replay')
    own_identity = identity(os.getpid())
    save_json(folder / 'actor_started.json', {'identity': own_identity})
    spec = read_json(folder / 'scene_spec.json')
    task, base = spec['task'], spec['table']
    os.environ['MUJOCO_EGL_DEVICE_ID'] = str(task['render_gpu'])
    from starHarness_Libero.libero_env import LiberoEnvironment
    from starHarness_Libero.controller import Controller
    from starHarness_Libero.policies import AtomicResidentPolicy, InternResidentPolicy
    from starHarness_Libero.preview import PreviewExporter
    from starHarness_Libero.qwen import DeterministicUpdater
    from starHarness_Libero.recording import VideoRecorder
    from starHarness_Libero.storage import EpisodeStore
    from starHarness_Libero.schema import validate_table
    import numpy as np
    validate_table(base)
    module = runpy.run_path(task['entrypoint'], run_name='scene_registration')
    if callable(module.get('register_suite')):
        module['register_suite']()
    state = dict(identity=own_identity, status='opening', revision=1, steps=0,
                 vla_steps=0, tool_steps=0, initializations=0, commands=[], error=None,
                 policy_queries=0,active_elapsed_seconds=0.,state_requests=0,
                 current_command_id=None, current_stage_id=None, native_success=False)
    state.update(plan_protocol=1, plan_stage_count=None, plan_stage_index=None)
    env = None
    preview = PreviewExporter(folder, fps=8)
    stopping = False
    def signalled(*_):
        nonlocal stopping
        stopping = True
    signal.signal(signal.SIGTERM, signalled)
    signal.signal(signal.SIGINT, signalled)
    last_activity = time.monotonic()
    # Idle scenes have a documented 30 minute lease, not permanent GPU reservation.
    idle_seconds = 1800
    def persist():
        state.update(updated_at=time.time(), remaining_steps=max(0, base['budget']['max_steps'] - state['steps']),
                     idle_expiry=time.time() + max(0, idle_seconds - (time.monotonic() - last_activity)))
        save_json(folder / 'actor_state.json', state)
    def state_hash():
        return hashlib.sha256(np.asarray(env.domain.sim.get_state().flatten()).tobytes()).hexdigest()
    def publish(observation, source='idle', stage_id=None, force=True):
        frame = np.concatenate([np.ascontiguousarray(observation[k][::-1, ::-1])
                               for k in ('agentview_image', 'robot0_eye_in_hand_image')], axis=1)
        # Revision offsets prevent a reset's frame zero from reusing an old key.
        preview.offer(frame, state['revision'] * 1_000_000 + env.steps,
            dict(stage_id=stage_id, source=source, tool=None, scene_step=env.steps,
                 revision=state['revision']), time.time(), force=force)
    def initialize():
        nonlocal env
        if env is not None:
            env.close()
        env = LiberoEnvironment(copy.deepcopy(base), render_gpu=task['render_gpu'],
                                settling_steps=task['settling_steps'])
        observation = env.reset()
        state.update(status='idle', steps=0, vla_steps=0, tool_steps=0,
                     policy_queries=0,active_elapsed_seconds=0.,state_requests=0,
                     initializations=state['initializations'] + 1, native_success=env.native_status()['success'])
        state['initial_state_hash'] = state['state_hash'] = state_hash()
        publish(observation)
        persist()
    class SceneRecorder:
        def __init__(self, video, stage_ids):
            self.video, self.stage_ids = video, stage_ids
            self.metadata = video.metadata
            self.context = dict(source='starting', tool=None)
            self.last_step = 0
        def set_context(self, **context):
            self.context = context
            self.video.set_context(**context)
            index = context.get('stage_id')
            if type(index) is int and 1 <= index <= len(self.stage_ids):
                state.update(current_stage_id=self.stage_ids[index-1], plan_stage_index=index)
        def capture(self, observation, step):
            self.video.capture(observation, step)
            if step > self.last_step:
                source = self.context.get('source')
                if source in ('vla','tool'):
                    state[source+'_steps'] += step-self.last_step
                self.last_step = step
            state['steps'] = env.steps
            state['native_success'] = env.native_status()['success']
            publish(observation, self.context.get('source', 'vla'), state['current_stage_id'], force=False)
            # Status work is at most 1 Hz, preview does not fsync every action.
            if step % 20 == 0:
                persist()
        def close(self):
            self.video.close()
            publish(env.latest_observation, 'idle', state['current_stage_id'])
    try:
        persist()
        initialize()
        while not stopping and time.monotonic() - last_activity < idle_seconds:
            pending = sorted(d for d in (folder / 'commands').glob('cmd_*')
                             if (d / 'request.json').exists() and not (d / 'done.json').exists())
            if not pending:
                time.sleep(.1)
                continue
            directory = pending[0]
            request = read_json(directory / 'request.json')
            # Actor-local exclusive claim; this process is never restarted/replayed.
            with (directory / 'claimed.json').open('x') as handle:
                handle.write('{}')
            last_activity = time.monotonic()
            state.update(current_command_id=directory.name, error=None)
            try:
                if request['revision'] != state['revision']:
                    raise ValueError('Stale scene revision')
                operation = request['operation']
                if operation == 'close':
                    save_json(directory / 'done.json', {'status': 'closed'})
                    break
                if operation == 'reset':
                    state.update(status='resetting', revision=state['revision'] + 1)
                    persist()
                    initialize()
                    outcome = {'status': 'reset', 'revision': state['revision']}
                elif operation in ('execute', 'execute_plan'):
                    stage_ids = request['plan']['stage_ids'] if operation == 'execute_plan' else [request['stage_id']]
                    if operation == 'execute_plan' and request['plan']['scene_step'] != env.steps:
                        raise ValueError('Scene changed since planning')
                    state.update(status='executing', current_stage_id=stage_ids[0],
                                 plan_stage_count=len(stage_ids), plan_stage_index=1)
                    persist()
                    before = state_hash()
                    table = plan_table(base,stage_ids,{**state,'steps':env.steps})
                    save_json(directory / 'compiled_plan.json', dict(
                        source_stage_ids=stage_ids, table=table, operator_plan=request.get('plan'),
                        scene_revision=state['revision'], before_state_hash=before))
                    store = EpisodeStore(directory / 'episode', table)
                    settings = task['policies'][spec['policy']]
                    policy = (AtomicResidentPolicy(settings['atomic_port'], store,
                              replan_steps=settings['atomic_replan_steps']) if spec['policy'] == 'atomic' else
                              InternResidentPolicy(settings['intern_socket'], settings['prompt_manifest'], store))
                    if hasattr(policy, 'validate_instructions'):
                        policy.validate_instructions(table['stages'])
                    recorder = SceneRecorder(VideoRecorder(store.path), stage_ids)
                    result = Controller(table, env, policy, DeterministicUpdater(), store, recorder).run(
                        initial_observation=env.latest_observation, keep_environment=True,
                        stop_requested=lambda: stopping or (directory / 'stop.json').exists(),
                        native_final_override=(operation == 'execute_plan' and stage_ids == [s['id'] for s in base['stages']]))
                    state['policy_queries'] += result['policy'].get('queries',0)
                    state['active_elapsed_seconds'] += result['elapsed_seconds']
                    state['state_requests'] += result['state_requests']
                    outcome = dict(status=result['status'], stage_id=stage_ids[0],
                        instruction=' → '.join(s['instruction'] for s in table['stages']),
                        operation=operation, source_stage_ids=stage_ids,
                        planning_request_id=request.get('plan',{}).get('planning_request_id'),
                        completed_source_stage_ids=[stage_ids[i-1] for i in result['completed_stage_ids']],
                        stage_results=[dict(source_stage_id=source, plan_stage_id=i,
                            **result['stage_states'][str(i)]) for i,source in enumerate(stage_ids,1)],
                        workflow_success=result.get('workflow_success'),
                        stage_completed=result['all_stages_completed'], native_success=result['native_success'],
                        termination_reason=result['termination_reason'], steps=result['steps'],
                        vla_steps=result['vla_steps'], tool_steps=result['tool_steps'],
                        before_state_hash=before, after_state_hash=state_hash(),
                        video=f'commands/{directory.name}/episode/episode.mp4')
                    video_path = store.path / 'episode.mp4'
                    outcome['video_size_bytes'] = video_path.stat().st_size if video_path.is_file() else None
                    save_json(directory / 'outcome.json', outcome)
                    if result['status'] == 'error':
                        # An interface fault is not a normal failed skill. Close safely.
                        raise RuntimeError(result.get('error', 'Command interface failure'))
                else:
                    raise ValueError('Unsupported scene operation')
                state['state_hash'] = state_hash()
                state['commands'].append(command_record(directory.name,request['revision'],outcome))
                exhausted = (env.steps >= base['budget']['max_steps'] or
                    state['policy_queries'] >= base['budget']['max_policy_queries'] or
                    math.ceil(state['active_elapsed_seconds']) >= base['budget']['max_wall_seconds'] or
                    state['state_requests'] >= base['budget']['max_state_requests'])
                state.update(status='exhausted' if exhausted else 'idle',
                             current_command_id=None, current_stage_id=None, steps=env.steps,
                             plan_stage_index=None,plan_stage_count=None)
                save_json(directory / 'done.json', outcome)
                persist()
            except Exception as error:
                save_json(directory / 'done.json', {'status': 'error', 'error': type(error).__name__})
                raise
            last_activity = time.monotonic()
    except Exception as error:
        state.update(status='failed', error=f'{type(error).__name__}: {str(error)[:300]}')
        persist()
        raise
    finally:
        if env is not None:
            try:
                env.close()
            except Exception as error:
                state.update(status='failed',error='Simulation cleanup error: '+type(error).__name__)
        state.update(status='closed' if state['status'] != 'failed' else 'failed',
                     current_command_id=None, current_stage_id=None)
        state['preview'] = preview.close()
        persist()
        claim.close()


if __name__ == '__main__':
    run(sys.argv[1])
