# robot_runner：安全封装现有执行器

## 交互场景

新增认证接口：`GET/POST /scenes`、`GET /scenes/{scene_id}`、`GET /scenes/{scene_id}/frame`、`POST /scenes/{scene_id}/commands`。固定 SSH 入口 `scene_client.py` 从 stdin 读 `{op:open|command,input:{...}}`，凭据只由现有 client.py 读取。open 输入为 task_id/policy/seed/request_id/owner；command 为 operation/revision/request_id/owner，execute 另需登记 stage_id。owner 来自可信 Agnes actor 的哈希；原 HTTP token 持有者属于运营边界，不能将该 token 交给浏览器。

打开只初始化仿真，不调用 VLA；一位 detached actor 保留环境，后续命令调用 Controller 的可选 retain/initial_observation 接口。原 CLI 的 fresh-run 默认行为完全保留。模型每个 command 获取/释放现有服务 lease，不卸载常驻权重。execute 只可选择本场景原阶段，保留它的指令、检查和 post_tools；本场景完整 native_success 不会冒充当前单一子目标完成。记录分别保留 stage_completed、native_success、动作和复位步数、before/after state hash 及录像。

场景和原任务共享唯一执行位；未关闭的空闲场景亦占位。累计 horizon/control cap 不变，用尽后显式 reset；reset 同 seed/init state 新建环境并递增 revision。闲置30分钟自动关闭仿真（等待不走仿真步）；最多128个操作，结果不覆盖。HTTP重启不重放；actor进程不确定时保留执行位。stop 在控制器动作前和推理返回后检查，是合作式软件停止、不是硬件急停。

本服务把现有 `starHarness_Libero` CLI 封装为单任务异步 HTTP 接口，不改 VLA、仿真、动作预算或原生成功判据。目前默认任务登记为空；本地模拟测试不等于已部署或真实机器人验收。

## 本次安全修复

- 进程查询区分 `alive / gone / unknown`。查询超时、权限错误、无法读取进程状态均为 `unknown`；任务槽保持占用，拒绝新任务。只在确认原进程退出后释放。
- 服务重启后核对原守护进程和执行器，不重放已占用请求。查询恢复后可重新关联同一运行。
- 所有接口，包括 `/health`、`/tasks` 和只读结果接口，均要求 `Authorization: Bearer <token>`。缺失、错误或重复认证头返回 `401`，不启动或停止进程。
- 仍只监听 `127.0.0.1`，仍拒绝浏览器 `Origin`，保留任务白名单、幂等性、独占锁及输入校验。
- 支持关闭后的同端口重启，避免 TCP `TIME_WAIT` 导致重新绑定失败；不启用 `SO_REUSEPORT`，不能抢占仍在监听的服务。
- 相对 `--state-dir` 在服务启动时固定为绝对目录；传给校验器和执行器的阶段表、输出目录也为绝对路径。任务 `cwd` 与服务目录不同不会再造成“阶段表不存在”，不修改已有失败回合或自动重跑。
- 令牌只从私有文件读取到 HTTP 服务内存；不放进命令行、环境变量、运行目录、执行器子进程或日志。仅把令牌文件路径传给服务。

## 私有令牌与启动方式

Python 3.10+，仅依赖标准库。在运行服务的主机上执行；首次创建令牌文件，不显示其内容、不覆盖已有文件：

```sh
python3 -B auth.py --create-token-file "$HOME/.config/robot_runner/api.token"
```

令牌目录必须属于当前用户且权限为 `0700`；令牌文件必须是当前用户拥有的普通文件，权限建议 `0600`（允许 `0400`），不接受符号链接。自动创建的是 256 位随机令牌。不要把此文件放进运行产物目录或代码库。

不启用真实任务的服务启动示例（在本目录运行）：

```sh
python3 -B server.py \
  --token-file "$HOME/.config/robot_runner/api.token" \
  --registry registry.empty.json \
  --state-dir "$HOME/.local/share/robot_runner" \
  --port 18431
```

`--token-file` 现在是必填项，不能匿名运行。使用真实任务登记并获得实验授权后才能添加 `--enable-runs`；不要为了部署删锁、清空状态、重放旧请求或启动模型。

客户端应从自己的安全凭据文件在内存中读取令牌、设置认证头，不要把令牌写在 shell 命令参数、提示词、网页前端或日志中。接入 Agnes 时，由其后端工具适配器调用本服务；网页前端不直接持有令牌或访问本端口。SSH 转发仍需保留，令牌不替代网络隔离。同一 Unix 用户及 root 不在此凭据隔离的防护范围内。

令牌在服务启动时读取一次。更换私有令牌文件后需要重启 HTTP 服务；关闭 HTTP 服务不会主动停止已启动的守护进程，重启必须使用原状态目录。此处不自动生成、轮换或同步任何现有凭据。

## 服务器上的操作客户端

部署目录中的 `client.py` 默认只访问 `127.0.0.1:18431`，从同目录 `private/api.token` 读取令牌，不需要把令牌复制到本机或粘贴进命令行。通过 SSH 进入服务器、切换到部署目录后，可使用服务使用的同一个 Python 解释器：

```sh
python3 -B client.py health
python3 -B client.py tasks
```

获得真实实验授权并启用服务后，才执行下面的 `start`。示例任务 ID 必须先出现在 `tasks` 返回值中，种子也必须已登记；`request-id` 是这一次请求的固定标识，网络重试时保持不变，新的独立回合使用新的标识。

```sh
python3 -B client.py start --task-id same_perturb_five_stage --policy internw0 --seed 47 --request-id phase1-smoke-001
python3 -B client.py status run_替换为返回的32位标识
python3 -B client.py result run_替换为返回的32位标识
python3 -B client.py stop run_替换为返回的32位标识
```

默认启动没有 `--enable-runs`，所以 `start` 会返回 `403`，这是部署验收时的安全预期，不是模型失败。客户端本身不是 Agnes 对话工具或网页播放器；现有独立控制插件通过受限 SSH 适配器复用这些接口，见 [控制插件](../../integrations/agnes_robot_control/README.md)。

## 接口约定

所有请求必须携带上述认证头。POST 使用 `Content-Type: application/json`。

- `GET /health`、`GET /tasks`：服务信息、登记任务。
- `POST /runs`：恰好包含 `task_id`、`policy`、`seed`、`request_id`。新任务返回 `202`；同一请求幂等重试返回 `200` 和原 `run_id`；参数冲突、已有活动任务或归属不确定返回 `409`。
- `GET /runs/{run_id}`：运行状态、阶段、步数等快照；`active=true` 也可能表示归属不确定、等待核实，并不保证机器人正在运动。
- `POST /runs/{run_id}/stop`：请求体 `{}`。仅向确认属于本服务的守护进程写停止请求，由它停止自己创建的执行器；不停止常驻模型或其他用户进程。归属不确定返回 `409`，不发送信号。
- `GET /runs/{run_id}/result`：运行中或归属不确定返回 `202`；终态返回 `200`。`completed` 表示运行已结束，不表示任务成功；`native_success`、`workflow_success` 分开保留。

## 回归测试

从工作区根目录执行：

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest discover -s services/robot_runner/tests -v
```

测试只使用临时目录、回环 HTTP 和假执行器，不加载模型、不启动仿真、不访问付费接口。包含进程查询故障、PID 复用、重启幂等、认证拒绝、未经授权的停止、客户端断开和令牌不进入运行产物等场景。

默认空 registry 仅用于开发。当前服务器登记和历史真实验收记录见本目录 `connection.json`；Agnes 控制插件的部署与只读验收不等于已完成对话发起真实 GPU 实验。

`GET /tasks` 另提供 `configuration_available`、公开 `stages`（id/instruction/max_steps）、只读 `budget`、`completion_mode` 与 `stable_steps`。只读取登记的哈希固定文件，不接受客户端文件路径，不加载执行器或策略。文件缺失、被修改、特殊文件、非法格式、重复阶段 ID 或超限时保留合法选项但返回配置不可用；不泄漏内部路径，不自动更新哈希。

## 第二阶段预览扩展

新增经原有 token 认证的 `GET /runs`（最近 20 回合）和 `GET /runs/{run_id}/frame`（有界最新预览包）。仍拒绝浏览器 Origin；只供服务器端只读桥调用。preview.json 缺失时，旧回合可返回明确标记的历史 PNG，绝不伪装为实时画面。预览损坏不停止机器人。`ROBOT_PREVIEW_FPS` 是操作员注册环境的允许字段，默认关闭。

任务4新增同样认证的 `GET /runs/{run_id}/details`：固定回合的阶段表、历史完成与条件快照、记录的执行／复位模式、独立最终结果和脱敏事件摘要。不接受文件路径、日志名称、命令或URL。只读取固定JSON（每个最多256KiB）与三个JSONL尾部（每个64KiB），拒绝各级符号链接／特殊文件；只公开允许字段，不转发原始日志、异常、凭据或环境变量。摘要最多80项并标注截断；无记录时保留未知。不改变执行器或成功判定。

