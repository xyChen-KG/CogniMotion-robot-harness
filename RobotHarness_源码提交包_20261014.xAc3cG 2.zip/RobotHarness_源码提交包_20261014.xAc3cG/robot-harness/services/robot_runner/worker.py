"""Detached per-run guardian. Only signals its own still-unreaped Popen child."""
from __future__ import annotations

import fcntl
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from files import identity, read_json, save_json


def run(folder):
    folder = Path(folder).resolve()
    claim = (folder / 'worker.lock').open('a')
    fcntl.flock(claim, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if (folder / 'worker_started.json').exists():
        raise RuntimeError('Worker cannot replay a claimed run')
    spec = read_json(folder / 'launch.json')
    save_json(folder / 'worker_started.json', {'identity': identity(os.getpid()), 'at': time.time()})
    state = {'status': 'starting', 'started_at': time.time(), 'finished_at': None,
             'worker_identity': identity(os.getpid()), 'child_identity': None,
             'exit_code': None, 'error': None, 'stop_requested': False,
             'child_spawn_attempted': False, 'child_exit_observed': False}
    child = None
    signalled = False

    def stopping(signum, frame):
        nonlocal signalled
        signalled = True

    signal.signal(signal.SIGTERM, stopping)
    signal.signal(signal.SIGINT, stopping)

    def persist():
        state['updated_at'] = time.time()
        save_json(folder / 'worker_state.json', state)

    def stop_requested():
        return signalled or (folder / 'stop.json').exists()

    try:
        persist()
        # Existing CLI validate path loads neither models nor simulation.
        with (folder / 'validation.log').open('x') as log:
            check = subprocess.run(spec['validate_command'], cwd=spec['cwd'], env=spec['env'],
                                   stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                   timeout=20, close_fds=True)
        if check.returncode:
            raise RuntimeError('Existing CLI rejected the registered configuration; see validation.log')
        if stop_requested():
            state.update(status='stopped', stop_requested=True)
            return
        with (folder / 'executor.log').open('x') as log:
            state['child_spawn_attempted'] = True
            persist()
            child = subprocess.Popen(spec['command'], cwd=spec['cwd'], env=spec['env'],
                                     stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                     close_fds=True)
            state.update(status='running', child_identity=identity(child.pid))
            persist()
            while child.poll() is None:
                if stop_requested() and not state['stop_requested']:
                    state.update(status='stopping', stop_requested=True)
                    persist()
                    # This guardian remains the parent; an unreaped child PID cannot
                    # be reused. No kill-by-persisted-PID or signal to VLA services.
                    child.send_signal(signal.SIGTERM)
                time.sleep(0.1)
            state.update(exit_code=child.returncode, child_exit_observed=True)
        result = read_json(folder / 'episode/result.json')
        if state['stop_requested']:
            state['status'] = 'stopped'
            if not isinstance(result, dict):
                state['error'] = 'Stopped process produced no final result; artifacts may be incomplete'
        elif child.returncode == 0 and isinstance(result, dict) and result.get('status') == 'complete':
            state['status'] = 'finished'  # Independent of native/workflow success.
        elif isinstance(result, dict):
            state.update(status='failed', error=result.get('error') or 'Executor returned an error')
        else:
            state.update(status='interrupted', error='Executor exited without a readable final result')
    except Exception as error:
        state.update(status='start_failed' if child is None else 'failed', error=str(error)[:500])
        if child is None:
            state['child_spawn_attempted'] = False  # Popen failure: no executor was created.
    finally:
        # An unexpected guardian exception must not free the run slot while an
        # owned child is still alive. Do not retry, replay or forcibly kill it.
        if child is not None and child.poll() is None:
            state.update(status='interrupted', error='Guardian fault while executor is still alive')
        state['finished_at'] = time.time()
        persist()
        claim.close()


if __name__ == '__main__':
    run(sys.argv[1])
