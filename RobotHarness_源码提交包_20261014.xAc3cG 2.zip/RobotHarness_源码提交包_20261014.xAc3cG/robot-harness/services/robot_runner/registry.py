"""Operator-owned allowlist -> exact existing CLI argv; no client paths/commands."""
from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import re
import stat

from files import read_json, sha256

NAME = re.compile(r'[A-Za-z0-9._-]{1,128}\Z')
ENV_KEYS = {'PYTHONPATH', 'LIBERO_CONFIG_PATH', 'MUJOCO_GL', 'PYOPENGL_PLATFORM',
            'HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE', 'TOKENIZERS_PARALLELISM',
            'PYTHONDONTWRITEBYTECODE', 'MPLCONFIGDIR', 'NUMBA_CACHE_DIR', 'ROBOT_PREVIEW_FPS'}


def public_checker(value):
    """Expose only bounded predicate data, never arbitrary private table fields."""
    predicates = {'on','in','open','close','turnon','turnoff','native_success','grasped',
                  'released','lifted','stationary','gripper_far'}
    if not isinstance(value, dict) or not {'all'} <= set(value) <= {'all','sequence'}:
        return None
    result = {'all':[]}
    groups = [value['all']]
    sequence = value.get('sequence', [])
    if not isinstance(sequence, list) or len(sequence)>8:
        return None
    for event in sequence:
        if not isinstance(event, dict) or set(event)!={'all'}:
            return None
        groups.append(event['all'])
    for group in groups:
        if not isinstance(group, list) or not 1<=len(group)<=32:
            return None
        for condition in group:
            if (not isinstance(condition, dict) or not {'predicate','args'} <= set(condition) <= {'predicate','args','negate'}
                    or condition['predicate'] not in predicates or not isinstance(condition['args'], list)
                    or len(condition['args'])>4 or type(condition.get('negate',False)) is not bool):
                return None
            for argument in condition['args']:
                if not ((isinstance(argument,str) and re.fullmatch(r'[A-Za-z0-9_@.-]{1,128}',argument))
                        or (type(argument) in (int,float) and -1e6<=argument<=1e6)):
                    return None
    return copy.deepcopy(value)


class Registry:
    def __init__(self, path):
        value = read_json(path)
        if not isinstance(value, dict) or set(value) != {'version', 'tasks'} or value['version'] != 1:
            raise ValueError('Registry requires version:1 and tasks')
        if not isinstance(value['tasks'], list):
            raise ValueError('tasks must be a list')
        self.tasks = {}
        for task in value['tasks']:
            required = {'id', 'title', 'python', 'entrypoint', 'task_table', 'cwd',
                        'env', 'allowed_seeds', 'policies', 'sha256', 'render_gpu', 'settling_steps'}
            if not isinstance(task, dict) or set(task) != required:
                raise ValueError('Invalid operator registry task fields')
            if not isinstance(task['id'], str) or not NAME.fullmatch(task['id']) or task['id'] in self.tasks:
                raise ValueError('Invalid or duplicate task id')
            for key in ('python', 'entrypoint', 'task_table', 'cwd'):
                if not isinstance(task[key], str) or not Path(task[key]).is_absolute():
                    raise ValueError(key + ' must be an operator-owned absolute path')
            if not isinstance(task['title'], str) or len(task['title']) > 200:
                raise ValueError('Invalid title')
            env = task['env']
            if not isinstance(env, dict) or set(env) - ENV_KEYS or any(not isinstance(v, str) for v in env.values()):
                raise ValueError('Only explicitly permitted non-secret environment keys are accepted')
            if 'ROBOT_PREVIEW_FPS' in env and not 0 <= float(env['ROBOT_PREVIEW_FPS']) <= 10:
                raise ValueError('Preview FPS must be between 0 and 10')
            seeds = task['allowed_seeds']
            if not isinstance(seeds, list) or not seeds or any(type(s) is not int or not 0 <= s <= 2147483647 for s in seeds):
                raise ValueError('allowed_seeds must be a finite nonnegative integer list')
            for key in ('render_gpu', 'settling_steps'):
                if type(task[key]) is not int or task[key] < 0:
                    raise ValueError('Invalid ' + key)
            if not isinstance(task['sha256'], dict) or any(
                    not Path(p).is_absolute() or not isinstance(h, str) or not re.fullmatch('[a-f0-9]{64}', h)
                    for p, h in task['sha256'].items()):
                raise ValueError('Invalid pinned hashes')
            if not {task['entrypoint'], task['task_table']} <= set(task['sha256']):
                raise ValueError('Entrypoint and table must be hash-pinned')
            policies = task['policies']
            if not isinstance(policies, dict) or not policies or set(policies) - {'atomic', 'internw0'}:
                raise ValueError('Only current CLI policies atomic/internw0 are supported')
            for name, settings in policies.items():
                expected = {'atomic_port', 'atomic_replan_steps'} if name == 'atomic' else {'intern_socket', 'prompt_manifest'}
                if not isinstance(settings, dict) or set(settings) != expected:
                    raise ValueError('Invalid policy settings')
                if name == 'atomic':
                    if type(settings['atomic_port']) is not int or not 1 <= settings['atomic_port'] <= 65535:
                        raise ValueError('Invalid Atomic port')
                    if type(settings['atomic_replan_steps']) is not int or settings['atomic_replan_steps'] < 1:
                        raise ValueError('Invalid replan steps')
                else:
                    if any(not isinstance(v, str) or not Path(v).is_absolute() for v in settings.values()):
                        raise ValueError('InternW0 paths must be absolute')
                    if settings['prompt_manifest'] not in task['sha256']:
                        raise ValueError('Prompt manifest must be hash-pinned')
            self.tasks[task['id']] = copy.deepcopy(task)

    def listing(self):
        """Only public, bounded config from hash-pinned operator registrations.

        Missing/changed inputs are explicit, never stale invented stage tables.
        This does not import the executor, connect models or validate reachability.
        """
        result = []
        for task in self.tasks.values():
            row = {'task_id': task['id'], 'title': task['title'],
                   'policies': sorted(task['policies']), 'allowed_seeds': task['allowed_seeds'],
                   'configuration_available': False, 'stages': None, 'budget': None,
                   'completion_mode': None, 'stable_steps': None, 'configuration_error': None}
            try:
                path = Path(task['task_table'])
                # Open the pinned file itself, not a raced symlink or special file.
                fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
                with os.fdopen(fd, 'rb') as handle:
                    info = os.fstat(handle.fileno())
                    if not stat.S_ISREG(info.st_mode) or info.st_size > 262144:
                        raise ValueError('Invalid registered table')
                    raw = handle.read(262145)
                if len(raw) > 262144:
                    raise ValueError('Registered table exceeds display limit')
                if hashlib.sha256(raw).hexdigest() != task['sha256'][str(path)]:
                    raise ValueError('Registered table changed')
                table = json.loads(raw)
                if not isinstance(table, dict):
                    raise ValueError('Invalid registered table')
                stages = table.get('stages')
                if not isinstance(stages, list) or not 1 <= len(stages) <= 32:
                    raise ValueError('Stage list exceeds display contract')
                public_stages = []
                stage_ids = set()
                for stage in stages:
                    if (not isinstance(stage, dict) or type(stage.get('id')) is not int
                            or stage['id'] < 1 or stage['id'] in stage_ids
                            or not isinstance(stage.get('instruction'), str)
                            or not stage['instruction'].strip() or len(stage['instruction']) > 2048
                            or type(stage.get('max_steps')) is not int or stage['max_steps'] < 1):
                        raise ValueError('Invalid registered stage')
                    stage_ids.add(stage['id'])
                    public_stages.append({k: stage[k] for k in ('id', 'instruction', 'max_steps')})
                    public_stages[-1]['checker'] = public_checker(stage.get('checker'))
                    public_stages[-1]['post_tools'] = [
                        {k:call[k] for k in ('tool','max_steps') if k in call}
                        for call in stage.get('post_tools', [])[:8]
                        if isinstance(call,dict) and call.get('tool') in ('reset_to_stage_start','move_to')
                        and type(call.get('max_steps')) is int and 0<call['max_steps']<=10000]
                budget = table.get('budget')
                keys = ('max_steps', 'check_interval_steps', 'max_state_requests',
                        'max_policy_queries', 'max_wall_seconds')
                if not isinstance(budget, dict) or any(type(budget.get(k)) is not int or budget[k] < 1 for k in keys):
                    raise ValueError('Invalid registered budget')
                row.update(configuration_available=True, stages=public_stages,
                           budget={k: budget[k] for k in keys},
                           completion_mode=table.get('completion_mode', 'stable_conditions'),
                           stable_steps=table.get('stable_steps'))
            except (OSError, ValueError, KeyError, TypeError):
                row['configuration_error'] = 'Registered table unavailable, changed, or outside display limits'
            result.append(row)
        return result

    def prepare(self, task_id, policy, seed, folder):
        task = self.tasks[task_id]
        # Refuse changed source files. Never refresh hashes automatically.
        for path, digest in task['sha256'].items():
            if sha256(path) != digest:
                raise ValueError('Registered input changed: ' + Path(path).name)
        if not os.access(task['python'], os.X_OK) or not Path(task['cwd']).is_dir():
            raise ValueError('Registered Python/cwd is unavailable')
        table = read_json(task['task_table'])
        if not isinstance(table, dict) or not isinstance(table.get('task'), dict):
            raise ValueError('Registered stage table is unreadable')
        if not isinstance(table.get('stages'), list) or not table['stages'] or any(s.get('completed') is not False for s in table['stages']):
            raise ValueError('Registered table must describe a fresh episode')
        budget = table.get('budget')
        if not isinstance(budget, dict) or not budget or any(type(v) is not int or v < 1 for v in budget.values()):
            raise ValueError('Registered budget must contain positive integers')
        table = copy.deepcopy(table)
        table['task']['seed'] = seed  # ONLY the approved seed changes; no budget override.
        # Both validation and execution use task['cwd'], not the service cwd.
        # Never pass a service-relative table/output path across that boundary.
        folder = Path(folder).resolve()
        table_path = folder / 'task_table.json'
        command = [task['python'], '-B', '-u', task['entrypoint'], 'run',
                   '--task-table', str(table_path), '--output', str(folder / 'episode'),
                   '--policy', policy, '--state-updater', 'deterministic',
                   '--render-gpu', str(task['render_gpu']), '--settling-steps', str(task['settling_steps'])]
        settings = task['policies'][policy]
        if policy == 'atomic':
            command += ['--atomic-port', str(settings['atomic_port']),
                        '--atomic-replan-steps', str(settings['atomic_replan_steps'])]
        else:
            if not stat.S_ISSOCK(Path(settings['intern_socket']).stat().st_mode):
                raise ValueError('Registered InternW0 socket is unavailable')
            manifest = read_json(settings['prompt_manifest'])
            entries = manifest.get('prompts', []) if isinstance(manifest, dict) else []
            cached = {e.get('instruction'): e for e in entries if isinstance(e, dict)}
            for stage in table['stages']:
                entry = cached.get(stage['instruction'])
                if entry is None or sha256(entry['context_file']) != entry['sha256']:
                    raise ValueError('Existing prompt cache is missing or changed; no encoding/download attempted')
            command += ['--intern-socket', settings['intern_socket'], '--prompt-manifest', settings['prompt_manifest']]
        env = {k: os.environ[k] for k in ('PATH', 'HOME', 'USER', 'LANG', 'TMPDIR') if k in os.environ}
        env.update(task['env'])
        env.update(PYTHONDONTWRITEBYTECODE='1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
        validate = [task['python'], '-B', task['entrypoint'], 'validate', '--task-table', str(table_path)]
        return table, {'command': command, 'validate_command': validate, 'cwd': task['cwd'],
                       'env': env, 'source_sha256': task['sha256'], 'budget': budget,
                       'stage_count': len(table['stages'])}
