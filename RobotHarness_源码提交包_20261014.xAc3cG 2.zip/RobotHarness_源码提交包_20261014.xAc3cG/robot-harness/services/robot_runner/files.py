"""Private persistent JSON and process identity helpers (no robot imports)."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile


def read_json(path):
    try:
        with Path(path).open(encoding='utf-8') as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None


def save_json(path, value):
    path = Path(path)
    fd, temporary = tempfile.mkstemp(prefix=path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(value, handle, ensure_ascii=False, allow_nan=False, indent=2)
            handle.write('\n')
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _read_process_identity(pid):
    """Raise ProcessLookupError only for confirmed absence or a zombie."""
    if type(pid) is not int or pid <= 0:
        raise ValueError('Invalid PID')
    if sys.platform.startswith('linux'):
        # Check procfs availability before treating a missing PID file as exit.
        boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        try:
            stat = Path(f'/proc/{pid}/stat').read_text()
        except FileNotFoundError:
            # A hidden/unmounted procfs entry alone is not an exit proof.
            os.kill(pid, 0)  # ESRCH confirms exit; EPERM or a live PID stays unknown.
            raise ValueError('Process exists without a readable procfs identity')
        fields = stat[stat.rfind(')') + 2:].split()
        if fields[0] in ('Z', 'X'):
            raise ProcessLookupError(pid)
        return {'pid': pid, 'birth': fields[19], 'boot': boot, 'platform': 'linux'}
    if sys.platform == 'darwin':
        try:
            value = subprocess.check_output(
                ['/bin/ps', '-p', str(pid), '-o', 'lstart=', '-o', 'stat='],
                text=True, stderr=subprocess.DEVNULL, timeout=2).strip()
        except subprocess.CalledProcessError:
            # ps failure alone may mean a permissions/query failure, not exit.
            os.kill(pid, 0)  # Only ESRCH proves absence; this sends no signal.
            raise
        if not value:
            os.kill(pid, 0)
            raise ValueError('Empty process identity')
        if value.split()[-1].startswith('Z'):
            raise ProcessLookupError(pid)
        # Execution state (S/R) changes and must NOT form part of identity.
        birth = value.rsplit(None, 1)[0]
        return {'pid': pid, 'birth': birth, 'platform': 'darwin'}
    raise ValueError('Unsupported process identity platform')


def identity(pid):
    """Best-effort identity for persistence; None is NOT an exit proof."""
    try:
        return _read_process_identity(pid)
    except (OSError, ValueError, subprocess.SubprocessError, IndexError):
        return None


def process_state(saved):
    """alive / gone / unknown; mismatched birth identity means the owner is gone."""
    if not isinstance(saved, dict):
        return 'unknown'
    try:
        current = _read_process_identity(saved.get('pid'))
    except ProcessLookupError:
        return 'gone'
    except (OSError, ValueError, subprocess.SubprocessError, IndexError):
        return 'unknown'
    if not isinstance(current, dict):
        return 'unknown'
    return 'alive' if current == saved else 'gone'


def same_process(saved):
    return process_state(saved) == 'alive'


def private_directory(path):
    path = Path(path)
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    if path.is_symlink() or path.stat().st_uid != os.getuid():
        raise ValueError('Private directory must be owned by this user and not a symlink')
    os.chmod(path, 0o700)
    return path
