"""Browser-read-only dashboard plus separate backend-authenticated scene effects."""
from __future__ import annotations

import argparse
import base64
import fcntl
import hmac
import html
import http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import secrets
import signal
import subprocess
import sys
import threading
import time
from urllib.parse import parse_qs, urlsplit

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'robot_runner'))
from auth import create_token_file, load_token
from files import identity, private_directory, read_json, save_json, same_process
from viewer_transport import RUN_ID, ViewerTransport


class ViewerServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, port, transport, private_root, admin_token):
        self.transport = transport
        self.private_root = private_directory(private_root)
        self.admin_token = admin_token
        self.instance_id = secrets.token_urlsafe(24)
        self.session = secrets.token_urlsafe(32)
        self.bootstrap_token, self.bootstrap_expiry = None, 0
        self.auth_lock, self.video_lock = threading.Lock(), threading.Lock()
        self.cache = private_directory(self.private_root / 'video_cache')
        super().__init__(('127.0.0.1', port), ViewerHandler)

    def make_bootstrap(self):
        with self.auth_lock:
            self.bootstrap_token = secrets.token_urlsafe(32)
            self.bootstrap_expiry = time.monotonic() + 120
            body = ('<!doctype html><meta charset="utf-8"><title>打开机器人观看窗口</title>'
                '<p>正在安全打开本地观看窗口…</p>'
                f'<form method="post" action="http://127.0.0.1:{self.server_port}/auth/session">'
                f'<input type="hidden" name="access" value="{html.escape(self.bootstrap_token)}"></form>'
                '<script>document.forms[0].submit()</script>')
            path = self.private_root / 'open_viewer.html'
            if path.is_symlink():
                raise ValueError('Invalid bootstrap file')
            descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
            with os.fdopen(descriptor, 'w', encoding='utf-8') as handle:
                handle.write(body)
                handle.flush()
                os.fsync(handle.fileno())
            return path

    def video_path(self, run_id):
        snapshot = self.transport.snapshot(run_id)
        rows = {r['run_id']: r for r in snapshot['runs']}
        if snapshot.get('status'):
            rows[snapshot['status']['run_id']] = snapshot['status']
        row = rows.get(run_id)
        if row is None or row.get('active') is not False:
            raise ValueError('Only a listed completed run can be replayed')
        expected_size = row.get('video_size_bytes')
        if type(expected_size) is not int or not 0 < expected_size <= 64 * 1024 * 1024:
            raise ValueError('Select this completed run and wait for recording metadata')
        path = self.cache / (run_id + '.mp4')
        with self.video_lock:
            if path.is_symlink():
                raise ValueError('Invalid video cache')
            if path.exists() and path.stat().st_size == expected_size:
                return path
            partial = self.cache / (run_id + '.partial')
            if partial.is_symlink():
                raise ValueError('Invalid video cache')
            command = ['scp', '-q', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=12',
                '-o', 'ClearAllForwardings=yes',
                self.transport.ssh_alias + ':' + self.transport.runner_dir + '/state/' + run_id + '/episode/episode.mp4',
                str(partial)]
            copied = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL, timeout=45)
            if copied.returncode or not partial.exists() or partial.stat().st_size != expected_size:
                raise ValueError('Recording download failed; no task was restarted')
            os.replace(partial, path)
        return path

    def integration_read(self, value):
        """Backend-only read facade. No robot start/stop or arbitrary URLs/paths."""
        if not isinstance(value, dict):
            raise ValueError('Object required')
        if value == {'op': 'tasks'}:
            return self.transport.catalog()  # Fixed GET /tasks only, no URL/path arguments.
        if value == {'op': 'scene'}:
            return self.transport.scene_snapshot()
        if value.get('op') == 'scene_replay_chunk' and set(value) == {'op','scene_id','command_id','offset'}:
            scene_id, command_id, offset = value['scene_id'], value['command_id'], value['offset']
            if (not isinstance(scene_id,str) or not re.fullmatch(r'scene_[a-f0-9]{32}',scene_id)
                    or not isinstance(command_id,str) or not re.fullmatch(r'cmd_[a-f0-9]{32}',command_id)
                    or type(offset) is not int or not 0 <= offset < 64*1024*1024):
                raise ValueError('Invalid scene recording request')
            rows = self.transport.scene_snapshot().get('scenes', [])
            row = next((r for r in rows if r['scene_id']==scene_id), None)
            item = next((c for c in (row or {}).get('commands', []) if c['command_id']==command_id), None)
            size = (item or {}).get('video_size_bytes')
            if type(size) is not int or not 0 < size <= 64*1024*1024 or offset >= size:
                raise ValueError('Completed scene operation recording unavailable')
            path = self.cache / (scene_id + '_' + command_id + '.mp4')
            with self.video_lock:
                if path.is_symlink():
                    raise ValueError('Invalid scene video cache')
                if not path.exists() or path.stat().st_size != size:
                    partial = path.with_suffix('.partial')
                    if partial.is_symlink():
                        raise ValueError('Invalid scene video cache')
                    remote = f'{self.transport.runner_dir}/state/{scene_id}/commands/{command_id}/episode/episode.mp4'
                    command = ['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=12','-o','ClearAllForwardings=yes',
                               self.transport.ssh_alias+':'+remote,str(partial)]
                    copied = subprocess.run(command,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,
                                            stderr=subprocess.DEVNULL,timeout=20)
                    if copied.returncode or not partial.is_file() or partial.stat().st_size != size:
                        raise ValueError('Scene video copy failed; no operation replayed')
                    os.replace(partial,path)
            with path.open('rb') as handle:
                handle.seek(offset)
                data = handle.read(192*1024)
            return dict(scene_id=scene_id,command_id=command_id,offset=offset,total_bytes=size,
                        next_offset=offset+len(data),eof=offset+len(data)==size,mime='video/mp4',
                        data_base64=base64.b64encode(data).decode('ascii'))
        if value.get('op') == 'observation' and set(value) <= {'op', 'run_id'}:
            run_id = value.get('run_id')
            if run_id is not None:
                self.transport.watch(run_id)  # Subscribe to a read-only observation; never controls the task.
            snapshot = self.transport.snapshot(run_id)
            keys = ('run_id', 'status', 'active', 'current_stage', 'stage_count', 'steps',
                    'vla_steps', 'tool_steps', 'elapsed_seconds', 'completed_stage_ids',
                    'native_success', 'workflow_success', 'video_size_bytes', 'created_at', 'finished_at',
                    'ownership_uncertain')
            def summary(row):
                result = {key: row.get(key) for key in keys}
                result['request'] = {key: row.get('request', {}).get(key) for key in ('task_id', 'policy', 'seed')}
                return result
            snapshot['runs'] = [summary(row) for row in snapshot['runs']]
            if snapshot.get('status'):
                details = snapshot['status'].get('details')
                snapshot['status'] = summary(snapshot['status'])
                if isinstance(details, dict) and details.get('run_id') == snapshot['selected_run_id']:
                    snapshot['details'] = details
            frame = snapshot.get('frame')
            if frame and len(frame.get('image_base64', '')) > 600_000:
                snapshot.update(frame=None, available=False, error='Preview exceeds integration size limit')
            return snapshot
        if value.get('op') == 'replay_chunk' and set(value) == {'op', 'run_id', 'offset'}:
            run_id, offset = value['run_id'], value['offset']
            if not isinstance(run_id, str) or not RUN_ID.fullmatch(run_id) or type(offset) is not int or offset < 0:
                raise ValueError('Invalid recording request')
            path = self.video_path(run_id)
            size = path.stat().st_size
            if offset >= size:
                raise ValueError('Recording offset out of range')
            with path.open('rb') as handle:
                handle.seek(offset)
                data = handle.read(192 * 1024)
            return dict(run_id=run_id, offset=offset, total_bytes=size,
                        next_offset=offset + len(data), eof=offset + len(data) == size,
                        mime='video/mp4', data_base64=base64.b64encode(data).decode('ascii'))
        raise ValueError('Only tasks, observation and replay_chunk are available')


class ViewerHandler(BaseHTTPRequestHandler):
    server_version, sys_version = 'RobotViewer/0.1', ''

    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, *args):
        pass  # No cookies, auth headers or form bodies in logs.

    def permitted_host(self):
        hosts = self.headers.get_all('Host', [])
        if len(hosts) != 1 or hosts[0] not in ('127.0.0.1:' + str(self.server.server_port),
                                            'localhost:' + str(self.server.server_port)):
            raise PermissionError('Invalid loopback host')

    def authenticated(self):
        cookies = self.headers.get_all('Cookie', [])
        if len(cookies) != 1:
            return False
        entries = [part.strip().split('=', 1) for part in cookies[0].split(';')]
        sessions = [value for key, value in entries if key == 'robot_viewer_session'] if all(len(e) == 2 for e in entries) else []
        return len(sessions) == 1 and hmac.compare_digest(sessions[0], self.server.session)

    def body(self, *, form=False):
        lengths = self.headers.get_all('Content-Length', [])
        if (self.headers.get('Transfer-Encoding') is not None or len(lengths) != 1
                or not lengths[0].isdigit() or int(lengths[0]) > 4096):
            raise ValueError('Invalid body size')
        expected = 'application/x-www-form-urlencoded' if form else 'application/json'
        if self.headers.get('Content-Type', '').split(';')[0].strip() != expected:
            raise ValueError('Invalid request content type')
        raw = self.rfile.read(int(lengths[0]))
        if len(raw) != int(lengths[0]):
            raise ValueError('Incomplete body')
        raw = raw.decode('utf-8')
        if form:
            values = parse_qs(raw, strict_parsing=True)
            if set(values) != {'access'} or len(values['access']) != 1:
                raise ValueError('Invalid session request')
            return values['access'][0]
        def pairs(items):
            result = {}
            for k, v in items:
                if k in result:
                    raise ValueError('Duplicate key')
                result[k] = v
            return result
        return json.loads(raw, object_pairs_hook=pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Invalid number')))

    def send_headers(self, code, content_type, length, *, extra=()):
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(length))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; media-src 'self'; connect-src 'self'; frame-ancestors 'self'; object-src 'none'; base-uri 'none'")
        for key, value in extra:
            self.send_header(key, value)
        self.end_headers()

    def reply(self, code, value):
        data = json.dumps(value, ensure_ascii=False, allow_nan=False).encode()
        self.send_headers(code, 'application/json; charset=utf-8', len(data))
        self.wfile.write(data)

    def dispatch(self):
        self.permitted_host()
        if self.command == 'GET' and self.path == '/health':
            return self.reply(200, {'service': 'robot_viewer', 'instance_id': self.server.instance_id})
        if self.command == 'POST' and self.path in ('/internal/read', '/internal/scene-effect'):
            credentials = self.headers.get_all('Authorization', [])
            if (self.headers.get('Origin') is not None or len(credentials) != 1
                    or not hmac.compare_digest(credentials[0].encode('ascii'), b'Bearer ' + self.server.admin_token)):
                raise PermissionError('Backend operator authentication required')
            value = self.body()
            if self.path == '/internal/read':
                return self.reply(200, self.server.integration_read(value))
            if (not isinstance(value, dict) or set(value) != {'op', 'input'}
                    or value['op'] not in ('open', 'command') or not isinstance(value['input'], dict)):
                raise ValueError('Invalid scene effect')
            return self.reply(200, self.server.transport.scene_effect(value))
        if self.command == 'POST' and self.path == '/auth/bootstrap':
            # Operator CLI only. No browser Origin and no admin key in browser JS.
            credentials = self.headers.get_all('Authorization', [])
            if self.headers.get('Origin') is not None or len(credentials) != 1:
                raise PermissionError('Operator authentication required')
            expected = b'Bearer ' + self.server.admin_token
            if not hmac.compare_digest(credentials[0].encode('ascii'), expected):
                raise PermissionError('Operator authentication required')
            if self.body() != {}:
                raise ValueError('Empty bootstrap request required')
            return self.reply(200, {'bootstrap_file': str(self.server.make_bootstrap())})
        if self.command == 'POST' and self.path == '/auth/session':
            if self.headers.get('Origin') not in (None, 'null'):
                raise PermissionError('Private file bootstrap required')
            access = self.body(form=True)
            with self.server.auth_lock:
                if (not self.server.bootstrap_token or time.monotonic() > self.server.bootstrap_expiry
                        or not hmac.compare_digest(access, self.server.bootstrap_token)):
                    raise PermissionError('Bootstrap expired or already used; open the launcher again')
                self.server.bootstrap_token = None
            # A same-origin document completes the file -> HTTP transition.
            # A direct cross-site 303 may omit a freshly set Strict cookie.
            data = ('<!doctype html><meta charset="utf-8"><title>机器人实时画面</title>'
                    '<p>观看会话已建立。<a href="/">进入观看窗口</a></p>'
                    '<script src="/session.js" defer></script>').encode('utf-8')
            self.send_headers(200, 'text/html; charset=utf-8', len(data), extra=[
                ('Set-Cookie', 'robot_viewer_session=' + self.server.session + '; Path=/; HttpOnly; SameSite=Strict')])
            return self.wfile.write(data)
        if self.path in ('/app.js', '/session.js', '/style.css') and self.command == 'GET':
            data = (HERE / 'static' / self.path[1:]).read_bytes()
            self.send_headers(200, 'text/javascript; charset=utf-8' if self.path.endswith('.js') else 'text/css; charset=utf-8', len(data))
            return self.wfile.write(data)
        if self.path == '/' and self.command == 'GET':
            if not self.authenticated():
                data = '<!doctype html><meta charset="utf-8"><title>机器人实时画面</title><h2>请通过「打开实时画面.command」进入</h2><p>本地观看窗口需要独立会话认证。服务器令牌不会提供给浏览器。</p>'.encode()
            else:
                data = (HERE / 'static/index.html').read_bytes()
            self.send_headers(200, 'text/html; charset=utf-8', len(data))
            return self.wfile.write(data)
        if not self.authenticated():
            return self.reply(401, {'error': 'Local viewer session required'})
        if self.command == 'POST':
            if self.headers.get('Origin') != 'http://' + self.headers['Host']:
                raise PermissionError('Same-origin session required')
            value = self.body()
            if self.path == '/api/watch' and isinstance(value, dict) and set(value) == {'run_id'}:
                self.server.transport.watch(value['run_id'])
                return self.reply(200, {'watching': value['run_id'], 'read_only': True})
            if self.path == '/api/reconnect' and value == {}:
                self.server.transport.reconnect()
                return self.reply(200, {'reconnecting_observer_only': True})
        if self.command == 'GET' and urlsplit(self.path).path == '/api/snapshot':
            query = parse_qs(urlsplit(self.path).query, keep_blank_values=True, strict_parsing=True)
            if not query:
                return self.reply(200, self.server.transport.snapshot())
            if set(query) != {'run_id'} or len(query['run_id']) != 1:
                raise ValueError('Only one listed run can be observed')
            run_id = query['run_id'][0]
            self.server.transport.watch(run_id)
            return self.reply(200, self.server.transport.snapshot(run_id))
        video = re.fullmatch(r'/video/(run_[a-f0-9]{32})', self.path)
        if self.command == 'GET' and video:
            path = self.server.video_path(video.group(1))
            size = path.stat().st_size
            start, end, code = 0, size - 1, 200
            if self.headers.get('Range'):
                found = re.fullmatch(r'bytes=(\d*)-(\d*)', self.headers['Range'])
                if not found or not any(found.groups()):
                    raise ValueError('Single byte range required')
                a, b = found.groups()
                if a:
                    start, end = int(a), min(int(b), size - 1) if b else size - 1
                else:
                    start = max(0, size - int(b))
                if not 0 <= start <= end < size:
                    self.send_headers(416, 'video/mp4', 0, extra=[('Content-Range', 'bytes */' + str(size))])
                    return
                code = 206
            extra = [('Accept-Ranges', 'bytes')]
            if code == 206:
                extra.append(('Content-Range', f'bytes {start}-{end}/{size}'))
            self.send_headers(code, 'video/mp4', end - start + 1, extra=extra)
            with path.open('rb') as source:
                source.seek(start)
                remaining = end - start + 1
                while remaining:
                    chunk = source.read(min(65536, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
            return
        self.reply(404, {'error': 'Unknown read-only viewer route'})

    def handle_method(self):
        try:
            self.dispatch()
        except PermissionError:
            self.reply(403, {'error': 'Viewer authentication or origin check failed'})
        except (ValueError, KeyError, TypeError, UnicodeError):
            self.reply(400, {'error': 'Invalid viewer request or recording not ready'})
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            pass
        except (OSError, subprocess.SubprocessError):
            self.reply(503, {'error': 'Viewing service unavailable; robot execution is unaffected'})

    do_GET = handle_method
    do_POST = handle_method


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=18432)
    parser.add_argument('--private-dir', type=Path, default=HERE / 'private')
    args = parser.parse_args(argv)
    private = private_directory(args.private_dir)
    claim = (private / 'viewer.lock').open('a')
    fcntl.flock(claim, fcntl.LOCK_EX | fcntl.LOCK_NB)
    token = private / 'admin.token'
    if not token.exists():
        create_token_file(token)
    transport = ViewerTransport()
    server = ViewerServer(args.port, transport, private, load_token(token))
    save_json(private / 'server_state.json', {'identity': identity(os.getpid()), 'port': server.server_port,
        'instance_id': server.instance_id, 'read_only': False, 'browser_read_only': True,
        'backend_scene_control': True, 'remote_token_copied': False})
    stopped = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stopped.set())
    signal.signal(signal.SIGINT, lambda *_: stopped.set())
    transport.start()
    server.timeout = .2
    print(json.dumps({'event': 'ready', 'url': 'http://127.0.0.1:' + str(server.server_port),
                     'browser_read_only': True, 'backend_scene_control': True}), flush=True)
    try:
        while not stopped.is_set():
            server.handle_request()
    finally:
        transport.close()
        server.server_close()
        claim.close()


if __name__ == '__main__':
    main()
