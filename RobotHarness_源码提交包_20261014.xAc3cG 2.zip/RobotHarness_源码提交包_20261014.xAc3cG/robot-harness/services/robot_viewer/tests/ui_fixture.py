"""Public synthetic UI fixture: NO credentials, remote data, SSH or robot access."""
import base64
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import struct
import zlib

STATIC=Path(__file__).resolve().parents[1]/'static'
RUN='run_'+'a'*32
def chunk(kind,body):
    return struct.pack('>I',len(body))+kind+body+struct.pack('>I',zlib.crc32(kind+body))
rgb=b''.join(b'\0'+b''.join(bytes((35+x//4,75+y//3,105)) if x<256 else bytes((75,55+y//4,40+(x-256)//3)) for x in range(512)) for y in range(256))
png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',512,256,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(rgb))+chunk(b'IEND',b'')
status={'run_id':RUN,'request':{'task_id':'界面测试（模拟数据）','policy':'internw0'},'current_stage':3,'stage_count':5,'steps':1200,'vla_steps':260,'tool_steps':940,'status':'running','active':True,'completed_stage_ids':[1,2]}
snapshot={'runs':[status],'status':status,'selected_run_id':RUN,'connection':'connected','runner_available':True,'mode':'live','available':True,'frame_age_seconds':.3,
    'frame':{'frame_id':1196,'step':1196,'stage_id':3,'source':'vla','width':512,'height':256,'image_mime':'image/png','image_base64':base64.b64encode(png).decode()}}
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        if self.path=='/api/snapshot': raw=json.dumps(snapshot,ensure_ascii=False).encode(); mime='application/json'
        elif self.path in ('/','/app.js','/style.css'):
            raw=(STATIC/('index.html' if self.path=='/' else self.path[1:])).read_bytes()
            mime={'/':'text/html','/app.js':'text/javascript','/style.css':'text/css'}[self.path]
        else:self.send_error(404);return
        self.send_response(200);self.send_header('Content-Type',mime+'; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
if __name__=='__main__':
    ThreadingHTTPServer(('127.0.0.1',18433),Handler).serve_forever()
