"""Loopback/UI transport tests: no SSH, models, simulation or paid calls."""
import base64
import contextlib
import http.client
import io
import json
import os
from pathlib import Path
import queue
import re
import secrets
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
from urllib.parse import urlencode

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from viewer_server import ViewerServer
from viewer_transport import ViewerTransport
from remote_preview_bridge import read_commands
import remote_preview_bridge
import viewer

RUN = 'run_' + 'a' * 32
OTHER = 'run_' + 'b' * 32


class TransportTests(unittest.TestCase):
    def test_scene_delta_and_connection_age_cannot_masquerade_as_live(self):
        transport=ViewerTransport();scene='scene_'+'a'*32
        frame=dict(frame_id=1000000,width=512,height=256,image_mime='image/jpeg',
                   image_base64=base64.b64encode(b'jpeg').decode())
        packet=dict(type='scene',scene_id=scene,status={'scene_id':scene,'status':'idle'},scenes=[{'scene_id':scene}],frame=frame)
        with patch('viewer_transport.time.monotonic',return_value=100):
            transport.ingest(packet)
            delta=dict(frame);delta.pop('image_base64')
            transport.ingest(dict(packet,frame=delta))
            self.assertEqual(transport.scene_snapshot()['frame']['image_base64'],frame['image_base64'])
            self.assertEqual(transport.scene_snapshot()['connection'],'connected')
        with patch('viewer_transport.time.monotonic',return_value=110):
            self.assertEqual(transport.scene_snapshot()['connection'],'reconnecting')
    def test_catalog_uses_fixed_read_command_and_unknown_on_failure(self):
        row = {'task_id': 'five', 'title': 'five', 'policies': ['atomic'], 'allowed_seeds': [47],
               'configuration_available': False, 'stages': None, 'budget': None}
        packet = {'http_status': 200, 'response': {'tasks': [row], 'runs_enabled': False}}
        original = __import__('subprocess').Popen
        commands = []
        def fake(command, **kwargs):
            commands.append(command)
            return original([sys.executable, '-B', '-c', 'print(' + repr(json.dumps(packet)) + ')'], **kwargs)
        transport = ViewerTransport()
        with patch('viewer_transport.subprocess.Popen', side_effect=fake):
            self.assertFalse(transport.catalog()['runs_enabled'])
            self.assertEqual(commands[0][-1], transport.python + ' -B ' + transport.runner_dir + '/client.py tasks')
            self.assertIn('BatchMode=yes', commands[0]); self.assertIn('ClearAllForwardings=yes', commands[0])
            for broken in ([], {'http_status': 401, 'response': {}},
                           {'http_status': 200, 'response': {'tasks': [row, row], 'runs_enabled': True}}):
                packet = broken
                result = transport.catalog()
                self.assertFalse(result['runner_available']); self.assertIsNone(result['runs_enabled'])
                self.assertEqual(result['tasks'], [])
        self.assertIsNone(transport.process); self.assertEqual(transport.connections, 0)

    def test_delta_frames_selection_age_and_validation(self):
        transport = ViewerTransport()
        transport.ingest({'type': 'runs', 'runs': [{'run_id': RUN, 'active': True}]})
        frame = {'frame_id': 12, 'width': 512, 'height': 256, 'image_mime': 'image/jpeg',
                 'image_base64': base64.b64encode(b'\xff\xd8x\xff\xd9').decode()}
        message = dict(type='update', run_id=RUN, frame=frame, available=True, mode='live',
                       frame_age_seconds=3, status={'run_id': RUN})
        transport.ingest(message)
        self.assertGreaterEqual(transport.snapshot()['frame_age_seconds'], 3)
        delta = dict(frame); delta.pop('image_base64')
        transport.ingest(dict(message, frame=delta))
        self.assertEqual(transport.snapshot()['frame']['image_base64'], frame['image_base64'])
        transport.ingest(dict(message, run_id=OTHER))
        self.assertEqual(transport.snapshot()['selected_run_id'], RUN)
        with self.assertRaises(ValueError):
            transport.watch(OTHER)
        for change in ({'frame_age_seconds': float('nan')}, {'frame': dict(frame, width=99999)},
                       {'frame': dict(frame, image_base64='!')}):
            with self.assertRaises(ValueError):
                transport.ingest(dict(message, **change))
        self.assertIsNone(transport.process)
        transport.reconnect()
        self.assertTrue(transport.reconnect_event.is_set())
        self.assertIsNone(transport.process)

    def test_persistent_reader_reconnects_without_task_commands(self):
        program = ('import json,sys,time\n'
            'print(json.dumps({"type":"runs","runs":[{"run_id":"' + RUN + '","active":True}]}),flush=True)\n'
            'for line in sys.stdin:\n'
            ' command=json.loads(line)\n'
            ' assert command == {"op":"watch","run_id":"' + RUN + '"}\n'
            ' print(json.dumps({"type":"health","runner_available":True}),flush=True)\n')
        transport = ViewerTransport(command=[sys.executable, '-B', '-u', '-c', program])
        transport.start()
        try:
            deadline = time.monotonic() + 4
            while not transport.snapshot()['runner_available'] and time.monotonic() < deadline:
                time.sleep(.02)
            self.assertTrue(transport.snapshot()['runner_available'])
            first = transport.process
            transport.reconnect()
            deadline = time.monotonic() + 4
            while transport.snapshot()['ssh_connections_started'] < 2 and time.monotonic() < deadline:
                time.sleep(.02)
            self.assertGreaterEqual(transport.snapshot()['ssh_connections_started'], 2)
            self.assertIsNotNone(first.poll())
            self.assertEqual(transport.snapshot()['selected_run_id'], RUN)
        finally:
            transport.close()
        self.assertFalse(transport.thread.is_alive())

    def test_bridge_accepts_watch_only(self):
        pending, stopped = queue.Queue(maxsize=1), threading.Event()
        commands = [dict(op='start', run_id=RUN), dict(op='watch', run_id='../bad'),
                    dict(op='watch', run_id=OTHER, extra=True), dict(op='watch', run_id=RUN)]
        read_commands(io.StringIO('\n'.join(json.dumps(c) for c in commands) + '\n'), pending, stopped)
        self.assertEqual(pending.get_nowait(), RUN)
        self.assertTrue(stopped.is_set())

    def test_bridge_active_previews_are_faster_than_status_reads_and_read_only(self):
        packets, calls, results = [], [], []
        values = {'/health': {'runs_enabled': False}, '/runs': {'runs': [{'run_id': RUN}]}, '/scenes':{'scenes':[]},
                  '/runs/' + RUN: {'run_id': RUN, 'active': True},
                  '/runs/' + RUN + '/details': {'run_id': RUN},
                  '/runs/' + RUN + '/frame': {'frame': None, 'available': False, 'mode': 'waiting'}}
        class Connection:
            def __init__(self, *args, **kwargs): pass
            def request(self, method, path, headers):
                if method != 'GET' or path not in values: raise AssertionError('Unexpected bridge write/route')
                self.path = path; calls.append((time.monotonic(), path))
            def getresponse(self): return self
            status = 200
            def read(self, limit): return json.dumps(values[self.path]).encode()
            def close(self): pass
        with tempfile.TemporaryDirectory(prefix='viewer_bridge_cadence_') as temporary:
            from auth import create_token_file
            folder = Path(temporary); (folder / 'private').mkdir(mode=0o700)
            create_token_file(folder / 'private/api.token')
            read_fd, write_fd = os.pipe()
            stream = os.fdopen(read_fd, 'r')
            with patch.object(remote_preview_bridge.sys, 'stdin', stream), \
                    patch.object(remote_preview_bridge.http.client, 'HTTPConnection', Connection), \
                    patch.object(remote_preview_bridge, 'emit', lambda packet: packets.append((time.monotonic(), packet))):
                thread = threading.Thread(target=lambda: results.append(remote_preview_bridge.main(['--runner-dir', temporary])))
                thread.start()
                try:
                    os.write(write_fd, (json.dumps({'op': 'watch', 'run_id': RUN}) + '\n').encode())
                    deadline = time.monotonic() + 4
                    while sum(p['type'] == 'update' for _, p in packets) < 8 and time.monotonic() < deadline:
                        time.sleep(.01)
                finally:
                    os.close(write_fd); thread.join(5); stream.close()
                self.assertFalse(thread.is_alive())
            updates = [stamp for stamp, p in packets if p['type'] == 'update']
            self.assertGreaterEqual(len(updates), 8)
            self.assertLess((updates[7] - updates[0]) / 7, .2)
            self.assertLess(sum(path.endswith('/details') for _, path in calls), len(updates))
            self.assertEqual(results, [0])

    def test_two_viewers_keep_separate_frames_and_fair_observation(self):
        transport = ViewerTransport()
        transport.ingest({'type': 'runs', 'runs': [{'run_id': RUN, 'active': True},
                                                 {'run_id': OTHER, 'active': False}]})
        frame = dict(frame_id=1, width=32, height=16, image_mime='image/jpeg',
                     image_base64=base64.b64encode(b'first').decode())
        # A packet may arrive after a different browser has requested another run.
        transport.watch(RUN)
        transport.watch(OTHER)
        transport.ingest(dict(type='update', run_id=RUN, frame=frame, available=True,
                             mode='live', frame_age_seconds=0, status={'run_id': RUN, 'active': True}))
        transport.ingest(dict(type='update', run_id=OTHER, frame=dict(frame, image_base64=base64.b64encode(b'second').decode()),
                             available=True, mode='final', frame_age_seconds=1,
                             status={'run_id': OTHER, 'active': False}))
        delta = dict(frame); delta.pop('image_base64')
        transport.ingest(dict(type='update', run_id=RUN, frame=delta, available=True,
                             mode='live', frame_age_seconds=0, status={'run_id': RUN, 'active': True}))
        self.assertEqual(transport.snapshot(RUN)['frame']['image_base64'], frame['image_base64'])
        self.assertEqual(transport.snapshot(OTHER)['frame']['image_base64'], base64.b64encode(b'second').decode())
        self.assertEqual(transport.snapshot(RUN)['status']['run_id'], RUN)
        # Repeated polling of a failed/terminal history item must not clear or starve live data.
        for _ in range(10):
            transport.watch(RUN); transport.watch(OTHER)
        now = time.monotonic()
        self.assertEqual(transport.next_watch(OTHER, now - 2, now), RUN)
        self.assertIsNotNone(transport.snapshot(RUN)['frame'])
        transport.ingest({'type': 'runs', 'runs': [{'run_id': RUN, 'active': True}]})
        self.assertEqual(set(transport.observations), {RUN})
        self.assertNotIn(OTHER, transport.watch_requests)
        transport.ingest({'type': 'runs', 'runs': []})
        self.assertIsNone(transport.snapshot()['selected_run_id'])
        self.assertEqual(transport.observations, {})

    def test_two_active_viewers_rotate_only_after_packet_or_timeout(self):
        transport = ViewerTransport()
        transport.ingest({'type': 'runs', 'runs': [{'run_id': RUN, 'active': True},
                                                 {'run_id': OTHER, 'active': True}]})
        transport.watch(RUN); transport.watch(OTHER)
        now = time.monotonic()
        transport.watch_served[RUN] = now
        self.assertEqual(transport.next_watch(RUN, now, now + .5), RUN)
        transport.ingest(dict(type='update', run_id=RUN, frame=None, available=False,
                             mode='waiting', frame_age_seconds=None, status={'run_id': RUN, 'active': True}))
        self.assertEqual(transport.next_watch(RUN, now - 1, now + 1), OTHER)
        self.assertEqual(transport.next_watch(RUN, now - 3, now), OTHER)

    def test_persistent_reader_serves_two_polling_clients_without_starvation(self):
        program = ('import json,sys,time\n'
            'runs=' + repr([{'run_id': RUN, 'active': True}, {'run_id': OTHER, 'active': True}]) + '\n'
            'print(json.dumps({"type":"runs","runs":runs}),flush=True)\n'
            'for line in sys.stdin:\n'
            ' command=json.loads(line)\n'
            ' assert command["op"] == "watch"\n'
            ' run=command["run_id"]\n'
            ' time.sleep(.15)\n'
            ' print(json.dumps({"type":"update","run_id":run,"status":{"run_id":run,"active":True},'
            '"frame":None,"mode":"waiting","available":False,"frame_age_seconds":None}),flush=True)\n')
        transport = ViewerTransport(command=[sys.executable, '-B', '-u', '-c', program])
        transport.start()
        try:
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                if len(transport.snapshot()['runs']) == 2:
                    transport.watch(RUN); transport.watch(OTHER)
                    if transport.snapshot(RUN)['status'] and transport.snapshot(OTHER)['status']:
                        break
                time.sleep(.02)
            self.assertEqual(transport.snapshot(RUN)['status']['run_id'], RUN)
            self.assertEqual(transport.snapshot(OTHER)['status']['run_id'], OTHER)
            self.assertEqual(transport.snapshot()['ssh_connections_started'], 1)
        finally:
            transport.close()


class FakeTransport(ViewerTransport):
    def __init__(self):
        super().__init__()
        self.ingest({'type': 'runs', 'runs': [{'run_id': RUN, 'active': False}]})
        self.ingest(dict(type='update', run_id=RUN, frame=None, available=False, mode='final',
                         frame_age_seconds=None, status={'run_id': RUN, 'active': False, 'video_size_bytes': 16}))

    def catalog(self):
        return {'connection': 'connected', 'runner_available': True, 'runs_enabled': False,
                'tasks': [{'task_id': 'registered', 'policies': ['atomic'], 'allowed_seeds': [47]}]}


class ViewerHTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='robot_viewer_test_')
        self.transport = FakeTransport()
        self.token = secrets.token_urlsafe(32).encode()
        self.server = ViewerServer(0, self.transport, Path(self.temp.name) / 'private', self.token)
        self.thread = threading.Thread(target=self.server.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
        self.thread.start()
        self.cookie = None
        self.origin = 'http://127.0.0.1:' + str(self.server.server_port)

    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(2)
        self.temp.cleanup()

    def call(self, method, path, body=None, headers=None, cookie=True):
        supplied = dict(headers or {})
        if cookie and self.cookie:
            supplied['Cookie'] = self.cookie
        client = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=3)
        try:
            client.request(method, path, body=body, headers=supplied)
            response = client.getresponse()
            return response.status, response.read(), dict(response.getheaders())
        finally:
            client.close()

    def authenticate(self):
        code, raw, _ = self.call('POST', '/auth/bootstrap', '{}', {
            'Content-Type': 'application/json', 'Authorization': 'Bearer ' + self.token.decode()})
        self.assertEqual(code, 200)
        path = Path(json.loads(raw)['bootstrap_file'])
        self.assertEqual(path.stat().st_mode & 0o777, 0o600)
        access = re.search('name="access" value="([^"]+)"', path.read_text()).group(1)
        request = urlencode({'access': access})
        code, _, headers = self.call('POST', '/auth/session', request,
            {'Content-Type': 'application/x-www-form-urlencoded', 'Origin': 'null'})
        self.assertEqual(code, 200)
        self.cookie = headers['Set-Cookie'].split(';')[0]
        self.assertIn('HttpOnly', headers['Set-Cookie'])
        self.assertEqual(self.call('POST', '/auth/session', request,
            {'Content-Type': 'application/x-www-form-urlencoded'})[0], 403)

    def test_authentication_no_credentials_in_browser_snapshot(self):
        self.assertEqual(self.call('GET', '/api/snapshot')[0], 401)
        self.assertEqual(self.call('POST', '/auth/bootstrap', '{}', {'Content-Type': 'application/json'})[0], 403)
        self.authenticate()
        code, raw, _ = self.call('GET', '/api/snapshot')
        self.assertEqual(code, 200)
        self.assertNotIn(self.token, raw)
        self.assertNotIn(self.server.session.encode(), raw)
        self.assertEqual(json.loads(raw)['selected_run_id'], RUN)

    def test_backend_facade_is_bounded_read_only_and_never_browser_authorized(self):
        headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + self.token.decode()}
        body = json.dumps({'op': 'observation', 'run_id': RUN})
        self.assertEqual(self.call('POST', '/internal/read', body, {'Content-Type':'application/json'})[0], 403)
        self.assertEqual(self.call('POST', '/internal/read', body, dict(headers, Origin=self.origin))[0], 403)
        code, raw, _ = self.call('POST', '/internal/read', body, headers)
        self.assertEqual(code, 200)
        self.assertNotIn(self.token, raw)
        self.assertNotIn('stage_states', json.loads(raw)['status'])
        self.transport.observations[RUN]['status']['details'] = {'run_id': RUN, 'stages': [{'id': 1, 'achieved_once': True, 'current_satisfied': False}],
                                          'native_success': True, 'workflow_success': True}
        code, raw, _ = self.call('POST', '/internal/read', body, headers)
        self.assertTrue(json.loads(raw)['details']['stages'][0]['achieved_once'])
        self.assertFalse(json.loads(raw)['details']['stages'][0]['current_satisfied'])
        self.transport.observations[RUN]['status']['details']['run_id'] = OTHER
        code, raw, _ = self.call('POST', '/internal/read', body, headers)
        self.assertNotIn('details', json.loads(raw))
        code, raw, _ = self.call('POST', '/internal/read', json.dumps({'op':'tasks'}), headers)
        self.assertEqual(code, 200); self.assertEqual(json.loads(raw)['tasks'][0]['task_id'], 'registered')
        self.assertNotIn(self.token, raw)
        for extra in ({'url':'http://evil'}, {'path':'/private'}, {'run_id':RUN}, {'command':'start'}):
            self.assertEqual(self.call('POST', '/internal/read', json.dumps(dict(op='tasks', **extra)), headers)[0], 400)
        for op in ('start', 'stop', 'exec', 'reconnect'):
            self.assertEqual(self.call('POST', '/internal/read', json.dumps({'op':op}), headers)[0], 400)
        with patch.object(self.transport,'catalog',return_value={'connection':'connected','runs_enabled':False,'tasks':[]}) as catalog:
            code,raw,_=self.call('POST','/internal/read',json.dumps({'op':'tasks'}),headers)
            self.assertEqual(code,200);self.assertFalse(json.loads(raw)['runs_enabled']);catalog.assert_called_once()

    def test_scene_effect_requires_backend_auth_and_is_not_a_read_operation(self):
        headers={'Content-Type':'application/json','Authorization':'Bearer '+self.token.decode()}
        payload=json.dumps({'op':'command','input':{'scene_id':'scene_'+'a'*32,'operation':'close'}})
        with patch.object(self.transport,'scene_effect',return_value={'http_status':400,'response':{'error':'invalid'}}) as send:
            self.assertEqual(self.call('POST','/internal/scene-effect',payload,{'Content-Type':'application/json'})[0],403)
            self.assertEqual(self.call('POST','/internal/scene-effect',payload,dict(headers,Origin=self.origin))[0],403)
            self.assertEqual(self.call('POST','/internal/read',payload,headers)[0],400)
            send.assert_not_called()
            self.assertEqual(self.call('POST','/internal/scene-effect',payload,headers)[0],200)
            send.assert_called_once()
            self.assertEqual(self.call('POST','/internal/read',json.dumps({'op':'tasks','path':'/bad'}),headers)[0],400)
        (self.server.cache/(RUN+'.mp4')).write_bytes(b'0123456789abcdef')
        code, raw, _ = self.call('POST', '/internal/read', json.dumps({'op':'replay_chunk','run_id':RUN,'offset':4}), headers)
        self.assertEqual(code, 200)
        self.assertEqual(base64.b64decode(json.loads(raw)['data_base64']), b'456789abcdef')
        self.assertEqual(self.call('POST', '/internal/read', json.dumps({'op':'replay_chunk','run_id':RUN,'offset':16}), headers)[0], 400)

    def test_launcher_reuses_nonce_verified_server_despite_shell_timezone_identity(self):
        private = self.server.private_root
        (private/'server_state.json').write_text(json.dumps({'identity':{'pid':123},
            'port':self.server.server_port,'instance_id':self.server.instance_id}))
        token_file = private/'admin.token'; token_file.write_bytes(self.token); token_file.chmod(0o600)
        with patch.object(viewer,'HERE',private.parent), patch.object(viewer,'process_state',return_value='gone'), \
                patch.object(viewer.subprocess,'Popen',side_effect=AssertionError('Must not start a duplicate viewer')), \
                contextlib.redirect_stdout(io.StringIO()) as output:
            viewer.main(['prepare'])
        self.assertTrue(json.loads(output.getvalue())['read_only'])
        self.assertTrue((private/'open_viewer.html').exists())

    def test_backend_observation_is_run_scoped_even_if_another_client_switches(self):
        self.transport.ingest({'type': 'runs', 'runs': [{'run_id': RUN}, {'run_id': OTHER}]})
        self.transport.ingest(dict(type='update', run_id=OTHER, frame=None, available=False,
            mode='waiting', frame_age_seconds=None, status={'run_id': OTHER, 'active': True, 'steps': 99}))
        original = self.transport.watch
        def racing_watch(run):
            original(run)
            original(OTHER)  # A different request selects B between A's watch and snapshot.
        with patch.object(self.transport, 'watch', side_effect=racing_watch):
            result = self.server.integration_read({'op': 'observation', 'run_id': RUN})
        self.assertEqual(result['selected_run_id'], RUN)
        self.assertEqual(result['status']['run_id'], RUN)
        self.assertNotEqual(result['status']['steps'], 99)

    def test_standalone_snapshot_is_scoped_and_query_is_bounded(self):
        self.authenticate()
        self.transport.ingest({'type': 'runs', 'runs': [{'run_id': RUN}, {'run_id': OTHER}]})
        self.transport.watch(OTHER)
        code, raw, _ = self.call('GET', '/api/snapshot?run_id=' + RUN)
        self.assertEqual(code, 200)
        self.assertEqual(json.loads(raw)['status']['run_id'], RUN)
        for query in ('run_id=bad', 'run_id=', 'run_id=' + RUN + '&run_id=' + OTHER,
                      'run_id=' + RUN + '&url=http://bad'):
            self.assertEqual(self.call('GET', '/api/snapshot?' + query)[0], 400)

    def test_csrf_bad_json_and_task_mutation_routes_rejected(self):
        self.authenticate()
        headers = {'Content-Type': 'application/json', 'Origin': self.origin}
        self.assertEqual(self.call('POST', '/api/watch', json.dumps({'run_id': RUN}),
            dict(headers, Origin='http://evil.invalid'))[0], 403)
        self.assertEqual(self.call('POST', '/api/watch', json.dumps({'run_id': RUN}), headers)[0], 200)
        self.assertEqual(self.call('POST', '/api/reconnect', '{}', headers)[0], 200)
        self.assertTrue(self.transport.reconnect_event.is_set())
        for route in ('/runs', '/api/start', '/api/stop'):
            self.assertEqual(self.call('POST', route, '{}', headers)[0], 404)
        for body in ('{"run_id":"x","run_id":"y"}', '{"run_id":NaN}', 'x' * 4097):
            self.assertEqual(self.call('POST', '/api/watch', body, headers)[0], 400)
        self.assertEqual(self.call('GET', '/health', headers={'Host': 'evil.invalid'})[0], 403)

    def test_video_range_is_authenticated_and_terminal_only(self):
        video = b'0123456789abcdef'
        (self.server.cache / (RUN + '.mp4')).write_bytes(video)
        self.assertEqual(self.call('GET', '/video/' + RUN)[0], 401)
        self.authenticate()
        code, data, headers = self.call('GET', '/video/' + RUN, headers={'Range': 'bytes=2-5'})
        self.assertEqual((code, data), (206, b'2345'))
        self.assertEqual(headers['Content-Range'], 'bytes 2-5/16')
        self.assertEqual(self.call('GET', '/video/' + RUN, headers={'Range': 'bytes=99-'})[0], 416)
        self.transport.observations[RUN]['status']['active'] = True
        self.assertEqual(self.call('GET', '/video/' + RUN)[0], 400)


if __name__ == '__main__':
    unittest.main()
