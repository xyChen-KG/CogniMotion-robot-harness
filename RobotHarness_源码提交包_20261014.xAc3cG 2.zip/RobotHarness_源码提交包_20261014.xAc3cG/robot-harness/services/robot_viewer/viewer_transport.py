"""Persistent SSH observer and a separate explicit backend scene-command relay."""
from __future__ import annotations

import base64
import copy
import json
from pathlib import Path
import re
import select
import subprocess
import threading
import time

RUN_ID = re.compile(r'run_[a-f0-9]{32}\Z')
MAX_LINE = 2_000_000


class ViewerTransport:
    def __init__(self, *, ssh_alias='robot-gpu', runner_dir='/opt/robot-harness/services/robot_runner',
                 remote_bridge='/opt/robot-harness/services/robot_viewer/remote_preview_bridge.py',
                 python='/opt/libero/runtime/bin/python', command=None):
        for value in (ssh_alias, runner_dir, remote_bridge, python):
            if not re.fullmatch(r'[A-Za-z0-9_./-]+', value) or value.startswith('-'):
                raise ValueError('Invalid operator-owned SSH configuration')
        self.ssh_alias, self.runner_dir, self.python = ssh_alias, runner_dir, python
        self.command = command or ['ssh', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=12',
            '-o', 'ClearAllForwardings=yes', '-o', 'ServerAliveInterval=10', '-o', 'ServerAliveCountMax=2',
            ssh_alias, f'{python} -B {remote_bridge} --runner-dir {runner_dir}']
        self.lock = threading.RLock()
        self.stop_event, self.reconnect_event = threading.Event(), threading.Event()
        self.process = self.thread = None
        self.selected = None
        self.runs, self.observations = [], {}
        self.scene = None
        self.watch_requests, self.watch_served = {}, {}
        self.connection, self.error = 'connecting', None
        self.runner_available, self.runs_enabled = False, False
        self.last_message = None
        self.connections = 0

    def start(self):
        self.thread = threading.Thread(target=self._run, name='viewer-ssh', daemon=True)
        self.thread.start()

    def watch(self, run_id):
        if not isinstance(run_id, str) or not RUN_ID.fullmatch(run_id):
            raise ValueError('Invalid run_id')
        with self.lock:
            if run_id not in {r.get('run_id') for r in self.runs}:
                raise ValueError('Choose a listed run')
            self.selected = run_id  # Default for the standalone viewer only.
            self.watch_requests[run_id] = time.monotonic()

    def next_watch(self, current, started, now):
        """Fairly multiplex one read-only bridge; UI polls cannot cancel packets.

        Active subscriptions expire after eight seconds. Terminal observations
        are refreshed at most every ten seconds so history tabs do not compete
        with a running task for every preview. All maps are bounded by /runs.
        """
        with self.lock:
            requested = [run for run, stamp in self.watch_requests.items() if now - stamp <= 8]
            if not requested:
                requested = [self.selected] if self.selected else []
            due = [run for run in requested if not (
                self.observations.get(run, {}).get('status', {}).get('active') is False
                and now - self.observations[run]['received'] < 10)]
            if not due:
                return current if current in requested else next(iter(requested), None)
            received = self.observations.get(current, {}).get('received', 0)
            if current in due and (now - started < .75 or (received < started and now - started < 2)):
                return current  # Give an in-flight observation a chance to arrive.
            return min(due, key=lambda run: self.watch_served.get(run, 0))

    def ingest(self, message):
        if not isinstance(message, dict):
            raise ValueError('Invalid bridge packet')
        with self.lock:
            now = time.monotonic()
            if message.get('type') == 'runs':
                runs = message.get('runs')
                if not isinstance(runs, list) or len(runs) > 20:
                    raise ValueError('Invalid runs listing')
                self.runs = [r for r in runs if isinstance(r, dict) and isinstance(r.get('run_id'), str)
                             and RUN_ID.fullmatch(r['run_id'])]
                listed = {r['run_id'] for r in self.runs}
                for cache in (self.observations, self.watch_requests, self.watch_served):
                    for run in set(cache) - listed:
                        del cache[run]
                self.runs_enabled = message.get('runs_enabled') is True
                if self.selected not in listed:
                    preferred = next((r for r in self.runs if r.get('active')), next(iter(self.runs), None))
                    self.selected = preferred['run_id'] if preferred else None
            elif message.get('type') == 'health':
                self.runner_available = message.get('runner_available') is True
                self.error = None if self.runner_available else '远程运行服务暂不可用；不会自动启动任务'
            elif message.get('type') == 'scene':
                scene_id = message.get('scene_id')
                if scene_id is not None and not re.fullmatch(r'scene_[a-f0-9]{32}', str(scene_id)):
                    raise ValueError('Invalid scene identifier')
                frame = message.get('frame')
                if frame:
                    if frame.get('image_mime') != 'image/jpeg' or any(
                            type(frame.get(k)) is not int or not 1 <= frame[k] <= 2048 for k in ('width', 'height')):
                        raise ValueError('Invalid scene image')
                    if 'image_base64' in frame:
                        if len(base64.b64decode(frame['image_base64'], validate=True)) > 600_000:
                            raise ValueError('Scene preview exceeds limit')
                    elif (self.scene and self.scene.get('scene_id') == scene_id
                          and (self.scene.get('frame') or {}).get('frame_id') == frame.get('frame_id')):
                        frame = dict(frame, image_base64=self.scene['frame']['image_base64'])
                    else:
                        frame = None
                rows = message.get('scenes')
                if not isinstance(rows, list) or len(rows) > 20 or (scene_id and
                        (message.get('status') or {}).get('scene_id') != scene_id):
                    raise ValueError('Invalid scene status')
                self.scene = dict(scene_id=scene_id, status=message.get('status'), scenes=rows, frame=frame,
                                  mode=message.get('mode'), available=bool(frame),
                                  frame_age_seconds=message.get('frame_age_seconds'), received=now)
            elif message.get('type') == 'update':
                run_id = message.get('run_id')
                if run_id not in {r['run_id'] for r in self.runs}:
                    return
                previous = self.observations.get(run_id, {}).get('frame')
                frame = message.get('frame')
                if frame is not None:
                    if not isinstance(frame, dict) or frame.get('image_mime') not in ('image/jpeg', 'image/png'):
                        raise ValueError('Invalid image packet')
                    if not all(type(frame.get(k)) is int and 1 <= frame[k] <= 2048 for k in ('width', 'height')):
                        raise ValueError('Invalid frame dimensions')
                    if 'image_base64' in frame:
                        raw = base64.b64decode(frame['image_base64'], validate=True)
                        if len(raw) > 1_500_000:
                            raise ValueError('Image exceeds limit')
                    elif previous and previous['frame_id'] == frame.get('frame_id'):
                        frame = dict(frame, image_base64=previous['image_base64'])
                    else:
                        return
                age = message.get('frame_age_seconds')
                if age is not None and (type(age) not in (int, float) or not 0 <= age < 1e10):
                    raise ValueError('Invalid frame age')
                status = message.get('status')
                if not isinstance(status, dict) or status.get('run_id') != run_id:
                    raise ValueError('Invalid run status')
                self.observations[run_id] = dict(status=status, frame=frame,
                    available=message.get('available') is True, mode=message.get('mode'),
                    frame_age=age, received=now)
            else:
                raise ValueError('Unknown bridge packet')
            self.connection, self.last_message = 'connected', now

    def scene_snapshot(self):
        with self.lock:
            value = copy.deepcopy(self.scene or {'scene_id': None, 'status': None, 'scenes': [], 'frame': None})
            received = value.pop('received', None)
            value.update(connection=self.connection, runner_available=self.runner_available,
                         observation_age_seconds=None if received is None else time.monotonic() - received)
            if value['observation_age_seconds'] is None or value['observation_age_seconds'] > 8:
                value['connection'] = 'reconnecting'
            return value

    def scene_effect(self, value):
        """Backend-authenticated explicit effect only. No URLs/commands supplied by UI."""
        command = ['ssh', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=12',
                   '-o', 'ClearAllForwardings=yes', self.ssh_alias,
                   f'{self.python} -B {self.runner_dir}/scene_client.py']
        try:
            result = subprocess.run(command, input=json.dumps(value).encode(), stdout=subprocess.PIPE,
                                    stderr=subprocess.DEVNULL, timeout=22, close_fds=True)
            if len(result.stdout) > 524288:
                raise ValueError('Oversized scene response')
            reply = json.loads(result.stdout)
            if not isinstance(reply, dict) or type(reply.get('http_status')) is not int or not isinstance(reply.get('response'), dict):
                raise ValueError('Invalid scene response')
            return reply
        except (OSError, ValueError, subprocess.SubprocessError):
            return {'http_status': 503, 'response': {'error': '场景请求结果未知；请刷新状态，不要换请求编号自动重试。'}}

    def snapshot(self, run_id=None):
        with self.lock:
            now = time.monotonic()
            selected = self.selected if run_id is None else run_id
            observation = self.observations.get(selected, {})
            age = observation.get('frame_age')
            if age is not None:
                age += now - observation['received']
            connection_age = None if self.last_message is None else now - self.last_message
            connection = self.connection
            if connection_age is not None and connection_age > 8:
                connection = 'reconnecting'
            return copy.deepcopy({'connection': connection, 'connection_age_seconds': connection_age,
                'runner_available': self.runner_available, 'runs_enabled': self.runs_enabled,
                'error': self.error, 'runs': self.runs, 'selected_run_id': selected,
                'status': observation.get('status'), 'frame': observation.get('frame'),
                'available': observation.get('available', False), 'mode': observation.get('mode', 'waiting'),
                'frame_age_seconds': age, 'ssh_connections_started': self.connections})

    def catalog(self):
        """Fresh, bounded GET /tasks via fixed server client. No selectable route.

        Unlike the streaming preview, failure returns unknown execution switch;
        it never substitutes the previous listing as current live config.
        """
        command = ['ssh', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=12',
                   '-o', 'ClearAllForwardings=yes', self.ssh_alias,
                   f'{self.python} -B {self.runner_dir}/client.py tasks']
        try:
            process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                       stderr=subprocess.DEVNULL, close_fds=True)
            try:
                raw = bytearray()
                deadline = time.monotonic() + 20
                while True:
                    if time.monotonic() >= deadline:
                        raise subprocess.TimeoutExpired(command, 20)
                    ready, _, _ = select.select([process.stdout], [], [], .2)
                    if ready:
                        chunk = __import__('os').read(process.stdout.fileno(), 65536)
                        if not chunk:
                            break
                        raw.extend(chunk)
                        if len(raw) > 524288:
                            raise ValueError('Catalog exceeds response limit')
                if process.wait(timeout=3) != 0:
                    raise ValueError('Catalog query failed')
            finally:
                if process.poll() is None:
                    process.terminate()  # This one SSH client only.
                    try:
                        process.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=3)
                process.stdout.close()
            packet = json.loads(raw)
            if not isinstance(packet, dict):
                raise ValueError('Invalid catalog envelope')
            body = packet.get('response')
            if packet.get('http_status') != 200 or not isinstance(body, dict):
                raise ValueError('Invalid catalog reply')
            tasks = body.get('tasks')
            if not isinstance(tasks, list) or len(tasks) > 64:
                raise ValueError('Invalid catalog size')
            public = []
            seen = set()
            for task in tasks:
                if (not isinstance(task, dict) or not re.fullmatch(r'[A-Za-z0-9._-]{1,128}', str(task.get('task_id', '')))
                        or task['task_id'] in seen
                        or not isinstance(task.get('policies'), list) or not isinstance(task.get('allowed_seeds'), list)
                        or not task['policies'] or not 1 <= len(task['allowed_seeds']) <= 256
                        or any(p not in ('atomic', 'internw0') for p in task['policies'])
                        or any(type(s) is not int or not 0 <= s <= 2147483647 for s in task['allowed_seeds'])):
                    raise ValueError('Invalid registered choices')
                seen.add(task['task_id'])
                keys = ('task_id', 'title', 'policies', 'allowed_seeds', 'configuration_available',
                        'stages', 'budget', 'completion_mode', 'stable_steps', 'configuration_error')
                public.append({k: task.get(k) for k in keys})
            return {'connection': 'connected', 'runner_available': True,
                    'runs_enabled': body.get('runs_enabled') if type(body.get('runs_enabled')) is bool else None,
                    'tasks': public, 'error': None}
        except (OSError, ValueError, TypeError, subprocess.SubprocessError):
            return {'connection': 'unavailable', 'runner_available': False, 'runs_enabled': None,
                    'tasks': [], 'error': '任务目录暂不可读取；未启动、停止或修改任务。'}

    def reconnect(self):
        self.reconnect_event.set()

    def _end_ssh(self, child):
        if child.poll() is None:
            child.terminate()  # Only our own SSH/bridge, never a model or runner.
            try:
                child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=3)

    def _run(self):
        backoff = 1
        while not self.stop_event.is_set():
            self.reconnect_event.clear()
            with self.lock:
                self.connection = 'connecting' if self.connections == 0 else 'reconnecting'
            child = None
            try:
                child = subprocess.Popen(self.command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL, bufsize=0, close_fds=True, start_new_session=True)
                with self.lock:
                    self.process = child
                    self.connections += 1
                buffer, sent_watch, watch_started = b'', None, 0
                last_received = time.monotonic()
                while not self.stop_event.is_set() and not self.reconnect_event.is_set():
                    now = time.monotonic()
                    selected = self.next_watch(sent_watch, watch_started, now)
                    if selected and selected != sent_watch:
                        child.stdin.write((json.dumps({'op': 'watch', 'run_id': selected}) + '\n').encode())
                        sent_watch = selected
                        watch_started = now
                        with self.lock:
                            self.watch_served[selected] = now
                    readable, _, _ = select.select([child.stdout], [], [], .2)
                    if readable:
                        chunk = __import__('os').read(child.stdout.fileno(), 65536)
                        if not chunk:
                            raise EOFError('SSH closed')
                        buffer += chunk
                        if len(buffer) > MAX_LINE:
                            raise ValueError('Bridge packet too large')
                        while b'\n' in buffer:
                            line, buffer = buffer.split(b'\n', 1)
                            self.ingest(json.loads(line))
                            last_received = time.monotonic()
                            backoff = 1
                    if child.poll() is not None or time.monotonic() - last_received > 15:
                        raise EOFError('SSH heartbeat lost')
            except (OSError, ValueError, EOFError, TypeError, KeyError):
                with self.lock:
                    self.connection = 'reconnecting'
                    self.error = '观看连接中断，正在重连；机器人不会因此停止或重跑'
            finally:
                if child is not None:
                    self._end_ssh(child)
                    for stream in (child.stdin, child.stdout):
                        if stream:
                            stream.close()
                with self.lock:
                    self.process = None
            if not self.stop_event.is_set():
                self.stop_event.wait(backoff)
                backoff = min(backoff * 2, 20)

    def close(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=6)
