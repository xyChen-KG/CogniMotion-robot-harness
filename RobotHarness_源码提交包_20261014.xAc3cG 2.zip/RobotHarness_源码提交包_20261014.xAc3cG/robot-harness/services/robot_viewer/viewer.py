"""Open an authenticated local viewer without putting any token in URLs/argv."""
import argparse
import http.client
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'robot_runner'))
from auth import load_token
from files import private_directory, read_json, process_state


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['open', 'prepare'])
    args = parser.parse_args(argv)
    private = private_directory(HERE / 'private')
    info = read_json(private / 'server_state.json')
    reachable = False
    if info:
        # ps lstart is timezone-dependent on macOS. A private instance nonce is
        # authoritative for reusing a reachable server, even from another shell TZ.
        try:
            probe = http.client.HTTPConnection('127.0.0.1', info['port'], timeout=3)
            try:
                probe.request('GET', '/health')
                response = probe.getresponse(); health = json.loads(response.read())
                if response.status != 200 or health.get('instance_id') != info['instance_id']:
                    raise RuntimeError('Port belongs to a different service; no token was sent')
                reachable = True
            finally:
                probe.close()
        except (ConnectionRefusedError, TimeoutError):
            pass
        if not reachable and process_state(info.get('identity')) != 'gone':
            raise RuntimeError('Cannot confirm local viewer exit; no duplicate server was started')
    if not reachable:
        with (private / 'viewer.log').open('a') as log:
            child = subprocess.Popen([sys.executable, '-B', '-u', str(HERE / 'viewer_server.py')],
                cwd=HERE, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                start_new_session=True, close_fds=True)
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline:
            info = read_json(private / 'server_state.json')
            if info and info.get('identity', {}).get('pid') == child.pid:
                break
            if child.poll() is not None:
                raise RuntimeError('Viewer startup failed; inspect private/viewer.log')
            time.sleep(.1)
        else:
            raise TimeoutError('Viewer readiness timed out')
    c = http.client.HTTPConnection('127.0.0.1', info['port'], timeout=5)
    c.request('GET', '/health')
    r = c.getresponse(); health = json.loads(r.read()); c.close()
    if r.status != 200 or health.get('instance_id') != info['instance_id']:
        raise RuntimeError('Port belongs to a different service; no token was sent')
    c = http.client.HTTPConnection('127.0.0.1', info['port'], timeout=5)
    c.request('POST', '/auth/bootstrap', body='{}', headers={'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + load_token(private / 'admin.token').decode('ascii')})
    r = c.getresponse(); result = json.loads(r.read()); c.close()
    if r.status != 200:
        raise RuntimeError('Cannot open local authenticated session')
    path = Path(result['bootstrap_file'])
    if path != private / 'open_viewer.html':
        raise RuntimeError('Unexpected private bootstrap path')
    if args.operation == 'open':
        subprocess.run(['open', str(path)], check=True)
    print(json.dumps({'url': 'http://127.0.0.1:' + str(info['port']),
                      'bootstrap_file': str(path), 'read_only': True, 'remote_token_copied': False}))


if __name__ == '__main__':
    main()
