"use strict";
const byId = id => document.getElementById(id);
const labels = {starting:"初始化",running:"执行中",stopping:"正在停止",finished:"已结束",stopped:"已停止",failed:"执行错误",start_failed:"启动失败",interrupted:"需检查"};
let selected = null, requested = null, frameKey = null, optionsKey = "", watching = false, snapshot = null;
function text(id, value){byId(id).textContent = value;}
function warning(message){byId("warning").hidden = !message; text("warning",message || "");}
function outcome(id,value){text(id,value === true ? "成功" : value === false ? "未成功" : "未知");byId(id).className = value === true ? "success" : value === false ? "failure" : "";}
async function api(path, body){
  const controller = new AbortController();const timeout = setTimeout(()=>controller.abort(),5000);
  try{
    const response = await fetch(path,{method:body === undefined ? "GET" : "POST",credentials:"same-origin",cache:"no-store",signal:controller.signal,
      headers:body === undefined ? {} : {"Content-Type":"application/json"},body:body === undefined ? undefined : JSON.stringify(body)});
    if(response.status === 401){throw new Error("观看会话已过期，请重新打开启动器");}
    if(!response.ok){throw new Error("观看请求失败，机器人不受影响");}
    return await response.json();
  }finally{clearTimeout(timeout);}
}
function resetVideo(){const video=byId("video");video.pause();video.removeAttribute("src");video.load();byId("video-section").hidden=true;}
function drawFrame(data){
  const frame=data.frame;if(!frame || !frame.image_base64){return;}
  const key=data.selected_run_id+":"+frame.frame_id;if(key === frameKey){return;}
  const image=new Image();const target=data.selected_run_id;
  image.onload=()=>{
    if(selected !== target){return;}
    for(const [id,index] of [["agentview",0],["wrist",1]]){
      const canvas=byId(id);canvas.width=Math.floor(image.width/2);canvas.height=image.height;
      canvas.getContext("2d").drawImage(image,index*canvas.width,0,canvas.width,image.height,0,0,canvas.width,image.height);
      canvas.parentElement.classList.add("has-frame");
    }
    frameKey=key;
  };
  image.onerror=()=>warning("预览图片暂不可读，保留上一个有效画面");
  image.src="data:"+frame.image_mime+";base64,"+frame.image_base64;
}
function render(data){
  snapshot=data;
  const states=data.runs || [];const key=states.map(r=>r.run_id+":"+r.status).join("|");
  if(key !== optionsKey){
    const previous=byId("runs").value;byId("runs").replaceChildren();
    if(!states.length){const option=document.createElement("option");option.textContent="暂无已登记回合";option.value="";byId("runs").append(option);}
    for(const run of states){const option=document.createElement("option");option.value=run.run_id;option.textContent=(run.request?.task_id || "任务")+" · "+(run.request?.policy || "")+" · "+(labels[run.status] || run.status)+" · "+run.run_id.slice(-8);byId("runs").append(option);}
    if(states.some(r=>r.run_id === previous)){byId("runs").value=previous;}
    optionsKey=key;
  }
  if(selected !== data.selected_run_id){
    selected=data.selected_run_id;frameKey=null;resetVideo();
    for(const id of ["agentview","wrist"]){const canvas=byId(id);canvas.getContext("2d").clearRect(0,0,canvas.width,canvas.height);canvas.parentElement.classList.remove("has-frame");}
    if(selected){byId("runs").value=selected;}
  }
  const connected=data.connection === "connected" && data.runner_available;
  text("connection",connected ? "只读通道已连接" : "连接中断 / 重连中");byId("connection").className="badge "+(connected ? "" : "warning");
  text("connection-detail",connected ? "不接管机器人执行" : "保留最后画面，不重启任务");
  const status=data.status || {},frame=data.frame || {};
  text("stage",status.current_stage == null ? "—" : status.current_stage+" / "+(status.stage_count ?? "?"));
  text("task",status.request?.task_id || "等待回合");text("steps",status.steps ?? "—");
  text("step-detail","VLA "+(status.vla_steps ?? "—")+" / 工具 "+(status.tool_steps ?? "—"));
  text("run-state",labels[status.status] || "等待");
  text("phase",frame.source === "tool" ? "画面：工具 / "+(frame.tool || "运动") : frame.source === "vla" ? "画面：VLA 执行" : frame.source === "archive" ? "画面：历史末帧" : "画面：等待采集");
  const age=data.frame_age_seconds;text("frame-age",data.mode === "archive" ? "历史帧" : age == null ? "—" : age.toFixed(1)+" s");
  text("frame-step", "画面步数 "+(frame.step ?? "—")+" · 画面阶段 "+(frame.stage_id ?? "—"));
  text("milestones","已完成阶段 "+(status.completed_stage_ids?.length ? status.completed_stage_ids.join(" → ") : "—"));
  outcome("native",status.native_success);outcome("workflow",status.workflow_success);
  const mode=data.mode === "archive" ? "历史画面，非实时" : !status.active && data.available ? "最终画面" : data.available ? "实时预览" : "等待首帧";
  text("mode",mode);byId("mode").className="badge "+(data.mode === "archive" ? "warning" : "muted");
  byId("replay").disabled=!(status.active === false && status.video_size_bytes > 0);
  text("run-id","run_id "+(selected || "—"));
  document.querySelector(".views").classList.toggle("stale",!connected || data.mode === "archive" || (age != null && age > 2));
  warning(!connected ? (data.error || "观看连接中断，正在恢复；不会重新启动机器人") : data.mode === "archive" ? "这是历史回合的末帧。新的预览回合启动后才能显示实时画面。" : status.active && age > 2 ? "画面已 "+age.toFixed(1)+" 秒未更新；可能正在推理、仿真暂停或采集延迟。" : "");
  drawFrame(data);
}
byId("watch").onclick=async()=>{if(watching || !byId("runs").value){return;}watching=true;const run=byId("runs").value;try{await api("/api/watch",{run_id:run});requested=run;}catch(error){warning(error.message);}finally{watching=false;}};
byId("reconnect").onclick=async()=>{try{await api("/api/reconnect",{});}catch(error){warning(error.message);}};
byId("replay").onclick=()=>{if(!selected || byId("replay").disabled){return;}byId("video-section").hidden=false;const video=byId("video");video.src="/video/"+selected;video.load();video.play().catch(()=>{});};
async function poll(){const target=requested,started=performance.now();let interval=500;try{const data=await api("/api/snapshot"+(target?"?run_id="+encodeURIComponent(target):""));if(target===requested){render(data);if(!requested)requested=data.selected_run_id;}interval=data.status?.active===false?1000:125;}catch(error){warning(error.message);text("connection","本地连接异常");byId("connection").className="badge danger";}setTimeout(poll,Math.max(0,(document.hidden?1500:interval)-(performance.now()-started)));}
poll();
