"use strict";
window.location.replace("/");
