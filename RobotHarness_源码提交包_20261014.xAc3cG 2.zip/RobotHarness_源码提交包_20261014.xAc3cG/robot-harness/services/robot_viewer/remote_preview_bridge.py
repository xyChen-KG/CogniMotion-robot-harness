"""READ ONLY SSH bridge. Remote runner token never leaves this host."""
from __future__ import annotations

import argparse
import http.client
import json
from pathlib import Path
import queue
import re
import sys
import threading
import time

RUN_ID = re.compile(r'run_[a-f0-9]{32}\Z')
MAX_LINE = 2_000_000


def emit(value):
    print(json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(',', ':')), flush=True)


def read_commands(stream, pending, stopped):
    while not stopped.is_set():
        line = stream.readline(4097)
        if not line:
            stopped.set()
            return
        try:
            command = json.loads(line)
            if len(line) > 4096 or not isinstance(command, dict) or set(command) != {'op', 'run_id'}:
                continue
            if command['op'] != 'watch' or not RUN_ID.fullmatch(command['run_id']):
                continue
            try:
                pending.get_nowait()
            except queue.Empty:
                pass
            pending.put_nowait(command['run_id'])
        except (ValueError, TypeError, queue.Full):
            continue


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runner-dir', type=Path, required=True)
    args = parser.parse_args(argv)
    sys.path.insert(0, str(args.runner_dir))
    from auth import load_token
    token = load_token(args.runner_dir / 'private/api.token')

    def get(path):
        connection = http.client.HTTPConnection('127.0.0.1', 18431, timeout=4)
        try:
            connection.request('GET', path, headers={'Authorization': 'Bearer ' + token.decode('ascii')})
            response = connection.getresponse()
            raw = response.read(MAX_LINE + 1)
            if response.status != 200 or len(raw) > MAX_LINE:
                raise ValueError('Read-only runner request failed')
            return json.loads(raw)
        finally:
            connection.close()

    pending, stopped = queue.Queue(maxsize=1), threading.Event()
    threading.Thread(target=read_commands, args=(sys.stdin, pending, stopped), daemon=True).start()
    selected, last_frame, cached_status = None, None, None
    next_listing = next_status = next_scene_status = 0
    scenes, scene_status, scene_key = [], None, None
    while not stopped.is_set():
        began = time.monotonic()
        try:
            try:
                requested = pending.get_nowait()
                if requested != selected:
                    selected, last_frame, cached_status, next_status = requested, None, None, 0
            except queue.Empty:
                pass
            if began >= next_listing:
                health = get('/health')
                runs = get('/runs')['runs']
                emit({'type': 'runs', 'runs': runs, 'runs_enabled': health['runs_enabled']})
                emit({'type': 'health', 'runner_available': True})
                next_listing = began + 2
            if began >= next_scene_status:
                scenes = get('/scenes')['scenes']
                scene_status = next((row for row in scenes if row.get('active')), scenes[0] if scenes else None)
                next_scene_status = began + 1
            if scene_status:
                scene_id = scene_status['scene_id']
                preview = get('/scenes/' + scene_id + '/frame')
                frame = preview.get('frame')
                if frame:
                    frame = dict(frame)
                    key = (scene_id, frame['frame_id'])
                    if key == scene_key:
                        frame.pop('image_base64', None)
                    scene_key = key
                emit({'type': 'scene', 'scenes': scenes, 'scene_id': scene_id, 'status': scene_status,
                      'frame': frame, 'available': preview['available'], 'mode': preview['mode'],
                      'frame_age_seconds': preview.get('frame_age_seconds')})
            else:
                emit({'type': 'scene', 'scenes': [], 'scene_id': None, 'status': None, 'frame': None})
            if selected:
                if began >= next_status or cached_status is None:
                    cached_status = get('/runs/' + selected)
                    cached_status['details'] = get('/runs/' + selected + '/details')
                    if not cached_status['active']:
                        result = get('/runs/' + selected + '/result')
                        video = next((a for a in result.get('artifacts', []) if a['path'] == 'episode/episode.mp4'), None)
                        cached_status['video_size_bytes'] = video['size_bytes'] if video else None
                    next_status = began + 1
                preview = get('/runs/' + selected + '/frame')
                frame = preview.get('frame')
                if frame:
                    frame = dict(frame)
                    key = (selected, frame['frame_id'])
                    if key == last_frame:
                        frame.pop('image_base64', None)
                    last_frame = key
                emit({'type': 'update', 'run_id': selected, 'status': cached_status,
                      'available': preview['available'], 'mode': preview['mode'],
                      'frame': frame, 'frame_age_seconds': preview.get('frame_age_seconds')})
        except (OSError, ValueError, KeyError, TypeError, http.client.HTTPException):
            emit({'type': 'health', 'runner_available': False, 'error': 'Runner unavailable; no task was started or stopped'})
            next_listing = 0
            stopped.wait(1)
        # Latest-only previews at 8 Hz; status/details at 1 Hz. Terminal/idle
        # watching is cheaper and never renders, steps, or starts a task.
        interval = .125 if ((cached_status and cached_status.get('active') is True)
                           or (scene_status and scene_status.get('status') == 'executing')) else .5
        stopped.wait(max(.01, interval - (time.monotonic() - began)))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except BrokenPipeError:
        pass  # Viewer disconnects never affect the executor.
