# 第三方来源与归属

本项目的集成代码不构成对第三方模型、数据集或框架的独立原创声明。使用范围及成员实际分工应由参赛团队如实填写。

| 组件 | 上游 | 本次代码版本 | 包内范围 |
|---|---|---|---|
| AtomicVLA | https://github.com/zhanglk9/AtomicVLA | `c3583055adde0a491a11ffe08c15ca6459a64254` | 筛选的源码、配置与原始 LICENSE / LICENSE_GEMMA.txt；不含权重 |
| InternW0-Delta | https://github.com/InternRobotics/InternW0-Delta | `90801baa3bdc7829c1e4989edfe3d0fb2410ea6a` | 筛选的源码、配置与原始 LICENSE；不含权重或视觉/文本骨干 |
| Agnes Harness | https://github.com/AgnesAI-Labs/agnes-harness | 本地依赖基础版本 `cde816b88c737b9fd04e7ef55b899e7b4cd55eb7` | 外部依赖，不复制完整框架；附 LICENSE、NOTICE 与网页视频 CSP 最小补丁 |
| LIBERO | https://github.com/Lifelong-Robot-Learning/LIBERO | 按各任务 `sources.json` 记录核对 | 外部仿真依赖；八个自定义派生任务、初始状态与阶段表随包 |

第三方源码快照按文件类型筛选，省略了 `.git`、大文件、二进制权重、演示图像等，不能代替官方完整模型发布。各目录原许可证决定使用和再分发条件；不要用集成插件的 MIT 声明覆盖第三方许可。AtomicVLA 使用的 Gemma 及两个模型的各骨干权重，还需遵守其独立条款。

原部署中的冻结模型标识：AtomicVLA 配置为 `Atomic_libero`，InternW0 为 `InternRobotics/InternW0-Delta-Libero`。这些名称及公开版本号是复现信息，不是账号或密钥。发布包没有提供任何训练/微调结果，也没有宣称自定义任务是官方基准。
