"""RoboTwin training-checkpoint evaluation."""
