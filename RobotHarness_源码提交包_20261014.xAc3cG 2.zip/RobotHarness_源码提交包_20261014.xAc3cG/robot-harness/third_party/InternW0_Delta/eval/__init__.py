"""Benchmark evaluation entry points."""
