# Robot Harness：Agnes 长程机器人执行组件

这是源码提交副本，不是正在运行的工作目录。已移除个人服务器地址、个人路径、GPU 标识和运行状态；不含任何实际 API key、SSH 密钥、令牌、模型权重或运行环境。

## 包含内容

- `harnesses/starHarness_Libero/`：可变长度阶段表、官方谓词检查、阶段推进、真实关节复位、连续录像、InternW0/AtomicVLA 策略适配器。
- `services/robot_runner/`：单执行位、异步运行、场景会话、幂等请求、结果与预览接口。
- `services/robot_viewer/`：SSH 预览桥与本地认证观看服务。
- `services/internw0_delta_resident/` 和 `services/atomicvla_resident/`：两个冻结 VLA 的服务桥接代码。
- `integrations/agnes_robot_control/` 和 `integrations/agnes_robot_viewer/`：Agnes 工具、实时面板、规划回执与授权执行。
- `benchmarks/custom_long/{same,mixed,same_perturb,mixed_perturb}/{five_stage,eight_stage}/`：八个自定义 LIBERO 派生任务及初始状态。这不是官方 LIBERO/Plus 测试集。
- `third_party/{InternW0_Delta,AtomicVLA}/`：固定版本的上游源码快照与原始许可证。训练权重不在包内。
- `patches/agnes-web-media.patch`：当前 Agnes 网页播放 Blob MP4 所需的最小 CSP 改动和对应测试。

## 真实能力与限制

大模型使用 Agnes 当前会话账号，在当前登记技能范围内选择并排序阶段；结构校验不等于证明规划可完成。默认文字规划，图像输入是可选项。执行前需要宿主授权。当前没有自动重新规划、无限重试或新技能生成。

阶段切换读取仿真谓词，因此不是纯视觉完成判断实验。历史阶段达成、当前条件、最终 `native_success` 独立保留；复位普通失败可记录后继续，但总预算、接口异常等保护不移除。

这个发布包没有启动任何真实机器人或新实验，也不包含尚未结束的批次结果。随包的静态/离线检查不是端到端任务成功证明。

## 部署约定

以下路径均为**示例路径**，需要部署者配置，不指向原服务器：

- 项目：`/opt/robot-harness`
- 标准 LIBERO 源码：`/opt/libero/repo`
- 仿真 Python：`/opt/libero/runtime/bin/python`
- 模型根目录：`/opt/vla/InternW0_Delta`、`/opt/vla/AtomicVLA`
- SSH 别名：`robot-gpu`（自行配置 HostName/User/IdentityFile，不要提交密钥）
- GPU：通过 `ROBOT_GPU` / `CUDA_VISIBLE_DEVICES` 显式选择。

必须分别准备 LIBERO、两个 VLA 的官方依赖和权重；依赖和许可证见 `THIRD_PARTY.md` 与各上游 `pyproject.toml`。不要把两个模型的 Python/JAX/PyTorch 环境混成一个共享环境。

`third_party/` 是无 `.git` 的源码快照。旧 `start.py` 含源代码/下载清单的现场核验，不能把缺失核验文件当成已验证后直接跳过。复现时可按固定版本克隆上游；或使用下述服务桥，在准备好依赖和权重后显式启动。启动服务会加载模型，占用 GPU，不会自动执行任务。

### AtomicVLA

官方 AtomicVLA 源码安装到其模型环境，冻结权重置于 `/opt/vla/AtomicVLA/weights/libero`：

```sh
CUDA_VISIBLE_DEVICES=0 /opt/vla/AtomicVLA/runtime/bin/python \
  /opt/robot-harness/services/atomicvla_resident/serve_resident.py \
  --candidate AtomicVLA --port 18321 --ready-file /tmp/atomic-ready.json
```

服务只监听本机回环地址；不要把裸模型服务暴露到公网。

### InternW0-Delta

官方源码放到 `/opt/vla/InternW0_Delta/repo`；权重与 T5/RynnBrain 等依赖按上游说明准备到 `weights/` 和 `backbones/`。用一个全新的私有服务目录：

```sh
CUDA_VISIBLE_DEVICES=1 /opt/vla/InternW0_Delta/runtime/bin/python \
  /opt/robot-harness/services/internw0_delta_resident/serve_resident.py \
  --service-dir /opt/vla/InternW0_Delta/resident
```

InternW0 使用预计算的**精确指令** T5 编码；不能只改 JSON 文本而沿用旧编码。可用 `harnesses/starHarness_Libero/prepare_intern_prompts.py` 在模型环境中离线准备。编码目录必须位于对应 candidate root 的 `runs/` 下。训练权重和指令编码都没有打包。

### 任务登记与运行服务

在准备好仿真环境和指令编码后，用 `tools/make_registry.py` 根据当前部署路径生成登记表，自动计算副本文件的哈希：

```sh
python3 tools/make_registry.py --project-root /opt/robot-harness \
  --libero-root /opt/libero --sim-python /opt/libero/runtime/bin/python \
  --intern-socket /opt/vla/InternW0_Delta/resident/policy.sock \
  --intern-manifest /opt/vla/InternW0_Delta/runs/prompts/prompt_manifest.json \
  --output /opt/robot-harness/services/robot_runner/registry.server.json
```

若只使用 AtomicVLA，可省略两个 `--intern-*` 参数。该脚本只生成配置，不连接模型、不执行仿真。

按 `services/robot_runner/README.md` 创建新的私有随机令牌并启动服务。默认不启用执行；获得实验授权后才添加 `--enable-runs`。令牌不得写进网页、代码、提示词或日志。

`services/robot_viewer/viewer_transport.py` 和控制插件的后端保留了受限 SSH 通道。发布副本的默认别名已改为 `robot-gpu`；解释器/桥接目录为示例路径，部署到其他位置时仅修改服务器端/本机后端配置，不能接受浏览器任意路径或命令。

### Agnes 接入

安装官方 Agnes Harness，应用 `patches/agnes-web-media.patch` 后按官方流程重新构建。将两个 `integrations/` 插件按正常 inspect/install/trust/enable 流程接入，保留权限检查。查看各插件 README。

在 Agnes 的 Models & accounts 中设置自己的模型账号。规划模块没有独立 API key；发布包不包含任何原账号配置。viewer 的本机配置为 `~/.config/robot-harness/agnes-viewer.json`，权限 0600，只存端口和私有目录路径；实际随机令牌由本机服务生成。

如果用于限制模型品牌的比赛，应使用允许的 Agnes 模型重新验证规划，并向主办方确认第三方 VLA 执行组件是否允许；包装成工具不自动满足模型限制。

## 提交包检查

```sh
python3 tools/check_package.py
```

该命令只核对文件哈希、JSON/Python 语法和明确的敏感数据模式，不加载模型或运行仿真。分享前仍需人工审查。`MANIFEST.json` 与 `PACKAGING_AUDIT.json` 记录了这次源码副本的范围和检查结果。
